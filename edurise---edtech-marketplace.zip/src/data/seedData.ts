import { Course, User, Review, Transaction, WithdrawalRequest } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_student_1',
    name: 'Aryan Patel',
    email: 'aryan.patel@example.com',
    role: 'student',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    title: 'Aspiring Full Stack Engineer & Data Enthusiast',
    joinedDate: 'January 2026',
    bio: 'CS Undergraduate passionate about building intelligent systems and competitive coding.'
  },
  {
    id: 'user_educator_1',
    name: 'Rahul Sharma',
    email: 'rahul.sharma@edurise.edu',
    role: 'educator',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    title: 'Ex-IITian, Senior Mathematics Faculty & JEE Mentor',
    subjects: ['Mathematics', 'Competitive Exams', 'Calculus', 'Linear Algebra'],
    experienceYears: 11,
    rating: 4.9,
    totalStudents: 18400,
    totalCourses: 4,
    isVerified: true,
    joinedDate: 'March 2024',
    followersCount: 14200,
    bio: 'Taught over 50,000 students online and offline. Helped 1,200+ crack top engineering institutions with visual problem-solving paradigms.',
    socialLinks: {
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com',
      twitter: 'https://twitter.com'
    }
  },
  {
    id: 'user_educator_2',
    name: 'Ananya Verma',
    email: 'ananya.verma@edurise.edu',
    role: 'educator',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    title: 'Staff Software Architect & Python Core Enthusiast',
    subjects: ['Programming', 'Web Development', 'Python', 'System Design'],
    experienceYears: 9,
    rating: 4.95,
    totalStudents: 24300,
    totalCourses: 5,
    isVerified: true,
    joinedDate: 'August 2024',
    followersCount: 22100,
    bio: 'Ex-FAANG engineer, passionate open source contributor, and educator simplifying complex software architecture through project-driven learning.',
    socialLinks: {
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com',
      website: 'https://ananyaverma.dev'
    }
  },
  {
    id: 'user_educator_3',
    name: 'Arjun Mehta',
    email: 'arjun.mehta@edurise.edu',
    role: 'educator',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    title: 'Experimental Physicist & National Olympiad Gold Medalist',
    subjects: ['Physics', 'Competitive Exams', 'Electrodynamics', 'Quantum Physics'],
    experienceYears: 8,
    rating: 4.88,
    totalStudents: 15600,
    totalCourses: 3,
    isVerified: true,
    joinedDate: 'January 2025',
    followersCount: 11800,
    bio: 'Master of intuitive physics visualizations. Turning abstract equations into crystal-clear mental models.',
    socialLinks: {
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com'
    }
  },
  {
    id: 'user_educator_4',
    name: 'Priya Singh',
    email: 'priya.singh@edurise.edu',
    role: 'educator',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    title: 'Lead AI Researcher & Kaggle Grandmaster',
    subjects: ['AI & Machine Learning', 'Data Science', 'Deep Learning', 'NLP'],
    experienceYears: 7,
    rating: 4.92,
    totalStudents: 19800,
    totalCourses: 3,
    isVerified: true,
    joinedDate: 'May 2024',
    followersCount: 17500,
    bio: 'Researching generative models and transformer architectures. Making modern AI accessible to every aspiring builder.',
    socialLinks: {
      youtube: 'https://youtube.com',
      linkedin: 'https://linkedin.com'
    }
  },
  {
    id: 'user_admin_1',
    name: 'Vikramaditya Sen',
    email: 'admin@edurise.edu',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    title: 'Head of Quality & Operations @ EduRise',
    joinedDate: 'January 2024',
    bio: 'Overseeing educator verification, pedagogical review, and ecosystem integrity.'
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course_python_bootcamp',
    title: 'Complete Python Masterclass: Zero to Production Hero',
    subtitle: 'Master modern Python 3.12, OOP, Data Structures, Web Scraping, APIs, and real-world backend architectures with 20+ hands-on projects.',
    description: `Welcome to the most comprehensive, modern, and production-tested Python course on EduRise. Whether you are writing your first line of code or leveling up your existing skillset, this curriculum has been meticulously designed with industry best practices.

You will go from fundamental syntax and data structures to building complex web scrapers, RESTful microservices, asynchronous background workers, and deploying containerized applications to cloud platforms.

Every module contains coding assignments, chapter quizzes, cheat-sheet PDFs, and free previews so you can learn with total confidence.`,
    educatorId: 'user_educator_2',
    educatorName: 'Ananya Verma',
    educatorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Staff Software Architect & Python Core Enthusiast',
    thumbnail: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    price: 1299,
    originalPrice: 4999,
    discountPercent: 74,
    category: 'Programming',
    level: 'All Levels',
    language: 'English',
    rating: 4.94,
    ratingCount: 3840,
    studentsCount: 14250,
    totalDuration: '32h 45m',
    totalLecturesCount: 42,
    isBestseller: true,
    isFeatured: true,
    status: 'published',
    whatYouWillLearn: [
      'Master Python syntax, list comprehensions, decorators, and generators',
      'Object-Oriented Programming (OOP) with clean architecture principles',
      'Asynchronous programming with asyncio and concurrent execution',
      'Build robust APIs with FastAPI and automated testing suites',
      'Database persistence with SQLAlchemy and PostgreSQL migrations',
      'Production debugging, profiling, and Docker deployment workflows'
    ],
    requirements: [
      'A computer (Windows, macOS, or Linux) with internet access',
      'Zero prior programming experience required — we start from absolute basics!'
    ],
    chapters: [
      {
        id: 'ch_py_1',
        title: 'Chapter 1: Python Fundamentals & Environment Setup',
        description: 'Get your IDE configured, learn core syntax, variables, and operator precedence.',
        lectures: [
          {
            id: 'lec_py_1_1',
            title: '1.1 Welcome to Python & Course Roadmap',
            duration: '08:40',
            durationSeconds: 520,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            videoType: 'mp4',
            description: 'Introduction to Python ecosystem, compiler vs interpreter mental models, and what you will build.',
            isFreePreview: true,
            resources: [
              { id: 'res_1', title: 'Python 3.12 Installation Guide.pdf', type: 'pdf', url: '#', size: '1.4 MB' },
              { id: 'res_2', title: 'Curriculum Roadmap & CheatSheet.pdf', type: 'pdf', url: '#', size: '2.8 MB' }
            ],
            summary: 'A high-level overview of modern Python applications, setup walkthroughs for VS Code, and understanding the execution cycle.'
          },
          {
            id: 'lec_py_1_2',
            title: '1.2 Variables, Data Types & Dynamic Typing',
            duration: '14:20',
            durationSeconds: 860,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            videoType: 'mp4',
            description: 'Deep dive into integers, floats, strings, booleans, type casting, and Python memory reference model.',
            isFreePreview: true,
            quiz: {
              id: 'quiz_py_1_2',
              title: 'Variables & Types Checkpoint',
              passingScore: 75,
              questions: [
                {
                  id: 'q1',
                  question: 'What is the output of `type(3.14)` in Python?',
                  options: ['<class "int">', '<class "float">', '<class "double">', '<class "number">'],
                  correctAnswerIndex: 1,
                  explanation: 'Python represents decimal numbers as floating-point objects of type `float`.'
                },
                {
                  id: 'q2',
                  question: 'Which of the following is an immutable data type in Python?',
                  options: ['List', 'Dictionary', 'Tuple', 'Set'],
                  correctAnswerIndex: 2,
                  explanation: 'Tuples are immutable sequence types in Python; their elements cannot be modified once created.'
                }
              ]
            }
          },
          {
            id: 'lec_py_1_3',
            title: '1.3 Operators, Expressions & String Formatting',
            duration: '16:15',
            durationSeconds: 975,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            videoType: 'mp4',
            description: 'Arithmetic, logical, bitwise operators, and f-strings mastering.',
            isFreePreview: false
          }
        ]
      },
      {
        id: 'ch_py_2',
        title: 'Chapter 2: Control Flow & Algorithmic Logic',
        description: 'Conditionals, for/while loops, break/continue statements, and pattern matching.',
        lectures: [
          {
            id: 'lec_py_2_1',
            title: '2.1 Conditional Branching & Match-Case Statements',
            duration: '12:30',
            durationSeconds: 750,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
            videoType: 'mp4',
            description: 'Master if-elif-else ladders and structural pattern matching introduced in Python 3.10+.',
            isFreePreview: false
          },
          {
            id: 'lec_py_2_2',
            title: '2.2 For Loops, Iterables & The Range Function',
            duration: '18:45',
            durationSeconds: 1125,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
            videoType: 'mp4',
            description: 'Looping through sequences, nested iterations, and enumerate/zip utilities.',
            isFreePreview: false
          },
          {
            id: 'lec_py_2_3',
            title: '2.3 While Loops & Infinite Loop Prevention',
            duration: '11:10',
            durationSeconds: 670,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
            videoType: 'mp4',
            description: 'Loop condition guarantees, sentinel values, and loop invariants.',
            isFreePreview: false
          }
        ]
      },
      {
        id: 'ch_py_3',
        title: 'Chapter 3: Functions, Scopes & Modular Design',
        description: 'Writing reusable, pure functions, docstrings, type annotations, and packaging.',
        lectures: [
          {
            id: 'lec_py_3_1',
            title: '3.1 Defining Functions, Arguments & *args/**kwargs',
            duration: '21:00',
            durationSeconds: 1260,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
            videoType: 'mp4',
            description: 'Positional arguments, keyword-only args, default values, and variable-length parameter handling.',
            isFreePreview: false
          },
          {
            id: 'lec_py_3_2',
            title: '3.2 First-Class Functions, Closures & Decorators',
            duration: '24:15',
            durationSeconds: 1455,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
            videoType: 'mp4',
            description: 'Unlock one of Python’s superpower design patterns with custom memoization and logging decorators.',
            isFreePreview: false
          }
        ]
      }
    ],
    createdAt: '2025-09-15',
    updatedAt: '2026-02-10'
  },
  {
    id: 'course_dsa_java',
    title: 'Data Structures & Algorithms: The Ace Interview Guide',
    subtitle: 'From Arrays and Linked Lists to Dynamic Programming, Graphs, and Segment Trees. 300+ LeetCode problems decoded step-by-step.',
    description: `Designed specifically for software engineers preparing for Tier-1 product tech interviews. This course breaks down algorithmic intuition into structured patterns so you can solve unseen problems with ease.

Each topic begins with memory visualization, dry runs on whiteboard diagrams, time & space complexity analysis, and optimal implementations with clean code.`,
    educatorId: 'user_educator_2',
    educatorName: 'Ananya Verma',
    educatorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Staff Software Architect & Python Core Enthusiast',
    thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    price: 1799,
    originalPrice: 5999,
    discountPercent: 70,
    category: 'Programming',
    level: 'Intermediate',
    language: 'Hinglish',
    rating: 4.96,
    ratingCount: 4210,
    studentsCount: 18900,
    totalDuration: '48h 10m',
    totalLecturesCount: 65,
    isBestseller: true,
    isFeatured: true,
    status: 'published',
    whatYouWillLearn: [
      'Master asymptotic Big-O analysis and mathematical recurrence relations',
      'Implement custom Trees, Heaps, Disjoint Sets, and Trie data structures',
      'Conquer Dynamic Programming: 1D, 2D, Knapsack, Digit DP, Bitmask DP',
      'Graph Theory: BFS, DFS, Dijkstra, Bellman-Ford, Floyd-Warshall, Tarjan',
      'Two-Pointers, Sliding Window, and Monotonic Stack patterns'
    ],
    requirements: [
      'Basic programming syntax in any language (Java, C++, or Python)'
    ],
    chapters: [
      {
        id: 'ch_dsa_1',
        title: 'Chapter 1: Time & Space Complexity Masterclass',
        lectures: [
          {
            id: 'lec_dsa_1_1',
            title: '1.1 Asymptotic Notations & Master Theorem',
            duration: '18:20',
            durationSeconds: 1100,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            videoType: 'mp4',
            description: 'Deconstruct Big-O, Big-Omega, Big-Theta, and solving divide-and-conquer recurrences.',
            isFreePreview: true,
            summary: 'Understanding lower and upper bounds of algorithmic efficiency with asymptotic rigor.'
          },
          {
            id: 'lec_dsa_1_2',
            title: '1.2 Memory Layout & CPU Cache Locality',
            duration: '15:10',
            durationSeconds: 910,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            videoType: 'mp4',
            description: 'Why contiguous array allocations beat linked lists in real hardware cache hits.',
            isFreePreview: false
          }
        ]
      }
    ],
    createdAt: '2025-10-01',
    updatedAt: '2026-02-15'
  },
  {
    id: 'course_jee_physics',
    title: 'JEE Advanced Physics: Mechanics & Electrodynamics Masterclass',
    subtitle: 'Master the toughest concepts in Mechanics, Rotational Motion, Electromagnetism, and Modern Physics with intuitive visual problem solving.',
    description: `Crafted specifically for serious aspirants targeting top ranks in competitive examinations. Taught by Arjun Mehta (Olympiad Gold Medalist), this course builds deep fundamental intuition rather than rote memorization.`,
    educatorId: 'user_educator_3',
    educatorName: 'Arjun Mehta',
    educatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Experimental Physicist & National Olympiad Gold Medalist',
    thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    price: 1999,
    originalPrice: 6499,
    discountPercent: 69,
    category: 'Physics',
    level: 'Advanced',
    language: 'Hindi',
    rating: 4.91,
    ratingCount: 2950,
    studentsCount: 11200,
    totalDuration: '54h 30m',
    totalLecturesCount: 58,
    isBestseller: true,
    isFeatured: true,
    status: 'published',
    whatYouWillLearn: [
      'Master Kinematics & Relative Motion in 2D/3D frames of reference',
      'Rotational Dynamics & Instantaneous Center of Zero Velocity',
      'Maxwell’s Equations, Biot-Savart Law, and Electromagnetic Induction',
      'Wave Optics, Wave-Particle Duality, and Nuclear Physics problem patterns'
    ],
    requirements: [
      'Class 11/12 Physics and high school algebra/calculus fundamentals'
    ],
    chapters: [
      {
        id: 'ch_phys_1',
        title: 'Chapter 1: Vectors, Calculus & Relative Kinematics',
        lectures: [
          {
            id: 'lec_phys_1_1',
            title: '1.1 Geometric Interpretation of River-Boat & Rain-Man Problems',
            duration: '22:15',
            durationSeconds: 1335,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
            videoType: 'mp4',
            description: 'Solving multi-dimensional relative velocity problems with visual vector triangles.',
            isFreePreview: true,
            resources: [
              { id: 'res_phys_1', title: 'Relative Kinematics Practice Sheet (Advanced).pdf', type: 'pdf', url: '#', size: '3.1 MB' }
            ]
          }
        ]
      }
    ],
    createdAt: '2025-11-12',
    updatedAt: '2026-01-20'
  },
  {
    id: 'course_ai_ml_deep_dive',
    title: 'AI & Machine Learning: Foundations to LLMs & GenAI',
    subtitle: 'From Linear Algebra, Neural Networks, PyTorch, CNNs, Transformers, to fine-tuning modern LLMs and building RAG pipelines.',
    description: `A state-of-the-art machine learning curriculum designed by Kaggle Grandmaster Priya Singh. Learn the mathematical rigor under the hood and train real production models with PyTorch, Hugging Face, and LangChain.`,
    educatorId: 'user_educator_4',
    educatorName: 'Priya Singh',
    educatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Lead AI Researcher & Kaggle Grandmaster',
    thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    price: 2499,
    originalPrice: 7999,
    discountPercent: 68,
    category: 'AI & Machine Learning',
    level: 'Intermediate',
    language: 'English',
    rating: 4.97,
    ratingCount: 3120,
    studentsCount: 13500,
    totalDuration: '44h 15m',
    totalLecturesCount: 48,
    isBestseller: true,
    isFeatured: true,
    status: 'published',
    whatYouWillLearn: [
      'Build Neural Networks from scratch with backpropagation matrix calculus',
      'Computer Vision with Convolutional Networks & Vision Transformers (ViT)',
      'Natural Language Processing with BERT, GPT, and Self-Attention mechanisms',
      'Train, fine-tune LoRA/QLoRA adapters and build enterprise RAG applications'
    ],
    requirements: [
      'Basic Python knowledge and high school linear algebra/calculus'
    ],
    chapters: [
      {
        id: 'ch_ai_1',
        title: 'Chapter 1: Mathematical Foundations for ML',
        lectures: [
          {
            id: 'lec_ai_1_1',
            title: '1.1 Tensors, Matrix Operations & Gradient Descent Visualized',
            duration: '19:40',
            durationSeconds: 1180,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
            videoType: 'mp4',
            description: 'Why convex optimization and stochastic gradients drive modern deep learning.',
            isFreePreview: true
          }
        ]
      }
    ],
    createdAt: '2025-08-20',
    updatedAt: '2026-02-18'
  },
  {
    id: 'course_fullstack_web',
    title: 'Full Stack Web Development: React, Node, Next.js & Cloud',
    subtitle: 'Build production-ready, ultra-fast modern web applications with React 19, Next.js App Router, TypeScript, Tailwind CSS, PostgreSQL, and AWS.',
    description: `Everything you need to become a high-impact, employable full-stack software engineer in 2026. You'll build 6 commercial-grade full-stack apps from scratch.`,
    educatorId: 'user_educator_2',
    educatorName: 'Ananya Verma',
    educatorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Staff Software Architect & Python Core Enthusiast',
    thumbnail: 'https://images.unsplash.com/photo-1581291518655-9523c932edcf?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    price: 1499,
    originalPrice: 4999,
    discountPercent: 70,
    category: 'Web Development',
    level: 'All Levels',
    language: 'English',
    rating: 4.93,
    ratingCount: 5200,
    studentsCount: 21400,
    totalDuration: '52h 00m',
    totalLecturesCount: 60,
    isBestseller: true,
    isFeatured: true,
    status: 'published',
    whatYouWillLearn: [
      'Master modern TypeScript, React hooks, Server Components, and state architecture',
      'Build REST & GraphQL APIs with Express, NestJS, and Prisma ORM',
      'JWT Authentication, OAuth 2.0, WebSockets, and Redis caching',
      'Deploy CI/CD pipelines to AWS with Docker, Nginx, and SSL encryption'
    ],
    requirements: [
      'No web development experience needed. HTML/CSS basics helpful.'
    ],
    chapters: [
      {
        id: 'ch_fs_1',
        title: 'Chapter 1: Modern JavaScript & TypeScript Foundations',
        lectures: [
          {
            id: 'lec_fs_1_1',
            title: '1.1 ES6+ Features, Async/Await & Event Loop',
            duration: '16:50',
            durationSeconds: 1010,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
            videoType: 'mp4',
            description: 'Understanding microtasks, macrotasks, and promise resolution under the hood.',
            isFreePreview: true
          }
        ]
      }
    ],
    createdAt: '2025-07-10',
    updatedAt: '2026-02-01'
  },
  {
    id: 'course_math_competitive',
    title: 'Mathematics for Competitive Exams & Higher Olympiads',
    subtitle: 'Calculus, Number Theory, Combinatorics, and Coordinate Geometry explained with intuitive visual proofs and shortcut algorithms.',
    description: `Rahul Sharma's flagship mathematics course covering high-yield problem solving frameworks for JEE, ISI, CMI, and National Olympiads.`,
    educatorId: 'user_educator_1',
    educatorName: 'Rahul Sharma',
    educatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Ex-IITian, Senior Mathematics Faculty & JEE Mentor',
    thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    price: 1599,
    originalPrice: 4499,
    discountPercent: 64,
    category: 'Mathematics',
    level: 'Advanced',
    language: 'Hinglish',
    rating: 4.95,
    ratingCount: 3600,
    studentsCount: 14800,
    totalDuration: '38h 20m',
    totalLecturesCount: 45,
    isBestseller: true,
    isFeatured: false,
    status: 'published',
    whatYouWillLearn: [
      'Calculus: Limits, Continuity, Differentiability, Definite Integrals',
      'Coordinate Geometry: Conic Sections, Tangents, Normals & Locus',
      'Algebra: Complex Numbers, Matrices, Determinants, Probability'
    ],
    requirements: [
      'Basic 10th grade algebra and trigonometry'
    ],
    chapters: [
      {
        id: 'ch_math_1',
        title: 'Chapter 1: Limits, Continuity & L\'Hôpital Frameworks',
        lectures: [
          {
            id: 'lec_math_1_1',
            title: '1.1 Evaluating Indeterminate Forms with Taylor Series Expansion',
            duration: '20:30',
            durationSeconds: 1230,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            videoType: 'mp4',
            description: 'Why series expansions beat standard L\'Hôpital rule for complex olympiad limits.',
            isFreePreview: true
          }
        ]
      }
    ],
    createdAt: '2025-06-15',
    updatedAt: '2026-01-14'
  },
  {
    id: 'course_chem_organic',
    title: 'Organic Chemistry Masterclass: Mechanisms & Syntheses',
    subtitle: 'Deconstruct reaction mechanisms, SN1/SN2/E1/E2, named reactions, and retrosynthesis with 3D molecular mental models.',
    description: `Master organic chemistry with zero stress. Learn how electron movement and orbital overlap predict reaction outcomes consistently.`,
    educatorId: 'user_educator_1',
    educatorName: 'Rahul Sharma',
    educatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Ex-IITian, Senior Mathematics Faculty & JEE Mentor',
    thumbnail: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    price: 999,
    originalPrice: 2999,
    discountPercent: 66,
    category: 'Chemistry',
    level: 'Intermediate',
    language: 'Hindi',
    rating: 4.88,
    ratingCount: 1840,
    studentsCount: 7600,
    totalDuration: '28h 40m',
    totalLecturesCount: 36,
    isBestseller: false,
    isFeatured: false,
    status: 'published',
    whatYouWillLearn: [
      'Master curved arrow notation and electron resonance stability',
      'Nucleophilic substitutions, Eliminations, Electrophilic Aromatic Substitution',
      'Carbonyl compounds, Grignard reagents, Aldol & Cannizzaro condensations'
    ],
    requirements: ['High school general chemistry fundamentals'],
    chapters: [
      {
        id: 'ch_chem_1',
        title: 'Chapter 1: Electronic Displacement Effects',
        lectures: [
          {
            id: 'lec_chem_1_1',
            title: '1.1 Inductive, Mesomeric, Hyperconjugation & Aromaticity',
            duration: '17:15',
            durationSeconds: 1035,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            videoType: 'mp4',
            description: 'Determine relative stability of carbocations, carbanions, and free radicals.',
            isFreePreview: true
          }
        ]
      }
    ],
    createdAt: '2025-05-10',
    updatedAt: '2025-12-10'
  },
  {
    id: 'course_ui_ux_design',
    title: 'Product Design & UI/UX Masterclass: Figma to Systems',
    subtitle: 'User research, wireframing, high-fidelity UI design, design systems, micro-interactions, and developer handoff in Figma.',
    description: `Build delightful, accessible digital interfaces that users love. A practical, portfolio-building bootcamp for aspiring product designers.`,
    educatorId: 'user_educator_4',
    educatorName: 'Priya Singh',
    educatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Lead AI Researcher & Kaggle Grandmaster',
    thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    price: 1199,
    originalPrice: 3999,
    discountPercent: 70,
    category: 'Design',
    level: 'Beginner',
    language: 'English',
    rating: 4.89,
    ratingCount: 1620,
    studentsCount: 6400,
    totalDuration: '24h 15m',
    totalLecturesCount: 30,
    isBestseller: false,
    isFeatured: false,
    status: 'published',
    whatYouWillLearn: [
      'Master Figma Auto-layout, components, variants, and design tokens',
      'Information architecture, user personas, journey mapping, and usability testing',
      'Typography hierarchy, mathematical spacing, and WCAG contrast compliance'
    ],
    requirements: ['No prior design experience needed. A free Figma account.'],
    chapters: [
      {
        id: 'ch_des_1',
        title: 'Chapter 1: Design Thinking & Visual Foundations',
        lectures: [
          {
            id: 'lec_des_1_1',
            title: '1.1 Visual Hierarchy, Color Theory & Spacing Rhythms',
            duration: '15:40',
            durationSeconds: 940,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
            videoType: 'mp4',
            description: 'Why spacing and typography define modern premium SaaS products.',
            isFreePreview: true
          }
        ]
      }
    ],
    createdAt: '2025-04-12',
    updatedAt: '2025-11-20'
  },
  {
    id: 'course_pending_sample',
    title: 'Quantum Computing for Beginners: Qubits & Qiskit',
    subtitle: 'Explore quantum superposition, entanglement, quantum gates, and execute real quantum circuits using IBM Qiskit SDK.',
    description: `A futuristic introductory course awaiting administrator review before going public. Demonstrates the EduRise educator submission and approval workflow.`,
    educatorId: 'user_educator_3',
    educatorName: 'Arjun Mehta',
    educatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    educatorTitle: 'Experimental Physicist & National Olympiad Gold Medalist',
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&auto=format&fit=crop&q=80',
    previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    price: 1899,
    originalPrice: 4999,
    discountPercent: 62,
    category: 'Physics',
    level: 'Advanced',
    language: 'English',
    rating: 5.0,
    ratingCount: 0,
    studentsCount: 0,
    totalDuration: '18h 00m',
    totalLecturesCount: 22,
    isBestseller: false,
    isFeatured: false,
    status: 'pending_approval',
    whatYouWillLearn: [
      'Understand Bloch Sphere, Quantum Superposition and Bell States',
      'Implement Deutsch-Jozsa and Grover\'s search algorithm in Qiskit'
    ],
    requirements: ['Basic linear algebra (matrices and vectors)'],
    chapters: [
      {
        id: 'ch_qc_1',
        title: 'Chapter 1: The Quantum State',
        lectures: [
          {
            id: 'lec_qc_1_1',
            title: '1.1 Qubits vs Classical Bits',
            duration: '14:20',
            durationSeconds: 860,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            videoType: 'mp4',
            description: 'Superposition visualized in Hilbert space.',
            isFreePreview: true
          }
        ]
      }
    ],
    createdAt: '2026-02-28',
    updatedAt: '2026-02-28'
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev_1',
    courseId: 'course_python_bootcamp',
    userId: 'user_student_1',
    userName: 'Aryan Patel',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'Ananya ma\'am is simply exceptional! Her explanations of decorators and async event loops made concepts click that I struggled with for months. Highly recommend!',
    date: '2 weeks ago',
    helpfulCount: 42
  },
  {
    id: 'rev_2',
    courseId: 'course_python_bootcamp',
    userId: 'user_rev_2',
    userName: 'Rohit Deshmukh',
    userAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'The project-based approach with FastAPI and PostgreSQL helped me land my first software internship. The AI Tutor button on each lecture is a game changer for instant doubts.',
    date: '1 month ago',
    helpfulCount: 29
  },
  {
    id: 'rev_3',
    courseId: 'course_dsa_java',
    userId: 'user_rev_3',
    userName: 'Tanvi Saxena',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'Best DSA course hands down. The dynamic programming pattern breakdown removed all my fear of hard LeetCode problems.',
    date: '3 weeks ago',
    helpfulCount: 56
  },
  {
    id: 'rev_4',
    courseId: 'course_jee_physics',
    userId: 'user_rev_4',
    userName: 'Siddharth Roy',
    userAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    rating: 5,
    comment: 'Arjun sir’s visual diagrams for rotational motion and electrodynamics are pure genius. Solved Irodov problems in minutes!',
    date: '1 month ago',
    helpfulCount: 38
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx_10842',
    userId: 'user_student_1',
    userName: 'Aryan Patel',
    userEmail: 'aryan.patel@example.com',
    courseId: 'course_python_bootcamp',
    courseTitle: 'Complete Python Masterclass: Zero to Production Hero',
    educatorId: 'user_educator_2',
    educatorName: 'Ananya Verma',
    amount: 1299,
    discountAmount: 200,
    taxAmount: 198,
    totalAmount: 1297,
    platformFeeAmount: 260,
    educatorEarningAmount: 1037,
    paymentMethod: 'UPI',
    paymentId: 'pay_UPI_98327491',
    status: 'SUCCESS',
    createdAt: '2026-02-14 14:32'
  },
  {
    id: 'tx_10841',
    userId: 'user_rev_2',
    userName: 'Rohit Deshmukh',
    userEmail: 'rohit.d@example.com',
    courseId: 'course_dsa_java',
    courseTitle: 'Data Structures & Algorithms: The Ace Interview Guide',
    educatorId: 'user_educator_2',
    educatorName: 'Ananya Verma',
    amount: 1799,
    discountAmount: 0,
    taxAmount: 324,
    totalAmount: 2123,
    platformFeeAmount: 425,
    educatorEarningAmount: 1698,
    paymentMethod: 'Card',
    paymentId: 'pay_CRD_11029384',
    status: 'SUCCESS',
    createdAt: '2026-02-18 10:15'
  },
  {
    id: 'tx_10840',
    userId: 'user_rev_3',
    userName: 'Tanvi Saxena',
    userEmail: 'tanvi.s@example.com',
    courseId: 'course_ai_ml_deep_dive',
    courseTitle: 'AI & Machine Learning: Foundations to LLMs & GenAI',
    educatorId: 'user_educator_4',
    educatorName: 'Priya Singh',
    amount: 2499,
    discountAmount: 500,
    taxAmount: 360,
    totalAmount: 2359,
    platformFeeAmount: 472,
    educatorEarningAmount: 1887,
    paymentMethod: 'Netbanking',
    paymentId: 'pay_NBK_77612309',
    status: 'SUCCESS',
    createdAt: '2026-02-21 18:40'
  }
];

export const INITIAL_WITHDRAWALS: WithdrawalRequest[] = [
  {
    id: 'wdr_101',
    educatorId: 'user_educator_2',
    educatorName: 'Ananya Verma',
    amount: 25000,
    status: 'PROCESSED',
    method: 'Bank Transfer',
    accountDetails: 'HDFC Bank - A/C ending in 4912 (IFSC: HDFC0001234)',
    requestedAt: '2026-02-01',
    processedAt: '2026-02-02'
  },
  {
    id: 'wdr_102',
    educatorId: 'user_educator_1',
    educatorName: 'Rahul Sharma',
    amount: 18500,
    status: 'PROCESSED',
    method: 'UPI',
    accountDetails: 'rahul.sharma@okhdfcbank',
    requestedAt: '2026-02-15',
    processedAt: '2026-02-16'
  }
];

export const COURSE_CATEGORIES = [
  { name: 'Programming', icon: 'Code', count: 248, desc: 'Python, Java, C++, Go & Rust' },
  { name: 'AI & Machine Learning', icon: 'BrainCircuit', count: 186, desc: 'LLMs, PyTorch, Deep Learning & Vision' },
  { name: 'Data Science', icon: 'BarChart3', count: 142, desc: 'Pandas, SQL, PowerBI & Statistics' },
  { name: 'Web Development', icon: 'Globe', count: 310, desc: 'React, Next.js, Node, Cloud & DevOps' },
  { name: 'Mathematics', icon: 'Divide', count: 195, desc: 'Calculus, Algebra, Olympiad & JEE' },
  { name: 'Physics', icon: 'Atom', count: 160, desc: 'Mechanics, Electrodynamics & Quantum' },
  { name: 'Chemistry', icon: 'FlaskConical', count: 130, desc: 'Organic, Inorganic & Physical Chemistry' },
  { name: 'Biology', icon: 'Dna', count: 110, desc: 'Genetics, Physiology & NEET Prep' },
  { name: 'Competitive Exams', icon: 'Award', count: 220, desc: 'JEE, NEET, GATE, UPSC & Olympiads' },
  { name: 'Business', icon: 'Briefcase', count: 125, desc: 'Finance, Product Management & Startups' },
  { name: 'Design', icon: 'Palette', count: 155, desc: 'UI/UX, Figma, Systems & Motion' },
  { name: 'Personal Development', icon: 'Sparkles', count: 90, desc: 'Communication, Productivity & Focus' }
] as const;
