export type UserRole = 'student' | 'educator' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  bio?: string;
  title?: string;
  subjects?: string[];
  experienceYears?: number;
  rating?: number;
  totalStudents?: number;
  totalCourses?: number;
  isVerified?: boolean;
  joinedDate: string;
  followersCount?: number;
  isFollowed?: boolean;
  socialLinks?: {
    twitter?: string;
    linkedin?: string;
    youtube?: string;
    website?: string;
  };
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  description?: string;
  questions: QuizQuestion[];
  passingScore: number; // percentage e.g. 70
  timeLimitMinutes?: number;
}

export interface ResourceFile {
  id: string;
  title: string;
  type: 'pdf' | 'code' | 'archive' | 'link';
  url: string;
  size?: string;
}

export interface Lecture {
  id: string;
  title: string;
  duration: string; // e.g. "12:45"
  durationSeconds: number;
  videoUrl: string;
  videoType: 'mp4' | 'youtube' | 'canvas';
  description: string;
  isFreePreview: boolean;
  resources?: ResourceFile[];
  quiz?: Quiz;
  summary?: string;
}

export interface Chapter {
  id: string;
  title: string;
  description?: string;
  lectures: Lecture[];
}

export type CourseLevel = 'All Levels' | 'Beginner' | 'Intermediate' | 'Advanced';
export type CourseCategory = 
  | 'Programming'
  | 'AI & Machine Learning'
  | 'Data Science'
  | 'Web Development'
  | 'Mathematics'
  | 'Physics'
  | 'Chemistry'
  | 'Biology'
  | 'Competitive Exams'
  | 'Business'
  | 'Design'
  | 'Personal Development';

export type CourseStatus = 'published' | 'pending_approval' | 'draft' | 'rejected';

export interface Review {
  id: string;
  courseId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  rating: number; // 1-5
  comment: string;
  date: string;
  helpfulCount: number;
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  educatorId: string;
  educatorName: string;
  educatorAvatar: string;
  educatorTitle: string;
  thumbnail: string;
  previewVideoUrl: string;
  price: number; // in INR
  originalPrice: number;
  discountPercent: number;
  category: CourseCategory;
  level: CourseLevel;
  language: string; // e.g. "English", "Hinglish", "Hindi"
  rating: number;
  ratingCount: number;
  studentsCount: number;
  totalDuration: string;
  totalLecturesCount: number;
  isBestseller?: boolean;
  isFeatured?: boolean;
  status: CourseStatus;
  adminFeedback?: string;
  whatYouWillLearn: string[];
  requirements: string[];
  chapters: Chapter[];
  createdAt: string;
  updatedAt: string;
}

export interface Note {
  id: string;
  userId: string;
  courseId: string;
  lectureId: string;
  timestamp: string; // e.g. "04:32"
  content: string;
  createdAt: string;
}

export interface DiscussionMessage {
  id: string;
  courseId: string;
  lectureId?: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userRole: UserRole;
  title?: string;
  content: string;
  createdAt: string;
  replies?: DiscussionMessage[];
  upvotes: number;
}

export interface Enrollment {
  courseId: string;
  userId: string;
  enrolledAt: string;
  progressPercent: number;
  completedLectureIds: string[];
  lastPlayedLectureId?: string;
  isCompleted: boolean;
  completedAt?: string;
  certificateId?: string;
  quizScores?: Record<string, number>; // quizId -> percentage
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  courseId: string;
  courseTitle: string;
  educatorId: string;
  educatorName: string;
  amount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  platformFeeAmount: number;
  educatorEarningAmount: number;
  paymentMethod: 'UPI' | 'Card' | 'Netbanking' | 'Wallet';
  paymentId: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  createdAt: string;
}

export interface WithdrawalRequest {
  id: string;
  educatorId: string;
  educatorName: string;
  amount: number;
  status: 'PENDING' | 'PROCESSED' | 'REJECTED';
  method: 'UPI' | 'Bank Transfer';
  accountDetails: string;
  requestedAt: string;
  processedAt?: string;
}

export interface StudyPlanItem {
  week: number;
  title: string;
  focusTopics: string[];
  estimatedHours: number;
  tasks: string[];
}

export interface StudyPlan {
  id: string;
  goal: string;
  availableHoursPerWeek: number;
  targetDate: string;
  courseTitle: string;
  schedule: StudyPlanItem[];
  createdAt: string;
}

export interface VideoUploadTask {
  id: string;
  file: File | { name: string; size: number };
  courseId: string;
  chapterId: string;
  lectureTitle: string;
  description: string;
  isFreePreview: boolean;
  progress: number;
  status: 'uploading' | 'processing' | 'ready' | 'published' | 'failed';
  videoUrl?: string;
  thumbnailUrl?: string;
  duration?: string;
}
