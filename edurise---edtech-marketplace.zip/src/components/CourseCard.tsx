import React from 'react';
import { Course } from '../types';
import { useApp } from '../context/AppContext';
import { Star, Clock, Users, Play, Heart, ShoppingBag, Check } from 'lucide-react';

interface CourseCardProps {
  course: Course;
  layout?: 'grid' | 'horizontal';
}

export const CourseCard: React.FC<CourseCardProps> = ({ course, layout = 'grid' }) => {
  const {
    navigateTo,
    isInWishlist,
    toggleWishlist,
    isInCart,
    addToCart,
    isEnrolled,
    openPaymentModal
  } = useApp();

  const enrolled = isEnrolled(course.id);
  const inCart = isInCart(course.id);
  const inWishlist = isInWishlist(course.id);

  if (layout === 'horizontal') {
    return (
      <div className="group bg-white rounded-2xl border border-slate-200/80 hover:border-indigo-300 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col sm:flex-row overflow-hidden">
        {/* Thumbnail */}
        <div
          onClick={() => navigateTo('course-detail', course.id)}
          className="relative sm:w-64 h-44 sm:h-auto overflow-hidden bg-slate-900 cursor-pointer shrink-0"
        >
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent"></div>
          
          {course.isBestseller && (
            <span className="absolute top-3 left-3 bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full shadow-md">
              Bestseller
            </span>
          )}

          <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white text-xs font-medium bg-black/50 px-2 py-0.5 rounded-md backdrop-blur-xs">
            <Play className="w-3 h-3 fill-white" />
            <span>Preview</span>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700">
                {course.category}
              </span>
              <span className="text-xs font-medium text-slate-600">{course.level}</span>
            </div>

            <h3
              onClick={() => navigateTo('course-detail', course.id)}
              className="text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-2 cursor-pointer"
            >
              {course.title}
            </h3>

            <p className="text-xs text-slate-600 line-clamp-2 mt-1.5">
              {course.subtitle}
            </p>

            <div className="flex items-center gap-2 mt-3">
              <img
                src={course.educatorAvatar}
                alt={course.educatorName}
                className="w-5 h-5 rounded-full object-cover"
              />
              <span
                onClick={() => navigateTo('educator-profile', undefined, undefined, course.educatorId)}
                className="text-xs text-slate-700 font-medium hover:text-indigo-600 cursor-pointer"
              >
                {course.educatorName}
              </span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-1 text-amber-500 font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{course.rating}</span>
                <span className="text-slate-600 font-normal">({course.ratingCount.toLocaleString()})</span>
              </div>
              <span>&bull;</span>
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-600" />
                <span>{course.totalDuration}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-lg font-black text-slate-900">₹{course.price}</span>
                {course.originalPrice > course.price && (
                  <span className="text-xs text-slate-600 line-through ml-1.5 font-medium">
                    ₹{course.originalPrice}
                  </span>
                )}
              </div>

              {enrolled ? (
                <button
                  onClick={() => navigateTo('player', course.id)}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Resume
                </button>
              ) : (
                <button
                  onClick={() => openPaymentModal(course)}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Enroll Now
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/90 hover:border-indigo-300 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden">
      
      {/* Card Thumbnail */}
      <div className="relative aspect-16/10 overflow-hidden bg-slate-900">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 cursor-pointer"
          onClick={() => navigateTo('course-detail', course.id)}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none"></div>

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {course.isBestseller && (
              <span className="bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full shadow-md">
                Bestseller
              </span>
            )}
            <span className="bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-semibold px-2 py-0.5 rounded-md">
              {course.level}
            </span>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleWishlist(course.id);
            }}
            className={`p-1.5 rounded-full backdrop-blur-md transition-transform active:scale-90 cursor-pointer ${
              inWishlist
                ? 'bg-rose-500 text-white'
                : 'bg-black/40 text-white hover:bg-black/70'
            }`}
            title="Save to Wishlist"
          >
            <Heart className={`w-4 h-4 ${inWishlist ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Category Pill on bottom */}
        <div className="absolute bottom-3 left-3">
          <span className="bg-white/90 backdrop-blur-md text-indigo-900 text-[11px] font-bold px-2.5 py-0.5 rounded-md">
            {course.category}
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Educator Info */}
          <div className="flex items-center gap-2 mb-2">
            <img
              src={course.educatorAvatar}
              alt={course.educatorName}
              className="w-5 h-5 rounded-full object-cover"
            />
            <span
              onClick={() => navigateTo('educator-profile', undefined, undefined, course.educatorId)}
              className="text-xs text-slate-600 hover:text-indigo-600 truncate font-medium cursor-pointer"
            >
              {course.educatorName}
            </span>
          </div>

          {/* Title */}
          <h3
            onClick={() => navigateTo('course-detail', course.id)}
            className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-2 cursor-pointer leading-snug"
          >
            {course.title}
          </h3>

          {/* Metadata Row */}
          <div className="flex items-center gap-2 text-xs text-slate-600 mt-2.5">
            <div className="flex items-center gap-1 font-bold text-amber-500">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{course.rating}</span>
            </div>
            <span className="text-slate-600">({course.ratingCount.toLocaleString()})</span>
            <span>&bull;</span>
            <div className="flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-slate-600" />
              <span>{course.studentsCount.toLocaleString()} students</span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-600 mt-1.5">
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-600" />
              <span>{course.totalDuration}</span>
            </div>
            <span>&bull;</span>
            <span>{course.chapters.reduce((acc, c) => acc + c.lectures.length, 0)} lectures</span>
          </div>
        </div>

        {/* Price & Action Button Footer */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-black text-slate-900">₹{course.price}</span>
              {course.originalPrice > course.price && (
                <span className="text-xs text-slate-600 line-through">₹{course.originalPrice}</span>
              )}
            </div>
            {course.discountPercent > 0 && (
              <span className="text-[10px] font-bold text-emerald-600">
                {course.discountPercent}% OFF
              </span>
            )}
          </div>

          {enrolled ? (
            <button
              onClick={() => navigateTo('player', course.id)}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1"
            >
              <Play className="w-3 h-3 fill-white" />
              <span>Resume</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  if (inCart) {
                    navigateTo('discovery');
                  } else {
                    addToCart(course.id);
                  }
                }}
                className={`p-2 rounded-xl transition-colors cursor-pointer ${
                  inCart
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
                title={inCart ? 'In Cart' : 'Add to Cart'}
              >
                {inCart ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
              </button>
              <button
                onClick={() => openPaymentModal(course)}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
              >
                Buy Now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
