import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  GraduationCap,
  Search,
  BookOpen,
  Users,
  Grid,
  Sparkles,
  ShoppingBag,
  Heart,
  ChevronDown,
  User as UserIcon,
  ShieldCheck,
  Briefcase,
  LogOut,
  Layers,
  Check,
  Menu,
  X,
  CreditCard
} from 'lucide-react';
import { COURSE_CATEGORIES } from '../data/seedData';
import { CourseCategory } from '../types';

export const Navbar: React.FC = () => {
  const {
    currentUser,
    setCurrentUserRole,
    currentPage,
    navigateTo,
    cart,
    wishlist,
    openAuthModal,
    openPaymentModal,
    courses
  } = useApp();

  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isRoleMenuOpen, setIsRoleMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const categoryRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const roleMenuRef = useRef<HTMLDivElement>(null);
  const cartRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (categoryRef.current && !categoryRef.current.contains(e.target as Node)) {
        setIsCategoryOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setIsUserMenuOpen(false);
      }
      if (roleMenuRef.current && !roleMenuRef.current.contains(e.target as Node)) {
        setIsRoleMenuOpen(false);
      }
      if (cartRef.current && !cartRef.current.contains(e.target as Node)) {
        setIsCartOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigateTo('discovery');
    }
  };

  const cartCourses = courses.filter(c => cart.includes(c.id));
  const cartTotal = cartCourses.reduce((sum, c) => sum + c.price, 0);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          
          {/* Brand Logo */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => navigateTo('landing')}
              className="flex items-center gap-2.5 group text-left cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-blue-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 font-display">
                  Edu<span className="text-indigo-600">Rise</span>
                </span>
                <span className="hidden sm:block text-[10px] font-semibold uppercase tracking-widest text-slate-600 -mt-1">
                  Learn &bull; Teach &bull; Rise
                </span>
              </div>
            </button>

            {/* Categories Dropdown */}
            <div className="relative hidden lg:block" ref={categoryRef}>
              <button
                onClick={() => setIsCategoryOpen(!isCategoryOpen)}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                  isCategoryOpen
                    ? 'bg-indigo-50 text-indigo-700'
                    : 'text-slate-700 hover:text-indigo-600 hover:bg-slate-50'
                }`}
              >
                <Grid className="w-4 h-4 text-indigo-600" />
                <span>Categories</span>
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isCategoryOpen ? 'rotate-180' : ''}`} />
              </button>

              {isCategoryOpen && (
                <div className="absolute left-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 p-3 grid grid-cols-1 gap-1 animate-in fade-in slide-in-from-top-2 duration-150 z-50">
                  <div className="px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-slate-600 border-b border-slate-100 mb-1">
                    Explore Subjects
                  </div>
                  <div className="max-h-96 overflow-y-auto pr-1">
                    {COURSE_CATEGORIES.map(cat => (
                      <button
                        key={cat.name}
                        onClick={() => {
                          setIsCategoryOpen(false);
                          navigateTo('discovery');
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-indigo-50/70 text-slate-700 hover:text-indigo-700 transition-colors text-left group"
                      >
                        <span className="font-medium">{cat.name}</span>
                        <span className="text-xs text-slate-600 group-hover:text-indigo-500 font-mono">
                          {cat.count}+
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-2">
            <form onSubmit={handleSearchSubmit} className="relative w-full">
              <input
                type="text"
                placeholder="Search Python, Physics, JEE, DSA, AI..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-sm bg-slate-100/80 hover:bg-slate-100 focus:bg-white text-slate-900 placeholder:text-slate-600 rounded-full border border-transparent focus:border-indigo-400 focus:outline-hidden focus:ring-3 focus:ring-indigo-500/15 transition-all"
              />
              <Search className="w-4 h-4 text-slate-600 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </form>
          </div>

          {/* Navigation Links */}
          <nav className="hidden xl:flex items-center gap-5 text-sm font-medium text-slate-600">
            <button
              onClick={() => navigateTo('discovery')}
              className={`hover:text-indigo-600 transition-colors cursor-pointer ${
                currentPage === 'discovery' ? 'text-indigo-600 font-semibold' : ''
              }`}
            >
              Courses
            </button>
            <button
              onClick={() => navigateTo('discovery')}
              className="hover:text-indigo-600 transition-colors cursor-pointer"
            >
              Educators
            </button>
            <button
              onClick={() => navigateTo('ai-hub')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-indigo-700 bg-indigo-50 hover:bg-indigo-100 transition-colors cursor-pointer ${
                currentPage === 'ai-hub' ? 'ring-2 ring-indigo-500' : ''
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>AI Tools</span>
            </button>
            {currentUser.role !== 'educator' && (
              <button
                onClick={() => {
                  if (currentUser.role === 'student') {
                    openAuthModal('educator-signup');
                  } else {
                    navigateTo('educator-dashboard');
                  }
                }}
                className="text-slate-700 hover:text-indigo-600 transition-colors font-medium cursor-pointer"
              >
                Become an Educator
              </button>
            )}
          </nav>

          {/* Right Action Tools & Profile */}
          <div className="flex items-center gap-2.5 sm:gap-3.5">
            
            {/* Quick Role Tester Chip */}
            <div className="relative" ref={roleMenuRef}>
              <button
                onClick={() => setIsRoleMenuOpen(!isRoleMenuOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full border border-indigo-200 bg-indigo-50/80 text-indigo-800 hover:bg-indigo-100 transition-all cursor-pointer shadow-xs"
                title="Switch active role demo"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="capitalize">{currentUser.role} Mode</span>
                <ChevronDown className="w-3 h-3 text-indigo-600" />
              </button>

              {isRoleMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-3 py-2 text-xs font-bold uppercase tracking-wider text-slate-600 border-b border-slate-100">
                    Switch Test Persona
                  </div>
                  
                  <button
                    onClick={() => {
                      setCurrentUserRole('student');
                      setIsRoleMenuOpen(false);
                      navigateTo('student-dashboard');
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs transition-colors ${
                      currentUser.role === 'student' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">S</div>
                      <div>
                        <div className="font-semibold text-slate-900">Student: Aryan</div>
                        <div className="text-[10px] text-slate-600">Enrolled in Python, Learner</div>
                      </div>
                    </div>
                    {currentUser.role === 'student' && <Check className="w-4 h-4 text-indigo-600" />}
                  </button>

                  <button
                    onClick={() => {
                      setCurrentUserRole('educator');
                      setIsRoleMenuOpen(false);
                      navigateTo('educator-dashboard');
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs transition-colors ${
                      currentUser.role === 'educator' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center font-bold">E</div>
                      <div>
                        <div className="font-semibold text-slate-900">Educator: Ananya Verma</div>
                        <div className="text-[10px] text-slate-600">Course Creator, Earnings</div>
                      </div>
                    </div>
                    {currentUser.role === 'educator' && <Check className="w-4 h-4 text-indigo-600" />}
                  </button>

                  <button
                    onClick={() => {
                      setCurrentUserRole('admin');
                      setIsRoleMenuOpen(false);
                      navigateTo('admin-dashboard');
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs transition-colors ${
                      currentUser.role === 'admin' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">A</div>
                      <div>
                        <div className="font-semibold text-slate-900">Admin: Vikramaditya</div>
                        <div className="text-[10px] text-slate-600">Approvals, Verifications</div>
                      </div>
                    </div>
                    {currentUser.role === 'admin' && <Check className="w-4 h-4 text-indigo-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* Wishlist Button */}
            <button
              onClick={() => {
                if (currentUser.role === 'student') {
                  navigateTo('student-dashboard');
                } else {
                  navigateTo('discovery');
                }
              }}
              className="relative p-2 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center shadow-xs">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Dropdown */}
            <div className="relative" ref={cartRef}>
              <button
                onClick={() => setIsCartOpen(!isCartOpen)}
                className="relative p-2 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                title="Shopping Cart"
              >
                <ShoppingBag className="w-5 h-5" />
                {cart.length > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-indigo-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center shadow-xs animate-bounce">
                    {cart.length}
                  </span>
                )}
              </button>

              {isCartOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-100 p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <span className="font-bold text-slate-900">Your Cart ({cart.length})</span>
                    <span className="text-xs text-indigo-600 font-medium font-mono">
                      Total: ₹{cartTotal.toLocaleString()}
                    </span>
                  </div>

                  {cartCourses.length === 0 ? (
                    <div className="py-8 text-center text-slate-600">
                      <ShoppingBag className="w-10 h-10 mx-auto text-slate-500 mb-2" />
                      <p className="text-sm font-medium">Your cart is empty</p>
                      <button
                        onClick={() => {
                          setIsCartOpen(false);
                          navigateTo('discovery');
                        }}
                        className="mt-3 text-xs text-indigo-600 font-semibold hover:underline"
                      >
                        Discover Popular Courses &rarr;
                      </button>
                    </div>
                  ) : (
                    <div className="py-3 max-h-72 overflow-y-auto divide-y divide-slate-100">
                      {cartCourses.map(course => (
                        <div key={course.id} className="py-2.5 flex items-center gap-3">
                          <img
                            src={course.thumbnail}
                            alt={course.title}
                            className="w-12 h-12 rounded-lg object-cover shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-slate-900 truncate">
                              {course.title}
                            </p>
                            <p className="text-[11px] text-slate-600">{course.educatorName}</p>
                            <p className="text-xs font-bold text-slate-900 mt-0.5">₹{course.price}</p>
                          </div>
                          <button
                            onClick={() => {
                              setIsCartOpen(false);
                              openPaymentModal(course);
                            }}
                            className="px-2.5 py-1 text-xs font-semibold bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                          >
                            Checkout
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {cartCourses.length > 0 && (
                    <div className="pt-3 border-t border-slate-100">
                      <button
                        onClick={() => {
                          setIsCartOpen(false);
                          openPaymentModal(cartCourses[0]);
                        }}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <CreditCard className="w-4 h-4" />
                        Proceed to Checkout (₹{cartTotal.toLocaleString()})
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* User Profile Avatar Dropdown */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 p-1 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-full object-cover ring-2 ring-indigo-500/20"
                />
              </button>

              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-3 py-2.5 border-b border-slate-100">
                    <p className="text-sm font-bold text-slate-900 truncate">{currentUser.name}</p>
                    <p className="text-xs text-slate-600 truncate">{currentUser.email}</p>
                    <span className="inline-block mt-1.5 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-md bg-indigo-50 text-indigo-700">
                      {currentUser.role} Account
                    </span>
                  </div>

                  <div className="py-1">
                    {currentUser.role === 'student' && (
                      <>
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            navigateTo('student-dashboard');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-left"
                        >
                          <BookOpen className="w-4 h-4 text-indigo-600" />
                          <span>Student Dashboard</span>
                        </button>
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            navigateTo('student-dashboard');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-left"
                        >
                          <Layers className="w-4 h-4 text-indigo-600" />
                          <span>My Enrolled Courses</span>
                        </button>
                      </>
                    )}

                    {currentUser.role === 'educator' && (
                      <>
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            navigateTo('educator-dashboard');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-left"
                        >
                          <Briefcase className="w-4 h-4 text-indigo-600" />
                          <span>Educator Dashboard</span>
                        </button>
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            navigateTo('educator-profile', undefined, undefined, currentUser.id);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-left"
                        >
                          <UserIcon className="w-4 h-4 text-indigo-600" />
                          <span>Public Profile</span>
                        </button>
                      </>
                    )}

                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          navigateTo('admin-dashboard');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-left"
                      >
                        <ShieldCheck className="w-4 h-4 text-indigo-600" />
                        <span>Admin Oversight Panel</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        navigateTo('ai-hub');
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-left"
                    >
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <span>AI Learning Suite</span>
                    </button>
                  </div>

                  <div className="pt-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        openAuthModal('login');
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 rounded-lg text-left"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Switch Account / Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
              className="p-2 text-slate-700 hover:bg-slate-100 rounded-lg lg:hidden"
              aria-label="Toggle navigation"
            >
              {isMobileNavOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileNavOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-4 duration-200 shadow-xl">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <input
              type="text"
              placeholder="Search courses..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm bg-slate-100 rounded-xl border border-transparent focus:border-indigo-500 focus:bg-white"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </form>

          <div className="grid grid-cols-2 gap-2 text-sm font-medium">
            <button
              onClick={() => {
                setIsMobileNavOpen(false);
                navigateTo('discovery');
              }}
              className="p-2.5 rounded-xl bg-slate-50 text-slate-800 text-left flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>Courses</span>
            </button>
            <button
              onClick={() => {
                setIsMobileNavOpen(false);
                navigateTo('ai-hub');
              }}
              className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700 text-left flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>AI Tools</span>
            </button>
            <button
              onClick={() => {
                setIsMobileNavOpen(false);
                navigateTo('student-dashboard');
              }}
              className="p-2.5 rounded-xl bg-slate-50 text-slate-800 text-left flex items-center gap-2"
            >
              <Layers className="w-4 h-4 text-blue-600" />
              <span>Student Area</span>
            </button>
            <button
              onClick={() => {
                setIsMobileNavOpen(false);
                navigateTo('educator-dashboard');
              }}
              className="p-2.5 rounded-xl bg-slate-50 text-slate-800 text-left flex items-center gap-2"
            >
              <Briefcase className="w-4 h-4 text-purple-600" />
              <span>Teacher Area</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
