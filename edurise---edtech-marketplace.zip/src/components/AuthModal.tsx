import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  GraduationCap,
  Sparkles,
  ShieldCheck,
  User as UserIcon,
  Briefcase,
  Lock,
  Mail,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { User, UserRole } from '../types';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    setUser,
    users,
    addNotification,
    navigateTo
  } = useApp();

  const [activeTab, setActiveTab] = useState<'student' | 'educator' | 'admin'>(
    authModalMode === 'educator-signup'
      ? 'educator'
      : authModalMode === 'admin-login'
      ? 'admin'
      : 'student'
  );

  const [isSignUp, setIsSignUp] = useState(authModalMode.includes('signup'));
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [subjectSpecialization, setSubjectSpecialization] = useState('Programming');
  const [experienceYears, setExperienceYears] = useState('5');
  const [bio, setBio] = useState('');

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      alert('Please enter your email.');
      return;
    }

    if (isSignUp) {
      const newUser: User = {
        id: `user_${activeTab}_${Date.now()}`,
        name: name || (activeTab === 'student' ? 'New Student' : 'New Educator'),
        email,
        role: activeTab as UserRole,
        avatar:
          activeTab === 'educator'
            ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
            : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        title:
          activeTab === 'educator'
            ? `${subjectSpecialization} Specialist & Mentor`
            : 'Learner @ EduRise',
        subjects: activeTab === 'educator' ? [subjectSpecialization] : undefined,
        experienceYears: activeTab === 'educator' ? Number(experienceYears) : undefined,
        isVerified: activeTab === 'admin',
        joinedDate: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        bio: bio || 'Excited to learn and grow on EduRise.'
      };

      setUser(newUser);
      addNotification(
        'success',
        `Welcome to EduRise, ${newUser.name}!`,
        activeTab === 'educator'
          ? 'Your educator profile has been created. Start creating your first course.'
          : 'Your student account is active. Explore thousands of courses!'
      );
      closeAuthModal();
      navigateTo(
        activeTab === 'educator'
          ? 'educator-dashboard'
          : activeTab === 'admin'
          ? 'admin-dashboard'
          : 'student-dashboard'
      );
    } else {
      // Find existing user or create instant session
      const matched = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.role === activeTab);
      if (matched) {
        setUser(matched);
      } else {
        const fallback: User = {
          id: `user_${activeTab}_${Date.now()}`,
          name: email.split('@')[0],
          email,
          role: activeTab as UserRole,
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          joinedDate: 'Recent',
          isVerified: activeTab === 'admin'
        };
        setUser(fallback);
      }

      addNotification('success', 'Logged in successfully', `Welcome back to EduRise!`);
      closeAuthModal();
      navigateTo(
        activeTab === 'educator'
          ? 'educator-dashboard'
          : activeTab === 'admin'
          ? 'admin-dashboard'
          : 'student-dashboard'
      );
    }
  };

  const handleQuickFill = (role: 'student' | 'educator' | 'admin') => {
    setActiveTab(role);
    setIsSignUp(false);
    if (role === 'student') {
      setEmail('aryan.patel@example.com');
      setPassword('password123');
    } else if (role === 'educator') {
      setEmail('ananya.verma@edurise.edu');
      setPassword('password123');
    } else if (role === 'admin') {
      setEmail('admin@edurise.edu');
      setPassword('adminPass123');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden relative">
        
        {/* Header Bar */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold text-slate-900">
              Edu<span className="text-indigo-600">Rise</span> Access
            </span>
          </div>

          <button
            onClick={closeAuthModal}
            className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Role Selector Tabs */}
        <div className="p-6 pt-4">
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-2xl mb-6">
            <button
              onClick={() => {
                setActiveTab('student');
                setEmail('');
              }}
              className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'student'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Student</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('educator');
                setEmail('');
              }}
              className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'educator'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Educator</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('admin');
                setIsSignUp(false);
                setEmail('');
              }}
              className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-white text-amber-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          </div>

          {/* Quick Preset Fill Badges */}
          <div className="mb-5 p-3 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex flex-col gap-1.5">
            <span className="text-[11px] font-bold text-indigo-900 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Instant One-Click Demo Logins:</span>
            </span>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickFill('student')}
                className="px-2.5 py-1 text-[11px] font-medium bg-white text-blue-700 rounded-lg border border-blue-200 hover:bg-blue-50 transition-colors shadow-2xs"
              >
                Student (Aryan)
              </button>
              <button
                type="button"
                onClick={() => handleQuickFill('educator')}
                className="px-2.5 py-1 text-[11px] font-medium bg-white text-purple-700 rounded-lg border border-purple-200 hover:bg-purple-50 transition-colors shadow-2xs"
              >
                Educator (Ananya)
              </button>
              <button
                type="button"
                onClick={() => handleQuickFill('admin')}
                className="px-2.5 py-1 text-[11px] font-medium bg-white text-amber-800 rounded-lg border border-amber-200 hover:bg-amber-50 transition-colors shadow-2xs"
              >
                Admin (Vikramaditya)
              </button>
            </div>
          </div>

          {/* Main Form */}
          <form onSubmit={handleSubmit} className="space-y-3.5">
            {isSignUp && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder={activeTab === 'student' ? 'e.g. Aryan Patel' : 'e.g. Ananya Verma'}
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:bg-white focus:outline-hidden"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder={
                    activeTab === 'admin'
                      ? 'admin@edurise.edu'
                      : activeTab === 'educator'
                      ? 'educator@edurise.edu'
                      : 'student@example.com'
                  }
                  className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:bg-white focus:outline-hidden"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:bg-white focus:outline-hidden font-mono"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {/* Educator Specific Onboarding Fields */}
            {isSignUp && activeTab === 'educator' && (
              <div className="space-y-3 p-3 bg-purple-50/50 rounded-2xl border border-purple-100">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-purple-900 mb-1">Primary Subject</label>
                    <select
                      value={subjectSpecialization}
                      onChange={e => setSubjectSpecialization(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-purple-200 rounded-xl text-slate-800"
                    >
                      <option>Programming</option>
                      <option>Mathematics</option>
                      <option>Physics</option>
                      <option>AI & Machine Learning</option>
                      <option>Web Development</option>
                      <option>Chemistry</option>
                      <option>Competitive Exams</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-purple-900 mb-1">Years Teaching</label>
                    <input
                      type="number"
                      value={experienceYears}
                      onChange={e => setExperienceYears(e.target.value)}
                      min="1"
                      max="40"
                      className="w-full p-2 text-xs bg-white border border-purple-200 rounded-xl text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-purple-900 mb-1">Short Professional Bio</label>
                  <textarea
                    rows={2}
                    value={bio}
                    onChange={e => setBio(e.target.value)}
                    placeholder="Briefly state your qualifications and teaching philosophy..."
                    className="w-full p-2 text-xs bg-white border border-purple-200 rounded-xl text-slate-800"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <span>
                {isSignUp
                  ? `Create ${activeTab.toUpperCase()} Account`
                  : `Sign In as ${activeTab.toUpperCase()}`}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Mode Switcher */}
          {activeTab !== 'admin' && (
            <div className="mt-4 pt-4 border-t border-slate-100 text-center text-xs text-slate-600">
              {isSignUp ? (
                <p>
                  Already have an account?{' '}
                  <button
                    onClick={() => setIsSignUp(false)}
                    className="font-bold text-indigo-600 hover:underline cursor-pointer"
                  >
                    Log In
                  </button>
                </p>
              ) : (
                <p>
                  Don't have an account yet?{' '}
                  <button
                    onClick={() => setIsSignUp(true)}
                    className="font-bold text-indigo-600 hover:underline cursor-pointer"
                  >
                    Sign Up Free
                  </button>
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
