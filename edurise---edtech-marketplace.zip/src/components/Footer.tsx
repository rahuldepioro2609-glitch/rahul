import React from 'react';
import { useApp } from '../context/AppContext';
import { GraduationCap, Heart, Shield, Award, Sparkles, Send, Globe, Mail, Phone } from 'lucide-react';
import { COURSE_CATEGORIES } from '../data/seedData';

export const Footer: React.FC = () => {
  const { navigateTo } = useApp();

  return (
    <footer className="bg-slate-900 text-slate-400 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 pb-12 border-b border-slate-800 text-slate-300">
          <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">Top 1% Educators</p>
              <p className="text-xs text-slate-400">Verified industry masters & IITians</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">24/7 AI Teaching Assistant</p>
              <p className="text-xs text-slate-400">Instant doubt solving on every lecture</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">Lifetime Access</p>
              <p className="text-xs text-slate-400">Learn at your own pace forever</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">Verified Certificates</p>
              <p className="text-xs text-slate-400">Industry recognized credentials</p>
            </div>
          </div>
        </div>

        {/* Main Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 py-12">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-500 flex items-center justify-center text-white shadow-md">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="text-2xl font-extrabold tracking-tight text-white font-display">
                Edu<span className="text-indigo-400">Rise</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              Empowering learners worldwide through expert-led recorded courses, interactive AI tutoring, and rewarding instructor monetization.
            </p>
            <p className="text-xs font-semibold text-slate-300 italic">
              &ldquo;Anyone can teach. Everyone can learn.&rdquo;
            </p>

            {/* Newsletter Form */}
            <div className="pt-2 max-w-sm">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                Join 50,000+ Lifelong Learners
              </label>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-slate-800/80 border border-slate-700 text-white placeholder:text-slate-500 text-xs px-3.5 py-2.5 rounded-xl flex-1 focus:outline-hidden focus:border-indigo-500"
                />
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    alert('Thank you for subscribing to EduRise updates!');
                  }}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Subscribe</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Col 2: Marketplace */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-white">Marketplace</p>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => navigateTo('discovery')} className="hover:text-white transition-colors cursor-pointer">
                  All Courses
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('discovery')} className="hover:text-white transition-colors cursor-pointer">
                  Bestsellers
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('discovery')} className="hover:text-white transition-colors cursor-pointer">
                  Free Previews
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('discovery')} className="hover:text-white transition-colors cursor-pointer">
                  Top Educators
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('ai-hub')} className="hover:text-white transition-colors cursor-pointer">
                  AI Study Planner
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Popular Categories */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-white">Categories</p>
            <ul className="space-y-2 text-sm">
              {COURSE_CATEGORIES.slice(0, 5).map(cat => (
                <li key={cat.name}>
                  <button onClick={() => navigateTo('discovery')} className="hover:text-white transition-colors cursor-pointer">
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Teaching & Admin */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-white">Educators & Admin</p>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => navigateTo('educator-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Teacher Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('educator-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Create a Course
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('educator-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Upload Video Content
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('educator-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Educator Revenue & Payouts
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('admin-dashboard')} className="hover:text-white transition-colors cursor-pointer text-indigo-400 font-medium">
                  Admin Oversight Panel
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 mt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p>© {new Date().getFullYear()} EduRise Technologies Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-white transition-colors cursor-pointer">Privacy Policy</span>
            <span className="hover:text-white transition-colors cursor-pointer">Terms of Service</span>
            <span className="hover:text-white transition-colors cursor-pointer">Educator Agreement</span>
            <span className="hover:text-white transition-colors cursor-pointer">Security</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
