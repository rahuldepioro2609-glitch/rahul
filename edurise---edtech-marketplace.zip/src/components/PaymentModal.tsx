import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShieldCheck,
  CreditCard,
  Smartphone,
  Building2,
  Wallet,
  CheckCircle2,
  Sparkles,
  Tag,
  Lock,
  ArrowRight,
  Loader2
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const PaymentModal: React.FC = () => {
  const { isPaymentModalOpen, closePaymentModal, pendingPurchaseCourse, purchaseCourse, navigateTo } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'Netbanking' | 'Wallet'>('UPI');
  const [upiId, setUpiId] = useState('student@oksbi');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  if (!isPaymentModalOpen || !pendingPurchaseCourse) return null;

  const originalPrice = pendingPurchaseCourse.price;
  let discountAmount = 0;

  if (appliedCoupon === 'EDURISE50') {
    discountAmount = Math.round(originalPrice * 0.5);
  } else if (appliedCoupon === 'WELCOME20') {
    discountAmount = Math.round(originalPrice * 0.2);
  }

  const taxableAmount = Math.max(0, originalPrice - discountAmount);
  const gstAmount = Math.round(taxableAmount * 0.18);
  const totalAmount = taxableAmount + gstAmount;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    const code = couponInput.trim().toUpperCase();

    if (code === 'EDURISE50') {
      setAppliedCoupon('EDURISE50');
      setCouponInput('');
    } else if (code === 'WELCOME20') {
      setAppliedCoupon('WELCOME20');
      setCouponInput('');
    } else {
      setCouponError('Invalid coupon code. Try "EDURISE50" or "WELCOME20"');
    }
  };

  const handlePayNow = async () => {
    setIsProcessing(true);

    // Simulate secure 1.5s gateway handshake
    setTimeout(async () => {
      await purchaseCourse(pendingPurchaseCourse, paymentMethod, appliedCoupon || undefined);
      setIsProcessing(false);
      setIsCompleted(true);

      // Trigger celebratory confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }, 1400);
  };

  const handleFinishAndLearn = () => {
    closePaymentModal();
    setIsCompleted(false);
    navigateTo('player', pendingPurchaseCourse.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden flex flex-col md:flex-row relative">
        
        {/* Close Button */}
        <button
          onClick={closePaymentModal}
          disabled={isProcessing}
          className="absolute top-4 right-4 z-10 p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {isCompleted ? (
          /* Success Screen */
          <div className="w-full p-8 md:p-12 text-center flex flex-col items-center justify-center bg-gradient-to-b from-emerald-50/50 to-white">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4 shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 mb-2">Payment Successful!</h2>
            <p className="text-sm text-slate-600 max-w-md mb-6">
              You are now officially enrolled in <strong className="text-slate-900">"{pendingPurchaseCourse.title}"</strong>. An email receipt has been sent to your address.
            </p>

            <div className="w-full max-w-sm p-4 bg-slate-50 rounded-2xl border border-slate-200/80 mb-6 text-left text-xs space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction ID:</span>
                <span className="font-bold text-slate-800">TXN_{Math.random().toString(36).substring(2, 9).toUpperCase()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount Paid:</span>
                <span className="font-bold text-emerald-600">₹{totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Access Type:</span>
                <span className="font-bold text-slate-800">Lifetime Unlimited</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 w-full max-w-sm">
              <button
                onClick={handleFinishAndLearn}
                className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Start Learning Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Payment Flow */
          <>
            {/* Left: Order Summary */}
            <div className="md:w-5/12 bg-slate-50 p-6 md:p-8 border-b md:border-b-0 md:border-r border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-indigo-600 text-xs font-bold uppercase tracking-wider mb-3">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Secure Razorpay Checkout</span>
                </div>

                <h3 className="text-base font-bold text-slate-900 line-clamp-2 mb-2">
                  {pendingPurchaseCourse.title}
                </h3>
                <p className="text-xs text-slate-500 mb-4">Instructor: {pendingPurchaseCourse.educatorName}</p>

                <img
                  src={pendingPurchaseCourse.thumbnail}
                  alt={pendingPurchaseCourse.title}
                  className="w-full h-24 object-cover rounded-xl mb-4 border border-slate-200"
                />

                {/* Price Breakdown */}
                <div className="space-y-2 text-xs border-t border-slate-200 pt-3">
                  <div className="flex justify-between text-slate-600">
                    <span>Course Fee</span>
                    <span>₹{originalPrice.toLocaleString()}</span>
                  </div>

                  {discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-semibold">
                      <span>Discount ({appliedCoupon})</span>
                      <span>-₹{discountAmount.toLocaleString()}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-slate-600">
                    <span>GST (18% Govt. Tax)</span>
                    <span>₹{gstAmount.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between text-sm font-black text-slate-900 border-t border-slate-200 pt-2">
                    <span>Total Payable</span>
                    <span className="text-indigo-600">₹{totalAmount.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Security Badge */}
              <div className="mt-6 pt-3 text-[11px] text-slate-500 flex items-center gap-2 border-t border-slate-200/60">
                <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>256-Bit SSL Encrypted & RBI Guideline Compliant</span>
              </div>
            </div>

            {/* Right: Payment Method Selector */}
            <div className="md:w-7/12 p-6 md:p-8 flex flex-col justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-3">Select Payment Method</h4>

                {/* Method Tabs */}
                <div className="grid grid-cols-4 gap-2 mb-5">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('UPI')}
                    className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 text-[11px] font-semibold transition-all cursor-pointer ${
                      paymentMethod === 'UPI'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>UPI / QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Card')}
                    className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 text-[11px] font-semibold transition-all cursor-pointer ${
                      paymentMethod === 'Card'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Cards</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Netbanking')}
                    className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 text-[11px] font-semibold transition-all cursor-pointer ${
                      paymentMethod === 'Netbanking'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>NetBanking</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Wallet')}
                    className={`p-2.5 rounded-xl border flex flex-col items-center gap-1 text-[11px] font-semibold transition-all cursor-pointer ${
                      paymentMethod === 'Wallet'
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <Wallet className="w-4 h-4" />
                    <span>Wallets</span>
                  </button>
                </div>

                {/* Method Specific Form */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 mb-5">
                  {paymentMethod === 'UPI' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                        <span>Instant UPI Payment</span>
                        <div className="flex gap-1.5 text-[10px] text-slate-500">
                          <span className="px-1.5 py-0.5 bg-white rounded border">GPay</span>
                          <span className="px-1.5 py-0.5 bg-white rounded border">PhonePe</span>
                          <span className="px-1.5 py-0.5 bg-white rounded border">Paytm</span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={upiId}
                        onChange={e => setUpiId(e.target.value)}
                        placeholder="Enter your UPI ID (e.g. name@okhdfcbank)"
                        className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-hidden"
                      />
                      <p className="text-[11px] text-slate-500">
                        A payment request will be sent to your UPI app upon clicking Pay Now.
                      </p>
                    </div>
                  )}

                  {paymentMethod === 'Card' && (
                    <div className="space-y-2.5 text-xs">
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Card Number</label>
                        <input
                          type="text"
                          defaultValue="4532 &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; 8921"
                          className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Expiry</label>
                          <input
                            type="text"
                            defaultValue="08/29"
                            className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono text-center"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">CVV</label>
                          <input
                            type="password"
                            defaultValue="•••"
                            className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono text-center"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'Netbanking' && (
                    <div className="space-y-2.5 text-xs">
                      <label className="block text-[10px] uppercase font-bold text-slate-500">Select Popular Indian Bank</label>
                      <div className="grid grid-cols-2 gap-2">
                        {['HDFC Bank', 'State Bank of India', 'ICICI Bank', 'Axis Bank', 'Kotak Mahindra', 'Punjab National'].map(bank => (
                          <button
                            key={bank}
                            type="button"
                            onClick={() => setSelectedBank(bank)}
                            className={`p-2 rounded-xl text-left border text-xs transition-colors cursor-pointer ${
                              selectedBank === bank
                                ? 'border-indigo-600 bg-indigo-50 font-bold text-indigo-700'
                                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            {bank}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'Wallet' && (
                    <div className="space-y-2 text-xs">
                      <label className="block text-[10px] uppercase font-bold text-slate-500">Select Digital Wallet</label>
                      <div className="space-y-1.5">
                        {['Paytm Wallet', 'Amazon Pay', 'Mobikwik'].map(w => (
                          <div key={w} className="flex items-center gap-2 p-2 bg-white border border-slate-200 rounded-xl">
                            <input type="radio" name="wallet" id={w} defaultChecked={w === 'Paytm Wallet'} />
                            <label htmlFor={w} className="text-xs font-medium text-slate-800">{w}</label>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Coupon Code Input */}
                <div className="mb-4">
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        placeholder="Coupon (e.g. EDURISE50)"
                        value={couponInput}
                        onChange={e => setCouponInput(e.target.value)}
                        className="w-full pl-8 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:border-indigo-500 uppercase font-mono"
                      />
                      <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    </div>
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                    >
                      Apply
                    </button>
                  </form>

                  {appliedCoupon && (
                    <div className="mt-1.5 flex items-center justify-between text-[11px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                      <span>Applied: <strong>{appliedCoupon}</strong></span>
                      <button
                        onClick={() => setAppliedCoupon(null)}
                        className="text-emerald-800 font-bold hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  )}

                  {couponError && (
                    <p className="mt-1 text-[11px] text-rose-600">{couponError}</p>
                  )}
                </div>
              </div>

              {/* Action Button */}
              <div>
                <button
                  type="button"
                  onClick={handlePayNow}
                  disabled={isProcessing}
                  className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Verifying with Bank...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>Pay ₹{totalAmount.toLocaleString()} & Enroll</span>
                    </>
                  )}
                </button>

                <p className="text-center text-[10px] text-slate-400 mt-2">
                  By clicking Pay, you agree to EduRise Terms & 30-Day Money Back Guarantee.
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
