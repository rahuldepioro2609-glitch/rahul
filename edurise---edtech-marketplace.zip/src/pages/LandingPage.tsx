import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CourseCard } from '../components/CourseCard';
import { COURSE_CATEGORIES } from '../data/seedData';
import {
  GraduationCap,
  Sparkles,
  ArrowRight,
  Play,
  Star,
  CheckCircle2,
  Users,
  BookOpen,
  Award,
  ShieldCheck,
  TrendingUp,
  Brain,
  Video,
  FileCheck,
  Zap,
  Globe,
  ChevronRight,
  Heart
} from 'lucide-react';
import { motion } from 'motion/react';

export const LandingPage: React.FC = () => {
  const { courses, users, navigateTo, openAuthModal } = useApp();
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<string>('All');

  const featuredCourses = courses.filter(c => c.isFeatured || c.isBestseller);
  const filteredCourses =
    selectedCategoryTab === 'All'
      ? featuredCourses
      : courses.filter(c => c.category === selectedCategoryTab);

  const topEducators = users.filter(u => u.role === 'educator');

  return (
    <div className="min-h-screen bg-slate-50/50">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-indigo-950 via-slate-900 to-slate-900 text-white pt-12 pb-24 lg:pt-20 lg:pb-32">
        {/* Subtle Ambient Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[450px] bg-indigo-600/20 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-[400px] h-[350px] bg-blue-600/15 blur-[100px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-400/30 text-indigo-300 text-xs font-semibold backdrop-blur-md">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Next-Gen EdTech &bull; AI-Powered Marketplace</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white font-display leading-[1.1]">
                Learn From Great Teachers.{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-blue-300 to-indigo-200">
                  Grow Without Limits.
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Discover expert-led recorded courses, learn at your own pace, and master skills with an interactive video player and 24/7 AI tutor.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={() => navigateTo('discovery')}
                  className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2.5 cursor-pointer active:scale-95"
                >
                  <span>Explore Courses</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => openAuthModal('educator-signup')}
                  className="w-full sm:w-auto px-7 py-4 bg-white/10 hover:bg-white/15 text-white font-bold text-sm sm:text-base rounded-2xl border border-white/20 backdrop-blur-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Become an Educator</span>
                  <Award className="w-4 h-4 text-indigo-300" />
                </button>
              </div>

              {/* Social Proof Badges */}
              <div className="pt-6 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    <img className="w-7 h-7 rounded-full border-2 border-slate-900 object-cover" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80" alt="student" />
                    <img className="w-7 h-7 rounded-full border-2 border-slate-900 object-cover" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80" alt="student" />
                    <img className="w-7 h-7 rounded-full border-2 border-slate-900 object-cover" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80" alt="student" />
                    <img className="w-7 h-7 rounded-full border-2 border-slate-900 object-cover" src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80" alt="student" />
                  </div>
                  <span className="font-semibold text-slate-200">10,000+ Enrolled Students</span>
                </div>

                <div className="flex items-center gap-1.5 text-amber-400 font-bold">
                  <Star className="w-4 h-4 fill-amber-400" />
                  <span>4.9 / 5.0 Rating</span>
                </div>
              </div>
            </div>

            {/* Right: Live Interactive Mockup Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-3xl bg-slate-800/80 border border-slate-700/80 shadow-2xl p-4 backdrop-blur-xl">
                
                {/* Simulated Player Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-700/60 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                    <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                    <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                    <span className="text-slate-400 font-mono text-[11px] ml-2">EduRise Classroom Engine</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                    HD 1080p
                  </span>
                </div>

                {/* Simulated Video Preview */}
                <div className="relative aspect-16/9 rounded-2xl overflow-hidden my-3 group bg-black">
                  <img
                    src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80"
                    alt="Course Preview"
                    className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-black/30 to-transparent flex flex-col justify-between p-4">
                    <div className="flex justify-between items-start">
                      <span className="bg-indigo-600/90 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-md">
                        Chapter 3: Deep Neural Networks
                      </span>
                      <span className="bg-black/60 text-slate-300 text-[10px] px-2 py-0.5 rounded-md font-mono">
                        14:20 / 32:45
                      </span>
                    </div>

                    <button
                      onClick={() => navigateTo('course-detail', 'course-1')}
                      className="w-12 h-12 mx-auto rounded-full bg-white text-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform cursor-pointer"
                    >
                      <Play className="w-5 h-5 fill-indigo-600 ml-0.5" />
                    </button>

                    <div className="flex items-center justify-between text-xs text-white">
                      <span className="font-semibold">Instructor: Ananya Verma</span>
                      <span className="text-emerald-400 text-[11px] font-semibold">Speed: 1.25x</span>
                    </div>
                  </div>
                </div>

                {/* Simulated AI Assistant Callout */}
                <div className="p-3 rounded-2xl bg-indigo-950/60 border border-indigo-500/30 text-xs text-indigo-100 flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-white text-[11px]">AI Realtime Lecture Assistant</p>
                    <p className="text-[11px] text-indigo-200 mt-0.5">
                      "Would you like an intuitive breakdown of backpropagation gradients for this formula?"
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. TRUST STATS BAR */}
      <section className="bg-white border-y border-slate-200/90 py-8 relative z-20 -mt-8 mx-4 sm:mx-6 lg:mx-8 max-w-7xl lg:mx-auto rounded-3xl shadow-xl">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center divide-y md:divide-y-0 md:divide-x divide-slate-100">
          <div className="p-2">
            <p className="text-3xl lg:text-4xl font-black text-slate-900 font-display">10,000+</p>
            <p className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">Active Students</p>
          </div>
          <div className="p-2">
            <p className="text-3xl lg:text-4xl font-black text-indigo-600 font-display">500+</p>
            <p className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">Expert Educators</p>
          </div>
          <div className="p-2">
            <p className="text-3xl lg:text-4xl font-black text-slate-900 font-display">1,000+</p>
            <p className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">Recorded Courses</p>
          </div>
          <div className="p-2">
            <p className="text-3xl lg:text-4xl font-black text-indigo-600 font-display">99.4%</p>
            <p className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">Satisfaction Rate</p>
          </div>
        </div>
      </section>

      {/* 3. EXPLORE CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-10 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Diverse Disciplines</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Top Categories to Master
            </h2>
          </div>
          <button
            onClick={() => navigateTo('discovery')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Explore All 12 Subjects</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {COURSE_CATEGORIES.map(cat => (
            <button
              key={cat.name}
              onClick={() => navigateTo('discovery')}
              className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-indigo-400 hover:shadow-lg transition-all text-left group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1">
                {cat.name}
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">{cat.count}+ courses</p>
            </button>
          ))}
        </div>
      </section>

      {/* 4. FEATURED & BESTSELLING COURSES */}
      <section className="bg-slate-100/70 py-20 border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Curated Catalog</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
                Featured & Bestselling Courses
              </h2>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
              {['All', 'Programming', 'Physics', 'Mathematics', 'AI & Machine Learning'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setSelectedCategoryTab(tab)}
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                    selectedCategoryTab === tab
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Courses Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>

          <div className="mt-12 text-center">
            <button
              onClick={() => navigateTo('discovery')}
              className="px-8 py-3.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-2xl shadow-md transition-all inline-flex items-center gap-2 cursor-pointer"
            >
              <span>View All Available Courses ({courses.length})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 5. WHY EDURISE: 4 CORE PILLARS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">The EduRise Advantage</span>
          <h2 className="text-3xl font-extrabold text-slate-900 font-display mt-1">
            Built for Modern, Unstoppable Learners
          </h2>
          <p className="text-sm text-slate-600 mt-3">
            Every feature on EduRise is engineered to help students grasp hard concepts faster and educators earn respectfully.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Pillar 1 */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-xl transition-all">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-5">
              <Video className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Interactive Video Player</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              HD lecture playback with speed controls (0.75x–2x), timestamped personal note taking, and chapter quizzes.
            </p>
          </div>

          {/* Pillar 2 */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-xl transition-all">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-5">
              <Brain className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">24/7 AI Teaching Assistant</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Ask questions anytime on any lecture. Receive instant step-by-step explanations, code examples, and summaries.
            </p>
          </div>

          {/* Pillar 3 */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-xl transition-all">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mb-5">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Top 1% Verified Educators</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Courses are vetted and approved by academic administrators before publishing. Only verified experts teach here.
            </p>
          </div>

          {/* Pillar 4 */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-xl transition-all">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-5">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Verified Certificates</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Earn shareable, verifiable certificates upon completing courses to boost your LinkedIn and job applications.
            </p>
          </div>
        </div>
      </section>

      {/* 6. TOP EDUCATORS SPOTLIGHT */}
      <section className="bg-slate-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-12 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">Master Mentors</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display mt-1">
                Learn from Industry Leaders
              </h2>
            </div>
            <button
              onClick={() => openAuthModal('educator-signup')}
              className="text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
            >
              <span>Join as an Educator</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topEducators.map(educator => (
              <div
                key={educator.id}
                className="p-6 rounded-3xl bg-slate-800/80 border border-slate-700 hover:border-indigo-500/50 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-4 mb-4">
                    <img
                      src={educator.avatar}
                      alt={educator.name}
                      className="w-16 h-16 rounded-2xl object-cover ring-2 ring-indigo-500/30"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-base font-bold text-white">{educator.name}</h3>
                        {educator.isVerified && (
                          <CheckCircle2 className="w-4 h-4 text-blue-400" />
                        )}
                      </div>
                      <p className="text-xs text-indigo-300 font-medium">{educator.title}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{educator.experienceYears}+ Years Teaching</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-3 mb-4">
                    {educator.bio}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {educator.subjects?.map(s => (
                      <span key={s} className="px-2 py-0.5 text-[10px] font-semibold bg-slate-700/80 text-slate-300 rounded-md">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-700/60 flex items-center justify-between">
                  <div className="text-xs">
                    <span className="text-slate-400">Students: </span>
                    <span className="font-bold text-white font-mono">{educator.totalStudents?.toLocaleString()}</span>
                  </div>
                  <button
                    onClick={() => navigateTo('educator-profile', undefined, undefined, educator.id)}
                    className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    View Courses
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. TEACHER MONETIZATION CALL-TO-ACTION BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-blue-900 text-white p-8 sm:p-12 lg:p-16 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-8 space-y-4 text-center lg:text-left">
              <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-bold text-indigo-200 border border-white/10 inline-block">
                For Teachers & Content Creators
              </span>
              <h2 className="text-3xl sm:text-4xl font-black font-display text-white">
                Share Your Expertise. Earn On Your Terms.
              </h2>
              <p className="text-sm sm:text-base text-indigo-100 max-w-xl leading-relaxed">
                Upload your recorded course videos, set your price, and reach students across India and globally. Keep 80% of every sale with instant UPI/Bank payouts.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-left">
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
                  <p className="text-xl font-bold text-white">80%</p>
                  <p className="text-[11px] text-indigo-200">Educator Revenue Share</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
                  <p className="text-xl font-bold text-white">0 Setup Fees</p>
                  <p className="text-[11px] text-indigo-200">Free Video Hosting</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
                  <p className="text-xl font-bold text-white">Weekly Payouts</p>
                  <p className="text-[11px] text-indigo-200">Direct to Bank / UPI</p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col items-center justify-center gap-3">
              <button
                onClick={() => openAuthModal('educator-signup')}
                className="w-full py-4 px-6 bg-white text-indigo-900 hover:bg-indigo-50 font-black text-sm rounded-2xl shadow-xl transition-all cursor-pointer text-center"
              >
                Apply to Teach on EduRise &rarr;
              </button>
              <p className="text-[11px] text-indigo-200 text-center">
                Fast 24-hour verification & course approval
              </p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
