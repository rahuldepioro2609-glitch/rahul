import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Briefcase,
  Video,
  Plus,
  UploadCloud,
  DollarSign,
  TrendingUp,
  Users,
  CheckCircle2,
  Clock,
  Layers,
  ArrowRight,
  ShieldCheck,
  Building2,
  Smartphone,
  Trash2,
  Edit3,
  HelpCircle,
  FileText,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { COURSE_CATEGORIES } from '../data/seedData';
import { Course, CourseStatus, CourseCategory } from '../types';
import confetti from 'canvas-confetti';

export const EducatorDashboard: React.FC = () => {
  const {
    currentUser,
    courses,
    createCourse,
    withdrawals,
    requestWithdrawal,
    uploadTasks,
    startVideoUpload,
    navigateTo,
    addNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'my-courses' | 'create-course' | 'upload-video' | 'earnings' | 'analytics'
  >('my-courses');

  // Educator's Courses
  const myCourses = courses.filter(c => c.educatorId === currentUser.id);

  // New Course Builder State
  const [courseTitle, setCourseTitle] = useState('');
  const [courseSubtitle, setCourseSubtitle] = useState('');
  const [courseCategory, setCourseCategory] = useState<CourseCategory>('Programming');
  const [courseLevel, setCourseLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels'>('Beginner');
  const [coursePrice, setCoursePrice] = useState('1499');
  const [courseDescription, setCourseDescription] = useState('');
  const [whatYouLearnInput, setWhatYouLearnInput] = useState('Master core principles from scratch\nBuild 3 real-world portfolio projects\nAce technical interviews');
  const [requirementsInput, setRequirementsInput] = useState('Basic computer literacy\nNo prior coding experience needed');
  const [courseThumbnail, setCourseThumbnail] = useState('https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80');

  // Temporary builder chapters
  const [builderChapters, setBuilderChapters] = useState<
    Array<{ id: string; title: string; lectures: Array<{ id: string; title: string; duration: string; videoUrl: string; isFreePreview: boolean }> }>
  >([
    {
      id: 'ch_temp_1',
      title: 'Introduction & Environment Setup',
      lectures: [
        { id: 'lec_temp_1', title: 'Course Orientation & Setup', duration: '12:40', videoUrl: 'https://www.youtube-nocookie.com/embed/kqtD5dpn9C8', isFreePreview: true },
        { id: 'lec_temp_2', title: 'Core Concepts & First Project', duration: '20:15', videoUrl: 'https://www.youtube-nocookie.com/embed/kqtD5dpn9C8', isFreePreview: false }
      ]
    }
  ]);

  // Video Upload State
  const [uploadFileName, setUploadFileName] = useState('');
  const [uploadLectureTitle, setUploadLectureTitle] = useState('');
  const [uploadSelectedCourseId, setUploadSelectedCourseId] = useState(myCourses[0]?.id || 'course_python_bootcamp');
  const [uploadIsFreePreview, setUploadIsFreePreview] = useState(false);

  // Payout Request State
  const [payoutAmount, setPayoutAmount] = useState('15000');
  const [payoutMethod, setPayoutMethod] = useState<'UPI' | 'Bank Transfer'>('UPI');
  const [payoutDetail, setPayoutDetail] = useState('ananya.verma@oksbi');
  const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);

  // Financials
  const totalStudentsCount = myCourses.reduce((sum, c) => sum + c.studentsCount, 0);
  const totalGrossRevenue = myCourses.reduce((sum, c) => sum + c.price * c.studentsCount, 0);
  const educatorNetEarnings = Math.round(totalGrossRevenue * 0.8);
  const availablePayout = Math.max(25000, educatorNetEarnings - 50000);

  // Add Chapter to builder
  const handleAddChapter = () => {
    setBuilderChapters(prev => [
      ...prev,
      {
        id: `ch_temp_${Date.now()}`,
        title: `Section ${prev.length + 1}: Next Core Module`,
        lectures: [
          {
            id: `lec_temp_${Date.now()}`,
            title: 'Foundations & Hands-on Implementation',
            duration: '18:30',
            videoUrl: 'https://www.youtube-nocookie.com/embed/kqtD5dpn9C8',
            isFreePreview: false
          }
        ]
      }
    ]);
  };

  // Add Lecture to Chapter
  const handleAddLecture = (chapterIndex: number) => {
    const updated = [...builderChapters];
    updated[chapterIndex].lectures.push({
      id: `lec_temp_${Date.now()}`,
      title: `Lecture ${updated[chapterIndex].lectures.length + 1}: Deep Dive`,
      duration: '15:00',
      videoUrl: 'https://www.youtube-nocookie.com/embed/kqtD5dpn9C8',
      isFreePreview: false
    });
    setBuilderChapters(updated);
  };

  // Submit Course for Review
  const handleCreateCourseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseTitle.trim()) {
      alert('Please provide a course title.');
      return;
    }

    const newCourseData: Partial<Course> = {
      title: courseTitle,
      subtitle: courseSubtitle || 'Comprehensive hands-on recorded masterclass.',
      description: courseDescription || 'Learn industry-standard workflows from scratch with real code and projects.',
      category: courseCategory,
      level: courseLevel,
      language: 'English',
      price: Number(coursePrice) || 1499,
      originalPrice: (Number(coursePrice) || 1499) + 1500,
      thumbnail: courseThumbnail,
      whatYouWillLearn: whatYouLearnInput.split('\n').filter(s => s.trim().length > 0),
      requirements: requirementsInput.split('\n').filter(s => s.trim().length > 0),
      chapters: builderChapters.map((ch, idx) => ({
        id: `ch_${idx + 1}_${Date.now()}`,
        title: ch.title,
        lectures: ch.lectures.map((lec, lIdx) => ({
          id: `lec_${idx + 1}_${lIdx + 1}_${Date.now()}`,
          title: lec.title,
          duration: lec.duration,
          durationSeconds: 900,
          videoUrl: lec.videoUrl,
          videoType: 'youtube',
          description: 'Comprehensive guided lesson.',
          isFreePreview: lec.isFreePreview,
          summary: 'In this lecture, students will master fundamental principles step by step.'
        }))
      }))
    };

    createCourse(newCourseData);
    addNotification(
      'success',
      'Course Submitted for Admin Review',
      'Your course has been sent to the EduRise Admin queue for verification and publishing!'
    );
    confetti({ particleCount: 50, spread: 60 });
    setActiveTab('my-courses');
  };

  // Trigger Video Upload
  const handleStartUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFileName && !uploadLectureTitle) {
      alert('Please provide a file name or select a file.');
      return;
    }

    startVideoUpload(
      { name: uploadFileName || 'lecture_video_hd.mp4', size: 1024 * 1024 * 180 },
      uploadSelectedCourseId,
      'ch_1',
      uploadLectureTitle || 'New Master Lecture',
      'Detailed lesson recording.',
      uploadIsFreePreview
    );

    setUploadFileName('');
    setUploadLectureTitle('');
  };

  // Submit Payout Request
  const handlePayoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = Number(payoutAmount);
    if (!amountNum || amountNum <= 0) return;

    requestWithdrawal(amountNum, payoutMethod, payoutDetail);
    setIsPayoutModalOpen(false);
    confetti({ particleCount: 40, spread: 50 });
  };

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* 1. EDUCATOR BANNER */}
        <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl border border-purple-900/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-4 ring-purple-500/30"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                  {currentUser.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-400/30">
                  Verified Educator
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Educator Control Center &bull; Manage recorded video courses, upload content, and track revenue.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('create-course')}
              className="px-5 py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-2xl shadow-lg shadow-purple-600/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Course</span>
            </button>
            <button
              onClick={() => setActiveTab('upload-video')}
              className="px-4 py-3 bg-white/10 hover:bg-white/15 text-white font-bold text-xs rounded-2xl border border-white/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Video</span>
            </button>
          </div>
        </div>

        {/* 2. TOP METRICS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Students</span>
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">{totalStudentsCount.toLocaleString()}</p>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">+32 new this week</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Gross Revenue</span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">₹{totalGrossRevenue.toLocaleString()}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Total course sales</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Educator Earnings (80%)</span>
              <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-purple-700 mt-2 font-display">₹{educatorNetEarnings.toLocaleString()}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">After 20% platform share</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Available for Payout</span>
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                <Building2 className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">₹{availablePayout.toLocaleString()}</p>
            <button
              onClick={() => setIsPayoutModalOpen(true)}
              className="text-[11px] text-indigo-600 font-bold hover:underline mt-0.5 block cursor-pointer"
            >
              Withdraw Payout &rarr;
            </button>
          </div>
        </div>

        {/* 3. TABS NAVIGATION */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'my-courses', label: `My Courses (${myCourses.length})`, icon: Layers },
            { id: 'create-course', label: 'Course Builder', icon: Plus },
            { id: 'upload-video', label: `Upload Content (${uploadTasks.length} in queue)`, icon: Video },
            { id: 'earnings', label: 'Earnings & Payouts', icon: DollarSign },
            { id: 'analytics', label: 'Student Insights', icon: TrendingUp }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-purple-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-white hover:text-slate-900'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* 4. TAB CONTENTS */}

        {/* TAB 1: MY COURSES */}
        {activeTab === 'my-courses' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 font-display">Your Uploaded Courses</h2>
                <p className="text-xs text-slate-500">Live published courses and pending administrator approval requests.</p>
              </div>
              <button
                onClick={() => setActiveTab('create-course')}
                className="px-4 py-2 bg-purple-600 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Course</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3">Course</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3">Price</th>
                    <th className="px-6 py-3">Enrolled Students</th>
                    <th className="px-6 py-3">Rating</th>
                    <th className="px-6 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {myCourses.map(course => (
                    <tr key={course.id} className="hover:bg-slate-50/50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={course.thumbnail}
                            alt={course.title}
                            className="w-12 h-12 rounded-xl object-cover shrink-0"
                          />
                          <div>
                            <p className="font-bold text-slate-900">{course.title}</p>
                            <span className="text-[11px] text-slate-500">{course.category} &bull; {course.totalDuration}</span>
                          </div>
                        </div>
                      </td>

                      <td className="px-6 py-4">
                        {course.status === 'published' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Published</span>
                          </span>
                        )}
                        {course.status === 'pending_approval' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                            <Clock className="w-3 h-3 text-amber-600" />
                            <span>Pending Approval</span>
                          </span>
                        )}
                        {course.status === 'draft' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                            <span>Draft</span>
                          </span>
                        )}
                      </td>

                      <td className="px-6 py-4 font-bold text-slate-900">₹{course.price}</td>
                      <td className="px-6 py-4 font-mono font-bold text-slate-800">
                        {course.studentsCount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-amber-500 font-bold">
                        ⭐ {course.rating} ({course.ratingCount})
                      </td>

                      <td className="px-6 py-4 text-right space-x-2">
                        <button
                          onClick={() => navigateTo('course-detail', course.id)}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          View Live
                        </button>
                        <button
                          onClick={() => {
                            setUploadSelectedCourseId(course.id);
                            setActiveTab('upload-video');
                          }}
                          className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          + Upload Video
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: COURSE BUILDER */}
        {activeTab === 'create-course' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-8">
            <div>
              <div className="flex items-center gap-2 text-purple-600 text-xs font-bold uppercase tracking-wider mb-1">
                <Plus className="w-4 h-4" />
                <span>Educator Course Studio</span>
              </div>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                Create & Publish a Recorded Masterclass
              </h2>
              <p className="text-xs text-slate-500">
                Structure your syllabus, set pricing, add recorded lectures, and submit to Admin for approval.
              </p>
            </div>

            <form onSubmit={handleCreateCourseSubmit} className="space-y-6">
              
              {/* Step 1: Basic Information */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <h3 className="text-sm font-bold text-slate-900">Step 1: Course Overview & Pricing</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">Course Title</label>
                    <input
                      type="text"
                      required
                      value={courseTitle}
                      onChange={e => setCourseTitle(e.target.value)}
                      placeholder="e.g. Master Flutter & Dart with Clean Architecture"
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs focus:border-purple-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">Catchy Subtitle</label>
                    <input
                      type="text"
                      value={courseSubtitle}
                      onChange={e => setCourseSubtitle(e.target.value)}
                      placeholder="e.g. Build 5 production mobile apps and deploy to App Store & Play Store"
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
                    <select
                      value={courseCategory}
                      onChange={e => setCourseCategory(e.target.value as any)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800"
                    >
                      {COURSE_CATEGORIES.map(c => (
                        <option key={c.name} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Skill Level</label>
                    <select
                      value={courseLevel}
                      onChange={e => setCourseLevel(e.target.value as any)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800"
                    >
                      <option value="Beginner">Beginner</option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Advanced">Advanced</option>
                      <option value="All Levels">All Levels</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Course Price (INR ₹)</label>
                    <input
                      type="number"
                      required
                      value={coursePrice}
                      onChange={e => setCoursePrice(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Thumbnail Image URL</label>
                    <input
                      type="url"
                      value={courseThumbnail}
                      onChange={e => setCourseThumbnail(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-600"
                    />
                  </div>
                </div>
              </div>

              {/* Step 2: Learning Outcomes & Requirements */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <h3 className="text-sm font-bold text-slate-900">Step 2: Learning Objectives & Requirements</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">What will students learn? (1 per line)</label>
                    <textarea
                      rows={3}
                      value={whatYouLearnInput}
                      onChange={e => setWhatYouLearnInput(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Requirements / Prerequisites (1 per line)</label>
                    <textarea
                      rows={3}
                      value={requirementsInput}
                      onChange={e => setRequirementsInput(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs leading-relaxed"
                    />
                  </div>
                </div>
              </div>

              {/* Step 3: Chapter & Lectures Builder */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900">Step 3: Curriculum & Chapters</h3>
                  <button
                    type="button"
                    onClick={handleAddChapter}
                    className="px-3 py-1.5 bg-purple-600 text-white text-xs font-bold rounded-xl flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Section</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {builderChapters.map((chapter, chIdx) => (
                    <div key={chapter.id} className="p-4 bg-white rounded-2xl border border-slate-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <input
                          type="text"
                          value={chapter.title}
                          onChange={e => {
                            const updated = [...builderChapters];
                            updated[chIdx].title = e.target.value;
                            setBuilderChapters(updated);
                          }}
                          className="font-bold text-xs text-slate-900 bg-slate-100 p-2 rounded-lg flex-1 mr-3"
                        />
                        <button
                          type="button"
                          onClick={() => handleAddLecture(chIdx)}
                          className="text-xs text-purple-700 font-bold hover:underline cursor-pointer"
                        >
                          + Add Lecture
                        </button>
                      </div>

                      {/* Lectures in chapter */}
                      <div className="space-y-2 pl-3 border-l-2 border-purple-200">
                        {chapter.lectures.map((lec, lIdx) => (
                          <div key={lec.id} className="flex items-center gap-3 text-xs bg-slate-50 p-2 rounded-xl">
                            <Video className="w-3.5 h-3.5 text-slate-500" />
                            <input
                              type="text"
                              value={lec.title}
                              onChange={e => {
                                const updated = [...builderChapters];
                                updated[chIdx].lectures[lIdx].title = e.target.value;
                                setBuilderChapters(updated);
                              }}
                              className="bg-white border border-slate-200 rounded p-1 text-xs flex-1"
                            />
                            <label className="flex items-center gap-1 text-[11px] text-slate-600 font-semibold cursor-pointer">
                              <input
                                type="checkbox"
                                checked={lec.isFreePreview}
                                onChange={e => {
                                  const updated = [...builderChapters];
                                  updated[chIdx].lectures[lIdx].isFreePreview = e.target.checked;
                                  setBuilderChapters(updated);
                                }}
                              />
                              <span>Free Preview</span>
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-100">
                <p className="text-xs text-slate-500">
                  Note: All submitted courses are reviewed by EduRise Admin within 24 hours.
                </p>
                <button
                  type="submit"
                  className="px-8 py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-extrabold text-xs rounded-2xl shadow-lg transition-all flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submit Course for Admin Approval</span>
                </button>
              </div>

            </form>
          </div>
        )}

        {/* TAB 3: UPLOAD CONTENT PIPELINE */}
        {activeTab === 'upload-video' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-8">
            <div>
              <div className="flex items-center gap-2 text-purple-600 text-xs font-bold uppercase tracking-wider mb-1">
                <Video className="w-4 h-4" />
                <span>Content Video Pipeline</span>
              </div>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                Upload & Process High-Definition Lectures
              </h2>
              <p className="text-xs text-slate-500">
                Automated multi-stage transcoding (1080p / 720p / HLS Adaptive Bitrate) and AI lecture summary generator.
              </p>
            </div>

            {/* Video Dropzone Form */}
            <form onSubmit={handleStartUpload} className="p-6 rounded-3xl border-2 border-dashed border-purple-300 bg-purple-50/30 space-y-4 text-center">
              <div className="w-14 h-14 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center mx-auto mb-2">
                <UploadCloud className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">Drag and drop your lecture video here</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Supports MP4, MOV, MKV up to 4GB. High-speed multi-part upload.
              </p>

              <div className="max-w-md mx-auto grid grid-cols-1 gap-3 pt-3 text-left">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Select Target Course</label>
                  <select
                    value={uploadSelectedCourseId}
                    onChange={e => setUploadSelectedCourseId(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800"
                  >
                    {myCourses.map(c => (
                      <option key={c.id} value={c.id}>{c.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Lecture Title</label>
                  <input
                    type="text"
                    required
                    value={uploadLectureTitle}
                    onChange={e => setUploadLectureTitle(e.target.value)}
                    placeholder="e.g. Convolutional Neural Networks & Feature Maps"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Video File Name</label>
                  <input
                    type="text"
                    value={uploadFileName}
                    onChange={e => setUploadFileName(e.target.value)}
                    placeholder="e.g. lecture_04_cnn_architectures.mp4"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="freePreviewCheck"
                    checked={uploadIsFreePreview}
                    onChange={e => setUploadIsFreePreview(e.target.checked)}
                  />
                  <label htmlFor="freePreviewCheck" className="text-xs font-semibold text-slate-700 cursor-pointer">
                    Enable as Free Preview for unenrolled students
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>Start Video Encoding Pipeline</span>
                </button>
              </div>
            </form>

            {/* Active & Historical Upload Pipeline Tasks */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Upload & Transcoding Tasks</h3>
              {uploadTasks.map(task => (
                <div key={task.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <Video className="w-4 h-4 text-purple-600" />
                      <span className="font-bold text-slate-900">{task.lectureTitle}</span>
                      <span className="text-slate-400 font-mono">({task.file.name})</span>
                    </div>

                    <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                      task.status === 'published'
                        ? 'bg-emerald-100 text-emerald-800'
                        : task.status === 'processing'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {task.status} ({task.progress}%)
                    </span>
                  </div>

                  <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        task.status === 'published' ? 'bg-emerald-500' : 'bg-purple-600'
                      }`}
                      style={{ width: `${task.progress}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* TAB 4: EARNINGS & PAYOUTS */}
        {activeTab === 'earnings' && (
          <div className="space-y-8">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 font-display">
                    Earnings & Marketplace Payouts
                  </h2>
                  <p className="text-xs text-slate-500">
                    EduRise operates on a creator-first 80% educator commission model with instant UPI/NEFT withdrawals.
                  </p>
                </div>

                <button
                  onClick={() => setIsPayoutModalOpen(true)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>Request Withdrawal</span>
                </button>
              </div>

              {/* Commission Breakdown Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-100">
                  <span className="text-[11px] font-bold uppercase text-purple-700">Educator Share</span>
                  <p className="text-2xl font-black text-purple-950 mt-1 font-display">80%</p>
                  <p className="text-[11px] text-purple-800 mt-1">Directly credited per transaction</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[11px] font-bold uppercase text-slate-600">Platform Infrastructure</span>
                  <p className="text-2xl font-black text-slate-900 mt-1 font-display">20%</p>
                  <p className="text-[11px] text-slate-600 mt-1">Covers CDN, AI tutoring, & payment gateway</p>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100">
                  <span className="text-[11px] font-bold uppercase text-emerald-700">Available Balance</span>
                  <p className="text-2xl font-black text-emerald-950 mt-1 font-display">₹{availablePayout.toLocaleString()}</p>
                  <p className="text-[11px] text-emerald-800 mt-1">Ready for transfer</p>
                </div>
              </div>

              {/* Payout History */}
              <div className="pt-6 border-t border-slate-100">
                <h3 className="text-sm font-bold text-slate-900 mb-3">Withdrawal Settlements</h3>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden">
                  {withdrawals.map(p => (
                    <div key={p.id} className="p-4 bg-white flex items-center justify-between text-xs">
                      <div>
                        <span className="font-mono font-bold text-slate-900">{p.id}</span>
                        <p className="text-[11px] text-slate-500">{p.requestedAt} &bull; {p.method} ({p.accountDetails})</p>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-slate-900">₹{p.amount.toLocaleString()}</span>
                        <span className={`block text-[10px] font-bold uppercase ${
                          p.status === 'PROCESSED' ? 'text-emerald-600' : 'text-amber-600'
                        }`}>
                          {p.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: STUDENT INSIGHTS */}
        {activeTab === 'analytics' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-6">
            <h2 className="text-lg font-bold text-slate-900 font-display">Student Retention & Performance</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold">Course Completion Rate</span>
                <p className="text-2xl font-black text-slate-900 mt-1 font-display">78.4%</p>
                <p className="text-[11px] text-emerald-600 font-semibold mt-1">2.3x higher than industry average</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold">AI Tutor Questions Resolved</span>
                <p className="text-2xl font-black text-indigo-600 mt-1 font-display">4,280+</p>
                <p className="text-[11px] text-slate-500 mt-1">Across all lecture modules</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold">Average Student Rating</span>
                <p className="text-2xl font-black text-amber-500 mt-1 font-display">4.94 ⭐</p>
                <p className="text-[11px] text-slate-500 mt-1">Based on 1,420 ratings</p>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* WITHDRAWAL MODAL */}
      {isPayoutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 relative">
            <button
              onClick={() => setIsPayoutModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-800"
            >
              ✕
            </button>

            <h3 className="text-base font-bold text-slate-900 mb-1">Request Educator Payout</h3>
            <p className="text-xs text-slate-500 mb-4">Available balance: ₹{availablePayout.toLocaleString()}</p>

            <form onSubmit={handlePayoutSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Amount to Withdraw (₹)</label>
                <input
                  type="number"
                  required
                  value={payoutAmount}
                  onChange={e => setPayoutAmount(e.target.value)}
                  max={availablePayout}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Transfer Method</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('UPI')}
                    className={`p-2 rounded-xl border text-center font-bold ${
                      payoutMethod === 'UPI' ? 'border-purple-600 bg-purple-50 text-purple-700' : 'border-slate-200'
                    }`}
                  >
                    UPI ID
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('Bank Transfer')}
                    className={`p-2 rounded-xl border text-center font-bold ${
                      payoutMethod === 'Bank Transfer' ? 'border-purple-600 bg-purple-50 text-purple-700' : 'border-slate-200'
                    }`}
                  >
                    Bank Account (NEFT)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {payoutMethod === 'UPI' ? 'UPI Virtual Payment Address' : 'Bank Account No. & IFSC'}
                </label>
                <input
                  type="text"
                  required
                  value={payoutDetail}
                  onChange={e => setPayoutDetail(e.target.value)}
                  placeholder={payoutMethod === 'UPI' ? 'name@okhdfcbank' : 'A/C: 501002938192 | IFSC: HDFC0000123'}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-md cursor-pointer"
              >
                Confirm Withdrawal
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
