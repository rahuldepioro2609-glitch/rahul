import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { CourseCard } from '../components/CourseCard';
import { COURSE_CATEGORIES } from '../data/seedData';
import {
  Search,
  Filter,
  SlidersHorizontal,
  Star,
  Check,
  RotateCcw,
  Sparkles,
  Layers,
  ChevronDown
} from 'lucide-react';
import { CourseCategory, CourseLevel } from '../types';

export const CourseDiscoveryPage: React.FC = () => {
  const { courses, navigateTo } = useApp();

  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('All');
  const [minRating, setMinRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'popular' | 'rating' | 'newest' | 'price-low' | 'price-high'>('popular');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Filter Logic
  const filteredCourses = useMemo(() => {
    return courses
      .filter(course => {
        // Only published courses in discovery
        if (course.status !== 'published') return false;

        // Search title, educator, description, category
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesTitle = course.title.toLowerCase().includes(q);
          const matchesEducator = course.educatorName.toLowerCase().includes(q);
          const matchesDesc = course.description.toLowerCase().includes(q);
          const matchesCat = course.category.toLowerCase().includes(q);
          if (!matchesTitle && !matchesEducator && !matchesDesc && !matchesCat) {
            return false;
          }
        }

        // Category filter
        if (selectedCategory !== 'All' && course.category !== selectedCategory) {
          return false;
        }

        // Level filter
        if (selectedLevel !== 'All' && course.level !== selectedLevel && course.level !== 'All Levels') {
          return false;
        }

        // Language filter
        if (selectedLanguage !== 'All' && course.language !== selectedLanguage) {
          return false;
        }

        // Rating filter
        if (minRating > 0 && course.rating < minRating) {
          return false;
        }

        // Price range filter
        if (selectedPriceRange === 'free' && course.price > 0) return false;
        if (selectedPriceRange === 'under-999' && course.price >= 999) return false;
        if (selectedPriceRange === '1000-2000' && (course.price < 1000 || course.price > 2000)) return false;
        if (selectedPriceRange === 'above-2000' && course.price <= 2000) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'newest') return b.id.localeCompare(a.id);
        if (sortBy === 'price-low') return a.price - b.price;
        if (sortBy === 'price-high') return b.price - a.price;
        return b.studentsCount - a.studentsCount; // default popular
      });
  }, [
    courses,
    searchQuery,
    selectedCategory,
    selectedLevel,
    selectedLanguage,
    selectedPriceRange,
    minRating,
    sortBy
  ]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedLevel('All');
    setSelectedLanguage('All');
    setSelectedPriceRange('All');
    setMinRating(0);
    setSortBy('popular');
  };

  const activeFiltersCount =
    (selectedCategory !== 'All' ? 1 : 0) +
    (selectedLevel !== 'All' ? 1 : 0) +
    (selectedLanguage !== 'All' ? 1 : 0) +
    (selectedPriceRange !== 'All' ? 1 : 0) +
    (minRating > 0 ? 1 : 0) +
    (searchQuery ? 1 : 0);

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* 1. TOP HEADER & SEARCH BAR */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
                Discover Expert-Led Masterclasses
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Explore thousands of comprehensive recorded video courses created by verified teachers.
              </p>
            </div>

            {/* AI Assistant Quick Trigger */}
            <button
              onClick={() => navigateTo('ai-hub')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 text-xs font-bold transition-colors cursor-pointer w-fit"
            >
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>AI Course Matchmaker</span>
            </button>
          </div>

          {/* Search Input Bar */}
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by topic, instructor name, programming language, or exam..."
              className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-indigo-500 focus:bg-white transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Chips Bar */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === 'All'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Categories
            </button>
            {COURSE_CATEGORIES.map(cat => (
              <button
                key={cat.name}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectedCategory === cat.name
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 2. MAIN LAYOUT: SIDEBAR FILTERS (Left) + COURSE RESULTS (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
          
          {/* DESKTOP SIDEBAR FILTERS */}
          <aside className="hidden lg:block bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-6 sticky top-24">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
                <span>Filter Courses</span>
                {activeFiltersCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-mono">
                    {activeFiltersCount}
                  </span>
                )}
              </div>

              {activeFiltersCount > 0 && (
                <button
                  onClick={handleResetFilters}
                  className="text-xs text-indigo-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              )}
            </div>

            {/* Level Filter */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Skill Level
              </label>
              <div className="space-y-1 text-xs text-slate-600">
                {['All', 'Beginner', 'Intermediate', 'Advanced'].map(lvl => (
                  <label key={lvl} className="flex items-center gap-2 cursor-pointer py-1">
                    <input
                      type="radio"
                      name="levelFilter"
                      checked={selectedLevel === lvl}
                      onChange={() => setSelectedLevel(lvl)}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>{lvl}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Price Range Filter */}
            <div className="space-y-2 border-t border-slate-100 pt-4">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Price Range
              </label>
              <div className="space-y-1 text-xs text-slate-600">
                {[
                  { id: 'All', label: 'Any Price' },
                  { id: 'under-999', label: 'Under ₹999' },
                  { id: '1000-2000', label: '₹1,000 - ₹2,000' },
                  { id: 'above-2000', label: 'Above ₹2,000' }
                ].map(p => (
                  <label key={p.id} className="flex items-center gap-2 cursor-pointer py-1">
                    <input
                      type="radio"
                      name="priceFilter"
                      checked={selectedPriceRange === p.id}
                      onChange={() => setSelectedPriceRange(p.id)}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>{p.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Minimum Rating Filter */}
            <div className="space-y-2 border-t border-slate-100 pt-4">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Minimum Rating
              </label>
              <div className="space-y-1.5 text-xs">
                {[
                  { val: 4.5, label: '4.5 & up ⭐' },
                  { val: 4.0, label: '4.0 & up ⭐' },
                  { val: 0, label: 'All Ratings' }
                ].map(r => (
                  <button
                    key={r.val}
                    onClick={() => setMinRating(r.val)}
                    className={`w-full text-left px-3 py-1.5 rounded-xl font-semibold flex items-center justify-between cursor-pointer ${
                      minRating === r.val
                        ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{r.label}</span>
                    {minRating === r.val && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Language Filter */}
            <div className="space-y-2 border-t border-slate-100 pt-4">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Language
              </label>
              <select
                value={selectedLanguage}
                onChange={e => setSelectedLanguage(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:border-indigo-500"
              >
                <option value="All">All Languages</option>
                <option value="English">English</option>
                <option value="Hinglish">Hinglish</option>
                <option value="Hindi">Hindi</option>
              </select>
            </div>
          </aside>

          {/* RIGHT: COURSE RESULTS GRID */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Sort & Count Header */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-600 font-semibold">
                Showing <strong className="text-slate-900">{filteredCourses.length}</strong> available courses
              </span>

              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-500 font-medium">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value as any)}
                  className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800 font-semibold focus:border-indigo-500 cursor-pointer"
                >
                  <option value="popular">Most Popular</option>
                  <option value="rating">Highest Rated</option>
                  <option value="newest">Newest Releases</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
            </div>

            {/* Courses Grid */}
            {filteredCourses.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  No courses found matching your criteria
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Try clearing your filters or searching for alternative topics like Python, JEE Physics, or React.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredCourses.map(course => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
