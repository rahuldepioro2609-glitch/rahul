import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AITutorDrawer } from '../components/AITutorDrawer';
import {
  Play,
  CheckCircle2,
  Lock,
  ChevronDown,
  ChevronUp,
  FileText,
  HelpCircle,
  Sparkles,
  Download,
  Share2,
  RotateCcw,
  Maximize,
  Award,
  ArrowLeft,
  MessageSquare,
  BookOpen,
  Plus,
  Trash2
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CoursePlayerPageProps {
  courseId: string;
  initialLectureId?: string;
}

export const CoursePlayerPage: React.FC<CoursePlayerPageProps> = ({
  courseId,
  initialLectureId
}) => {
  const {
    courses,
    navigateTo,
    isEnrolled,
    enrollments,
    markLectureComplete,
    isLectureCompleted,
    saveNote,
    deleteNote,
    notes,
    openPaymentModal
  } = useApp();

  const course = courses.find(c => c.id === courseId) || courses[0];
  const enrolled = isEnrolled(course.id);
  const currentEnrollment = enrollments[course.id];
  const progressPercent = currentEnrollment?.progressPercent || 0;
  const completedLectureIds = currentEnrollment?.completedLectureIds || [];

  // Flatten all lectures to find first or requested
  const allLectures = course.chapters.flatMap(ch => ch.lectures);
  const defaultLecture =
    allLectures.find(l => l.id === initialLectureId) || allLectures[0];

  const [activeLectureId, setActiveLectureId] = useState<string>(defaultLecture?.id || '');
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [activeTab, setActiveTab] = useState<'overview' | 'notes' | 'resources' | 'discussion' | 'quiz'>('overview');
  const [isAITutorOpen, setIsAITutorOpen] = useState(false);

  // Notes state
  const [noteInput, setNoteInput] = useState('');
  const [noteTimestamp, setNoteTimestamp] = useState('04:30');

  // Quiz state
  const [selectedQuizAnswers, setSelectedQuizAnswers] = useState<{ [qIdx: number]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const activeLecture = allLectures.find(l => l.id === activeLectureId) || defaultLecture;
  const courseNotes = notes.filter(n => n.courseId === course.id);
  const totalLecturesCount = allLectures.length;

  const handleLectureSelect = (lectureId: string, isFreePreview: boolean) => {
    if (!enrolled && !isFreePreview) {
      openPaymentModal(course);
      return;
    }
    setActiveLectureId(lectureId);
    setQuizSubmitted(false);
    setSelectedQuizAnswers({});
  };

  const handleToggleComplete = () => {
    markLectureComplete(course.id, activeLecture.id);
    if (progressPercent >= 90) {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
    }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteInput.trim()) return;
    saveNote(course.id, activeLecture.id, noteTimestamp, noteInput.trim());
    setNoteInput('');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      
      {/* 1. TOP PLAYER NAV HEADER */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo('student-dashboard')}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Back to Dashboard"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-sm font-bold text-white truncate max-w-[280px] sm:max-w-md">
              {course.title}
            </h1>
            <p className="text-[11px] text-slate-400 truncate">
              {activeLecture?.title}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Progress Indicator */}
          <div className="hidden sm:flex items-center gap-2 text-xs">
            <span className="text-slate-400">Course Progress:</span>
            <div className="w-24 bg-slate-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-emerald-500 h-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="font-mono font-bold text-emerald-400">{progressPercent}%</span>
          </div>

          {/* AI Tutor Trigger Button */}
          <button
            onClick={() => setIsAITutorOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Tutor</span>
          </button>
        </div>
      </div>

      {/* 2. MAIN PLAYER & CURRICULUM LAYOUT */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* LEFT / CENTER: VIDEO FRAME + DETAILS TABS */}
        <div className="flex-1 flex flex-col overflow-y-auto">
          
          {/* Video Container */}
          <div className="relative aspect-16/9 bg-black flex items-center justify-center">
            {activeLecture?.videoUrl ? (
              <iframe
                src={`${activeLecture.videoUrl}?autoplay=1&rel=0`}
                title={activeLecture.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className="text-center p-8">
                <Play className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                <p className="text-sm font-bold text-slate-400">Video Content Processing</p>
              </div>
            )}

            {/* Unenrolled Banner if locked */}
            {!enrolled && !activeLecture.isFreePreview && (
              <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
                <Lock className="w-12 h-12 text-amber-400 mb-3" />
                <h3 className="text-lg font-bold text-white mb-1">This Lecture is Locked</h3>
                <p className="text-xs text-slate-300 max-w-sm mb-4">
                  Enroll in this course to access all video lectures, downloadable source codes, AI tutoring, and certificates.
                </p>
                <button
                  onClick={() => openPaymentModal(course)}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer"
                >
                  Unlock Full Course (₹{course.price})
                </button>
              </div>
            )}
          </div>

          {/* Video Controls / Info Bar */}
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-bold text-white text-sm">{activeLecture?.title}</span>
              {activeLecture?.isFreePreview && (
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded text-[10px] font-bold">
                  Free Preview
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              {/* Playback speed selector */}
              <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg">
                <span className="text-[10px] text-slate-400">Speed:</span>
                {[0.75, 1.0, 1.25, 1.5, 2.0].map(s => (
                  <button
                    key={s}
                    onClick={() => setPlaybackSpeed(s)}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                      playbackSpeed === s ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>

              {/* Mark Complete Checkbox */}
              {enrolled && (
                <button
                  onClick={handleToggleComplete}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer ${
                    completedLectureIds.includes(activeLecture?.id)
                      ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-indigo-600 text-white hover:bg-indigo-500'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>
                    {completedLectureIds.includes(activeLecture?.id) ? 'Completed' : 'Mark as Done'}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* TABBED SECTION (Below Video) */}
          <div className="bg-slate-900/50 p-4 sm:p-6 flex-1">
            
            {/* Tabs Header */}
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-6 overflow-x-auto no-scrollbar">
              {[
                { id: 'overview', label: 'AI Summary & Overview', icon: Sparkles },
                { id: 'notes', label: `My Notes (${courseNotes.length})`, icon: FileText },
                { id: 'resources', label: `Resources (${activeLecture?.resources?.length || 0})`, icon: Download },
                { id: 'quiz', label: 'Lecture Quiz', icon: HelpCircle },
                { id: 'discussion', label: 'Discussion / Q&A', icon: MessageSquare }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <tab.icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Tab 1: AI Summary & Overview */}
            {activeTab === 'overview' && (
              <div className="space-y-6 max-w-3xl">
                <div className="p-5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-xs leading-relaxed space-y-3">
                  <div className="flex items-center gap-2 text-indigo-300 font-bold">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <span>AI Generated Lecture Summary</span>
                  </div>
                  <p className="text-slate-300">
                    {activeLecture?.summary ||
                      'In this lecture, the instructor introduces the foundational principles of the topic, breaking down core mathematical formulas, real-world examples, and implementation techniques.'}
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white mb-2">About this Lesson</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Instructor: <strong className="text-slate-200">{course.educatorName}</strong> &bull; Length: <strong className="text-slate-200">{activeLecture?.duration}</strong>
                  </p>
                </div>
              </div>
            )}

            {/* Tab 2: Timestamped Notes */}
            {activeTab === 'notes' && (
              <div className="space-y-6 max-w-2xl">
                <form onSubmit={handleAddNote} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white">Create a Note at current timestamp</span>
                    <input
                      type="text"
                      value={noteTimestamp}
                      onChange={e => setNoteTimestamp(e.target.value)}
                      className="w-16 px-2 py-1 bg-slate-800 rounded border border-slate-700 text-center font-mono text-xs text-indigo-300"
                    />
                  </div>
                  <textarea
                    rows={2}
                    value={noteInput}
                    onChange={e => setNoteInput(e.target.value)}
                    placeholder="Type key takeaway, formula, or reminder..."
                    className="w-full p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Save Note</span>
                  </button>
                </form>

                {/* Notes List */}
                <div className="space-y-2">
                  {courseNotes.length === 0 ? (
                    <p className="text-xs text-slate-500 italic">No notes saved for this course yet.</p>
                  ) : (
                    courseNotes.map(note => (
                      <div
                        key={note.id}
                        className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-start justify-between gap-3 text-xs"
                      >
                        <div className="space-y-1">
                          <span className="px-2 py-0.5 rounded bg-indigo-900/60 text-indigo-300 font-mono text-[10px] font-bold">
                            {note.timestamp}
                          </span>
                          <p className="text-slate-200 mt-1">{note.content}</p>
                          <span className="text-[10px] text-slate-500">{note.createdAt}</span>
                        </div>
                        <button
                          onClick={() => deleteNote(note.id)}
                          className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Tab 3: Downloadable Resources */}
            {activeTab === 'resources' && (
              <div className="space-y-3 max-w-xl">
                {activeLecture?.resources && activeLecture.resources.length > 0 ? (
                  activeLecture.resources.map(res => (
                    <div
                      key={res.id}
                      className="p-4 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-indigo-900/40 text-indigo-400 flex items-center justify-center font-bold text-xs uppercase">
                          {res.type}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">{res.title}</p>
                          <p className="text-[11px] text-slate-400 font-mono">{res.size || '1.2 MB'}</p>
                        </div>
                      </div>

                      <a
                        href={res.url}
                        download
                        className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </a>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 italic">No downloadable attachments for this lecture.</p>
                )}
              </div>
            )}

            {/* Tab 4: Lecture Quiz */}
            {activeTab === 'quiz' && (
              <div className="space-y-6 max-w-2xl">
                {activeLecture?.quiz ? (
                  <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800 space-y-5">
                    <div>
                      <h3 className="text-sm font-bold text-white">{activeLecture.quiz.title}</h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Test your understanding of this lecture. Passing score: {activeLecture.quiz.passingScore}%
                      </p>
                    </div>

                    <div className="space-y-4">
                      {activeLecture.quiz.questions.map((q, qIdx) => (
                        <div key={q.id} className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700/60 space-y-2.5">
                          <p className="text-xs font-bold text-white">
                            {qIdx + 1}. {q.question}
                          </p>
                          <div className="space-y-1.5">
                            {q.options.map((opt, optIdx) => {
                              const isSelected = selectedQuizAnswers[qIdx] === optIdx;
                              const isCorrect = q.correctAnswerIndex === optIdx;

                              return (
                                <button
                                  key={optIdx}
                                  type="button"
                                  onClick={() => {
                                    if (!quizSubmitted) {
                                      setSelectedQuizAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
                                    }
                                  }}
                                  className={`w-full p-2.5 rounded-xl text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                                    quizSubmitted
                                      ? isCorrect
                                        ? 'bg-emerald-950/70 border border-emerald-500/50 text-emerald-200'
                                        : isSelected
                                        ? 'bg-rose-950/70 border border-rose-500/50 text-rose-200'
                                        : 'bg-slate-900 text-slate-400'
                                      : isSelected
                                      ? 'bg-indigo-600 text-white font-bold'
                                      : 'bg-slate-900 text-slate-300 hover:bg-slate-700'
                                  }`}
                                >
                                  <span>{opt}</span>
                                  {quizSubmitted && isCorrect && (
                                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                  )}
                                </button>
                              );
                            })}
                          </div>

                          {quizSubmitted && (
                            <p className="text-[11px] text-slate-300 mt-2 p-2 bg-slate-900/80 rounded-lg border border-slate-700">
                              💡 <strong>Explanation:</strong> {q.explanation}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>

                    {!quizSubmitted ? (
                      <button
                        onClick={() => {
                          setQuizSubmitted(true);
                          confetti({ particleCount: 40, spread: 50, origin: { y: 0.6 } });
                        }}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer"
                      >
                        Submit Answers
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setQuizSubmitted(false);
                          setSelectedQuizAnswers({});
                        }}
                        className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                      >
                        Retry Quiz
                      </button>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic">No quiz attached to this lecture.</p>
                )}
              </div>
            )}

            {/* Tab 5: Discussion */}
            {activeTab === 'discussion' && (
              <div className="space-y-4 max-w-2xl text-xs">
                <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 flex gap-3">
                  <input
                    type="text"
                    placeholder="Ask a question about this lecture..."
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white"
                  />
                  <button className="px-4 py-2 bg-indigo-600 text-white font-bold rounded-xl">
                    Post
                  </button>
                </div>
                <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">Rohit Sharma</span>
                    <span className="text-[10px] text-slate-500">2 days ago</span>
                  </div>
                  <p className="text-slate-300">
                    Why do we prefer PyTorch tensors over standard NumPy arrays when doing backprop?
                  </p>
                  <div className="pl-3 border-l-2 border-indigo-500 mt-2 text-slate-400">
                    <strong className="text-indigo-300">Ananya Verma (Instructor):</strong> Because PyTorch tensors natively store computational graphs for autograd and run seamlessly on CUDA GPUs!
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* RIGHT: COURSE CURRICULUM SIDEBAR (Fixed width) */}
        <div className="w-full lg:w-96 bg-slate-900 border-l border-slate-800 flex flex-col h-auto lg:h-full">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Course Content ({totalLecturesCount} Lectures)
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-2 max-h-[500px] lg:max-h-none">
            {course.chapters.map((chapter, chIdx) => (
              <div key={chapter.id} className="rounded-xl bg-slate-800/50 border border-slate-800 overflow-hidden">
                <div className="px-3 py-2 bg-slate-800 text-[11px] font-bold text-slate-300 flex items-center justify-between">
                  <span>Section {chIdx + 1}: {chapter.title}</span>
                  <span className="text-[10px] text-slate-500">{chapter.lectures.length}</span>
                </div>

                <div className="p-1 divide-y divide-slate-800/60">
                  {chapter.lectures.map(lecture => {
                    const isActive = lecture.id === activeLectureId;
                    const isDone = completedLectureIds.includes(lecture.id);

                    return (
                      <button
                        key={lecture.id}
                        onClick={() => handleLectureSelect(lecture.id, lecture.isFreePreview)}
                        className={`w-full p-2.5 rounded-lg text-left text-xs transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                          isActive
                            ? 'bg-indigo-600/30 text-indigo-200 font-bold border border-indigo-500/40'
                            : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <Play className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          )}
                          <span className="truncate">{lecture.title}</span>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono">
                          {!enrolled && !lecture.isFreePreview && (
                            <Lock className="w-3 h-3 text-amber-500" />
                          )}
                          <span>{lecture.duration}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Interactive AI Tutor Drawer */}
      <AITutorDrawer
        courseTitle={course.title}
        lectureTitle={activeLecture?.title}
        lectureSummary={activeLecture?.summary}
        isOpen={isAITutorOpen}
        onClose={() => setIsAITutorOpen(false)}
      />

    </div>
  );
};
