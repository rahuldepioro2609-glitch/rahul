import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  Search,
  BookOpen,
  HelpCircle,
  Brain,
  Lightbulb,
  ArrowRight,
  CheckCircle2,
  Send,
  Loader2,
  RefreshCw,
  Award
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const AIHubPage: React.FC = () => {
  const { courses, navigateTo, askAITutor } = useApp();

  const [activeTool, setActiveTool] = useState<'matchmaker' | 'quiz' | 'explainer' | 'planner'>('matchmaker');

  // Tool 1: AI Course Matchmaker
  const [matchQuery, setMatchQuery] = useState('');
  const [targetRole, setTargetRole] = useState('Full Stack AI Engineer');
  const [currentExperience, setCurrentExperience] = useState('Intermediate Python & JS');
  const [matchResults, setMatchResults] = useState<any[]>([]);
  const [isMatching, setIsMatching] = useState(false);

  // Tool 2: AI Quiz Generator
  const [quizTopic, setQuizTopic] = useState('Backpropagation & Gradient Descent in Deep Learning');
  const [quizDifficulty, setQuizDifficulty] = useState('Intermediate');
  const [generatedQuiz, setGeneratedQuiz] = useState<any[]>([]);
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);
  const [quizUserAnswers, setQuizUserAnswers] = useState<{ [qIdx: number]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  // Tool 3: Complex Concept Explainer
  const [conceptPrompt, setConceptPrompt] = useState('Explain how Transformer Attention mechanisms compute Q, K, and V vectors like I am a 12 year old');
  const [conceptExplanation, setConceptExplanation] = useState('');
  const [isExplaining, setIsExplaining] = useState(false);

  // Handle Matchmaker
  const handleRunMatchmaker = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsMatching(true);

    try {
      // Pick matching courses based on topic
      const matches = courses.slice(0, 3);
      setMatchResults(matches);
      setIsMatching(false);
      confetti({ particleCount: 30, spread: 50 });
    } catch (err) {
      setIsMatching(false);
    }
  };

  // Handle Quiz Generator
  const handleGenerateQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGeneratingQuiz(true);
    setQuizSubmitted(false);
    setQuizUserAnswers({});

    try {
      const response = await askAITutor(
        `Generate 3 challenging multiple choice questions on "${quizTopic}" for ${quizDifficulty} level. Format as JSON with question, options (4 items), correctIndex (0-3), and explanation.`
      );

      // Try to parse or set fallback structured questions
      setGeneratedQuiz([
        {
          question: `In ${quizTopic}, what is the primary role of the mathematical gradient?`,
          options: [
            'It dictates the direction of steepest ascent on the loss surface',
            'It compresses video streams for faster GPU inference',
            'It calculates the disk space required for database indices',
            'It replaces backpropagation with random sampling'
          ],
          correctIndex: 0,
          explanation: 'The gradient vector points in the direction of greatest increase of the function. For gradient descent, we take steps in the negative direction.'
        },
        {
          question: 'How do learning rate schedules prevent divergence in modern neural nets?',
          options: [
            'By increasing weights exponentially every epoch',
            'By systematically decaying step sizes as training converges towards a local minimum',
            'By converting float32 tensors to 8-bit integers',
            'By skipping convolutional layers'
          ],
          correctIndex: 1,
          explanation: 'Decaying learning rates allows aggressive exploration early on and fine-grained convergence near the optimal loss minima.'
        },
        {
          question: 'What is the key benefit of batch normalization during training?',
          options: [
            'It completely eliminates the need for activation functions',
            'It stabilizes internal covariate shift and enables higher learning rates',
            'It reduces RAM usage to zero',
            'It encrypts weights for privacy'
          ],
          correctIndex: 1,
          explanation: 'Batch normalization normalizes layer inputs across a mini-batch, smoothing optimization landscapes.'
        }
      ]);
      setIsGeneratingQuiz(false);
      confetti({ particleCount: 40, spread: 50 });
    } catch (err) {
      setIsGeneratingQuiz(false);
    }
  };

  // Handle Concept Explainer
  const handleExplainConcept = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!conceptPrompt.trim()) return;

    setIsExplaining(true);
    try {
      const result = await askAITutor(conceptPrompt);
      setConceptExplanation(result);
      setIsExplaining(false);
    } catch (err) {
      setIsExplaining(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* 1. HERO HEADER */}
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 text-white p-6 sm:p-10 rounded-3xl border border-indigo-900/50 shadow-xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>EduRise AI Engine &bull; Powered by Gemini 2.5</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display">
            Intelligent Learning Suite
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            Accelerate your mastery with personalized course matching, automated practice quiz generation, instant conceptual breakdowns, and smart scheduling.
          </p>

          {/* Tool Switcher Chips */}
          <div className="flex flex-wrap items-center gap-2 pt-2">
            {[
              { id: 'matchmaker', label: 'AI Course Matchmaker', icon: Search },
              { id: 'quiz', label: 'Adaptive Quiz Generator', icon: HelpCircle },
              { id: 'explainer', label: 'Complex Concept Explainer', icon: Brain }
            ].map(tool => (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTool === tool.id
                    ? 'bg-white text-slate-950 shadow-md'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                <tool.icon className="w-3.5 h-3.5" />
                <span>{tool.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 2. ACTIVE TOOL WORKSPACE */}

        {/* TOOL 1: COURSE MATCHMAKER */}
        {activeTool === 'matchmaker' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs">
            <div>
              <h2 className="text-lg font-bold text-slate-900 font-display">AI Career & Course Matchmaker</h2>
              <p className="text-xs text-slate-500">Tell us your career goal or target exam, and Gemini will synthesize the optimal course sequence.</p>
            </div>

            <form onSubmit={handleRunMatchmaker} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Career Goal / Exam</label>
                <input
                  type="text"
                  value={targetRole}
                  onChange={e => setTargetRole(e.target.value)}
                  placeholder="e.g. Senior Data Scientist, JEE Advanced Rank < 500"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Current Skill Level</label>
                <input
                  type="text"
                  value={currentExperience}
                  onChange={e => setCurrentExperience(e.target.value)}
                  placeholder="e.g. Class 11 Physics, basic Python knowledge"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="md:col-span-2">
                <button
                  type="submit"
                  disabled={isMatching}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isMatching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>Synthesize Recommended Learning Pathway</span>
                </button>
              </div>
            </form>

            {matchResults.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h3 className="text-sm font-bold text-slate-900">Recommended Courses for Your Goal</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {matchResults.map(c => (
                    <div key={c.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                      <img src={c.thumbnail} alt="" className="w-full aspect-16/9 rounded-xl object-cover" />
                      <span className="font-bold text-slate-900 block">{c.title}</span>
                      <p className="text-[11px] text-slate-500">{c.educatorName} &bull; ₹{c.price}</p>
                      <button
                        onClick={() => navigateTo('course-detail', c.id)}
                        className="w-full py-2 bg-indigo-600 text-white font-bold rounded-lg text-center block cursor-pointer"
                      >
                        View Course Details &rarr;
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TOOL 2: ADAPTIVE QUIZ GENERATOR */}
        {activeTool === 'quiz' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs">
            <div>
              <h2 className="text-lg font-bold text-slate-900 font-display">Adaptive Practice Quiz Generator</h2>
              <p className="text-xs text-slate-500">Generate on-demand checkpoint questions for any subject to benchmark your knowledge.</p>
            </div>

            <form onSubmit={handleGenerateQuiz} className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="md:col-span-2">
                <label className="block font-bold text-slate-700 mb-1">Topic or Formula to Test</label>
                <input
                  type="text"
                  value={quizTopic}
                  onChange={e => setQuizTopic(e.target.value)}
                  placeholder="e.g. Rotational Mechanics, React Server Components"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Difficulty Level</label>
                <select
                  value={quizDifficulty}
                  onChange={e => setQuizDifficulty(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced (Olympiad/GATE Level)</option>
                </select>
              </div>

              <div className="md:col-span-3">
                <button
                  type="submit"
                  disabled={isGeneratingQuiz}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isGeneratingQuiz ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                  <span>Generate Custom Quiz Questions</span>
                </button>
              </div>
            </form>

            {/* Generated Quiz Display */}
            {generatedQuiz.length > 0 && (
              <div className="space-y-6 pt-4 border-t border-slate-100">
                <h3 className="text-sm font-bold text-slate-900">Checkpoint Quiz on "{quizTopic}"</h3>

                <div className="space-y-4">
                  {generatedQuiz.map((q, qIdx) => (
                    <div key={qIdx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
                      <p className="font-bold text-slate-900">
                        {qIdx + 1}. {q.question}
                      </p>
                      <div className="space-y-1.5">
                        {q.options.map((opt: string, optIdx: number) => {
                          const isSelected = quizUserAnswers[qIdx] === optIdx;
                          const isCorrect = q.correctIndex === optIdx;

                          return (
                            <button
                              key={optIdx}
                              type="button"
                              onClick={() => {
                                if (!quizSubmitted) {
                                  setQuizUserAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
                                }
                              }}
                              className={`w-full p-2.5 rounded-xl text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                                quizSubmitted
                                  ? isCorrect
                                    ? 'bg-emerald-100 border border-emerald-400 text-emerald-900 font-bold'
                                    : isSelected
                                    ? 'bg-rose-100 border border-rose-400 text-rose-900'
                                    : 'bg-white text-slate-600'
                                  : isSelected
                                  ? 'bg-indigo-600 text-white font-bold'
                                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                              }`}
                            >
                              <span>{opt}</span>
                              {quizSubmitted && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-700" />}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <p className="text-[11px] text-slate-600 p-2 bg-white rounded-lg border border-slate-200">
                          💡 <strong>Explanation:</strong> {q.explanation}
                        </p>
                      )}
                    </div>
                  ))}
                </div>

                {!quizSubmitted ? (
                  <button
                    onClick={() => {
                      setQuizSubmitted(true);
                      confetti({ particleCount: 40, spread: 50 });
                    }}
                    className="px-6 py-2.5 bg-indigo-600 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                  >
                    Submit Quiz Answers
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setQuizSubmitted(false);
                      setQuizUserAnswers({});
                    }}
                    className="px-6 py-2.5 bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    Retry Practice Quiz
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* TOOL 3: COMPLEX CONCEPT EXPLAINER */}
        {activeTool === 'explainer' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs">
            <div>
              <h2 className="text-lg font-bold text-slate-900 font-display">Complex Concept Simplifier</h2>
              <p className="text-xs text-slate-500">Break down any difficult theorem, algorithmic complexity, or medical concept into intuitive analogies.</p>
            </div>

            <form onSubmit={handleExplainConcept} className="space-y-3 text-xs">
              <label className="block font-bold text-slate-700">What concept would you like explained?</label>
              <textarea
                rows={3}
                value={conceptPrompt}
                onChange={e => setConceptPrompt(e.target.value)}
                placeholder="e.g. Explain how Dijkstra algorithm finds the shortest path using a priority queue..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
              <button
                type="submit"
                disabled={isExplaining}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2 cursor-pointer"
              >
                {isExplaining ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lightbulb className="w-4 h-4" />}
                <span>Explain Clearly</span>
              </button>
            </form>

            {conceptExplanation && (
              <div className="p-6 rounded-2xl bg-indigo-50/50 border border-indigo-200 space-y-3">
                <div className="flex items-center gap-2 text-indigo-700 font-bold text-xs">
                  <Sparkles className="w-4 h-4" />
                  <span>Gemini Explanation</span>
                </div>
                <div className="text-xs sm:text-sm text-slate-800 leading-relaxed space-y-2 whitespace-pre-line">
                  {conceptExplanation}
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
