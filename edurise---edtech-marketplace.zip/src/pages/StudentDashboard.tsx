import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  BookOpen,
  CheckCircle2,
  Clock,
  Play,
  FileText,
  Award,
  Sparkles,
  Receipt,
  Download,
  Flame,
  ArrowRight,
  TrendingUp,
  Calendar,
  Layers,
  ChevronRight,
  ShieldCheck,
  Plus
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const StudentDashboard: React.FC = () => {
  const {
    currentUser,
    courses,
    enrollments,
    notes,
    deleteNote,
    studyPlans,
    generateAIStudyPlan,
    transactions,
    navigateTo,
    addNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'my-courses' | 'planner' | 'notes' | 'certificates' | 'invoices'
  >('my-courses');

  // AI Study Plan Generator Modal State
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [selectedCourseForPlan, setSelectedCourseForPlan] = useState('');
  const [targetExamDate, setTargetExamDate] = useState('2026-06-30');
  const [dailyHours, setDailyHours] = useState('2');
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);

  // Enrolled courses list
  const enrolledCourseIds = Object.keys(enrollments);
  const myEnrolledCourses = courses.filter(c => enrolledCourseIds.includes(c.id));

  // Completed courses (100% progress)
  const completedCourses = myEnrolledCourses.filter(
    c => (enrollments[c.id]?.progressPercent || 0) >= 100
  );

  // User's transactions
  const myTransactions = transactions.filter(
    t => t.studentId === currentUser.id || t.studentName === currentUser.name
  );

  // Overall student stats
  const totalCompletedLectures = Object.values(enrollments).reduce(
    (sum, en) => sum + en.completedLectureIds.length,
    0
  );
  const overallProgressAvg =
    myEnrolledCourses.length > 0
      ? Math.round(
          myEnrolledCourses.reduce((sum, c) => sum + (enrollments[c.id]?.progressPercent || 0), 0) /
            myEnrolledCourses.length
        )
      : 0;

  const handleCreateAIPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourseForPlan) {
      alert('Please select a course to plan.');
      return;
    }

    setIsGeneratingPlan(true);
    const targetCourse = courses.find(c => c.id === selectedCourseForPlan);

    try {
      await generateAIStudyPlan(
        selectedCourseForPlan,
        targetCourse?.title || 'Comprehensive Mastery Course',
        targetExamDate,
        Number(dailyHours) || 2
      );
      setIsGeneratingPlan(false);
      setIsPlanModalOpen(false);
      confetti({ particleCount: 50, spread: 60 });
    } catch (err) {
      setIsGeneratingPlan(false);
    }
  };

  const handleDownloadCertificate = (courseTitle: string) => {
    addNotification('success', 'Certificate Downloaded', `Certificate for "${courseTitle}" generated as PDF.`);
    confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
  };

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* 1. STUDENT HERO WELCOME BANNER */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-4 ring-indigo-500/30"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                  Welcome back, {currentUser.name}!
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>5 Day Streak</span>
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                You've completed <strong className="text-white">{totalCompletedLectures} lessons</strong>. Keep learning every day!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setSelectedCourseForPlan(myEnrolledCourses[0]?.id || courses[0]?.id);
                setIsPlanModalOpen(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI Study Planner</span>
            </button>
            <button
              onClick={() => navigateTo('discovery')}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white font-bold text-xs rounded-xl border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>Explore Courses</span>
            </button>
          </div>
        </div>

        {/* 2. TOP METRICS CARDS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Enrolled Courses</span>
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <BookOpen className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">{myEnrolledCourses.length}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Lifetime accessible</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Lessons Finished</span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">{totalCompletedLectures}</p>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">Verified completions</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Avg. Completion</span>
              <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">{overallProgressAvg}%</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Across active courses</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Certificates</span>
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">{completedCourses.length}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Verified certificates earned</p>
          </div>
        </div>

        {/* 3. TABS NAVIGATION */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'my-courses', label: `My Courses (${myEnrolledCourses.length})`, icon: BookOpen },
            { id: 'planner', label: `AI Study Plans (${studyPlans.length})`, icon: Calendar },
            { id: 'notes', label: `Saved Lecture Notes (${notes.length})`, icon: FileText },
            { id: 'certificates', label: `Certificates (${completedCourses.length})`, icon: Award },
            { id: 'invoices', label: `Purchases & Invoices (${myTransactions.length})`, icon: Receipt }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-white hover:text-slate-900'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* 4. TAB CONTENTS */}

        {/* TAB 1: MY COURSES */}
        {activeTab === 'my-courses' && (
          <div className="space-y-6">
            {myEnrolledCourses.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
                <BookOpen className="w-12 h-12 text-slate-400 mx-auto" />
                <h3 className="text-lg font-bold text-slate-900 font-display">You haven't enrolled in any courses yet</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Discover top-rated masterclasses taught by expert educators.
                </p>
                <button
                  onClick={() => navigateTo('discovery')}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  Browse Course Catalog
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {myEnrolledCourses.map(course => {
                  const enrollment = enrollments[course.id];
                  const progress = enrollment?.progressPercent || 0;
                  const completedLectures = enrollment?.completedLectureIds?.length || 0;
                  const totalLectures = course.chapters.reduce((acc, ch) => acc + ch.lectures.length, 0);

                  return (
                    <div
                      key={course.id}
                      className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden flex flex-col hover:shadow-md transition-shadow"
                    >
                      {/* Thumbnail & Action */}
                      <div className="relative aspect-16/9 bg-slate-950 overflow-hidden group">
                        <img
                          src={course.thumbnail}
                          alt={course.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <button
                          onClick={() => navigateTo('player', course.id)}
                          className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                        >
                          <div className="w-12 h-12 rounded-full bg-white text-indigo-600 flex items-center justify-center shadow-lg">
                            <Play className="w-5 h-5 fill-indigo-600 ml-0.5" />
                          </div>
                        </button>
                        <div className="absolute top-3 right-3 px-2 py-0.5 rounded bg-black/70 text-white text-[10px] font-bold">
                          {progress}% Completed
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                        <div className="space-y-2">
                          <span className="text-[10px] font-extrabold uppercase text-indigo-600 tracking-wider">
                            {course.category}
                          </span>
                          <h3
                            onClick={() => navigateTo('player', course.id)}
                            className="font-bold text-slate-900 text-sm line-clamp-2 hover:text-indigo-600 transition-colors cursor-pointer"
                          >
                            {course.title}
                          </h3>
                          <p className="text-xs text-slate-500 font-medium">
                            Instructor: {course.educatorName}
                          </p>
                        </div>

                        {/* Progress Bar */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Progress</span>
                            <span className="font-mono font-bold text-slate-900">{completedLectures} / {totalLectures} lessons</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>

                        {/* Resume CTA */}
                        <button
                          onClick={() => navigateTo('player', course.id)}
                          className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-white" />
                          <span>Continue Learning</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: AI STUDY PLANNER */}
        {activeTab === 'planner' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200">
              <div>
                <h2 className="text-base font-bold text-slate-900 font-display">AI-Powered Exam & Course Study Plans</h2>
                <p className="text-xs text-slate-500">Tailored schedules generated with Gemini considering your target exam date and hours.</p>
              </div>
              <button
                onClick={() => {
                  setSelectedCourseForPlan(myEnrolledCourses[0]?.id || courses[0]?.id);
                  setIsPlanModalOpen(true);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer w-fit"
              >
                <Plus className="w-4 h-4" />
                <span>Generate New Schedule</span>
              </button>
            </div>

            {studyPlans.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
                <Sparkles className="w-10 h-10 text-indigo-500 mx-auto" />
                <h3 className="text-base font-bold text-slate-900">No active AI study plans yet</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Let our Gemini AI analyze your syllabus and build a day-by-day roadmap tailored to your target completion date.
                </p>
                <button
                  onClick={() => setIsPlanModalOpen(true)}
                  className="px-5 py-2.5 bg-indigo-600 text-white font-bold text-xs rounded-xl"
                >
                  Create AI Study Plan
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {studyPlans.map(plan => (
                  <div key={plan.id} className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 shadow-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                      <div>
                        <span className="text-[10px] font-extrabold uppercase text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                          AI Generated Roadmap
                        </span>
                        <h3 className="text-base font-bold text-slate-900 mt-1">{plan.courseTitle}</h3>
                        <p className="text-xs text-slate-500">
                          Target Completion: <strong className="text-slate-800">{plan.targetDate}</strong> &bull; {plan.dailyCommitmentHours} Hours/day
                        </p>
                      </div>
                      <span className="text-xs text-slate-400 font-mono">Created {plan.createdAt}</span>
                    </div>

                    {/* Schedule items */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {plan.schedule.map(item => (
                        <div key={item.day} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded font-bold text-[10px]">
                              Day {item.day}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500">{item.estimatedMinutes} mins</span>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900">{item.topic}</h4>
                          <ul className="space-y-1 text-[11px] text-slate-600 list-disc pl-3.5">
                            {item.tasks.map((task, tIdx) => (
                              <li key={tIdx}>{task}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: SAVED LECTURE NOTES */}
        {activeTab === 'notes' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-6">
            <h2 className="text-base font-bold text-slate-900 font-display">All Saved Course Notes</h2>

            {notes.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-8 text-center">
                You haven't saved any timestamped notes yet. While watching lessons in the player, open the Notes tab to add notes!
              </p>
            ) : (
              <div className="divide-y divide-slate-100">
                {notes.map(note => (
                  <div key={note.id} className="py-4 flex items-start justify-between gap-4 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-mono font-bold text-[10px]">
                          {note.timestamp}
                        </span>
                        <span className="font-bold text-slate-900">Note</span>
                        <span className="text-slate-400">&bull; {note.createdAt}</span>
                      </div>
                      <p className="text-slate-700 leading-relaxed">{note.content}</p>
                    </div>

                    <button
                      onClick={() => deleteNote(note.id)}
                      className="text-slate-400 hover:text-rose-600 text-xs font-semibold p-1 cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: CERTIFICATES */}
        {activeTab === 'certificates' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-xs">
              <h2 className="text-base font-bold text-slate-900 font-display">Verified Certificates of Completion</h2>
              <p className="text-xs text-slate-500">Earned when you complete 100% of the recorded lectures and quizzes.</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                {completedCourses.length === 0 ? (
                  <div className="col-span-2 py-8 text-center text-slate-500 text-xs">
                    No completed courses yet. Finish all lectures in an enrolled course to unlock your certificate!
                  </div>
                ) : (
                  completedCourses.map(course => (
                    <div
                      key={course.id}
                      className="p-6 rounded-3xl bg-gradient-to-br from-indigo-900 to-slate-900 text-white border border-indigo-700/50 shadow-lg space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <Award className="w-8 h-8 text-amber-400" />
                        <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold text-[10px] uppercase border border-amber-400/30">
                          Verified Credential
                        </span>
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-white">{course.title}</h3>
                        <p className="text-xs text-slate-300 mt-0.5">Instructor: {course.educatorName}</p>
                      </div>
                      <div className="pt-2 flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400">ID: EDU-{course.id.substring(0, 8)}</span>
                        <button
                          onClick={() => handleDownloadCertificate(course.title)}
                          className="px-3 py-1.5 bg-white text-indigo-900 font-bold text-xs rounded-xl flex items-center gap-1.5 hover:bg-slate-100 transition-colors cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download PDF</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: PURCHASES & INVOICES */}
        {activeTab === 'invoices' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900 font-display">Purchase History & Tax Invoices</h2>
              <p className="text-xs text-slate-500">Official GST compliant payment receipts for all enrolled courses.</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3">Receipt No.</th>
                    <th className="px-6 py-3">Course</th>
                    <th className="px-6 py-3">Date</th>
                    <th className="px-6 py-3">Amount</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3 text-right">Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {myTransactions.map(tx => (
                    <tr key={tx.id} className="hover:bg-slate-50/50">
                      <td className="px-6 py-4 font-mono font-bold text-slate-800">{tx.id}</td>
                      <td className="px-6 py-4 font-bold text-slate-900">{tx.courseTitle}</td>
                      <td className="px-6 py-4 text-slate-500">{tx.createdAt}</td>
                      <td className="px-6 py-4 font-black text-slate-900">₹{tx.amount.toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => {
                            addNotification('info', 'Invoice Download', `Invoice ${tx.id} downloaded.`);
                          }}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          PDF Receipt
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* AI STUDY PLAN MODAL */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 relative">
            <button
              onClick={() => setIsPlanModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-800"
            >
              ✕
            </button>

            <div className="flex items-center gap-2 text-indigo-600 mb-1">
              <Sparkles className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Gemini Study Architect</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1">Generate Tailored Study Roadmap</h3>
            <p className="text-xs text-slate-500 mb-4">Input your daily schedule to receive an intelligent curriculum plan.</p>

            <form onSubmit={handleCreateAIPlan} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Course</label>
                <select
                  value={selectedCourseForPlan}
                  onChange={e => setSelectedCourseForPlan(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                >
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Exam / Goal Date</label>
                <input
                  type="date"
                  required
                  value={targetExamDate}
                  onChange={e => setTargetExamDate(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Daily Study Commitment (Hours/day)</label>
                <select
                  value={dailyHours}
                  onChange={e => setDailyHours(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="1">1 Hour / day (Light)</option>
                  <option value="2">2 Hours / day (Recommended)</option>
                  <option value="3">3 Hours / day (Intensive)</option>
                  <option value="4">4+ Hours / day (Full-time)</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={isGeneratingPlan}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                {isGeneratingPlan ? (
                  <span>Synthesizing Plan with Gemini...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate AI Schedule</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
