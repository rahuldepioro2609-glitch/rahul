import React from 'react';
import { useApp } from '../context/AppContext';
import { CourseCard } from '../components/CourseCard';
import {
  CheckCircle2,
  Star,
  Users,
  Award,
  Video,
  Globe,
  Share2,
  BookOpen,
  ArrowLeft
} from 'lucide-react';

interface EducatorProfilePageProps {
  educatorId: string;
}

export const EducatorProfilePage: React.FC<EducatorProfilePageProps> = ({ educatorId }) => {
  const { users, courses, navigateTo, addNotification } = useApp();

  const educator = users.find(u => u.id === educatorId) || {
    id: 'user_educator_2',
    name: 'Dr. Rajesh Khanna',
    email: 'rajesh.khanna@edurise.edu',
    role: 'educator' as const,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    headline: 'Ph.D. in Applied Physics & Senior JEE/NEET Faculty',
    bio: 'Dr. Rajesh has mentored over 40,000+ engineering and medical aspirants across India. Known for his visual intuition techniques for complex mechanics and electrodynamics.',
    kycStatus: 'verified' as const,
    walletBalance: 84000
  };

  const educatorCourses = courses.filter(
    c => c.educatorId === educator.id || c.educatorName === educator.name
  );

  const totalStudents = educatorCourses.reduce((acc, c) => acc + c.studentsCount, 0);
  const avgRating =
    educatorCourses.length > 0
      ? (educatorCourses.reduce((acc, c) => acc + c.rating, 0) / educatorCourses.length).toFixed(1)
      : '4.9';

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Back Link */}
        <div>
          <button
            onClick={() => navigateTo('discovery')}
            className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Course Catalog</span>
          </button>
        </div>

        {/* 1. EDUCATOR BANNER / HERO */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6 sm:p-10 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center gap-6">
              <img
                src={educator.avatar}
                alt={educator.name}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl object-cover ring-4 ring-indigo-500/20 shadow-md"
              />
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
                    {educator.name}
                  </h1>
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                </div>
                <p className="text-xs sm:text-sm font-semibold text-slate-600">
                  {educator.headline}
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                    EduRise Verified Faculty
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                addNotification('info', 'Link Copied', 'Teacher profile link copied to clipboard.');
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Profile</span>
            </button>
          </div>

          {/* Stats strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-100">
            <div className="p-3 bg-slate-50 rounded-2xl">
              <span className="text-[11px] text-slate-500 font-semibold block">Total Students</span>
              <span className="text-lg font-black text-slate-900 font-display">
                {totalStudents > 0 ? totalStudents.toLocaleString() : '34,200+'}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl">
              <span className="text-[11px] text-slate-500 font-semibold block">Instructor Rating</span>
              <span className="text-lg font-black text-amber-500 font-display">
                ⭐ {avgRating}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl">
              <span className="text-[11px] text-slate-500 font-semibold block">Courses Uploaded</span>
              <span className="text-lg font-black text-slate-900 font-display">
                {educatorCourses.length > 0 ? educatorCourses.length : 3}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl">
              <span className="text-[11px] text-slate-500 font-semibold block">Verified Lessons</span>
              <span className="text-lg font-black text-indigo-600 font-display">
                140+ HD Videos
              </span>
            </div>
          </div>

          {/* Biography */}
          <div className="space-y-2 pt-2">
            <h2 className="text-sm font-bold text-slate-900 font-display uppercase tracking-wider">
              About the Instructor
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-4xl">
              {educator.bio ||
                'Senior educator dedicated to building high-quality, comprehensive recorded curriculum. All courses feature full conceptual explanations, real-world case studies, and automated practice quizzes.'}
            </p>
          </div>
        </div>

        {/* 2. INSTRUCTOR COURSES */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-display">
                Recorded Courses by {educator.name}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Explore full structured curriculum with verified certificates.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {educatorCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
