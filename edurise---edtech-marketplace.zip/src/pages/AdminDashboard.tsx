import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  DollarSign,
  TrendingUp,
  Users,
  Layers,
  Search,
  Eye,
  AlertTriangle,
  FileCheck,
  ArrowUpRight,
  Sparkles,
  Building2,
  Briefcase
} from 'lucide-react';
import { CourseStatus } from '../types';
import confetti from 'canvas-confetti';

export const AdminDashboard: React.FC = () => {
  const {
    courses,
    updateCourseStatus,
    users,
    updateUserKyc,
    transactions,
    withdrawals,
    processWithdrawal,
    navigateTo,
    addNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'approvals' | 'educators' | 'transactions' | 'payouts'
  >('approvals');

  // Course Approval Queue
  const pendingCourses = courses.filter(c => c.status === 'pending_approval');
  const publishedCourses = courses.filter(c => c.status === 'published');

  // Educator verification queue
  const educators = users.filter(u => u.role === 'educator');
  const pendingKycEducators = educators.filter(u => u.kycStatus === 'pending');

  // Platform Ledger Metrics
  const totalVolume = transactions.reduce((acc, t) => acc + t.amount, 0);
  const platformRevenue = transactions.reduce((acc, t) => acc + t.platformFee, 0);
  const educatorPayoutsTotal = transactions.reduce((acc, t) => acc + t.educatorShare, 0);

  const handleApproveCourse = (courseId: string) => {
    updateCourseStatus(courseId, 'published');
    confetti({ particleCount: 40, spread: 60 });
  };

  const handleRejectCourse = (courseId: string) => {
    const reason = prompt('Reason for rejecting course curriculum:', 'Needs higher resolution audio in Module 2');
    if (reason) {
      updateCourseStatus(courseId, 'rejected');
    }
  };

  const handleApproveKyc = (userId: string) => {
    updateUserKyc(userId, 'verified');
    confetti({ particleCount: 30, spread: 50 });
  };

  const handleProcessPayout = (payoutId: string) => {
    processWithdrawal(payoutId, 'PROCESSED');
    confetti({ particleCount: 40, spread: 50 });
  };

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* 1. ADMIN HEADER */}
        <div className="bg-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-400/30 flex items-center justify-center">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                  Admin Central Control
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-indigo-500/30 text-indigo-300 border border-indigo-400/30">
                  Super Admin
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Marketplace compliance, quality assurance, educator KYC, and financial commission ledgers.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 bg-slate-800 rounded-2xl border border-slate-700 text-xs">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Platform Take Rate</span>
              <span className="text-emerald-400 font-black text-sm">20% Standard</span>
            </div>
          </div>
        </div>

        {/* 2. PLATFORM METRICS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Gross GMV Volume</span>
            <p className="text-2xl font-black text-slate-900 mt-2 font-display">₹{totalVolume.toLocaleString()}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Total marketplace orders</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">EduRise Net Revenue (20%)</span>
            <p className="text-2xl font-black text-emerald-600 mt-2 font-display">₹{platformRevenue.toLocaleString()}</p>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">Platform profit margin</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Course Review Queue</span>
            <p className="text-2xl font-black text-amber-600 mt-2 font-display">{pendingCourses.length}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Awaiting QA verification</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">KYC Approvals</span>
            <p className="text-2xl font-black text-indigo-600 mt-2 font-display">{pendingKycEducators.length}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Teacher onboarding queue</p>
          </div>
        </div>

        {/* 3. TABS NAVIGATION */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'approvals', label: `Course Approvals (${pendingCourses.length})`, icon: Layers },
            { id: 'educators', label: `Educator Verification (${educators.length})`, icon: Users },
            { id: 'transactions', label: `Marketplace Ledger (${transactions.length})`, icon: DollarSign },
            { id: 'payouts', label: `Withdrawals (${withdrawals.length})`, icon: Building2 }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-white hover:text-slate-900'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* 4. TAB CONTENTS */}

        {/* TAB 1: COURSE APPROVAL QUEUE */}
        {activeTab === 'approvals' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900 font-display">Course Verification & Publishing Queue</h2>
              <p className="text-xs text-slate-500">Teachers cannot publish courses to students until approved by Admin.</p>
            </div>

            {pendingCourses.length === 0 ? (
              <div className="p-12 text-center text-slate-500 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <p className="font-bold text-slate-800 text-sm">All course submissions are up to date!</p>
                <p className="text-xs">No pending approvals in the review queue.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {pendingCourses.map(course => (
                  <div key={course.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/50">
                    <div className="flex items-start gap-4">
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-20 h-14 rounded-xl object-cover shrink-0"
                      />
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                            PENDING QA
                          </span>
                          <span className="text-xs text-slate-500 font-bold">{course.category}</span>
                        </div>
                        <h3 className="text-sm font-bold text-slate-900">{course.title}</h3>
                        <p className="text-xs text-slate-500">
                          Instructor: <strong className="text-slate-700">{course.educatorName}</strong> &bull; Pricing: <strong className="text-slate-900">₹{course.price}</strong> &bull; {course.chapters.length} Sections
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 shrink-0">
                      <button
                        onClick={() => navigateTo('course-detail', course.id)}
                        className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect Syllabus</span>
                      </button>

                      <button
                        onClick={() => handleRejectCourse(course.id)}
                        className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>

                      <button
                        onClick={() => handleApproveCourse(course.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Approve & Publish</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: EDUCATOR KYC VERIFICATION */}
        {activeTab === 'educators' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900 font-display">Educator Verification & KYC</h2>
              <p className="text-xs text-slate-500">Review teacher credentials, academic backgrounds, and identity documents.</p>
            </div>

            <div className="divide-y divide-slate-100">
              {educators.map(educator => (
                <div key={educator.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={educator.avatar}
                      alt={educator.name}
                      className="w-12 h-12 rounded-full object-cover shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{educator.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          educator.kycStatus === 'verified'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          KYC {educator.kycStatus}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">{educator.email} &bull; {educator.headline || 'Verified Instructor'}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {educator.kycStatus === 'pending' ? (
                      <button
                        onClick={() => handleApproveKyc(educator.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Verify Teacher KYC</span>
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Teacher Verified</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: MARKETPLACE REVENUE & TRANSACTIONS */}
        {activeTab === 'transactions' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900 font-display">Marketplace Transaction Ledger</h2>
              <p className="text-xs text-slate-500">Real-time split of student payments (80% Educator / 20% EduRise).</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3">Tx ID</th>
                    <th className="px-6 py-3">Course / Student</th>
                    <th className="px-6 py-3">Gross Paid</th>
                    <th className="px-6 py-3">Educator Share (80%)</th>
                    <th className="px-6 py-3">EduRise Commission (20%)</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.map(tx => (
                    <tr key={tx.id} className="hover:bg-slate-50/50">
                      <td className="px-6 py-4 font-mono font-bold text-slate-800">{tx.id}</td>
                      <td className="px-6 py-4">
                        <span className="font-bold text-slate-900 block">{tx.courseTitle}</span>
                        <span className="text-[11px] text-slate-400">{tx.studentName} &bull; {tx.createdAt}</span>
                      </td>
                      <td className="px-6 py-4 font-black text-slate-900">₹{tx.amount.toLocaleString()}</td>
                      <td className="px-6 py-4 font-bold text-purple-700">₹{tx.educatorShare.toLocaleString()}</td>
                      <td className="px-6 py-4 font-bold text-emerald-600">₹{tx.platformFee.toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {tx.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: WITHDRAWALS & PAYOUTS */}
        {activeTab === 'payouts' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900 font-display">Educator Withdrawal Requests</h2>
              <p className="text-xs text-slate-500">Approve and settle educator balance withdrawals.</p>
            </div>

            <div className="divide-y divide-slate-100">
              {withdrawals.map(p => (
                <div key={p.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="font-mono font-bold text-slate-900 text-sm">{p.id}</span>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Amount: <strong className="text-slate-900 text-sm">₹{p.amount.toLocaleString()}</strong> &bull; Method: <strong className="text-purple-700">{p.method}</strong> ({p.accountDetails})
                    </p>
                    <span className="text-[11px] text-slate-400">{p.requestedAt}</span>
                  </div>

                  <div>
                    {p.status === 'PENDING' ? (
                      <button
                        onClick={() => handleProcessPayout(p.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                      >
                        Authorize UPI / Bank Payout
                      </button>
                    ) : (
                      <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-200">
                        ✓ Disbursed
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
