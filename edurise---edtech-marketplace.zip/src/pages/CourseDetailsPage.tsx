import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AITutorDrawer } from '../components/AITutorDrawer';
import {
  Star,
  Clock,
  BookOpen,
  Globe,
  Award,
  CheckCircle2,
  Play,
  Lock,
  ChevronDown,
  ChevronUp,
  Share2,
  Heart,
  ShoppingCart,
  Sparkles,
  ShieldCheck,
  RotateCcw,
  ArrowRight,
  MessageSquare,
  UserCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CourseDetailsPageProps {
  courseId: string;
}

export const CourseDetailsPage: React.FC<CourseDetailsPageProps> = ({ courseId }) => {
  const {
    courses,
    reviews,
    isEnrolled,
    isInCart,
    addToCart,
    removeFromCart,
    isInWishlist,
    toggleWishlist,
    openPaymentModal,
    navigateTo,
    addNotification,
    addReview
  } = useApp();

  const course = courses.find(c => c.id === courseId) || courses[0];
  const enrolled = isEnrolled(course.id);
  const inCart = isInCart(course.id);
  const inWishlist = isInWishlist(course.id);
  const courseReviews = reviews.filter(r => r.courseId === course.id);

  // Accordion state for syllabus sections (first 2 expanded by default)
  const [expandedSections, setExpandedSections] = useState<{ [key: string]: boolean }>({
    [course?.chapters?.[0]?.id || '']: true,
    [course?.chapters?.[1]?.id || '']: true
  });

  // AI Tutor Drawer State
  const [isAITutorOpen, setIsAITutorOpen] = useState(false);

  // Review Submission State
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  // Promo video modal or free preview state
  const [previewingLecture, setPreviewingLecture] = useState<{
    title: string;
    videoUrl: string;
  } | null>(null);

  const toggleSection = (chapterId: string) => {
    setExpandedSections(prev => ({ ...prev, [chapterId]: !prev[chapterId] }));
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    addNotification('info', 'Link Copied', 'Course link copied to clipboard.');
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewComment.trim()) return;

    setIsSubmittingReview(true);
    addReview(course.id, reviewRating, reviewComment.trim());
    setReviewComment('');
    setIsSubmittingReview(false);
    confetti({ particleCount: 40, spread: 50 });
  };

  const totalLectures = course.chapters.reduce((acc, ch) => acc + ch.lectures.length, 0);

  return (
    <div className="min-h-screen bg-slate-50/70 py-8 lg:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* 1. TOP BREADCRUMB & BACK NAV */}
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigateTo('discovery')}
              className="hover:text-indigo-600 font-semibold cursor-pointer"
            >
              Courses
            </button>
            <span>/</span>
            <span className="text-slate-700 font-bold">{course.category}</span>
            <span>/</span>
            <span className="text-slate-900 truncate max-w-xs">{course.title}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>
            <button
              onClick={() => toggleWishlist(course.id)}
              className={`p-1.5 rounded-xl border text-xs cursor-pointer ${
                inWishlist
                  ? 'bg-rose-50 border-rose-200 text-rose-600'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Heart className={`w-4 h-4 ${inWishlist ? 'fill-rose-600' : ''}`} />
            </button>
          </div>
        </div>

        {/* 2. HERO DETAIL BANNER */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Course Main Info (8 Cols) */}
          <div className="lg:col-span-8 space-y-6">
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-1 rounded-md text-[11px] font-extrabold uppercase bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {course.category}
                </span>
                <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-slate-100 text-slate-700">
                  {course.level}
                </span>
                {course.isBestseller && (
                  <span className="px-2.5 py-1 rounded-md text-[11px] font-extrabold uppercase bg-amber-100 text-amber-900 border border-amber-300">
                    Bestseller
                  </span>
                )}
              </div>

              <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-display leading-tight">
                {course.title}
              </h1>

              <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
                {course.subtitle}
              </p>
            </div>

            {/* Quick Metrics Bar */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-slate-600 pt-2 border-y border-slate-200 py-3">
              <div className="flex items-center gap-1.5">
                <div className="flex text-amber-400">
                  <Star className="w-4 h-4 fill-amber-400" />
                </div>
                <span className="font-extrabold text-slate-900 text-sm">{course.rating}</span>
                <span className="text-slate-500 font-mono">({course.ratingCount.toLocaleString()} ratings)</span>
              </div>

              <div className="flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-slate-400" />
                <span className="font-bold text-slate-800">{course.studentsCount.toLocaleString()}</span>
                <span>students enrolled</span>
              </div>

              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-400" />
                <span>{course.totalDuration} on-demand video</span>
              </div>

              <div className="flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-slate-400" />
                <span>{course.language}</span>
              </div>
            </div>

            {/* Instructor Quick Bio Card */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-3.5">
                <img
                  src={course.educatorAvatar}
                  alt={course.educatorName}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-indigo-500/20"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-slate-500">Created by</span>
                    <span className="font-bold text-slate-900 text-sm">{course.educatorName}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-1">{course.educatorTitle || 'Master Instructor'}</p>
                </div>
              </div>

              <button
                onClick={() => navigateTo('educator-profile', undefined, undefined, course.educatorId)}
                className="px-3 py-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 rounded-xl transition-colors cursor-pointer"
              >
                View Profile &rarr;
              </button>
            </div>

            {/* What you will learn Section */}
            <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
              <h2 className="text-lg font-bold text-slate-900 font-display">
                What you'll learn in this course
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {course.whatYouWillLearn.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Assistant Integration Banner */}
            <div className="p-5 rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg border border-indigo-800/40">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center shrink-0 border border-indigo-400/30">
                  <Sparkles className="w-5 h-5 text-indigo-300" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white font-display">
                    24/7 AI Course Tutor Included
                  </h3>
                  <p className="text-xs text-slate-300">
                    Ask lecture-specific doubts, generate practice quizzes, and get instant code reviews powered by Gemini.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsAITutorOpen(true)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md transition-all whitespace-nowrap cursor-pointer"
              >
                Try AI Tutor Demo
              </button>
            </div>

            {/* 3. COURSE SYLLABUS & CURRICULUM ACCORDION */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 font-display">
                    Course Curriculum & Syllabus
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {course.chapters.length} sections &bull; {totalLectures} lectures &bull; {course.totalDuration} total length
                  </p>
                </div>

                <button
                  onClick={() => {
                    const allExpanded = Object.keys(expandedSections).length === course.chapters.length;
                    if (allExpanded) {
                      setExpandedSections({});
                    } else {
                      const exp: { [key: string]: boolean } = {};
                      course.chapters.forEach(ch => { exp[ch.id] = true; });
                      setExpandedSections(exp);
                    }
                  }}
                  className="text-xs text-indigo-600 font-bold hover:underline cursor-pointer"
                >
                  Expand / Collapse All
                </button>
              </div>

              <div className="space-y-3">
                {course.chapters.map((chapter, chIdx) => {
                  const isOpen = !!expandedSections[chapter.id];

                  return (
                    <div
                      key={chapter.id}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs transition-all"
                    >
                      {/* Section Header */}
                      <button
                        type="button"
                        onClick={() => toggleSection(chapter.id)}
                        className="w-full p-4 flex items-center justify-between bg-slate-50 hover:bg-slate-100/80 transition-colors text-left cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs font-mono">
                            {chIdx + 1}
                          </span>
                          <div>
                            <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                              {chapter.title}
                            </h3>
                            <span className="text-[11px] text-slate-500">
                              {chapter.lectures.length} lessons
                            </span>
                          </div>
                        </div>

                        {isOpen ? (
                          <ChevronUp className="w-4 h-4 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        )}
                      </button>

                      {/* Section Lectures */}
                      {isOpen && (
                        <div className="divide-y divide-slate-100 px-4 py-2">
                          {chapter.lectures.map((lecture, lIdx) => (
                            <div
                              key={lecture.id}
                              className="py-3 flex items-center justify-between text-xs hover:bg-slate-50/60 rounded-xl px-2 transition-colors"
                            >
                              <div className="flex items-center gap-3">
                                {lecture.isFreePreview || enrolled ? (
                                  <Play className="w-3.5 h-3.5 text-indigo-600 fill-indigo-600/20" />
                                ) : (
                                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                                )}
                                <span className="text-slate-800 font-medium">{lecture.title}</span>
                              </div>

                              <div className="flex items-center gap-3 font-mono text-[11px] text-slate-500">
                                {lecture.isFreePreview && (
                                  <button
                                    onClick={() => setPreviewingLecture({ title: lecture.title, videoUrl: lecture.videoUrl })}
                                    className="px-2 py-0.5 bg-indigo-50 text-indigo-700 font-bold rounded hover:bg-indigo-100 text-[10px] cursor-pointer"
                                  >
                                    Preview
                                  </button>
                                )}
                                <span>{lecture.duration}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Requirements & Description */}
            <div className="space-y-4 pt-4">
              <h2 className="text-lg font-bold text-slate-900 font-display">
                Requirements & Prerequisites
              </h2>
              <ul className="space-y-2 text-xs text-slate-600 pl-4 list-disc">
                {course.requirements.map((req, idx) => (
                  <li key={idx}>{req}</li>
                ))}
              </ul>
            </div>

            <div className="space-y-4 pt-4">
              <h2 className="text-lg font-bold text-slate-900 font-display">
                Detailed Course Description
              </h2>
              <div className="text-xs sm:text-sm text-slate-700 leading-relaxed space-y-3 bg-white p-6 rounded-3xl border border-slate-200">
                <p>{course.description}</p>
                <p>
                  Every lesson is supplemented with real source code repositories, cheat sheets, checkpoint quizzes, and direct access to the course AI mentor.
                </p>
              </div>
            </div>

            {/* REVIEWS SECTION */}
            <div className="space-y-6 pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 font-display">
                    Student Ratings & Feedback
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Real feedback from verified enrolled students.
                  </p>
                </div>
              </div>

              {/* Review Submission Form if Enrolled */}
              {enrolled && (
                <form onSubmit={handleAddReview} className="p-5 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-2xs">
                  <span className="text-xs font-bold text-slate-900">Leave your course review</span>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className="p-1 cursor-pointer"
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= reviewRating
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-mono font-bold text-slate-700 ml-2">{reviewRating} Stars</span>
                  </div>

                  <textarea
                    rows={2}
                    required
                    value={reviewComment}
                    onChange={e => setReviewComment(e.target.value)}
                    placeholder="Share what you liked most about the explanations, exercises, and instructor pacing..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:border-indigo-500 focus:outline-hidden"
                  />

                  <button
                    type="submit"
                    disabled={isSubmittingReview}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                  >
                    Submit Review
                  </button>
                </form>
              )}

              {/* Reviews List */}
              <div className="space-y-3">
                {courseReviews.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No reviews yet. Be the first to share your experience!</p>
                ) : (
                  courseReviews.map(rev => (
                    <div
                      key={rev.id}
                      className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <img src={rev.userAvatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                          <span className="font-bold text-slate-900">{rev.userName}</span>
                          <span className="text-amber-500 font-bold">⭐ {rev.rating}.0</span>
                        </div>
                        <span className="text-[11px] text-slate-400">{rev.date}</span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">{rev.comment}</p>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>

          {/* Right Column: Sticky Purchase & Details Card (4 Cols) */}
          <div className="lg:col-span-4 sticky top-24 space-y-4">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
              
              {/* Thumbnail / Trailer Video */}
              <div className="relative aspect-16/9 bg-slate-950 overflow-hidden group">
                <img
                  src={course.thumbnail}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <button
                    onClick={() => setPreviewingLecture({ title: 'Course Trailer', videoUrl: course.previewVideoUrl })}
                    className="w-14 h-14 rounded-full bg-white/90 hover:bg-white text-indigo-600 flex items-center justify-center shadow-2xl transition-transform hover:scale-110 cursor-pointer"
                  >
                    <Play className="w-6 h-6 fill-indigo-600 ml-1" />
                  </button>
                </div>
                <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded bg-black/70 text-white text-[11px] font-bold">
                  Preview Course
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Price Display */}
                <div>
                  <div className="flex items-baseline gap-3">
                    <span className="text-3xl font-black text-slate-900 font-display">
                      ₹{course.price.toLocaleString()}
                    </span>
                    <span className="text-sm font-semibold text-slate-400 line-through">
                      ₹{course.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-xs font-extrabold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                      {course.discountPercent}% OFF
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Special promotional price. Includes full lifetime access & verified certificate.
                  </p>
                </div>

                {/* Primary CTA Buttons */}
                <div className="space-y-2.5">
                  {enrolled ? (
                    <button
                      onClick={() => navigateTo('player', course.id)}
                      className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-white" />
                      <span>Resume Course in Player</span>
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => openPaymentModal(course)}
                        className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>Enroll Now (Instant Access)</span>
                      </button>

                      <button
                        onClick={() => {
                          if (inCart) {
                            removeFromCart(course.id);
                          } else {
                            addToCart(course.id);
                          }
                        }}
                        className={`w-full py-3 border rounded-2xl font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                          inCart
                            ? 'bg-slate-100 border-slate-300 text-slate-700'
                            : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <ShoppingCart className="w-4 h-4" />
                        <span>{inCart ? 'Remove from Cart' : 'Add to Cart'}</span>
                      </button>
                    </>
                  )}
                </div>

                {/* Trust Inclusions Checklist */}
                <div className="space-y-2.5 pt-4 border-t border-slate-100 text-xs text-slate-600">
                  <div className="flex items-center gap-2.5">
                    <Clock className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>Full lifetime access to all recorded lectures</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <Award className="w-4 h-4 text-amber-500 shrink-0" />
                    <span>Official Verified Certificate of Completion</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>Integrated Gemini AI 24/7 Lecture Doubts Assistant</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <RotateCcw className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>7-Day Risk-Free Money Back Guarantee</span>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>

      </div>

      {/* FREE PREVIEW VIDEO MODAL */}
      {previewingLecture && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-slate-900 rounded-3xl max-w-3xl w-full border border-slate-800 shadow-2xl p-4 relative">
            <div className="flex items-center justify-between pb-3 px-2">
              <h3 className="text-sm font-bold text-white">{previewingLecture.title}</h3>
              <button
                onClick={() => setPreviewingLecture(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>
            <div className="aspect-16/9 bg-black rounded-2xl overflow-hidden">
              <iframe
                src={`${previewingLecture.videoUrl}?autoplay=1`}
                title="Preview"
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      )}

      {/* AI TUTOR DRAWER */}
      <AITutorDrawer
        courseTitle={course.title}
        isOpen={isAITutorOpen}
        onClose={() => setIsAITutorOpen(false)}
      />

    </div>
  );
};
