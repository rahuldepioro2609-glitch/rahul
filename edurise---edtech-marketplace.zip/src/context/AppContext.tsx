import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  User,
  UserRole,
  Course,
  Enrollment,
  Review,
  Transaction,
  WithdrawalRequest,
  Note,
  DiscussionMessage,
  VideoUploadTask,
  StudyPlan
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_COURSES,
  INITIAL_REVIEWS,
  INITIAL_TRANSACTIONS,
  INITIAL_WITHDRAWALS
} from '../data/seedData';

export type AppPage =
  | 'landing'
  | 'discovery'
  | 'course-detail'
  | 'student-dashboard'
  | 'player'
  | 'educator-dashboard'
  | 'admin-dashboard'
  | 'educator-profile'
  | 'study-planner'
  | 'ai-hub';

export interface ToastNotification {
  id: string;
  type: 'success' | 'info' | 'error' | 'warning';
  title: string;
  message: string;
  timestamp: number;
}

interface AppContextType {
  currentUser: User;
  users: User[];
  courses: Course[];
  enrollments: Record<string, Enrollment>; // courseId -> Enrollment
  cart: string[]; // courseIds
  wishlist: string[]; // courseIds
  followedEducators: string[];
  transactions: Transaction[];
  withdrawals: WithdrawalRequest[];
  notes: Note[];
  discussions: DiscussionMessage[];
  reviews: Review[];
  uploadTasks: VideoUploadTask[];
  savedStudyPlans: StudyPlan[];
  
  // Navigation & Routing State
  currentPage: AppPage;
  selectedCourseId: string | null;
  selectedLectureId: string | null;
  selectedEducatorId: string | null;
  studentDashboardTab: string;
  educatorDashboardTab: string;
  adminDashboardTab: string;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'signup' | 'educator-signup' | 'admin-login';
  isPaymentModalOpen: boolean;
  pendingPurchaseCourse: Course | null;

  // Actions
  navigateTo: (page: AppPage, courseId?: string, lectureId?: string, educatorId?: string) => void;
  setCurrentUserRole: (role: UserRole) => void;
  setUser: (user: User) => void;
  openAuthModal: (mode?: 'login' | 'signup' | 'educator-signup' | 'admin-login') => void;
  closeAuthModal: () => void;
  openPaymentModal: (course: Course) => void;
  closePaymentModal: () => void;
  
  // E-commerce & Enrollment
  addToCart: (courseId: string) => void;
  removeFromCart: (courseId: string) => void;
  isInCart: (courseId: string) => boolean;
  toggleWishlist: (courseId: string) => void;
  isInWishlist: (courseId: string) => boolean;
  toggleFollowEducator: (educatorId: string) => void;
  isFollowingEducator: (educatorId: string) => boolean;
  purchaseCourse: (course: Course, paymentMethod: 'UPI' | 'Card' | 'Netbanking' | 'Wallet', couponCode?: string) => Promise<boolean>;
  isEnrolled: (courseId: string) => boolean;
  
  // Learning & Player
  markLectureComplete: (courseId: string, lectureId: string) => void;
  isLectureCompleted: (courseId: string, lectureId: string) => boolean;
  saveNote: (courseId: string, lectureId: string, timestamp: string, content: string) => void;
  deleteNote: (noteId: string) => void;
  addReview: (courseId: string, rating: number, comment: string) => void;
  addDiscussionMessage: (courseId: string, lectureId: string | undefined, title: string, content: string) => void;
  saveStudyPlan: (plan: StudyPlan) => void;
  
  // Educator & Course Creation
  createCourse: (course: Partial<Course>) => Course;
  updateCourse: (courseId: string, updates: Partial<Course>) => void;
  startVideoUpload: (
    file: File | { name: string; size: number },
    courseId: string,
    chapterId: string,
    lectureTitle: string,
    description: string,
    isFreePreview: boolean
  ) => void;
  requestWithdrawal: (amount: number, method: 'UPI' | 'Bank Transfer', accountDetails: string) => boolean;
  
  // Admin Operations
  approveCourse: (courseId: string) => void;
  rejectCourse: (courseId: string, feedback?: string) => void;
  verifyEducator: (educatorId: string) => void;
  processWithdrawal: (withdrawalId: string) => void;
  
  // Toasts
  notifications: ToastNotification[];
  addNotification: (type: 'success' | 'info' | 'error' | 'warning', title: string, message: string) => void;
  removeNotification: (id: string) => void;
  
  // Tab switchers
  setStudentDashboardTab: (tab: string) => void;
  setEducatorDashboardTab: (tab: string) => void;
  setAdminDashboardTab: (tab: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'edurise_state_v1';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load state or use seed data
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_users`);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_currentUser`);
    return saved ? JSON.parse(saved) : INITIAL_USERS[0]; // Student Aryan by default
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_courses`);
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [enrollments, setEnrollments] = useState<Record<string, Enrollment>>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_enrollments`);
    if (saved) return JSON.parse(saved);
    // Pre-enroll student in Python Bootcamp for instant rich dashboard demo
    return {
      course_python_bootcamp: {
        courseId: 'course_python_bootcamp',
        userId: 'user_student_1',
        enrolledAt: '2026-02-14',
        progressPercent: 42,
        completedLectureIds: ['lec_py_1_1', 'lec_py_1_2'],
        lastPlayedLectureId: 'lec_py_1_3',
        isCompleted: false
      }
    };
  });

  const [cart, setCart] = useState<string[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_cart`);
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_wishlist`);
    return saved ? JSON.parse(saved) : ['course_dsa_java', 'course_ai_ml_deep_dive'];
  });

  const [followedEducators, setFollowedEducators] = useState<string[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_followedEducators`);
    return saved ? JSON.parse(saved) : ['user_educator_2'];
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_transactions`);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_withdrawals`);
    return saved ? JSON.parse(saved) : INITIAL_WITHDRAWALS;
  });

  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_notes`);
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'note_1',
        userId: 'user_student_1',
        courseId: 'course_python_bootcamp',
        lectureId: 'lec_py_1_2',
        timestamp: '05:42',
        content: 'Python memory allocation: variables point to heap objects. Tuples are immutable, lists are dynamic arrays.',
        createdAt: '2026-02-15 11:20'
      },
      {
        id: 'note_2',
        userId: 'user_student_1',
        courseId: 'course_python_bootcamp',
        lectureId: 'lec_py_1_1',
        timestamp: '03:10',
        content: 'PEP 8 naming conventions: snake_case for functions and variables, PascalCase for classes.',
        createdAt: '2026-02-14 16:30'
      }
    ];
  });

  const [discussions, setDiscussions] = useState<DiscussionMessage[]>(() => {
    return [
      {
        id: 'disc_1',
        courseId: 'course_python_bootcamp',
        lectureId: 'lec_py_1_2',
        userId: 'user_student_1',
        userName: 'Aryan Patel',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        userRole: 'student',
        title: 'Why is `is` different from `==` for small integers in Python?',
        content: 'I noticed 256 is 256 is True, but 1000 is 1000 can be False in the interactive REPL. Is this integer caching?',
        createdAt: '2 days ago',
        upvotes: 14,
        replies: [
          {
            id: 'disc_1_rep_1',
            courseId: 'course_python_bootcamp',
            lectureId: 'lec_py_1_2',
            userId: 'user_educator_2',
            userName: 'Ananya Verma (Educator)',
            userAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
            userRole: 'educator',
            content: 'Spot on Aryan! CPython pre-allocates an array of integer objects for small integers from -5 to 256 to save memory and allocation overhead. `==` checks value equality, whereas `is` checks memory reference ID!',
            createdAt: '1 day ago',
            upvotes: 22
          }
        ]
      }
    ];
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_reviews`);
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [uploadTasks, setUploadTasks] = useState<VideoUploadTask[]>([]);
  const [savedStudyPlans, setSavedStudyPlans] = useState<StudyPlan[]>([]);
  const [notifications, setNotifications] = useState<ToastNotification[]>([]);

  // Navigation State
  const [currentPage, setCurrentPage] = useState<AppPage>('landing');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [selectedLectureId, setSelectedLectureId] = useState<string | null>(null);
  const [selectedEducatorId, setSelectedEducatorId] = useState<string | null>(null);
  const [studentDashboardTab, setStudentDashboardTab] = useState<string>('dashboard');
  const [educatorDashboardTab, setEducatorDashboardTab] = useState<string>('dashboard');
  const [adminDashboardTab, setAdminDashboardTab] = useState<string>('dashboard');

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | 'educator-signup' | 'admin-login'>('login');
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [pendingPurchaseCourse, setPendingPurchaseCourse] = useState<Course | null>(null);

  // Persistence to localStorage
  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_currentUser`, JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_courses`, JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_enrollments`, JSON.stringify(enrollments));
  }, [enrollments]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_cart`, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_wishlist`, JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_followedEducators`, JSON.stringify(followedEducators));
  }, [followedEducators]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_transactions`, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_withdrawals`, JSON.stringify(withdrawals));
  }, [withdrawals]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_notes`, JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_reviews`, JSON.stringify(reviews));
  }, [reviews]);

  // Toast Helpers
  const addNotification = (type: 'success' | 'info' | 'error' | 'warning', title: string, message: string) => {
    const id = 'toast_' + Date.now() + '_' + Math.random().toString(36).substring(7);
    const newToast: ToastNotification = { id, type, title, message, timestamp: Date.now() };
    setNotifications(prev => [newToast, ...prev.slice(0, 4)]);
    setTimeout(() => {
      removeNotification(id);
    }, 4500);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(t => t.id !== id));
  };

  // Navigation Helper
  const navigateTo = (page: AppPage, courseId?: string, lectureId?: string, educatorId?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentPage(page);
    if (courseId !== undefined) setSelectedCourseId(courseId);
    if (lectureId !== undefined) setSelectedLectureId(lectureId);
    if (educatorId !== undefined) setSelectedEducatorId(educatorId);
  };

  // Role Switcher
  const setCurrentUserRole = (role: UserRole) => {
    if (role === 'student') {
      const student = users.find(u => u.role === 'student') || INITIAL_USERS[0];
      setCurrentUser(student);
      addNotification('info', 'Switched to Student Mode', `Browsing as ${student.name}`);
    } else if (role === 'educator') {
      const educator = users.find(u => u.role === 'educator') || INITIAL_USERS[2]; // Ananya Verma
      setCurrentUser(educator);
      addNotification('info', 'Switched to Educator Mode', `Managing courses as ${educator.name}`);
    } else if (role === 'admin') {
      const admin = users.find(u => u.role === 'admin') || INITIAL_USERS[4]; // Vikramaditya
      setCurrentUser(admin);
      addNotification('info', 'Switched to Admin Mode', `System oversight active as ${admin.name}`);
    }
  };

  const setUser = (user: User) => {
    setCurrentUser(user);
    if (!users.some(u => u.id === user.id)) {
      setUsers(prev => [...prev, user]);
    }
  };

  // Modal Handlers
  const openAuthModal = (mode: 'login' | 'signup' | 'educator-signup' | 'admin-login' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openPaymentModal = (course: Course) => {
    setPendingPurchaseCourse(course);
    setIsPaymentModalOpen(true);
  };

  const closePaymentModal = () => {
    setIsPaymentModalOpen(false);
    setPendingPurchaseCourse(null);
  };

  // Cart & Wishlist
  const addToCart = (courseId: string) => {
    if (!cart.includes(courseId)) {
      setCart(prev => [...prev, courseId]);
      addNotification('success', 'Added to Cart', 'Course is waiting in your cart');
    }
  };

  const removeFromCart = (courseId: string) => {
    setCart(prev => prev.filter(id => id !== courseId));
    addNotification('info', 'Removed from Cart', 'Item removed from your cart');
  };

  const isInCart = (courseId: string) => cart.includes(courseId);

  const toggleWishlist = (courseId: string) => {
    if (wishlist.includes(courseId)) {
      setWishlist(prev => prev.filter(id => id !== courseId));
      addNotification('info', 'Removed from Wishlist', 'Course removed from saved items');
    } else {
      setWishlist(prev => [...prev, courseId]);
      addNotification('success', 'Saved to Wishlist', 'Course saved for later');
    }
  };

  const isInWishlist = (courseId: string) => wishlist.includes(courseId);

  const toggleFollowEducator = (educatorId: string) => {
    if (followedEducators.includes(educatorId)) {
      setFollowedEducators(prev => prev.filter(id => id !== educatorId));
      addNotification('info', 'Unfollowed Educator', 'You will no longer receive course updates');
    } else {
      setFollowedEducators(prev => [...prev, educatorId]);
      addNotification('success', 'Following Educator', 'You will get notified when new courses launch!');
    }
  };

  const isFollowingEducator = (educatorId: string) => followedEducators.includes(educatorId);

  const isEnrolled = (courseId: string) => {
    return !!enrollments[courseId];
  };

  // Purchase & Payment Simulation
  const purchaseCourse = async (
    course: Course,
    paymentMethod: 'UPI' | 'Card' | 'Netbanking' | 'Wallet',
    couponCode?: string
  ): Promise<boolean> => {
    let discount = 0;
    if (couponCode?.toUpperCase() === 'EDURISE50') {
      discount = Math.round(course.price * 0.5);
    } else if (couponCode?.toUpperCase() === 'WELCOME20') {
      discount = Math.round(course.price * 0.2);
    }

    const netPrice = Math.max(0, course.price - discount);
    const tax = Math.round(netPrice * 0.18); // 18% GST standard in India
    const totalAmount = netPrice + tax;
    const platformFee = Math.round(netPrice * 0.20); // 20% platform commission
    const educatorShare = netPrice - platformFee;

    const newTx: Transaction = {
      id: `tx_${Date.now().toString().slice(-6)}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      courseId: course.id,
      courseTitle: course.title,
      educatorId: course.educatorId,
      educatorName: course.educatorName,
      amount: course.price,
      discountAmount: discount,
      taxAmount: tax,
      totalAmount,
      platformFeeAmount: platformFee,
      educatorEarningAmount: educatorShare,
      paymentMethod,
      paymentId: `pay_${paymentMethod}_${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      status: 'SUCCESS',
      createdAt: new Date().toLocaleString()
    };

    setTransactions(prev => [newTx, ...prev]);

    // Create Enrollment
    const firstLectureId = course.chapters[0]?.lectures[0]?.id;
    const newEnrollment: Enrollment = {
      courseId: course.id,
      userId: currentUser.id,
      enrolledAt: new Date().toISOString().split('T')[0],
      progressPercent: 0,
      completedLectureIds: [],
      lastPlayedLectureId: firstLectureId,
      isCompleted: false
    };

    setEnrollments(prev => ({
      ...prev,
      [course.id]: newEnrollment
    }));

    // Update course student count
    setCourses(prev =>
      prev.map(c => (c.id === course.id ? { ...c, studentsCount: c.studentsCount + 1 } : c))
    );

    // Remove from cart if present
    setCart(prev => prev.filter(id => id !== course.id));

    addNotification(
      'success',
      'Enrollment Successful! 🎉',
      `You now have lifetime access to "${course.title}". Happy learning!`
    );

    return true;
  };

  // Learning and Lecture tracking
  const markLectureComplete = (courseId: string, lectureId: string) => {
    setEnrollments(prev => {
      const existing = prev[courseId];
      if (!existing) return prev;

      const completed = existing.completedLectureIds.includes(lectureId)
        ? existing.completedLectureIds.filter(id => id !== lectureId)
        : [...existing.completedLectureIds, lectureId];

      const targetCourse = courses.find(c => c.id === courseId);
      const totalLectures = targetCourse
        ? targetCourse.chapters.reduce((acc, ch) => acc + ch.lectures.length, 0)
        : 1;

      const progressPercent = Math.min(100, Math.round((completed.length / Math.max(1, totalLectures)) * 100));
      const isCompleted = progressPercent >= 100;

      const updated: Enrollment = {
        ...existing,
        completedLectureIds: completed,
        progressPercent,
        isCompleted,
        lastPlayedLectureId: lectureId,
        completedAt: isCompleted && !existing.completedAt ? new Date().toISOString().split('T')[0] : existing.completedAt,
        certificateId: isCompleted && !existing.certificateId ? `EDURISE-CERT-${Date.now().toString(36).toUpperCase()}` : existing.certificateId
      };

      if (isCompleted && !existing.isCompleted) {
        addNotification('success', 'Course Completed! 🏆', `Congratulations! You unlocked your verified Certificate of Completion.`);
      }

      return {
        ...prev,
        [courseId]: updated
      };
    });
  };

  const isLectureCompleted = (courseId: string, lectureId: string) => {
    return !!enrollments[courseId]?.completedLectureIds?.includes(lectureId);
  };

  const saveNote = (courseId: string, lectureId: string, timestamp: string, content: string) => {
    const newNote: Note = {
      id: `note_${Date.now()}`,
      userId: currentUser.id,
      courseId,
      lectureId,
      timestamp,
      content,
      createdAt: new Date().toLocaleString()
    };
    setNotes(prev => [newNote, ...prev]);
    addNotification('success', 'Note Saved', `Timestamped note recorded at ${timestamp}`);
  };

  const deleteNote = (noteId: string) => {
    setNotes(prev => prev.filter(n => n.id !== noteId));
    addNotification('info', 'Note Deleted', 'Your note was removed');
  };

  const addReview = (courseId: string, rating: number, comment: string) => {
    const newReview: Review = {
      id: `rev_${Date.now()}`,
      courseId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      rating,
      comment,
      date: 'Just now',
      helpfulCount: 0
    };
    setReviews(prev => [newReview, ...prev]);

    // Recalculate average rating for course
    setCourses(prev =>
      prev.map(c => {
        if (c.id === courseId) {
          const newCount = c.ratingCount + 1;
          const newAvg = Number(((c.rating * c.ratingCount + rating) / newCount).toFixed(2));
          return { ...c, rating: newAvg, ratingCount: newCount };
        }
        return c;
      })
    );

    addNotification('success', 'Review Submitted', 'Thank you for rating this course!');
  };

  const addDiscussionMessage = (
    courseId: string,
    lectureId: string | undefined,
    title: string,
    content: string
  ) => {
    const newMsg: DiscussionMessage = {
      id: `disc_${Date.now()}`,
      courseId,
      lectureId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      userRole: currentUser.role,
      title,
      content,
      createdAt: 'Just now',
      upvotes: 1,
      replies: []
    };
    setDiscussions(prev => [newMsg, ...prev]);
    addNotification('success', 'Question Posted', 'Your question has been added to the discussion forum');
  };

  const saveStudyPlan = (plan: StudyPlan) => {
    setSavedStudyPlans(prev => [plan, ...prev]);
    addNotification('success', 'Study Plan Saved', `Personalized schedule ready in your dashboard!`);
  };

  // Educator Course Creation & Updates
  const createCourse = (courseData: Partial<Course>): Course => {
    const newCourse: Course = {
      id: `course_${Date.now()}`,
      title: courseData.title || 'Untitled Course',
      subtitle: courseData.subtitle || 'Comprehensive guide by expert educator',
      description: courseData.description || 'Course overview and outcomes.',
      educatorId: currentUser.id,
      educatorName: currentUser.name,
      educatorAvatar: currentUser.avatar,
      educatorTitle: currentUser.title || 'Expert Educator',
      thumbnail:
        courseData.thumbnail ||
        'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&auto=format&fit=crop&q=80',
      previewVideoUrl:
        courseData.previewVideoUrl ||
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      price: courseData.price || 999,
      originalPrice: courseData.originalPrice || 2999,
      discountPercent: Math.round(
        (((courseData.originalPrice || 2999) - (courseData.price || 999)) / (courseData.originalPrice || 2999)) * 100
      ),
      category: courseData.category || 'Programming',
      level: courseData.level || 'All Levels',
      language: courseData.language || 'English',
      rating: 5.0,
      ratingCount: 0,
      studentsCount: 0,
      totalDuration: '0h 0m',
      totalLecturesCount: 0,
      status: 'pending_approval', // Rule: Teachers cannot publish courses until approved by admin
      whatYouWillLearn: courseData.whatYouWillLearn || ['Fundamental concepts', 'Hands-on projects'],
      requirements: courseData.requirements || ['Basic curiosity and commitment to learn'],
      chapters: courseData.chapters || [],
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };

    setCourses(prev => [newCourse, ...prev]);
    addNotification(
      'info',
      'Course Submitted for Review',
      'Your course has been submitted to Admin Quality Assurance for approval.'
    );
    return newCourse;
  };

  const updateCourse = (courseId: string, updates: Partial<Course>) => {
    setCourses(prev =>
      prev.map(c => (c.id === courseId ? { ...c, ...updates, updatedAt: new Date().toISOString().split('T')[0] } : c))
    );
    addNotification('success', 'Course Updated', 'Your changes have been saved.');
  };

  // Video Upload Simulation Pipeline (Uploading -> Processing -> Ready -> Published)
  const startVideoUpload = (
    file: File | { name: string; size: number },
    courseId: string,
    chapterId: string,
    lectureTitle: string,
    description: string,
    isFreePreview: boolean
  ) => {
    const taskId = `task_${Date.now()}`;
    const newTask: VideoUploadTask = {
      id: taskId,
      file,
      courseId,
      chapterId,
      lectureTitle,
      description,
      isFreePreview,
      progress: 10,
      status: 'uploading',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&auto=format&fit=crop&q=80',
      duration: '14:20'
    };

    setUploadTasks(prev => [newTask, ...prev]);
    addNotification('info', 'Upload Started', `Uploading "${lectureTitle}" to secure storage.`);

    // Progress simulation
    let currentProgress = 10;
    const interval = setInterval(() => {
      currentProgress += 25;
      if (currentProgress < 100) {
        setUploadTasks(prev =>
          prev.map(t => (t.id === taskId ? { ...t, progress: currentProgress } : t))
        );
      } else {
        clearInterval(interval);
        // Move to processing
        setUploadTasks(prev =>
          prev.map(t => (t.id === taskId ? { ...t, progress: 100, status: 'processing' } : t))
        );

        setTimeout(() => {
          // Move to ready
          setUploadTasks(prev =>
            prev.map(t => (t.id === taskId ? { ...t, status: 'ready' } : t))
          );
          addNotification('success', 'Video Transcoded', `"${lectureTitle}" is processed and ready to publish.`);
        }, 1500);
      }
    }, 600);
  };

  // Withdrawal Flow
  const requestWithdrawal = (amount: number, method: 'UPI' | 'Bank Transfer', accountDetails: string): boolean => {
    const newWdr: WithdrawalRequest = {
      id: `wdr_${Date.now().toString().slice(-6)}`,
      educatorId: currentUser.id,
      educatorName: currentUser.name,
      amount,
      status: 'PENDING',
      method,
      accountDetails,
      requestedAt: new Date().toISOString().split('T')[0]
    };

    setWithdrawals(prev => [newWdr, ...prev]);
    addNotification('success', 'Withdrawal Requested', `Payout request for ₹${amount.toLocaleString()} submitted.`);
    return true;
  };

  // Admin Actions
  const approveCourse = (courseId: string) => {
    setCourses(prev =>
      prev.map(c => (c.id === courseId ? { ...c, status: 'published', adminFeedback: undefined } : c))
    );
    addNotification('success', 'Course Approved', 'Course is now live in the marketplace!');
  };

  const rejectCourse = (courseId: string, feedback?: string) => {
    setCourses(prev =>
      prev.map(c => (c.id === courseId ? { ...c, status: 'rejected', adminFeedback: feedback || 'Please update chapter curriculum.' } : c))
    );
    addNotification('warning', 'Course Returned', 'Feedback sent to educator.');
  };

  const verifyEducator = (educatorId: string) => {
    setUsers(prev =>
      prev.map(u => (u.id === educatorId ? { ...u, isVerified: true } : u))
    );
    addNotification('success', 'Educator Verified', 'Educator received verified blue badge.');
  };

  const processWithdrawal = (withdrawalId: string) => {
    setWithdrawals(prev =>
      prev.map(w => (w.id === withdrawalId ? { ...w, status: 'PROCESSED', processedAt: new Date().toISOString().split('T')[0] } : w))
    );
    addNotification('success', 'Payout Dispatched', 'Funds successfully transferred to educator account.');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        courses,
        enrollments,
        cart,
        wishlist,
        followedEducators,
        transactions,
        withdrawals,
        notes,
        discussions,
        reviews,
        uploadTasks,
        savedStudyPlans,
        currentPage,
        selectedCourseId,
        selectedLectureId,
        selectedEducatorId,
        studentDashboardTab,
        educatorDashboardTab,
        adminDashboardTab,
        isAuthModalOpen,
        authModalMode,
        isPaymentModalOpen,
        pendingPurchaseCourse,
        navigateTo,
        setCurrentUserRole,
        setUser,
        openAuthModal,
        closeAuthModal,
        openPaymentModal,
        closePaymentModal,
        addToCart,
        removeFromCart,
        isInCart,
        toggleWishlist,
        isInWishlist,
        toggleFollowEducator,
        isFollowingEducator,
        purchaseCourse,
        isEnrolled,
        markLectureComplete,
        isLectureCompleted,
        saveNote,
        deleteNote,
        addReview,
        addDiscussionMessage,
        saveStudyPlan,
        createCourse,
        updateCourse,
        startVideoUpload,
        requestWithdrawal,
        approveCourse,
        rejectCourse,
        verifyEducator,
        processWithdrawal,
        notifications,
        addNotification,
        removeNotification,
        setStudentDashboardTab,
        setEducatorDashboardTab,
        setAdminDashboardTab
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
