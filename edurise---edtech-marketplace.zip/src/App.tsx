/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ToastContainer } from './components/ToastContainer';
import { AuthModal } from './components/AuthModal';
import { PaymentModal } from './components/PaymentModal';

import { LandingPage } from './pages/LandingPage';
import { CourseDiscoveryPage } from './pages/CourseDiscoveryPage';
import { CourseDetailsPage } from './pages/CourseDetailsPage';
import { CoursePlayerPage } from './pages/CoursePlayerPage';
import { StudentDashboard } from './pages/StudentDashboard';
import { EducatorDashboard } from './pages/EducatorDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { EducatorProfilePage } from './pages/EducatorProfilePage';
import { AIHubPage } from './pages/AIHubPage';

const AppContent: React.FC = () => {
  const { currentPage, selectedCourseId, selectedLectureId, selectedEducatorId } = useApp();

  const renderCurrentView = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage />;
      case 'discovery':
        return <CourseDiscoveryPage />;
      case 'course-detail':
        return <CourseDetailsPage courseId={selectedCourseId || 'course_python_bootcamp'} />;
      case 'player':
        return (
          <CoursePlayerPage
            courseId={selectedCourseId || 'course_python_bootcamp'}
            initialLectureId={selectedLectureId || undefined}
          />
        );
      case 'student-dashboard':
        return <StudentDashboard />;
      case 'educator-dashboard':
        return <EducatorDashboard />;
      case 'admin-dashboard':
        return <AdminDashboard />;
      case 'educator-profile':
        return <EducatorProfilePage educatorId={selectedEducatorId || 'user_educator_2'} />;
      case 'ai-hub':
      case 'study-planner':
        return <AIHubPage />;
      default:
        return <LandingPage />;
    }
  };

  const isPlayerView = currentPage === 'player';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Hide standard navbar on full immersive player to maximize canvas space */}
      {!isPlayerView && <Navbar />}

      <main className="flex-1">
        {renderCurrentView()}
      </main>

      {!isPlayerView && <Footer />}

      {/* Global Modals & Notifications */}
      <AuthModal />
      <PaymentModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
