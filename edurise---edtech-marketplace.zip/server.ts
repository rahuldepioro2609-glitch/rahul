import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy/Safe Gemini AI Client Initializer
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// API Routes

// 1. Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 2. AI Tutor Chat Endpoint
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { message, courseTitle, lectureTitle, lectureSummary, history } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const ai = getAI();
    if (!ai) {
      // Fallback simulated intelligent response if API key is not yet set
      return res.json({
        reply: `[EduRise AI Tutor] Regarding "${lectureTitle || courseTitle || 'your lecture'}":\n\nGreat question! In ${courseTitle || 'this subject'}, this concept is essential. Break it down into 3 core steps:\n1. Understand the core invariant\n2. Trace through a simple concrete example\n3. Watch for edge conditions.\n\nLet me know if you would like me to generate 3 practice questions or write a simplified code/visual snippet!`,
        isSimulated: true
      });
    }

    const systemInstruction = `You are the EduRise AI Teaching Assistant and Expert Academic Tutor.
You are helping a student who is currently watching:
- Course: "${courseTitle || 'General'}"
- Current Lecture: "${lectureTitle || 'General Lecture'}"
${lectureSummary ? `- Lecture Context: "${lectureSummary}"` : ''}

Your pedagogical guidelines:
1. Explain concepts with crystal clarity, high accuracy, and intuitive analogies.
2. If the user asks for code, provide clean, idiomatic, well-commented code.
3. If they ask to simplify ("Explain this simply"), use everyday real-world metaphors.
4. If they ask for examples, give progressive examples (easy -> edge case).
5. Always be encouraging, friendly, and structured (use bolding, bullet points, and code blocks).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: message,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const reply = response.text || 'I could not generate an answer at this moment. Please try rephrasing your question.';
    return res.json({ reply, isSimulated: false });
  } catch (error: any) {
    console.error('Error in /api/ai/chat:', error);
    return res.status(500).json({ 
      error: 'Failed to generate AI tutor response',
      details: error?.message || String(error)
    });
  }
});

// 3. AI Study Planner Generator Endpoint
app.post('/api/ai/study-plan', async (req: Request, res: Response) => {
  try {
    const { goal, availableHoursPerWeek, targetDate, courseTitle } = req.body;

    const ai = getAI();
    if (!ai) {
      return res.json({
        plan: {
          id: 'plan_' + Date.now(),
          goal: goal || 'Master Course Concepts',
          availableHoursPerWeek: availableHoursPerWeek || 10,
          targetDate: targetDate || '4 Weeks',
          courseTitle: courseTitle || 'Enrolled Course',
          schedule: [
            {
              week: 1,
              title: 'Week 1: Core Fundamentals & Theory Setup',
              focusTopics: ['Syntax & Environment', 'Core Memory Models', 'Basic Exercises'],
              estimatedHours: availableHoursPerWeek || 10,
              tasks: ['Complete Chapter 1 lectures', 'Submit first checkpoint quiz', 'Take notes on foundational patterns']
            },
            {
              week: 2,
              title: 'Week 2: Intermediate Problem Solving & Algorithms',
              focusTopics: ['Control Flow', 'Data Structures', 'Practice Labs'],
              estimatedHours: availableHoursPerWeek || 10,
              tasks: ['Solve 5 standard problems', 'Build the week 2 mini-project', 'Review AI Tutor explanations']
            },
            {
              week: 3,
              title: 'Week 3: Advanced Architectures & Systems',
              focusTopics: ['Complex Case Studies', 'Performance Optimization'],
              estimatedHours: availableHoursPerWeek || 10,
              tasks: ['Watch advanced lectures at 1.25x speed', 'Code end-to-end milestone']
            },
            {
              week: 4,
              title: 'Week 4: Capstone Project & Certification Exam',
              focusTopics: ['Review Cheat Sheets', 'Final Comprehensive Assessment'],
              estimatedHours: availableHoursPerWeek || 10,
              tasks: ['Finish all pending lectures', 'Score >80% on final quiz', 'Generate certificate of completion']
            }
          ]
        },
        isSimulated: true
      });
    }

    const prompt = `Create a realistic, structured 4-week study timetable for a student studying "${courseTitle}".
Goal: "${goal}". Available time: ${availableHoursPerWeek} hours per week. Target deadline: "${targetDate}".
Provide 4 distinct weeks with practical focus topics, estimated hours, and 3 actionable weekly tasks.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            schedule: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  week: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  focusTopics: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  estimatedHours: { type: Type.NUMBER },
                  tasks: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ['week', 'title', 'focusTopics', 'estimatedHours', 'tasks']
              }
            }
          },
          required: ['schedule']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{"schedule":[]}');
    return res.json({
      plan: {
        id: 'plan_' + Date.now(),
        goal,
        availableHoursPerWeek,
        targetDate,
        courseTitle,
        schedule: parsed.schedule,
        createdAt: new Date().toISOString()
      },
      isSimulated: false
    });
  } catch (error: any) {
    console.error('Error in /api/ai/study-plan:', error);
    return res.status(500).json({ error: 'Failed to generate study plan' });
  }
});

// 4. AI Quiz Generator Endpoint
app.post('/api/ai/quiz', async (req: Request, res: Response) => {
  try {
    const { topic, courseTitle, difficulty } = req.body;
    
    const ai = getAI();
    if (!ai) {
      return res.json({
        quiz: {
          id: 'quiz_' + Date.now(),
          title: `Quiz: ${topic || courseTitle}`,
          description: `Test your understanding of ${topic || 'key concepts'}.`,
          passingScore: 70,
          questions: [
            {
              id: 'q_' + Math.random().toString(36).substring(7),
              question: `Which of the following is the primary advantage of mastering ${topic || 'this concept'} in modern industry?`,
              options: [
                'Guarantees optimal time and memory scaling with clean abstractions',
                'Completely eliminates the need for compilation or testing',
                'Only useful for theoretical research papers',
                'Prevents hardware overheating'
              ],
              correctAnswerIndex: 0,
              explanation: 'Clean abstractions and optimal scaling are the primary reasons why this pattern is standard in production.'
            },
            {
              id: 'q_' + Math.random().toString(36).substring(7),
              question: `When implementing ${topic || 'this solution'}, what is the most common pitfall to avoid?`,
              options: [
                'Writing modular functions',
                'Unbounded loops or unhandled edge conditions',
                'Adding descriptive variable names',
                'Using version control'
              ],
              correctAnswerIndex: 1,
              explanation: 'Edge conditions and unbounded loops cause runtime errors or resource exhaustion.'
            },
            {
              id: 'q_' + Math.random().toString(36).substring(7),
              question: `What is the recommended best practice when refactoring ${topic || 'code in this domain'}?`,
              options: [
                'Delete all unit tests before running',
                'Keep single responsibility principle and test incrementally',
                'Write everything in a single 10,000 line file',
                'Never profile memory usage'
              ],
              correctAnswerIndex: 1,
              explanation: 'Modular design with progressive unit testing ensures regression-free software.'
            }
          ]
        },
        isSimulated: true
      });
    }

    const prompt = `Generate a 4-question multiple-choice quiz for students on the topic "${topic || courseTitle}".
Difficulty: ${difficulty || 'intermediate'}.
Include clear, educational explanations for each question. Exactly 4 options per question and exactly 1 correct option index (0 to 3).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  correctAnswerIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING }
                },
                required: ['question', 'options', 'correctAnswerIndex', 'explanation']
              }
            }
          },
          required: ['title', 'questions']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({
      quiz: {
        id: 'quiz_' + Date.now(),
        title: parsed.title || `AI Quiz: ${topic}`,
        description: parsed.description || `Assessment on ${topic}`,
        passingScore: 75,
        questions: (parsed.questions || []).map((q: any, idx: number) => ({
          id: `q_${Date.now()}_${idx}`,
          ...q
        }))
      },
      isSimulated: false
    });
  } catch (error: any) {
    console.error('Error in /api/ai/quiz:', error);
    return res.status(500).json({ error: 'Failed to generate quiz' });
  }
});

// 5. AI Lecture Summary Endpoint
app.post('/api/ai/summary', async (req: Request, res: Response) => {
  try {
    const { lectureTitle, courseTitle, transcriptOrNotes } = req.body;
    const ai = getAI();

    if (!ai) {
      return res.json({
        summary: `### Quick Summary: ${lectureTitle}\n\n- **Core Thesis**: Deep dive into foundational mechanics and production patterns.\n- **Key Takeaways**:\n  1. Understand the theoretical baseline before implementation.\n  2. Real-world applications require handling asynchronous edge states.\n  3. Always profile time & space constraints.\n- **Action Item**: Review the attached PDF notes and complete the checkpoint quiz.`,
        isSimulated: true
      });
    }

    const prompt = `Provide a high-impact, beautifully formatted executive bullet summary for the lecture "${lectureTitle}" in the course "${courseTitle}".
${transcriptOrNotes ? `Lecture content notes: ${transcriptOrNotes}` : ''}
Include:
1. Core Theme
2. Key Conceptual Takeaways (3-4 bullet points)
3. Common Mistakes to Avoid
4. Next Steps for Student`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
    });

    return res.json({ summary: response.text, isSimulated: false });
  } catch (error: any) {
    console.error('Error in /api/ai/summary:', error);
    return res.status(500).json({ error: 'Failed to generate summary' });
  }
});

// 6. AI Course Recommendations
app.post('/api/ai/recommendations', async (req: Request, res: Response) => {
  try {
    const { interests, currentCourses, careerGoal } = req.body;
    const ai = getAI();

    if (!ai) {
      return res.json({
        recommendations: [
          {
            title: 'Full Stack Web Development: React, Node & Cloud',
            reason: 'Matches your interest in practical web architecture and building end-to-end applications.',
            category: 'Web Development'
          },
          {
            title: 'AI & Machine Learning: Foundations to LLMs',
            reason: 'Complements your programming skills with high-demand Generative AI capabilities.',
            category: 'AI & Machine Learning'
          },
          {
            title: 'Data Structures & Algorithms: The Ace Interview Guide',
            reason: 'Essential for technical interview preparation and competitive coding problem solving.',
            category: 'Programming'
          }
        ],
        isSimulated: true
      });
    }

    const prompt = `A student with interests in [${(interests || ['Coding', 'Mathematics']).join(', ')}] and career goal "${careerGoal || 'Software Engineer'}" wants personalized course recommendations.
Currently taking: [${(currentCourses || []).join(', ')}].
Recommend 3 specific course focus areas with tailored rationale for why this will accelerate their career.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              reason: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ['title', 'reason', 'category']
          }
        }
      }
    });

    const parsed = JSON.parse(response.text || '[]');
    return res.json({ recommendations: parsed, isSimulated: false });
  } catch (error: any) {
    console.error('Error in /api/ai/recommendations:', error);
    return res.status(500).json({ error: 'Failed to get recommendations' });
  }
});

// Production static file serving vs Development Vite middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EduRise server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
