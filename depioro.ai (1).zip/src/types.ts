export type LanguageCode =
  | 'hi'
  | 'en'
  | 'mr'
  | 'gu'
  | 'bn'
  | 'ta'
  | 'te';

export type IssueCategory =
  | 'Water'
  | 'Roads'
  | 'Healthcare'
  | 'Education'
  | 'Electricity'
  | 'Sanitation'
  | 'Transport'
  | 'Agriculture'
  | 'Other';

export type UrgencyLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type RequestStatus =
  | 'Submitted'
  | 'AI Analysed'
  | 'Clustered'
  | 'Under Review'
  | 'Development Planning'
  | 'Resolved';

export interface CitizenRequest {
  id: string;
  title: string;
  description: string;
  originalVoiceTranscript?: string;
  language: string;
  category: IssueCategory;
  state: string;
  district: string;
  cityVillageWard: string;
  submittedAt: string;
  priority: UrgencyLevel;
  status: RequestStatus;
  aiConfidence: number;
  keywords: string[];
  affectedPopulation: number;
  similarNearbyCount: number;
  imageUrl?: string;
  lat: number;
  lng: number;
  aiSummary: string;
  suggestedIntervention: string;
  sdgGoal?: string;
}

export interface DemandHotspot {
  id: string;
  district: string;
  state: string;
  topIssue: IssueCategory;
  requestsCount: number;
  affectedPopulation: number;
  infrastructureScore: number; // 0-100 (lower means worse deficit)
  priorityScore: number; // 0-100 (higher means more urgent)
  severity: UrgencyLevel;
  lat: number;
  lng: number;
  x: number; // SVG coordinate percentage 0-100
  y: number; // SVG coordinate percentage 0-100
  topKeywords: string[];
  recentTrend: string;
  recommendedProject: string;
  schemes: string[];
  activeRequests: string[]; // Request IDs
}

export interface AIRecommendation {
  id: string;
  number: string;
  title: string;
  district: string;
  state: string;
  category: IssueCategory;
  priorityScore: number;
  citizenRequestsCount: number;
  citizenDemandCount?: number;
  aiConfidence?: number;
  affectedPopulation: number;
  urgency: UrgencyLevel;
  impact: 'High' | 'Very High' | 'Moderate';
  infrastructureGap: string;
  aiReasoning: string;
  supportingFeedback: string[];
  suggestedIntervention: string;
  estimatedBudget: string;
  schemeAlignment: string;
  timeline: string;
  executiveBrief?: string;
}

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeName: string;
  greeting: string;
  samplePrompts: Array<{
    title: string;
    text: string;
    category: IssueCategory;
    location: string;
    district: string;
  }>;
}

export interface SystemTelemetry {
  totalUsers: number;
  totalRequests: number;
  aiProcessingStatus: 'Optimal' | 'Degraded' | 'High-Load';
  avgInferenceTimeMs: number;
  activeHotspotsCount: number;
  languagesProcessed: Record<string, number>;
  categoryBreakdown: Record<string, number>;
  uptimePercentage: number;
}
