import React from 'react';
import {
  Mic,
  Brain,
  Layers,
  MapPin,
  BarChart3,
  Sparkles,
  ShieldCheck,
  Globe,
  ArrowRight,
  CheckCircle2,
  Lock,
  Cpu,
  FileCheck,
  Building,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useDepioro } from '../context/DepioroContext';

export const HowItWorksPage: React.FC = () => {
  const { setCurrentRoute } = useDepioro();

  const stepBlocks = [
    {
      num: '01',
      icon: Mic,
      numColor: 'text-amber-600',
      iconBg: 'bg-amber-100/80 text-amber-800',
      title: 'Voice-First Multilingual Audio Ingestion',
      desc: 'Citizens in rural and peri-urban India often face barriers with complex online bureaucratic portals. Depioro allows natural spoken voice inputs in Hindi, Marathi, Bengali, Tamil, Telugu, Gujarati, and English.',
      boxTop: 'Input: Raw Audio Stream / Speech-to-Text',
      badge: '● 10 Indic Dialects',
      badgeColor: 'text-emerald-400',
      content: (
        <>
          <p className="text-slate-300">
            Citizen Input (Audio): <span className="text-amber-300 font-sans">“हमारे गांव पोहरी में 15 दिनों से पीने का पानी नहीं आ रहा है, कृपया हैंडपंप की मरम्मत करवाएं।”</span>
          </p>
          <p className="text-slate-400 text-[11px]">
            Processing: Normalization → Dialect acoustic model → Clean UTF-8 Devanagari text transcript.
          </p>
        </>
      ),
    },
    {
      num: '02',
      icon: Brain,
      numColor: 'text-amber-700',
      iconBg: 'bg-amber-100/80 text-amber-900',
      title: 'Gemini 3.7 Semantic Extraction',
      desc: 'Our server-side Gemini 3.7 Flash engine analyzes the transcript. It extracts the problem domain, assigns an urgency rating, pulls geo-entities, computes confidence, and indexes civic keywords.',
      boxTop: 'Output: Structured Civic Object',
      badge: 'Confidence: 96%',
      badgeColor: 'text-amber-300',
      content: (
        <div className="text-amber-200/90 space-y-1 text-[11px]">
          <div>{`{`}</div>
          <div className="pl-4 text-emerald-400">{`"category": "Water",`}</div>
          <div className="pl-4 text-amber-300">{`"urgency": "Critical",`}</div>
          <div className="pl-4">{`"district": "Shivpuri", "block": "Pohari",`}</div>
          <div className="pl-4">{`"keywords": ["Potable Water", "Handpump", "Aquifer"],`}</div>
          <div className="pl-4">{`"sdgGoal": "SDG 6: Clean Water & Sanitation"`}</div>
          <div>{`}`}</div>
        </div>
      ),
    },
    {
      num: '03',
      icon: MapPin,
      numColor: 'text-yellow-600',
      iconBg: 'bg-yellow-100 text-yellow-800',
      title: 'Spatial Density & Demand Clustering',
      desc: 'Individual grievances often get lost as one-off complaints. Depioro dynamically groups related requests within a spatial radius to create an emerging demand hotspot with quantitative urgency scoring.',
      boxTop: 'Cluster Telemetry',
      badge: '1,284 Complaints Ingested',
      badgeColor: 'text-amber-400',
      content: (
        <div className="grid grid-cols-2 gap-3 text-slate-200">
          <div className="bg-slate-800 p-2.5 rounded-xl border border-slate-700">
            <span className="text-[10px] text-slate-400 block">Infrastructure Gap</span>
            <strong className="text-red-400 text-sm">38 / 100 Deficit</strong>
          </div>
          <div className="bg-slate-800 p-2.5 rounded-xl border border-slate-700">
            <span className="text-[10px] text-slate-400 block">Priority Score</span>
            <strong className="text-amber-400 text-sm">92 / 100</strong>
          </div>
        </div>
      ),
    },
    {
      num: '04',
      icon: BarChart3,
      numColor: 'text-emerald-600',
      iconBg: 'bg-emerald-100 text-emerald-700',
      title: 'Actionable Scheme & Budget Recommendations',
      desc: 'District Magistrates and Planning Boards receive structured project dossiers with scheme mappings (Jal Jeevan Mission, PMGSY, NHM) and executive briefs for capital sanctioning.',
      boxTop: 'Target Policy Brief',
      badge: '₹14.8 Cr Scheme Capital',
      badgeColor: 'text-emerald-400',
      content: (
        <>
          <p className="text-slate-300">
            Project: <strong className="text-white">Shivpuri Potable Water Distribution & Solar Borewell Grid</strong>
          </p>
          <p className="text-slate-400 text-[11px]">
            Benefit: 42,000 rural citizens • 18 solar micro-grids • Jal Jeevan Mission Alignment
          </p>
        </>
      ),
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-3xl mx-auto space-y-4"
      >
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100/80 border border-amber-300 text-amber-900 text-xs font-semibold">
          <Brain className="w-3.5 h-3.5 text-amber-700" />
          <span>Semantic NLP & Spatial Intelligence Architecture</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-950 tracking-tight">
          How Depioro.ai Converts Grassroots Voices into Policy Action
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          A transparent look at the AI pipeline designed for Indian public governance, eliminating literacy hurdles and converting unstructured civic chatter into evidence-based DPR recommendations.
        </p>
      </motion.div>

      {/* 4 Deep Dive Step Blocks */}
      <div className="space-y-8">
        {stepBlocks.map((step, idx) => {
          const Icon = step.icon;
          return (
            <motion.div
              key={step.num}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              className="bg-white rounded-3xl p-6 sm:p-10 shadow-xs border border-amber-100/80 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center hover:shadow-md transition-shadow"
            >
              <div className="lg:col-span-4 space-y-3">
                <span className={`font-mono text-3xl font-black ${step.numColor}`}>{step.num}</span>
                <div className={`w-12 h-12 rounded-2xl ${step.iconBg} flex items-center justify-center`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-900">
                  {step.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {step.desc}
                </p>
              </div>

              <div className="lg:col-span-8 bg-slate-900 text-white rounded-2xl p-5 sm:p-6 space-y-3 font-mono text-xs border border-slate-800">
                <div className="text-slate-400 pb-2 border-b border-slate-800 flex justify-between">
                  <span>{step.boxTop}</span>
                  <span className={step.badgeColor}>{step.badge}</span>
                </div>
                {step.content}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* CTA Box */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center pt-4"
      >
        <div className="bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 text-white rounded-3xl p-8 shadow-xl max-w-3xl mx-auto space-y-4 border border-amber-600/30">
          <h3 className="text-2xl font-extrabold">Ready to Experience Depioro.ai?</h3>
          <p className="text-xs sm:text-sm text-amber-100 max-w-xl mx-auto">
            Try speaking an issue in Hindi or English, or open the district intelligence map.
          </p>
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <button
              onClick={() => setCurrentRoute('citizen')}
              className="px-5 py-3 rounded-xl bg-white text-amber-950 font-bold text-xs sm:text-sm shadow-md hover:bg-amber-50 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Mic className="w-4 h-4 text-amber-700" />
              <span>Report an Issue (Citizen)</span>
            </button>
            <button
              onClick={() => setCurrentRoute('dashboard')}
              className="px-5 py-3 rounded-xl bg-slate-950 text-white font-bold text-xs sm:text-sm shadow-md hover:bg-slate-900 transition-all flex items-center gap-2 cursor-pointer border border-slate-800"
            >
              <BarChart3 className="w-4 h-4 text-amber-400" />
              <span>Open Intelligence Dashboard</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

