import React, { useState } from 'react';
import {
  Mic,
  BarChart3,
  Sparkles,
  ArrowRight,
  Shield,
  Layers,
  MapPin,
  Users,
  CheckCircle2,
  TrendingUp,
  Brain,
  Globe,
  Radio,
  FileCheck,
  AlertTriangle,
  Play,
  Lightbulb,
  ChevronDown,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useDepioro } from '../context/DepioroContext';
import { LANGUAGES } from '../data/mockData';

export const LandingPage: React.FC = () => {
  const { setCurrentRoute, stats, hotspots, selectedLanguage, setSelectedLanguage } = useDepioro();
  const [activeStep, setActiveStep] = useState<number>(1);

  const steps = [
    {
      num: '01',
      title: 'Citizen Speaks',
      sub: 'Multi-lingual Voice & Text',
      desc: 'A citizen speaks or types in Hindi, Marathi, Bengali, Tamil, Telugu, Gujarati, or English without filling complex bureaucratic forms.',
      badge: 'Voice-First Access',
      icon: Mic,
      color: 'bg-amber-600',
      tagColor: 'bg-amber-50 text-amber-800 border-amber-200',
      sample: '“हमारे शिवपुरी पोहरी में 15 दिनों से पीने का पानी नहीं आ रहा है...”',
    },
    {
      num: '02',
      title: 'AI Understands',
      sub: 'Semantic NLP & Categorization',
      desc: 'Gemini AI identifies the language, extracts category (e.g. Water Infrastructure), detects urgency level, geo-location, and civic keywords.',
      badge: '96% AI Precision',
      icon: Brain,
      color: 'bg-amber-700',
      tagColor: 'bg-amber-100/70 text-amber-900 border-amber-300',
      sample: 'Extracted: Category: Water | Urgency: Critical | Shivpuri | Pop: 42,000',
    },
    {
      num: '03',
      title: 'Demand Emerges',
      sub: 'Spatial Hotspot Clustering',
      desc: 'Individual complaints across nearby wards and panchayats are clustered into geographic demand hotspots with severity scoring.',
      badge: 'Spatial Clustering',
      icon: MapPin,
      color: 'bg-yellow-600',
      tagColor: 'bg-yellow-50 text-yellow-800 border-yellow-200',
      sample: '1,284 nearby reports clustered in Pohari • Priority Score: 92/100',
    },
    {
      num: '04',
      title: 'Policymakers Act',
      sub: 'Actionable Project DPRs & Schemes',
      desc: 'District Magistrates and planning boards receive ranked development recommendations, executive briefs, and scheme budget alignments.',
      badge: 'Evidence-Based Governance',
      icon: BarChart3,
      color: 'bg-emerald-600',
      tagColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      sample: 'Recommendation: ₹14.8Cr Solar Potable Water Grid under Jal Jeevan Mission',
    },
  ];

  return (
    <div className="space-y-16 lg:space-y-24 pb-16">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-16 lg:pt-20 lg:pb-24 bg-gradient-to-b from-amber-50/70 via-stone-50 to-white border-b border-amber-100">
        {/* Subtle decorative background pattern */}
        <div className="absolute inset-0 opacity-[0.04] bg-[radial-gradient(#b45309_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="text-center max-w-3xl mx-auto space-y-6"
          >
            {/* Top Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1, duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100/80 border border-amber-300 text-amber-900 text-xs font-semibold shadow-2xs"
            >
              <span className="flex h-2 w-2 rounded-full bg-amber-600 animate-ping" />
              <span>Next-Generation Citizen Development Intelligence for India</span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-950 tracking-tight leading-[1.15]"
            >
              Turn Citizen Voices Into <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-amber-800 via-amber-600 to-yellow-600 bg-clip-text text-transparent">
                Development Intelligence.
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-base sm:text-lg lg:text-xl text-slate-600 font-normal leading-relaxed max-w-2xl mx-auto"
            >
              Depioro.ai listens to citizens in their own language, transforms local development requests into structured insights, and helps policymakers identify where infrastructure is needed most.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4"
            >
              <button
                id="hero-cta-report"
                onClick={() => setCurrentRoute('citizen')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold text-sm sm:text-base shadow-lg shadow-amber-900/20 hover:shadow-xl hover:shadow-amber-900/30 transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
              >
                <Mic className="w-5 h-5 text-amber-200" />
                <span>Report a Development Issue</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              <button
                id="hero-cta-dashboard"
                onClick={() => setCurrentRoute('dashboard')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm sm:text-base shadow-md hover:shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
              >
                <BarChart3 className="w-5 h-5 text-amber-400" />
                <span>Explore Intelligence Dashboard</span>
              </button>
            </motion.div>

            {/* Live Demo Trigger Helper */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="pt-2 flex items-center justify-center gap-2 text-xs text-slate-500"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Full end-to-end simulation ready: Report in Hindi → View live AI hotspot in Shivpuri</span>
            </motion.div>
          </motion.div>

          {/* VISUAL PIPELINE WORKFLOW (Citizen Voice -> AI -> Data -> Hotspots -> Policy Insights) */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="mt-14 max-w-5xl mx-auto"
          >
            <div className="bg-white rounded-2xl p-4 sm:p-8 shadow-xl shadow-amber-950/5 border border-amber-100">
              <div className="flex items-center justify-between pb-4 mb-6 border-b border-amber-50">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-600 animate-pulse" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Depioro End-to-End Processing Architecture
                  </span>
                </div>
                <span className="text-xs text-amber-800 font-medium">
                  Real-Time Multilingual NLP Engine
                </span>
              </div>

              {/* 5-Step Horizontal Flow */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
                {/* Node 1 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1, duration: 0.5 }}
                  className="bg-amber-50/40 hover:bg-amber-50/80 transition-all rounded-xl p-3.5 border border-amber-200/60 flex flex-col items-center text-center space-y-2 group"
                >
                  <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
                    <Mic className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Citizen Voice</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Hindi, Marathi, etc.</div>
                  </div>
                  <span className="text-[10px] font-semibold text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded-full">
                    Voice & Text
                  </span>
                </motion.div>

                {/* Arrow connector */}
                <div className="hidden md:flex items-center justify-center -mx-3 z-10 text-slate-300">
                  <ArrowRight className="w-4 h-4 text-amber-500" />
                </div>

                {/* Node 2 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="bg-amber-50/40 hover:bg-amber-50/80 transition-all rounded-xl p-3.5 border border-amber-200/60 flex flex-col items-center text-center space-y-2 group"
                >
                  <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
                    <Brain className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">AI Intelligence</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Gemini 3.7 NLP</div>
                  </div>
                  <span className="text-[10px] font-semibold text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded-full">
                    Category & Urgency
                  </span>
                </motion.div>

                {/* Arrow connector */}
                <div className="hidden md:flex items-center justify-center -mx-3 z-10 text-slate-300">
                  <ArrowRight className="w-4 h-4 text-amber-500" />
                </div>

                {/* Node 3 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="bg-amber-50/40 hover:bg-amber-50/80 transition-all rounded-xl p-3.5 border border-amber-200/60 flex flex-col items-center text-center space-y-2 group"
                >
                  <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Structured Data</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Keywords & Telemetry</div>
                  </div>
                  <span className="text-[10px] font-semibold text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded-full">
                    Geo-Tagged
                  </span>
                </motion.div>

                {/* Arrow connector */}
                <div className="hidden md:flex items-center justify-center -mx-3 z-10 text-slate-300">
                  <ArrowRight className="w-4 h-4 text-amber-500" />
                </div>

                {/* Node 4 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                  className="bg-amber-50/40 hover:bg-amber-50/80 transition-all rounded-xl p-3.5 border border-amber-200/60 flex flex-col items-center text-center space-y-2 group"
                >
                  <div className="w-10 h-10 rounded-lg bg-yellow-100 text-yellow-800 flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Demand Hotspots</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">District Clustering</div>
                  </div>
                  <span className="text-[10px] font-semibold text-yellow-800 bg-yellow-100/80 px-2 py-0.5 rounded-full">
                    Severity Scoring
                  </span>
                </motion.div>

                {/* Arrow connector */}
                <div className="hidden md:flex items-center justify-center -mx-3 z-10 text-slate-300">
                  <ArrowRight className="w-4 h-4 text-emerald-500" />
                </div>

                {/* Node 5 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.5, duration: 0.5 }}
                  className="bg-emerald-50/40 hover:bg-emerald-50/80 transition-all rounded-xl p-3.5 border border-emerald-200/60 flex flex-col items-center text-center space-y-2 group"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
                    <BarChart3 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Policy Insights</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Schemes & Budget</div>
                  </div>
                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                    Actionable DPRs
                  </span>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* TRUST & IMPACT SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.7 }}
          className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden border border-amber-950/30"
        >
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-amber-600/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-64 h-64 bg-yellow-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  Platform Telemetry & Civic Impact
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
                  Transforming India's Public Infrastructure Planning
                </h2>
              </div>
              <div className="text-xs text-slate-400 max-w-sm">
                *Demo statistics representing illustrative aggregation across Madhya Pradesh civic zones.
              </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 pt-2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1, duration: 0.5 }}
                className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700/60 space-y-1.5 hover:border-amber-500/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-400">Supported Languages</span>
                  <Globe className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                  10+
                </div>
                <p className="text-[11px] text-slate-400">
                  Hindi, Marathi, Bengali, Tamil, Telugu, Gujarati & more
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700/60 space-y-1.5 hover:border-amber-500/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-400">Citizen Reporting</span>
                  <Radio className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                  24/7
                </div>
                <p className="text-[11px] text-slate-400">
                  Instant voice-first AI transcription with zero literacy barriers
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3, duration: 0.5 }}
                className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700/60 space-y-1.5 hover:border-amber-500/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-400">AI-Powered Analysis</span>
                  <Brain className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                  &lt; 2.4s
                </div>
                <p className="text-[11px] text-slate-400">
                  Real-time categorization, urgency scoring & keyword tagging
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4, duration: 0.5 }}
                className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700/60 space-y-1.5 hover:border-amber-500/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-400">Demand Intelligence</span>
                  <TrendingUp className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                  {(stats?.totalRequests ?? 12482).toLocaleString()}+
                </div>
                <p className="text-[11px] text-slate-400">
                  Processed citizen inputs feeding {stats.hotspotsCount} live district hotspots
                </p>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* HOW IT WORKS (4-STEP WORKFLOW) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto space-y-3 mb-12"
        >
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold uppercase tracking-wider">
            <span>Seamless 4-Step Process</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            How Depioro.ai Works
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            Bridging grassroots citizen voices and state administrative decision-making through automated semantic intelligence.
          </p>
        </motion.div>

        {/* Step Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s, index) => {
            const Icon = s.icon;
            const isSelected = activeStep === index + 1;
            return (
              <motion.div
                key={s.num}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.12, duration: 0.5 }}
                onClick={() => setActiveStep(index + 1)}
                className={`cursor-pointer rounded-2xl p-6 transition-all duration-200 flex flex-col justify-between border ${
                  isSelected
                    ? 'bg-white ring-2 ring-amber-600 shadow-xl border-transparent -translate-y-1'
                    : 'bg-white hover:bg-amber-50/30 shadow-xs border-slate-200'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-black text-slate-300 font-mono">
                      {s.num}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${s.tagColor}`}>
                      {s.badge}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${s.color} text-white flex items-center justify-center shadow-sm`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">{s.title}</h3>
                      <p className="text-xs text-slate-500 font-medium">{s.sub}</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{s.desc}</p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <div className="p-2.5 rounded-lg bg-stone-50 text-[11px] text-slate-700 italic border border-stone-100">
                    {s.sample}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Action Link below workflow */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="mt-10 text-center"
        >
          <button
            onClick={() => setCurrentRoute('citizen')}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs sm:text-sm font-semibold shadow-sm transition-all cursor-pointer"
          >
            <Mic className="w-4 h-4 text-amber-200" />
            <span>Try Citizen Voice Reporting Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </motion.div>
      </section>

      {/* NEW GOVTECH INNOVATION MODULES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Jan Sunwai Copilot Showcase Card */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4 hover:border-amber-400 transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                <Radio className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                <span>Live Public Hearing Intelligence</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Jan Sunwai Live AI Voice Copilot
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Assists District Collectors and Gram Sabhas during in-person hearings. Automatically transcribes citizen oral testimony, identifies applicable schemes, assigns executive engineers, and generates binding 7-day action decrees.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Includes Hindi Speech Synthesis</span>
              <button
                onClick={() => setCurrentRoute('jan-sunwai')}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Launch Hearing Copilot</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </button>
            </div>
          </motion.div>

          {/* Vikas Budget Allocation Engine Card */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4 hover:border-amber-400 transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-xs font-bold">
                <TrendingUp className="w-3.5 h-3.5 text-amber-700" />
                <span>District Capital Allocation Engine</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Vikas Budget & ROI Optimizer
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Simulate capital allocation from ₹10 Cr to ₹100 Cr across citizen-demanded infrastructure packages. Uses knapsack optimization to maximize citizen welfare, speed of execution, or Central 60% matching grants.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Auto-Generates Financial Sanction Memos</span>
              <button
                onClick={() => setCurrentRoute('budget-optimizer')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Open Budget Simulator</span>
                <ArrowRight className="w-3.5 h-3.5 text-yellow-200" />
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* QUICK HOTSPOT TEASER SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.7 }}
          className="bg-gradient-to-br from-slate-900 to-amber-950/70 text-white rounded-3xl p-6 sm:p-10 shadow-xl border border-slate-800"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                <span>Live Demand Hotspot: Shivpuri District</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                1,284 Citizen Reports Clustered into Jal Jeevan Recommendation
              </h3>

              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                In Pohari Block, rural women reported extreme water scarcity via Hindi voice submissions. Depioro AI synthesized the complaints, mapped aquifer deficits, and generated a ₹14.8Cr project recommendation for the District Magistrate.
              </p>

              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
                  <span className="text-[10px] text-slate-400 block">Top Issue</span>
                  <strong className="text-sm font-bold text-amber-400">Water Supply</strong>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
                  <span className="text-[10px] text-slate-400 block">Priority Score</span>
                  <strong className="text-sm font-bold text-amber-400">92 / 100</strong>
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60">
                  <span className="text-[10px] text-slate-400 block">Population</span>
                  <strong className="text-sm font-bold text-emerald-400">42,000+</strong>
                </div>
              </div>

              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  onClick={() => {
                    setCurrentRoute('dashboard');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold text-xs sm:text-sm shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <BarChart3 className="w-4 h-4 text-amber-200" />
                  <span>Open Demand Hotspot Map</span>
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('recommendations');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs sm:text-sm border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>View Policy Executive Brief</span>
                </button>
              </div>
            </div>

            {/* Hotspot card preview visual */}
            <div className="lg:col-span-6">
              <motion.div
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2, duration: 0.6 }}
                className="bg-white text-slate-900 rounded-2xl p-5 sm:p-6 shadow-2xl border border-amber-100"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                    <span className="text-xs font-bold text-slate-900">
                      Active Cluster: Shivpuri-Pohari
                    </span>
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700">
                    Critical Urgency
                  </span>
                </div>

                <div className="mt-4 space-y-3">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-100 text-xs">
                    <p className="font-medium text-slate-800">
                      “शिवपुरी में पेयजल संकट: 400 से ज्यादा परिवार 3 किलोमीटर दूर से पानी लाने को मजबूर हैं।”
                    </p>
                    <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-500">
                      <span>Language: Hindi (हिन्दी)</span>
                      <span>•</span>
                      <span>Voice Transcription verified (96% AI confidence)</span>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200/60 text-xs space-y-1">
                    <div className="flex items-center justify-between text-amber-950 font-bold">
                      <span>AI Suggested Intervention</span>
                      <span className="text-[11px] text-amber-800">Jal Jeevan Mission</span>
                    </div>
                    <p className="text-amber-900 text-[11px]">
                      Deploy 18 deep-bore solar micro-grids & emergency mobile tanker routes.
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span>127 similar complaints nearby</span>
                  <button
                    onClick={() => setCurrentRoute('dashboard')}
                    className="font-semibold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
                  >
                    Inspect in Dashboard <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </section>
    </div>
  );
};

