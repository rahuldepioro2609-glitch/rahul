import React, { useState } from 'react';
import {
  Sparkles,
  MapPin,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
  TrendingUp,
  Download,
  Printer,
  Copy,
  ChevronRight,
  ShieldCheck,
  Building,
  Layers,
  ArrowRight,
  Send,
  Sliders,
  Check,
  Bell,
  Building2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDepioro } from '../context/DepioroContext';
import { AIRecommendation } from '../types';
import { generatePolicyExecutiveBrief } from '../services/aiService';
import { CircularProgressRing } from './CircularProgressRing';
import { NotifyStakeholdersModal, DispatchInfo } from './NotifyStakeholdersModal';
import { PrintDossierHeader, PrintSignatureBlock } from './PrintDossierHeader';

export const ProjectIntelligence: React.FC = () => {
  const { recommendations, selectedRecommendation, setSelectedRecommendation, setCurrentRoute } =
    useDepioro();

  const [activeRec, setActiveRec] = useState<AIRecommendation>(
    selectedRecommendation || recommendations[0]
  );
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [copied, setCopied] = useState(false);
  const [sanctioned, setSanctioned] = useState<Record<string, boolean>>({});
  const [isGeneratingBrief, setIsGeneratingBrief] = useState(false);
  const [generatedBriefText, setGeneratedBriefText] = useState<string | null>(null);
  const [notifyModalRec, setNotifyModalRec] = useState<AIRecommendation | null>(null);
  const [notifiedMap, setNotifiedMap] = useState<Record<string, DispatchInfo>>({});

  const filteredRecs = recommendations.filter((r) => {
    return filterCategory === 'All' || r.category === filterCategory;
  });

  const handleSelectRec = (rec: AIRecommendation) => {
    setActiveRec(rec);
    setSelectedRecommendation(rec);
    setGeneratedBriefText(null);
  };

  const handleCopySummary = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulateSanction = (recId: string) => {
    setSanctioned((prev) => ({ ...prev, [recId]: true }));
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch (err) {}
  };

  const handleGenerateFreshBrief = async () => {
    if (!activeRec) return;
    setIsGeneratingBrief(true);
    try {
      const brief = await generatePolicyExecutiveBrief(
        activeRec.title,
        `${activeRec.district}, ${activeRec.state}`,
        activeRec.category,
        activeRec.citizenDemandCount || activeRec.citizenRequestsCount || 1284,
        activeRec.affectedPopulation || 42000,
        activeRec.supportingFeedback
      );
      setGeneratedBriefText(brief);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingBrief(false);
    }
  };

  const handlePrintDossier = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 print:p-0 print:m-0 print:max-w-none print:space-y-4">
      {/* Official Government Print Header (Visible only when printed/PDF exported) */}
      <PrintDossierHeader
        title={activeRec ? activeRec.title : 'AI Infrastructure Recommendations Dossier'}
        documentType="DETAILED PROJECT REPORT (DPR) & POLICY DOSSIER"
        documentRef={`DEPIORO/DPR/2026/${activeRec?.district?.toUpperCase().slice(0, 3) || 'MP'}-${activeRec?.id?.toUpperCase().slice(-4) || '9102'}`}
        district={activeRec?.district || 'Sehore District'}
        state={activeRec?.state || 'Madhya Pradesh'}
        classification="CONFIDENTIAL • FOR ADMINISTRATIVE & SANCTIONING REVIEW"
      />

      {/* Screen Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Automated Detailed Project Reports (DPR) & Schemes</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-950 tracking-tight">
            AI Project Recommendations & Executive Briefs
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Data-backed public infrastructure projects ranked by urgency, citizen demand density, and budget alignment.
          </p>
        </div>

        {/* Category Filters & Print Action */}
        <div className="flex items-center gap-2.5">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3.5 py-2 rounded-xl border border-stone-300 bg-white text-xs font-semibold text-slate-800 shadow-2xs focus:ring-2 focus:ring-amber-500 cursor-pointer"
          >
            <option value="All">All Domains ({recommendations.length})</option>
            <option value="Water">Water Infrastructure</option>
            <option value="Roads">Roads & Connectivity</option>
            <option value="Healthcare">Healthcare Facilities</option>
            <option value="Sanitation">Sanitation & Drainage</option>
            <option value="Electricity">Electricity Grid</option>
          </select>

          <button
            onClick={handlePrintDossier}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-1.5 cursor-pointer"
            title="Print or Save PDF Dossier for Government Review"
          >
            <Printer className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Main Split: Left Recommendation Cards List & Right Deep Executive Brief */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start print:block print:gap-0">
        {/* Left 5 Cols: Ranked Project Cards (Hidden in print mode to keep focus on the active DPR dossier) */}
        <div className="lg:col-span-5 space-y-4 print:hidden">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1">
            <span>Ranked by AI Priority Score</span>
            <span>{filteredRecs.length} Projects Available</span>
          </div>

          {filteredRecs.map((rec, index) => {
            const isSelected = activeRec?.id === rec.id;
            const isSanctioned = sanctioned[rec.id];

            return (
              <div
                key={rec.id}
                onClick={() => handleSelectRec(rec)}
                className={`cursor-pointer rounded-3xl p-5 sm:p-6 transition-all border ${
                  isSelected
                    ? 'bg-amber-50/80 border-amber-600 shadow-md ring-2 ring-amber-500/20'
                    : 'bg-white hover:bg-stone-50 border-stone-200 shadow-2xs'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-md bg-slate-900 text-white">
                        #{index + 1}
                      </span>
                      <span className="text-xs font-bold text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded-full border border-amber-200">
                        Priority: {rec.priorityScore}/100
                      </span>
                      <span className="text-xs font-extrabold text-amber-900 bg-amber-100/60 px-2.5 py-0.5 rounded-lg whitespace-nowrap">
                        {rec.estimatedBudget}
                      </span>
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900 mt-1 leading-snug">
                      {rec.title}
                    </h3>
                  </div>

                  <div className="shrink-0 flex flex-col items-center pt-0.5">
                    <CircularProgressRing
                      value={rec.aiConfidence || 95}
                      size="sm"
                      variant="goldwood"
                      id={`project-rec-ring-${rec.id}`}
                      showLabel={true}
                      subLabel="Confidence"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 mt-2">
                  <MapPin className="w-3.5 h-3.5 text-amber-600" />
                  <span>
                    {rec.district}, {rec.state}
                  </span>
                  <span>•</span>
                  <span>{rec.category}</span>
                </div>

                <p className="text-xs text-slate-600 mt-2.5 line-clamp-2 leading-relaxed">
                  {rec.aiReasoning}
                </p>

                <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-stone-200/60 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Citizen Demand</span>
                    <strong className="text-slate-900 font-bold">
                      {(rec.citizenDemandCount ?? rec.citizenRequestsCount ?? 0).toLocaleString()} verified voices
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Population Benefited</span>
                    <strong className="text-emerald-700 font-bold">
                      {(rec.affectedPopulation ?? 0).toLocaleString()} citizens
                    </strong>
                  </div>
                </div>

                {/* Status Badges: Sanction & Stakeholder Notification */}
                <div className="mt-3 flex flex-col gap-2">
                  {notifiedMap[rec.id] && (
                    <div className="py-1 px-2.5 rounded-lg bg-amber-100/90 text-amber-950 text-[11px] font-bold flex items-center justify-between border border-amber-300/80">
                      <div className="flex items-center gap-1.5 truncate">
                        <Bell className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        <span className="truncate">Notified: {notifiedMap[rec.id].officesCount} Local Gov Offices</span>
                      </div>
                      <span className="font-mono text-[10px] text-amber-800 shrink-0">{notifiedMap[rec.id].dispatchId}</span>
                    </div>
                  )}

                  {isSanctioned && (
                    <div className="py-1 px-2.5 rounded-lg bg-emerald-100 text-emerald-900 text-[11px] font-bold flex items-center gap-1.5 border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>Administrative In-Principle Sanction Simulated</span>
                    </div>
                  )}

                  {/* Card Action: Notify Stakeholders Button */}
                  <div className="pt-1 flex items-center justify-end">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setNotifyModalRec(rec);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer hover:border-amber-400"
                    >
                      <Bell className="w-3.5 h-3.5 text-amber-700" />
                      <span>{notifiedMap[rec.id] ? 'Re-Notify Stakeholders' : 'Notify Stakeholders'}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right 7 Cols: Detailed Executive Intelligence Brief (Full Width in Print) */}
        <div className="lg:col-span-7 print:w-full print:m-0">
          {activeRec ? (
            <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-stone-200 space-y-6 sticky top-24 print:static print:border-none print:shadow-none print:p-0 print:space-y-4">
              {/* Header */}
              <div className="pb-4 border-b border-stone-100 space-y-2 print:border-stone-400 print:pb-2">
                <div className="flex flex-wrap items-center justify-between gap-2 print:hidden">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Executive Policy Brief (DPR Draft)
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        handleCopySummary(
                          `Project: ${activeRec.title}\nDistrict: ${activeRec.district}\nBudget: ${activeRec.estimatedBudget}\nIntervention: ${activeRec.suggestedIntervention}`
                        )
                      }
                      className="px-2.5 py-1 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
                    </button>
                    <button
                      onClick={handlePrintDossier}
                      className="px-2.5 py-1 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5 text-amber-700" />
                      <span>Print / PDF</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1 flex-1">
                    <h2 className="text-xl sm:text-2xl font-extrabold text-slate-950 leading-tight print:text-[16pt]">
                      {activeRec.title}
                    </h2>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 pt-1 print:text-[10pt]">
                      <span className="flex items-center gap-1 font-semibold text-amber-900">
                        <MapPin className="w-3.5 h-3.5 text-amber-600" /> {activeRec.district}, {activeRec.state}
                      </span>
                      <span>•</span>
                      <span className="font-bold text-slate-800">{activeRec.category} Infrastructure</span>
                      <span>•</span>
                      <span className="font-extrabold text-emerald-700">{activeRec.estimatedBudget}</span>
                    </div>
                  </div>

                  <div className="shrink-0 flex flex-col items-center bg-stone-50 px-3 py-2 rounded-2xl border border-stone-200/80 shadow-2xs print:border-stone-300">
                    <CircularProgressRing
                      value={activeRec.aiConfidence || 95}
                      size="md"
                      variant="goldwood"
                      id="active-rec-dpr-ring"
                      showLabel={true}
                      subLabel="AI Confidence"
                    />
                  </div>
                </div>
              </div>

              {/* Core Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs print:grid-cols-4 print:gap-2">
                <div className="bg-stone-50 p-3 rounded-2xl border border-stone-100 print:border-stone-300 print:rounded-lg">
                  <span className="text-slate-400 text-[10px] block print:text-stone-600">Priority Score</span>
                  <strong className="text-amber-700 font-extrabold text-base print:text-stone-950">
                    {activeRec.priorityScore} / 100
                  </strong>
                </div>

                <div className="bg-stone-50 p-3 rounded-2xl border border-stone-100 print:border-stone-300 print:rounded-lg">
                  <span className="text-slate-400 text-[10px] block print:text-stone-600">Citizen Demand</span>
                  <strong className="text-amber-900 font-extrabold text-base print:text-stone-950">
                    {(activeRec.citizenDemandCount ?? activeRec.citizenRequestsCount ?? 0).toLocaleString()}
                  </strong>
                </div>

                <div className="bg-stone-50 p-3 rounded-2xl border border-stone-100 print:border-stone-300 print:rounded-lg">
                  <span className="text-slate-400 text-[10px] block print:text-stone-600">Impact Population</span>
                  <strong className="text-slate-900 font-extrabold text-base print:text-stone-950">
                    {(activeRec.affectedPopulation ?? 0).toLocaleString()}
                  </strong>
                </div>

                <div className="bg-stone-50 p-3 rounded-2xl border border-stone-100 print:border-stone-300 print:rounded-lg">
                  <span className="text-slate-400 text-[10px] block print:text-stone-600">Infra Gap Score</span>
                  <strong className="text-rose-600 font-extrabold text-base print:text-stone-950">
                    {activeRec.infrastructureGapScore} / 100
                  </strong>
                </div>
              </div>

              {/* Problem Analysis & AI Reasoning */}
              <div className="space-y-2 break-inside-avoid">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5 print:text-[10pt] print:font-extrabold">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 print:hidden" />
                  AI Synthesis & Problem Reasoning
                </h4>
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs sm:text-sm text-slate-700 leading-relaxed space-y-2 print:border-stone-300 print:rounded-lg print:text-[10pt]">
                  <p>{activeRec.aiReasoning}</p>
                </div>
              </div>

              {/* Supporting Citizen Feedback Quotes */}
              <div className="space-y-2 break-inside-avoid">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider print:text-[10pt] print:font-extrabold">
                  Supporting Citizen Voice Feedback (Grassroots Quotes)
                </h4>
                <div className="space-y-2">
                  {activeRec.supportingFeedback.map((quote, i) => (
                    <div
                      key={i}
                      className="p-3 bg-amber-50/60 rounded-xl border border-amber-100 text-xs text-slate-700 italic flex items-start gap-2 print:bg-stone-50 print:border-stone-300 print:text-[9.5pt]"
                    >
                      <span className="text-amber-600 font-bold text-base leading-none">“</span>
                      <p className="flex-1">{quote}”</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Suggested Technical Intervention & Scheme Alignment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs break-inside-avoid print:grid-cols-2 print:gap-3">
                <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-100 space-y-1.5 print:bg-stone-50 print:border-stone-300 print:rounded-lg">
                  <span className="text-[10px] font-bold text-amber-950 uppercase tracking-wider block print:text-stone-800 print:text-[9pt]">
                    Suggested Engineering Intervention
                  </span>
                  <p className="text-amber-950 font-semibold leading-relaxed print:text-stone-950 print:text-[9.5pt]">
                    {activeRec.suggestedIntervention}
                  </p>
                </div>

                <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-100 space-y-1.5 print:bg-stone-50 print:border-stone-300 print:rounded-lg">
                  <span className="text-[10px] font-bold text-emerald-900 uppercase tracking-wider block print:text-stone-800 print:text-[9pt]">
                    Budget & Central/State Scheme Mapping
                  </span>
                  <p className="text-emerald-950 font-semibold leading-relaxed print:text-stone-950 print:text-[9.5pt]">
                    {activeRec.schemeAlignment}
                  </p>
                  <span className="inline-block mt-1 text-xs font-extrabold text-emerald-800 bg-emerald-200/70 px-2 py-0.5 rounded-lg print:border print:border-stone-400 print:bg-stone-100 print:text-stone-900">
                    Estimated Outlay: {activeRec.estimatedBudget}
                  </span>
                </div>
              </div>

              {/* Fresh AI Gemini Generative Brief (if triggered) */}
              {generatedBriefText && (
                <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl border border-amber-950/60 text-xs space-y-2 break-inside-avoid print:bg-stone-50 print:border-stone-300 print:text-stone-900">
                  <div className="flex items-center justify-between text-amber-300 font-bold text-xs pb-1 border-b border-slate-800 print:text-stone-800 print:border-stone-300">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" /> Live Gemini Policy Analysis
                    </span>
                    <span className="text-[10px] text-slate-400 print:text-stone-600">Model: Gemini 3.7 Flash</span>
                  </div>
                  <p className="text-slate-300 whitespace-pre-line leading-relaxed print:text-stone-900 print:text-[9.5pt]">
                    {generatedBriefText}
                  </p>
                </div>
              )}

              {/* Dispatched Stakeholder Telemetry Banner (if notified) */}
              {notifiedMap[activeRec.id] && (
                <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-300 text-xs space-y-1.5 break-inside-avoid print:bg-stone-50 print:border-stone-300">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-amber-950 flex items-center gap-1.5 print:text-stone-950">
                      <Bell className="w-4 h-4 text-amber-700 print:hidden" />
                      Official Stakeholder Notification Dispatched
                    </span>
                    <span className="font-mono text-[11px] bg-amber-200/80 text-amber-950 font-bold px-2 py-0.5 rounded print:border print:border-stone-400">
                      {notifiedMap[activeRec.id].dispatchId}
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-900 leading-relaxed print:text-stone-800">
                    Transmitted at <strong>{notifiedMap[activeRec.id].timestamp}</strong> to {notifiedMap[activeRec.id].officesCount} district & departmental authorities.
                  </p>
                </div>
              )}

              {/* MANDATORY GOVTECH DISCLAIMER BANNER */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/80 text-[11px] text-amber-900 flex items-start gap-2 break-inside-avoid print:bg-stone-50 print:border-stone-300 print:text-stone-700">
                <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5 print:hidden" />
                <p>
                  <strong>Institutional Notice:</strong> “AI-assisted recommendation — final decisions remain with authorized policymakers.”
                </p>
              </div>

              {/* Official Signature Block for Government Documents */}
              <PrintSignatureBlock
                preparedBy="Depioro AI Automated Synthesis & Demand Clustering Engine"
                reviewedBy="Superintending Engineer, Planning & Public Works"
                sanctioningAuthority="District Collector & District Magistrate"
              />

              {/* Screen Action Buttons (Hidden when printing) */}
              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 print:hidden">
                <button
                  type="button"
                  onClick={() => setNotifyModalRec(activeRec)}
                  className="w-full sm:w-auto py-3 px-4 rounded-xl bg-amber-100/80 hover:bg-amber-200/90 text-amber-950 text-xs sm:text-sm font-extrabold border border-amber-300 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                >
                  <Bell className="w-4 h-4 text-amber-800" />
                  <span>{notifiedMap[activeRec.id] ? 'Re-Notify Stakeholders' : 'Notify Stakeholders'}</span>
                </button>

                <button
                  onClick={() => handleSimulateSanction(activeRec.id)}
                  disabled={sanctioned[activeRec.id]}
                  className={`w-full sm:w-auto flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    sanctioned[activeRec.id]
                      ? 'bg-emerald-600 text-white cursor-default'
                      : 'bg-amber-600 hover:bg-amber-700 text-white shadow-md'
                  }`}
                >
                  {sanctioned[activeRec.id] ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Project In-Principle Sanctioned</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Simulate Policy In-Principle Sanction</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleGenerateFreshBrief}
                  disabled={isGeneratingBrief}
                  className="w-full sm:w-auto py-3 px-4 rounded-xl bg-slate-900 hover:bg-amber-950 text-white text-xs sm:text-sm font-semibold border border-slate-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-yellow-400" />
                  <span>{isGeneratingBrief ? 'Synthesizing with Gemini...' : 'Generate Live AI Brief'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-8 text-center text-slate-400 border border-stone-200">
              Select a project recommendation to view its full executive intelligence brief.
            </div>
          )}
        </div>
      </div>

      {/* Stakeholder Notification Trigger Modal */}
      <NotifyStakeholdersModal
        isOpen={!!notifyModalRec}
        onClose={() => setNotifyModalRec(null)}
        recommendation={notifyModalRec}
        onNotifySuccess={(recId, info) => {
          setNotifiedMap((prev) => ({ ...prev, [recId]: info }));
        }}
      />
    </div>
  );
};
