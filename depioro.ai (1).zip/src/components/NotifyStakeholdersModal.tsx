import React, { useState } from 'react';
import {
  Bell,
  Building2,
  Check,
  CheckCircle2,
  Copy,
  FileText,
  Mail,
  Phone,
  Radio,
  Send,
  ShieldCheck,
  X,
  AlertCircle,
} from 'lucide-react';
import { AIRecommendation } from '../types';

interface NotifyStakeholdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  recommendation: AIRecommendation | null;
  onNotifySuccess?: (recommendationId: string, dispatchInfo: DispatchInfo) => void;
}

export interface DispatchInfo {
  dispatchId: string;
  timestamp: string;
  officesCount: number;
  offices: string[];
  channels: string[];
}

export const NotifyStakeholdersModal: React.FC<NotifyStakeholdersModalProps> = ({
  isOpen,
  onClose,
  recommendation,
  onNotifySuccess,
}) => {
  if (!isOpen || !recommendation) return null;

  const [selectedOffices, setSelectedOffices] = useState<string[]>([
    'collector',
    'department_engineer',
    'zila_panchayat',
    'bdo',
  ]);
  const [selectedChannels, setSelectedChannels] = useState<string[]>([
    'eoffice',
    'sms_whatsapp',
    'dashboard_alert',
  ]);
  const [urgentPriority, setUrgentPriority] = useState<boolean>(true);
  const [customMemo, setCustomMemo] = useState<string>(
    `Urgent: AI synthesized high-density citizen demand hotspot for ${recommendation.title}. Immediate preliminary survey and technical assessment advised under ${recommendation.schemeAlignment}.`
  );
  const [isSending, setIsSending] = useState<boolean>(false);
  const [dispatchResult, setDispatchResult] = useState<DispatchInfo | null>(null);
  const [copiedDispatchId, setCopiedDispatchId] = useState<boolean>(false);

  // Dynamic department name based on category
  const getDepartmentTitle = (cat: string) => {
    switch (cat) {
      case 'Water':
        return 'Public Health Engineering Dept (PHED) / Jal Nigam';
      case 'Roads':
        return 'Public Works Department (PWD) Executive Division';
      case 'Healthcare':
        return 'Chief Medical & Health Officer (CMHO) Directorate';
      case 'Electricity':
        return 'State Electricity Distribution Co. (DISCOM)';
      case 'Education':
        return 'District Education Officer (DEO) & Samagra Shiksha';
      case 'Sanitation':
        return 'Municipal Solid Waste & Swachh Bharat Mission Cell';
      case 'Agriculture':
        return 'District Agricultural Officer & Krishi Vigyan Kendra';
      default:
        return 'District Infrastructure & Planning Nodal Cell';
    }
  };

  const officesList = [
    {
      id: 'collector',
      title: `Office of District Magistrate / Collector (${recommendation.district})`,
      role: 'Apex District Administration & Sanction Authority',
      icon: Building2,
    },
    {
      id: 'department_engineer',
      title: getDepartmentTitle(recommendation.category),
      role: 'Line Department Technical Execution Agency',
      icon: FileText,
    },
    {
      id: 'zila_panchayat',
      title: `Zila Panchayat / Municipal Commissioner (${recommendation.district})`,
      role: 'Grassroots Civic Governance & PRI Coordination',
      icon: Building2,
    },
    {
      id: 'bdo',
      title: 'Block Development Officer (BDO) & Sub-Divisional Magistrate (SDM)',
      role: 'Field Verification & Village Panchayat Liaison',
      icon: Radio,
    },
    {
      id: 'state_planning',
      title: `State Planning & Finance Commission (${recommendation.state})`,
      role: 'Budgetary Sanction & Matching Grant Approval',
      icon: ShieldCheck,
    },
  ];

  const channelsList = [
    {
      id: 'eoffice',
      label: 'NIC e-Office Dispatch (Official Electronic File System)',
      badge: 'Official E-Dossier',
    },
    {
      id: 'sms_whatsapp',
      label: 'Gov Alert Gateway (High-Priority SMS & WhatsApp Broadcast)',
      badge: 'Instant Mobile',
    },
    {
      id: 'dashboard_alert',
      label: 'State Integrated GIS Dashboard Priority Queue',
      badge: 'System Flag',
    },
  ];

  const toggleOffice = (id: string) => {
    setSelectedOffices((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleChannel = (id: string) => {
    setSelectedChannels((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSendNotification = () => {
    if (selectedOffices.length === 0 || selectedChannels.length === 0) {
      alert('Please select at least one local office and one transmission channel.');
      return;
    }

    setIsSending(true);

    setTimeout(() => {
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      const generatedId = `NIC-DISP/${recommendation.district.toUpperCase().slice(0, 3)}/2026/${randomNum}`;
      const now = new Date();
      const timeStr = `${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}, ${now.toLocaleDateString()}`;

      const selectedOfficeTitles = officesList
        .filter((o) => selectedOffices.includes(o.id))
        .map((o) => o.title);

      const selectedChannelTitles = channelsList
        .filter((c) => selectedChannels.includes(c.id))
        .map((c) => c.label);

      const info: DispatchInfo = {
        dispatchId: generatedId,
        timestamp: timeStr,
        officesCount: selectedOffices.length,
        offices: selectedOfficeTitles,
        channels: selectedChannelTitles,
      };

      setDispatchResult(info);
      setIsSending(false);

      if (onNotifySuccess) {
        onNotifySuccess(recommendation.id, info);
      }
    }, 850);
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedDispatchId(true);
    setTimeout(() => setCopiedDispatchId(false), 2000);
  };

  return (
    <div
      id="notify-stakeholders-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="notify-stakeholders-modal-container"
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl shadow-2xl border border-stone-200 w-full max-w-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 border-b border-amber-950/60 relative">
          <button
            id="notify-modal-close-button"
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-semibold mb-2">
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span>Government Stakeholder Notification Trigger</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Notify Local Government Authorities
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Simulate instant dispatch of AI-synthesized policy findings, citizen cluster demand, and DPR recommendations to jurisdictional administrative offices.
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Project Summary Strip */}
          <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider">
                Recommendation #{recommendation.number} • {recommendation.district}, {recommendation.state}
              </span>
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900 leading-snug">
                {recommendation.title}
              </h3>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                <span className="font-semibold text-slate-800">{recommendation.category} Infrastructure</span>
                <span>•</span>
                <span className="font-mono font-bold text-amber-900">{recommendation.estimatedBudget}</span>
                <span>•</span>
                <span className="text-slate-500">
                  {(recommendation.citizenDemandCount ?? recommendation.citizenRequestsCount ?? 0).toLocaleString()} citizen requests
                </span>
              </div>
            </div>

            <div className="shrink-0 bg-white px-3 py-2 rounded-xl border border-stone-200 text-right">
              <span className="text-[10px] text-slate-400 block font-medium">Priority Rating</span>
              <strong className="text-amber-700 font-black text-base">
                {recommendation.priorityScore} / 100
              </strong>
            </div>
          </div>

          {dispatchResult ? (
            /* SUCCESS CONFIRMATION STATE */
            <div className="space-y-5 py-2">
              <div className="bg-emerald-50 rounded-2xl p-5 border border-emerald-200 text-emerald-950 space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-base font-extrabold text-emerald-900">
                      Official Dispatch Successfully Triggered!
                    </h4>
                    <p className="text-xs text-emerald-700">
                      Notifications transmitted to {dispatchResult.officesCount} jurisdictional departments and executive heads.
                    </p>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-3.5 border border-emerald-200/80 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Dispatch Reference No:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-slate-900 bg-stone-100 px-2 py-0.5 rounded">
                        {dispatchResult.dispatchId}
                      </span>
                      <button
                        onClick={() => handleCopyId(dispatchResult.dispatchId)}
                        className="p-1 rounded hover:bg-stone-100 text-slate-500 hover:text-slate-800 transition-colors"
                        title="Copy Dispatch Number"
                      >
                        {copiedDispatchId ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Transmission Timestamp:</span>
                    <span className="font-semibold text-slate-800">{dispatchResult.timestamp}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Delivery Status:</span>
                    <span className="font-bold text-emerald-700 inline-flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Delivered to Official Gateways
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 pt-1">
                  <span className="text-xs font-bold text-emerald-900 block">Notified Authorities & Departments:</span>
                  <ul className="text-xs text-emerald-800 space-y-1 pl-1">
                    {dispatchResult.offices.map((office, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{office}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setDispatchResult(null)}
                  className="px-4 py-2 rounded-xl border border-stone-300 text-slate-700 text-xs font-semibold hover:bg-stone-50 transition-colors cursor-pointer"
                >
                  Send Another Notice
                </button>
                <button
                  onClick={onClose}
                  className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-amber-950 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            /* CONFIGURATION & TRANSMISSION FORM */
            <div className="space-y-5">
              {/* Target Government Offices Checklist */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-700" />
                    Target Administrative Stakeholders ({selectedOffices.length} Selected)
                  </label>
                  <button
                    onClick={() => {
                      if (selectedOffices.length === officesList.length) {
                        setSelectedOffices([]);
                      } else {
                        setSelectedOffices(officesList.map((o) => o.id));
                      }
                    }}
                    className="text-[11px] font-bold text-amber-700 hover:text-amber-800 underline cursor-pointer"
                  >
                    {selectedOffices.length === officesList.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="space-y-2">
                  {officesList.map((office) => {
                    const Icon = office.icon;
                    const isChecked = selectedOffices.includes(office.id);

                    return (
                      <label
                        key={office.id}
                        onClick={() => toggleOffice(office.id)}
                        className={`flex items-start gap-3 p-3 rounded-2xl border transition-all cursor-pointer select-none ${
                          isChecked
                            ? 'bg-amber-50/70 border-amber-400 ring-1 ring-amber-400/40'
                            : 'bg-white hover:bg-stone-50 border-stone-200'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="mt-1 w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-stone-300"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <Icon className={`w-3.5 h-3.5 ${isChecked ? 'text-amber-700' : 'text-slate-400'}`} />
                            <span className="text-xs font-bold text-slate-900 leading-snug">
                              {office.title}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {office.role}
                          </p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Notification Channels */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Send className="w-3.5 h-3.5 text-amber-700" />
                  Dispatch Gateways & Protocol Channels
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {channelsList.map((ch) => {
                    const isChecked = selectedChannels.includes(ch.id);

                    return (
                      <button
                        key={ch.id}
                        type="button"
                        onClick={() => toggleChannel(ch.id)}
                        className={`p-3 rounded-xl border text-left text-xs transition-all cursor-pointer flex flex-col justify-between ${
                          isChecked
                            ? 'bg-amber-100/70 border-amber-500 font-bold text-amber-950'
                            : 'bg-stone-50 hover:bg-stone-100 border-stone-200 text-slate-700'
                        }`}
                      >
                        <span className="leading-snug">{ch.label}</span>
                        <span
                          className={`inline-block mt-2 text-[10px] px-2 py-0.5 rounded-full font-semibold self-start ${
                            isChecked ? 'bg-amber-600 text-white' : 'bg-stone-200 text-slate-600'
                          }`}
                        >
                          {ch.badge}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Official Memo Message Content */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Official Advisory Dispatch Memo
                </label>
                <textarea
                  value={customMemo}
                  onChange={(e) => setCustomMemo(e.target.value)}
                  rows={3}
                  className="w-full p-3 rounded-2xl border border-stone-300 text-xs text-slate-800 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 leading-relaxed font-mono"
                  placeholder="Enter dispatch notes for the District Collector and Engineering Team..."
                />
              </div>

              {/* Priority Flag */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50/60 border border-amber-200/70 text-xs">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span className="font-bold text-amber-950">
                    Flag as High-Urgency District Priority Alert
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={urgentPriority}
                    onChange={(e) => setUrgentPriority(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-stone-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-600"></div>
                </label>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-stone-300 text-slate-700 text-xs font-semibold hover:bg-stone-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  id="submit-notify-stakeholders-btn"
                  type="button"
                  onClick={handleSendNotification}
                  disabled={isSending}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-extrabold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSending ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Transmitting Dispatches...</span>
                    </>
                  ) : (
                    <>
                      <Bell className="w-4 h-4" />
                      <span>Notify Stakeholders Now</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
