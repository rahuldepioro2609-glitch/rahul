import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Sparkles,
  TrendingUp,
  Building,
  CheckCircle2,
  AlertCircle,
  Download,
  Printer,
  FileSpreadsheet,
  Coins,
  PieChart,
  Layers,
  ArrowRight,
  Shield,
  Zap,
  Users,
  Check,
  RotateCcw,
  Scale,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useDepioro } from '../context/DepioroContext';
import { optimizeDistrictBudget, BudgetOptimizationResult } from '../services/aiService';
import { PrintDossierHeader, PrintSignatureBlock } from './PrintDossierHeader';

type OptimizationStrategy = 'welfare' | 'rapid' | 'equity' | 'central_leverage';

export const BudgetOptimizer: React.FC = () => {
  const { recommendations, selectedDistrict, setSelectedDistrict, setToastMessage, setCurrentRoute } =
    useDepioro();

  const [totalBudgetCr, setTotalBudgetCr] = useState<number>(35);
  const [strategy, setStrategy] = useState<OptimizationStrategy>('welfare');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [optimizationResult, setOptimizationResult] = useState<BudgetOptimizationResult | null>(null);
  const [sanctionIssued, setSanctionIssued] = useState(false);

  // Run optimization
  const runOptimization = async (budget: number, strat: OptimizationStrategy) => {
    setIsOptimizing(true);
    setSanctionIssued(false);

    try {
      const result = await optimizeDistrictBudget(
        budget,
        selectedDistrict === 'All' ? 'Madhya Pradesh Statewide' : `${selectedDistrict} District`,
        strat,
        recommendations
      );
      setOptimizationResult(result);
      setSelectedIds(result.selectedProjectIds || []);
    } catch (err) {
      console.error(err);
    } finally {
      setIsOptimizing(false);
    }
  };

  useEffect(() => {
    runOptimization(totalBudgetCr, strategy);
  }, [selectedDistrict]);

  // Compute live aggregates from selected IDs
  const activeSelectedProjects = recommendations.filter((r) => selectedIds.includes(r.id));
  const activeTotalCost = activeSelectedProjects.reduce((sum, r) => {
    const cost = parseFloat(String(r.estimatedBudget || '10').replace(/[^0-9.]/g, '')) || 10;
    return sum + cost;
  }, 0);
  const roundedActiveTotalCost = Math.round(activeTotalCost * 10) / 10;
  const activeBeneficiaries = activeSelectedProjects.reduce((sum, r) => sum + (r.affectedPopulation || 25000), 0);
  const centralSubsidy = Math.round(activeTotalCost * 0.6 * 10) / 10;
  const stateShare = Math.round((activeTotalCost - centralSubsidy) * 10) / 10;
  const budgetUtilizationPct = Math.min(100, Math.round((activeTotalCost / totalBudgetCr) * 100));

  const toggleProjectSelection = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleIssueSanction = () => {
    setSanctionIssued(true);
    setToastMessage(`Official Capital Sanction Order Issued for ₹${roundedActiveTotalCost} Cr across ${activeSelectedProjects.length} DPRs.`);
  };

  const handlePrintMemo = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 print:p-0 print:m-0 print:max-w-none print:space-y-4">
      {/* Official Government Print Header */}
      <PrintDossierHeader
        title="District Planning Board Capital Budget & Project Sanction Memo"
        documentType="FINANCIAL ALLOCATION & ADMINISTRATIVE SANCTION DIRECTIVE"
        documentRef={`DEPIORO/FIN/2026/SANC-${Math.round(activeTotalCost)}CR`}
        district={selectedDistrict === 'All' ? 'Statewide (All Districts)' : `${selectedDistrict} District`}
        state="Madhya Pradesh"
        classification="OFFICIAL MEMORANDUM • CAPITAL BUDGET SANCTION"
      />

      {/* Screen Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-950/60 space-y-6 print:hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-semibold mb-2">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>Vikas Budget & ROI Capital Allocation Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <span>Fiscal Allocation Simulator</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
                Knapsack ROI Optimizer
              </span>
            </h1>
            <p className="text-slate-300 text-sm mt-1 max-w-3xl">
              Simulate dynamic capital distribution across citizen-demanded infrastructure DPRs. Maximize citizen welfare, speed of execution, or Central matching scheme leverage under fiscal constraints.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handlePrintMemo}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Print Sanction Memorandum"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>Print Sanction Memo (PDF)</span>
            </button>
            <button
              onClick={() => setCurrentRoute('recommendations')}
              className="px-3.5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <FileSpreadsheet className="w-4 h-4 text-yellow-200" />
              <span>View Full DPRs</span>
            </button>
          </div>
        </div>

        {/* Controls: Budget Pool Slider & Strategy Selector */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Budget Pool Slider */}
          <div className="lg:col-span-6 p-4 rounded-2xl bg-slate-800/90 border border-slate-700 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-300 flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-amber-400" />
                <span>Available District Capital Pool:</span>
              </span>
              <span className="text-base sm:text-lg font-bold font-mono text-amber-300">
                ₹{totalBudgetCr} Crore
              </span>
            </div>

            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={totalBudgetCr}
              onChange={(e) => {
                const val = Number(e.target.value);
                setTotalBudgetCr(val);
                runOptimization(val, strategy);
              }}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>₹10 Cr (Micro Grant)</span>
              <span>₹50 Cr (District Avg)</span>
              <span>₹100 Cr (Major Metro)</span>
            </div>
          </div>

          {/* Strategy Selectors */}
          <div className="lg:col-span-6 space-y-2">
            <span className="text-xs font-semibold text-slate-300 block">
              Target Optimization Strategy:
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'welfare', label: 'Max Welfare', icon: Users, desc: 'Population Impact' },
                { id: 'rapid', label: 'Rapid 60-Day', icon: Zap, desc: 'Quick Delivery' },
                { id: 'equity', label: 'Block Equity', icon: Scale, desc: 'Balanced Spread' },
                { id: 'central_leverage', label: 'Central Grant', icon: Building, desc: '60% Match Share' },
              ].map((s) => {
                const isSelected = strategy === s.id;
                const Icon = s.icon;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      setStrategy(s.id as OptimizationStrategy);
                      runOptimization(totalBudgetCr, s.id as OptimizationStrategy);
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-amber-500 text-slate-900 border-amber-400 font-bold shadow-md shadow-amber-500/20'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-slate-900' : 'text-amber-400'}`} />
                      {isSelected && <Check className="w-3 h-3 text-slate-900" />}
                    </div>
                    <div className="text-xs">{s.label}</div>
                    <div className={`text-[10px] ${isSelected ? 'text-slate-900/80' : 'text-slate-400'}`}>
                      {s.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* KPI Aggregate Metric Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Total Sanctioned</div>
          <div className="text-lg sm:text-xl font-extrabold font-mono text-slate-900">
            ₹{roundedActiveTotalCost} <span className="text-xs font-medium text-slate-500">Cr</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {activeSelectedProjects.length} of {recommendations.length} DPRs funded
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Unallocated Reserve</div>
          <div className="text-lg sm:text-xl font-extrabold font-mono text-emerald-700">
            ₹{Math.max(0, Math.round((totalBudgetCr - activeTotalCost) * 10) / 10)}{' '}
            <span className="text-xs font-medium text-emerald-600">Cr</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {budgetUtilizationPct}% budget utilized
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Beneficiaries</div>
          <div className="text-lg sm:text-xl font-extrabold font-mono text-amber-700">
            {activeBeneficiaries.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Direct citizens covered</div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Central Subsidy</div>
          <div className="text-lg sm:text-xl font-extrabold font-mono text-blue-700">
            ₹{centralSubsidy} <span className="text-xs font-medium text-blue-600">Cr</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">60% Central grant match</div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Socioeconomic ROI</div>
          <div className="text-lg sm:text-xl font-extrabold font-mono text-purple-700">
            {optimizationResult?.welfareRoiScore || 94} <span className="text-xs font-medium text-purple-600">/ 100</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Welfare efficiency rating</div>
        </div>
      </div>

      {/* Main Split: Candidate DPR Project Allocations & Formal Sanction Memo */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Interactive Project Candidate Allocation List */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Candidate Infrastructure Packages (DPRs)
                </h3>
                <p className="text-xs text-slate-500">
                  Toggle checkboxes to manually adjust or lock specific project allocations.
                </p>
              </div>

              <button
                onClick={() => runOptimization(totalBudgetCr, strategy)}
                disabled={isOptimizing}
                className="text-xs font-semibold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isOptimizing ? 'animate-spin' : ''}`} />
                <span>Reset to AI Best</span>
              </button>
            </div>

            {/* Project List */}
            <div className="space-y-3">
              {recommendations.map((rec) => {
                const isSelected = selectedIds.includes(rec.id);
                const cost = parseFloat(String(rec.estimatedBudget || '10').replace(/[^0-9.]/g, '')) || 10;

                return (
                  <div
                    key={rec.id}
                    onClick={() => toggleProjectSelection(rec.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                      isSelected
                        ? 'bg-amber-50/50 border-amber-300 shadow-xs'
                        : 'bg-slate-50/70 border-slate-200 hover:bg-slate-100 opacity-75'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-md border flex items-center justify-center mt-0.5 shrink-0 transition-colors ${
                        isSelected
                          ? 'bg-amber-600 border-amber-600 text-white'
                          : 'border-slate-400 bg-white'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-800">
                            {rec.category}
                          </span>
                          <span className="text-[11px] font-semibold text-slate-600">
                            {rec.district}
                          </span>
                        </div>
                        <div className="text-xs font-bold font-mono text-slate-900">
                          {rec.estimatedBudget}
                        </div>
                      </div>

                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">
                        {rec.title}
                      </h4>
                      <p className="text-xs text-slate-600 line-clamp-1 mt-0.5">
                        {rec.suggestedIntervention}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-200/60">
                        <span>👥 {(rec.affectedPopulation || 25000).toLocaleString()} citizens</span>
                        <span>⚡ {rec.timeline}</span>
                        <span className="text-amber-800 font-medium">🎯 Score: {rec.priorityScore}/100</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Official Sanction Memorandum */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-sm border border-slate-200/80 space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-700" />
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  Financial Sanction Memorandum
                </h3>
              </div>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300 font-bold">
                AS/FS-2026
              </span>
            </div>

            {/* Memo Content */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-800 space-y-3 font-mono leading-relaxed">
              <div className="text-slate-900 font-bold border-b border-slate-200 pb-2">
                GOVERNMENT OF MADHYA PRADESH • DISTRICT PLANNING BOARD
              </div>
              <div>
                <strong>MEMO REF:</strong> DPB/FIN/2026/SANC-PKG-{activeSelectedProjects.length}
                <br />
                <strong>SANCTIONED AMOUNT:</strong> ₹{roundedActiveTotalCost} Cr (Rupees {roundedActiveTotalCost} Crore)
                <br />
                <strong>CENTRAL GRANT:</strong> ₹{centralSubsidy} Cr | <strong>STATE OUTLAY:</strong> ₹{stateShare} Cr
                <br />
                <strong>TARGET POPULATION:</strong> ~{activeBeneficiaries.toLocaleString()} Citizens
              </div>
              <div className="pt-2 border-t border-slate-200 text-slate-700 italic font-sans text-[11px]">
                "Administrative and Expenditure Sanction is hereby accorded for the execution of {activeSelectedProjects.length} prioritized capital works under the approved strategy matrix ({strategy}). Respective Departmental Engineers shall initiate e-tendering within 14 calendar days."
              </div>
            </div>

            {/* Summary List of Sanctioned Projects */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block">
                Sanctioned Packages Schedule ({activeSelectedProjects.length}):
              </span>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {activeSelectedProjects.map((p, idx) => (
                  <div
                    key={p.id}
                    className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="font-bold text-amber-700">{idx + 1}.</span>
                      <span className="font-semibold text-slate-800 truncate">{p.title}</span>
                    </div>
                    <span className="font-mono font-bold text-slate-900 shrink-0 ml-2">
                      {p.estimatedBudget}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-4 border-t border-slate-200 print:hidden">
              <button
                onClick={handleIssueSanction}
                disabled={sanctionIssued || activeSelectedProjects.length === 0}
                className={`w-full py-3 rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  sanctionIssued
                    ? 'bg-emerald-600 text-white cursor-default'
                    : 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white'
                }`}
              >
                {sanctionIssued ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Sanction Memo Formally Sealed</span>
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4 text-amber-200" />
                    <span>Issue Official Sanction Memo (₹{roundedActiveTotalCost} Cr)</span>
                  </>
                )}
              </button>

              <button
                onClick={handlePrintMemo}
                className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-300"
              >
                <Printer className="w-4 h-4 text-slate-600" />
                <span>Print Official Sanction Order (PDF)</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Official Signature Block for Printed Order */}
      <PrintSignatureBlock
        preparedBy="Depioro AI Vikas Budget Allocation & Knapsack Optimization Engine"
        reviewedBy="District Planning Officer / Chief Accounts Officer"
        sanctioningAuthority="District Magistrate & Chairman, District Planning Board"
      />
    </div>
  );
};
