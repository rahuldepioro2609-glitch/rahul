import React from 'react';
import { Shield, Sparkles, Building2, MapPin } from 'lucide-react';

interface PrintDossierHeaderProps {
  title: string;
  documentType?: string;
  documentRef?: string;
  district?: string;
  state?: string;
  classification?: string;
  generatedDate?: string;
}

export const PrintDossierHeader: React.FC<PrintDossierHeaderProps> = ({
  title,
  documentType = 'DETAILED PROJECT REPORT (DPR) & POLICY DOSSIER',
  documentRef = 'DEPIORO/DPR/2026/MP-0894',
  district = 'Madhya Pradesh State',
  state = 'Madhya Pradesh',
  classification = 'OFFICIAL / FOR POLICYMAKER USE ONLY',
  generatedDate,
}) => {
  const currentDate =
    generatedDate ||
    new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

  return (
    <div className="hidden print:block mb-6 pb-4 border-b-2 border-stone-800 text-black">
      {/* Top Banner with Emblems & Classification */}
      <div className="flex items-center justify-between text-[10pt] border-b border-stone-300 pb-2 mb-3">
        <div className="flex items-center gap-2 font-bold tracking-wider text-stone-700">
          <span>GOVERNMENT OF MADHYA PRADESH</span>
          <span>•</span>
          <span>PUBLIC INFRASTRUCTURE INTELLIGENCE SYSTEM</span>
        </div>
        <div className="font-mono text-[9pt] font-bold px-2 py-0.5 border border-stone-800 rounded">
          {classification}
        </div>
      </div>

      {/* Main Header Block */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-[11pt] font-extrabold uppercase tracking-widest text-amber-900">
            {documentType}
          </div>
          <h1 className="text-[18pt] font-black leading-tight mt-0.5 text-stone-950 font-serif">
            {title}
          </h1>
          <div className="flex items-center gap-3 text-[10pt] text-stone-700 mt-1">
            <span>Jurisdiction: <strong>{district}, {state}</strong></span>
            <span>•</span>
            <span>Generated: <strong>{currentDate}</strong></span>
            <span>•</span>
            <span>AI Pipeline: <strong>Depioro Semantic Core (v2.4)</strong></span>
          </div>
        </div>

        {/* Right Info Box */}
        <div className="text-right shrink-0">
          <div className="font-mono text-[9pt] text-stone-600">Doc Reference:</div>
          <div className="font-mono text-[11pt] font-extrabold text-stone-900 border border-stone-400 bg-stone-50 px-2.5 py-1 rounded mt-0.5">
            {documentRef}
          </div>
          <div className="text-[8pt] text-stone-500 mt-1">
            Digital Signature: Verified AI-Intake
          </div>
        </div>
      </div>
    </div>
  );
};

export const PrintSignatureBlock: React.FC<{
  preparedBy?: string;
  reviewedBy?: string;
  sanctioningAuthority?: string;
}> = ({
  preparedBy = 'AI System Analyst / Depioro Automated Synthesis',
  reviewedBy = 'Executive Engineer / District Planning Officer',
  sanctioningAuthority = 'District Collector / Departmental Secretary',
}) => {
  return (
    <div className="hidden print:block mt-8 pt-6 border-t-2 border-stone-800 break-inside-avoid text-black">
      <div className="text-[10pt] font-bold uppercase tracking-wider text-stone-600 mb-4">
        Administrative Review & Approval Signatures
      </div>
      
      <div className="grid grid-cols-3 gap-6 text-[9pt]">
        {/* Prepared By */}
        <div className="border border-stone-300 rounded p-3 bg-stone-50/50 flex flex-col justify-between h-28">
          <div>
            <div className="font-bold text-stone-900">1. Data Synthesis & AI Verification</div>
            <div className="text-stone-600 text-[8pt]">{preparedBy}</div>
          </div>
          <div className="border-t border-dashed border-stone-400 pt-1 text-[8pt] text-stone-500 font-mono">
            System Stamp: [DEPIORO-VERIFIED-2026]
          </div>
        </div>

        {/* Reviewed By */}
        <div className="border border-stone-300 rounded p-3 bg-stone-50/50 flex flex-col justify-between h-28">
          <div>
            <div className="font-bold text-stone-900">2. Technical & Field Appraisal</div>
            <div className="text-stone-600 text-[8pt]">{reviewedBy}</div>
          </div>
          <div className="border-t border-dashed border-stone-400 pt-1 text-[8pt] text-stone-500">
            Sign & Seal: _______________________
          </div>
        </div>

        {/* Sanctioning Authority */}
        <div className="border border-stone-300 rounded p-3 bg-stone-50/50 flex flex-col justify-between h-28">
          <div>
            <div className="font-bold text-stone-900">3. Administrative Sanction</div>
            <div className="text-stone-600 text-[8pt]">{sanctioningAuthority}</div>
          </div>
          <div className="border-t border-dashed border-stone-400 pt-1 text-[8pt] text-stone-500">
            Sign & Seal: _______________________
          </div>
        </div>
      </div>

      {/* Footer Legal Disclaimer */}
      <div className="mt-4 pt-2 border-t border-stone-200 text-center text-[8pt] text-stone-500 flex items-center justify-between">
        <span>Depioro.ai • AI-assisted citizen intelligence system. Final administrative sanction subject to statutory government verification.</span>
        <span>Page 1 of Dossier</span>
      </div>
    </div>
  );
};
