import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Sparkles,
  MapPin,
  Camera,
  Upload,
  Globe,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  Layers,
  Droplet,
  Car,
  HeartPulse,
  GraduationCap,
  Zap,
  Trash2,
  Bus,
  Wheat,
  HelpCircle,
  Volume2,
  Compass,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDepioro } from '../context/DepioroContext';
import { LANGUAGES } from '../data/mockData';
import { IssueCategory, LanguageCode, UrgencyLevel } from '../types';
import { analyzeCitizenReport, AIAnalysisResult } from '../services/aiService';
import { CircularProgressRing } from './CircularProgressRing';
import { AdvancedAnimatedIcon } from './AdvancedAnimatedIcon';

const CATEGORIES: Array<{ id: IssueCategory; label: string; icon: React.ElementType; color: string }> = [
  { id: 'Water', label: 'Water', icon: Droplet, color: 'text-sky-500 bg-sky-50 border-sky-200' },
  { id: 'Roads', label: 'Roads', icon: Car, color: 'text-amber-600 bg-amber-50 border-amber-200' },
  { id: 'Healthcare', label: 'Healthcare', icon: HeartPulse, color: 'text-rose-500 bg-rose-50 border-rose-200' },
  { id: 'Education', label: 'Education', icon: GraduationCap, color: 'text-indigo-500 bg-indigo-50 border-indigo-200' },
  { id: 'Electricity', label: 'Electricity', icon: Zap, color: 'text-yellow-600 bg-yellow-50 border-yellow-200' },
  { id: 'Sanitation', label: 'Sanitation', icon: Trash2, color: 'text-emerald-500 bg-emerald-50 border-emerald-200' },
  { id: 'Transport', label: 'Transport', icon: Bus, color: 'text-purple-500 bg-purple-50 border-purple-200' },
  { id: 'Agriculture', label: 'Agriculture', icon: Wheat, color: 'text-lime-600 bg-lime-50 border-lime-200' },
  { id: 'Other', label: 'Other', icon: HelpCircle, color: 'text-slate-500 bg-slate-50 border-slate-200' },
];

const DISTRICTS = [
  'Shivpuri',
  'Bhopal',
  'Indore',
  'Gwalior',
  'Jabalpur',
  'Ujjain',
  'Chhindwara',
  'Rewa',
  'Sagar',
  'Satna',
  'Vidisha',
  'Khargone',
];

export const CitizenPortal: React.FC = () => {
  const {
    selectedLanguage,
    setSelectedLanguage,
    addCitizenRequest,
    setCurrentRoute,
    setSelectedDistrict,
  } = useDepioro();

  // Form States
  const [reportText, setReportText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<IssueCategory>('Water');
  const [stateName, setStateName] = useState('Madhya Pradesh');
  const [district, setDistrict] = useState('Shivpuri');
  const [villageWard, setVillageWard] = useState('Pohari Block, Ward 04');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  // Voice Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioWaveform, setAudioWaveform] = useState<number[]>([12, 24, 38, 52, 34, 18, 45, 20]);
  const timerRef = useRef<any>(null);
  const audioIntervalRef = useRef<any>(null);

  // AI Analysis States
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<any>(null);

  const currentLangObj = LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0];

  // Voice recording timer & visualizer animation
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);

      audioIntervalRef.current = setInterval(() => {
        setAudioWaveform([
          Math.floor(Math.random() * 40) + 15,
          Math.floor(Math.random() * 60) + 20,
          Math.floor(Math.random() * 85) + 30,
          Math.floor(Math.random() * 95) + 35,
          Math.floor(Math.random() * 70) + 25,
          Math.floor(Math.random() * 50) + 15,
          Math.floor(Math.random() * 75) + 20,
          Math.floor(Math.random() * 40) + 10,
        ]);
      }, 150);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
    };
  }, [isRecording]);

  // Start Voice Recording
  const handleStartRecording = () => {
    setIsRecording(true);
    setAiAnalysis(null);
    setSubmissionSuccess(null);
  };

  // Stop Voice Recording & Transcribe
  const handleStopRecording = async () => {
    setIsRecording(false);

    // Pick appropriate sample transcript for the active language if user didn't write anything yet
    const matchingPrompt = currentLangObj.samplePrompts[0];
    const sampleSpeech = matchingPrompt
      ? matchingPrompt.text
      : 'हमारे क्षेत्र में पीने के पानी की भारी समस्या है, कृपया तुरंत सहायता करें।';

    setReportText(sampleSpeech);
    if (matchingPrompt) {
      setSelectedCategory(matchingPrompt.category);
      if (matchingPrompt.district) {
        setDistrict(matchingPrompt.district);
      }
      if (matchingPrompt.location) {
        setVillageWard(matchingPrompt.location);
      }
    }

    // Auto-trigger AI Analysis
    triggerAIAnalysis(sampleSpeech, currentLangObj.name, `${district}, ${stateName}`, selectedCategory);
  };

  // Trigger AI Analysis
  const triggerAIAnalysis = async (
    text: string,
    lang: string,
    loc: string,
    cat: IssueCategory
  ) => {
    if (!text.trim()) return;
    setIsAnalyzing(true);
    try {
      const result = await analyzeCitizenReport(text, lang, loc, cat);
      setAiAnalysis(result);
      if (result.category) {
        setSelectedCategory(result.category);
      }
    } catch (err) {
      console.error('Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle manual Text Change
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setReportText(val);
    if (val.length > 25 && !isAnalyzing && !aiAnalysis) {
      // Debounced / soft analysis trigger
    }
  };

  // Sample Prompt Quick Selection
  const handleSelectSamplePrompt = (prompt: (typeof currentLangObj.samplePrompts)[0]) => {
    setReportText(prompt.text);
    setSelectedCategory(prompt.category);
    setDistrict(prompt.district);
    setVillageWard(prompt.location);
    triggerAIAnalysis(prompt.text, currentLangObj.name, `${prompt.district}, ${stateName}`, prompt.category);
  };

  // "Use Current Location" GPS simulation
  const handleUseCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        () => {
          setDistrict('Shivpuri');
          setVillageWard('Pohari Block, Ward 04 (GPS Verified: 25.4244° N, 77.6591° E)');
        },
        () => {
          setDistrict('Shivpuri');
          setVillageWard('Pohari Ward 04 (Device Area)');
        }
      );
    } else {
      setDistrict('Shivpuri');
      setVillageWard('Shivpuri Central Ward 12');
    }
  };

  // Image Upload handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit Development Request
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!reportText.trim()) {
      alert('Please speak or type your development request.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Ensure AI analysis is generated
      let finalAnalysis = aiAnalysis;
      if (!finalAnalysis) {
        finalAnalysis = await analyzeCitizenReport(
          reportText,
          currentLangObj.name,
          `${district}, ${stateName}`,
          selectedCategory
        );
      }

      const created = await addCitizenRequest({
        title: finalAnalysis.summary || `${selectedCategory} Infrastructure Deficit in ${district}`,
        description: reportText,
        originalVoiceTranscript: isRecording || reportText.length > 20 ? reportText : undefined,
        language: currentLangObj.name,
        category: selectedCategory,
        state: stateName,
        district: district,
        cityVillageWard: villageWard,
        priority: finalAnalysis.urgency || 'High',
        status: 'AI Analysed',
        aiConfidence: finalAnalysis.aiConfidence || 95,
        keywords: finalAnalysis.keywords || [selectedCategory, district, 'Citizen Request'],
        affectedPopulation: finalAnalysis.affectedPopulation || 34000,
        imageUrl: uploadedImage || undefined,
        lat: district === 'Shivpuri' ? 25.4244 : district === 'Gwalior' ? 26.2183 : 23.2599,
        lng: district === 'Shivpuri' ? 77.6591 : district === 'Gwalior' ? 78.1828 : 77.4126,
        aiSummary: finalAnalysis.summary || `Citizen reported ${selectedCategory} requirements.`,
        suggestedIntervention:
          finalAnalysis.suggestedIntervention ||
          `Immediate technical site survey and capital allocation under central/state schemes.`,
        sdgGoal: finalAnalysis.sdgGoal || 'SDG 9: Industry, Innovation & Infrastructure',
      });

      // Confetti celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#2563eb', '#10b981', '#f59e0b', '#6366f1'],
        });
      } catch (err) {
        // Safe if confetti fails
      }

      setSubmissionSuccess(created);
    } catch (err) {
      console.error('Submission failed:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold">
          <Globe className="w-3.5 h-3.5 text-amber-600" />
          <span>Multilingual Voice & Text Reporting</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950 tracking-tight">
          What development issue would you like to report?
        </h1>
        <p className="text-sm sm:text-base text-slate-600 max-w-xl mx-auto">
          {currentLangObj.greeting}. Speak or type in your language — Depioro AI translates your voice into structured policy demands.
        </p>
      </div>

      {/* Language Selector Bar */}
      <div className="bg-white rounded-2xl p-4 shadow-xs border border-amber-100 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-amber-600" />
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            Preferred Language / भाषा:
          </span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              type="button"
              onClick={() => setSelectedLanguage(lang.code as LanguageCode)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedLanguage === lang.code
                  ? 'bg-amber-600 text-white shadow-xs font-semibold'
                  : 'bg-stone-50 text-slate-700 hover:bg-amber-50/50 border border-slate-200/60'
              }`}
            >
              {lang.nativeName} ({lang.name})
            </button>
          ))}
        </div>
      </div>

      {/* SUBMISSION SUCCESS MODAL / CARD */}
      {submissionSuccess && (
        <div className="bg-emerald-50 border-2 border-emerald-500 rounded-3xl p-6 sm:p-8 shadow-xl animate-in zoom-in-95 duration-200 space-y-5">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                  Request Registered & Clustered Successfully
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-emerald-950">
                  Request ID: {submissionSuccess.id}
                </h3>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-200/70 text-emerald-900 font-bold text-xs">
              Status: AI Analysed
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white/80 rounded-2xl p-4 border border-emerald-200 text-xs items-center">
            <div>
              <span className="text-slate-500 block">Category</span>
              <strong className="text-slate-900 font-bold">{submissionSuccess.category}</strong>
            </div>
            <div>
              <span className="text-slate-500 block">Location</span>
              <strong className="text-slate-900 font-bold">
                {submissionSuccess.cityVillageWard}, {submissionSuccess.district}
              </strong>
            </div>
            <div className="flex items-center gap-3">
              <CircularProgressRing
                value={submissionSuccess.aiConfidence}
                size="sm"
                variant="goldwood"
                id="submission-success-confidence-ring"
              />
              <div>
                <span className="text-slate-500 block text-[10px] font-semibold uppercase tracking-wider">
                  AI Confidence
                </span>
                <strong className="text-amber-800 font-bold text-sm font-mono">
                  {submissionSuccess.aiConfidence}% Verified
                </strong>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-emerald-100/60 rounded-xl text-xs text-emerald-900">
            <strong>Impact on Hotspot:</strong> Your report has been aggregated into the{' '}
            <span className="font-bold underline">{submissionSuccess.district} Hotspot Cluster</span>. It has increased the district priority score and is now visible on the Policymaker Dashboard.
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={() => setCurrentRoute('requests')}
              className="px-4 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-1.5"
            >
              <Clock className="w-4 h-4" />
              <span>Track My Request Timeline</span>
            </button>

            <button
              onClick={() => {
                setSelectedDistrict(submissionSuccess.district);
                setCurrentRoute('dashboard');
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-1.5"
            >
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span>View On Demand Hotspot Map</span>
            </button>

            <button
              onClick={() => {
                setSubmissionSuccess(null);
                setReportText('');
                setAiAnalysis(null);
              }}
              className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs sm:text-sm font-medium"
            >
              Report Another Issue
            </button>
          </div>
        </div>
      )}

      {/* MAIN REPORTING FORM */}
      {!submissionSuccess && (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 1. VOICE REPORTING SECTION */}
          <div className="bg-gradient-to-b from-amber-950 via-slate-900 to-amber-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-amber-900/60">
            <div className="relative z-10 space-y-6 text-center">
              <div className="space-y-1">
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-400/30">
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Voice-First Reporting / बोलकर शिकायत दर्ज करें</span>
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                  Speak Your Issue
                </h2>
                <p className="text-xs sm:text-sm text-amber-200">
                  “Speak naturally in your preferred language.”
                </p>
              </div>

              {/* Large Voice Recording Button */}
              <div className="flex flex-col items-center justify-center space-y-4 pt-2">
                <div className="relative">
                  {isRecording && (
                    <>
                      <div className="absolute inset-0 rounded-full bg-red-500/30 animate-ping" />
                      <div className="absolute -inset-4 rounded-full bg-red-500/20 animate-pulse" />
                    </>
                  )}

                  <button
                    type="button"
                    id="voice-mic-button"
                    onClick={isRecording ? handleStopRecording : handleStartRecording}
                    className={`relative z-10 w-24 h-24 sm:w-28 sm:h-28 rounded-full flex flex-col items-center justify-center transition-all transform shadow-2xl active:scale-95 ${
                      isRecording
                        ? 'bg-red-600 hover:bg-red-700 text-white ring-8 ring-red-400/40'
                        : 'bg-gradient-to-tr from-amber-600 via-yellow-500 to-amber-700 hover:from-amber-500 hover:to-yellow-400 text-white ring-4 ring-amber-400/30 hover:shadow-amber-500/50'
                    }`}
                  >
                    {isRecording ? (
                      <>
                        <MicOff className="w-8 h-8 sm:w-9 sm:h-9" />
                        <span className="text-[11px] font-bold mt-1">STOP</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-8 h-8 sm:w-9 sm:h-9" />
                        <span className="text-[11px] font-bold mt-1">SPEAK</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Recording Status / Waveform Animation */}
                {isRecording ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
                      <span className="font-mono text-base font-bold text-red-300">
                        Recording: {formatTime(recordingSeconds)}
                      </span>
                    </div>

                    {/* Audio Waveform visual bars */}
                    <div className="flex items-center justify-center gap-1.5 h-10 px-4">
                      {audioWaveform.map((h, i) => (
                        <div
                          key={i}
                          className="w-1.5 bg-red-400 rounded-full transition-all duration-150"
                          style={{ height: `${Math.max(8, (h / 100) * 36)}px` }}
                        />
                      ))}
                    </div>

                    <p className="text-xs text-amber-200">
                      Listening in <strong className="text-white">{currentLangObj.name}</strong>... Press Stop when finished.
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-amber-300 max-w-sm">
                    Tap the microphone button to start recording or select a sample voice prompt below.
                  </p>
                )}
              </div>

              {/* Sample Native Prompts for 1-Click Voice Test */}
              <div className="pt-2 border-t border-amber-900/80">
                <div className="text-[11px] font-semibold text-amber-300 mb-2 flex items-center justify-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-yellow-400" />
                  <span>Click a sample audio prompt in {currentLangObj.nativeName}:</span>
                </div>
                <div className="flex flex-wrap justify-center gap-2">
                  {currentLangObj.samplePrompts.map((prompt, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectSamplePrompt(prompt)}
                      className="px-3 py-1.5 rounded-xl bg-amber-900/60 hover:bg-amber-800 text-amber-100 text-xs border border-amber-700/80 transition-all text-left flex items-center gap-1.5"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-yellow-300" />
                      <span>{prompt.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 2. TEXT REPORTING SECTION */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <label htmlFor="issue-description" className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span>Text Reporting / शिकायत का विवरण</span>
                <span className="text-xs font-normal text-slate-400">(Type or edit transcribed text)</span>
              </label>
              {reportText && (
                <button
                  type="button"
                  onClick={() => {
                    setReportText('');
                    setAiAnalysis(null);
                  }}
                  className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" /> Clear
                </button>
              )}
            </div>

            <textarea
              id="issue-description"
              rows={4}
              value={reportText}
              onChange={handleTextChange}
              placeholder="Describe the problem in your own words… उदाहरण: हमारे गांव में पानी की पाइपलाइन पिछले 10 दिनों से बंद है..."
              className="w-full px-4 py-3 rounded-2xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm text-slate-900 placeholder:text-slate-400 bg-stone-50/50 resize-y transition-all leading-relaxed"
            />

            {/* Quick Analyze Button if not analyzed yet */}
            {reportText && !aiAnalysis && (
              <div className="flex justify-end">
                <button
                  type="button"
                  id="btn-analyze-report"
                  disabled={isAnalyzing}
                  onClick={() =>
                    triggerAIAnalysis(
                      reportText,
                      currentLangObj.name,
                      `${district}, ${stateName}`,
                      selectedCategory
                    )
                  }
                  className="px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold border border-amber-200 transition-all flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>{isAnalyzing ? 'Analyzing with AI...' : 'Preview AI Extraction'}</span>
                </button>
              </div>
            )}
          </div>

          {/* 3. CATEGORY SELECTOR */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-slate-900">
                Problem Category / समस्या की श्रेणी
              </label>
              <span className="text-xs text-slate-500 font-medium">Select closest domain</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
              {CATEGORIES.map((cat) => {
                const Icon = cat.icon;
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(cat.id);
                      if (reportText && !isAnalyzing) {
                        triggerAIAnalysis(reportText, currentLangObj.name, `${district}, ${stateName}`, cat.id);
                      }
                    }}
                    className={`p-3 rounded-2xl border text-left transition-all flex items-center gap-2.5 ${
                      isSelected
                        ? 'bg-amber-600 text-white border-amber-600 shadow-sm font-bold scale-[1.02]'
                        : 'bg-stone-50 hover:bg-stone-100 text-slate-700 border-slate-200/80'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                        isSelected ? 'bg-white/20 text-white' : cat.color
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-semibold">{cat.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. LOCATION SELECTOR */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-amber-600" />
                <span>Location of the Issue / स्थान</span>
              </label>
              <button
                type="button"
                id="btn-use-location"
                onClick={handleUseCurrentLocation}
                className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold border border-amber-200 transition-colors flex items-center gap-1.5"
              >
                <Compass className="w-3.5 h-3.5 text-amber-600" />
                <span>Use Current Location</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-600 block mb-1">State</label>
                <select
                  value={stateName}
                  onChange={(e) => setStateName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-medium text-slate-800 bg-stone-50 focus:ring-2 focus:ring-amber-500"
                >
                  <option value="Madhya Pradesh">Madhya Pradesh</option>
                  <option value="Uttar Pradesh">Uttar Pradesh</option>
                  <option value="Rajasthan">Rajasthan</option>
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Gujarat">Gujarat</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-600 block mb-1">District</label>
                <select
                  value={district}
                  onChange={(e) => {
                    const d = e.target.value;
                    setDistrict(d);
                    if (reportText && !isAnalyzing) {
                      triggerAIAnalysis(reportText, currentLangObj.name, `${d}, ${stateName}`, selectedCategory);
                    }
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-medium text-slate-800 bg-stone-50 focus:ring-2 focus:ring-amber-500"
                >
                  {DISTRICTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-600 block mb-1">
                  City / Village / Ward
                </label>
                <input
                  type="text"
                  value={villageWard}
                  onChange={(e) => setVillageWard(e.target.value)}
                  placeholder="e.g. Pohari Ward 4"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-medium text-slate-800 bg-stone-50 focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* 5. OPTIONAL IMAGE UPLOAD */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-3">
            <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Camera className="w-4 h-4 text-slate-500" />
              <span>Optional Photo / फोटो अपलोड करें</span>
            </label>

            <div className="border-2 border-dashed border-slate-200 hover:border-amber-400 rounded-2xl p-4 text-center transition-colors">
              {uploadedImage ? (
                <div className="flex items-center justify-between p-2 bg-stone-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <img
                      src={uploadedImage}
                      alt="Uploaded civic issue"
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    <span className="text-xs font-medium text-slate-700">Photo attached successfully</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setUploadedImage(null)}
                    className="text-xs text-red-500 hover:text-red-700 font-semibold"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <label className="cursor-pointer block py-3">
                  <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                  <span className="text-xs font-semibold text-amber-700 hover:underline">
                    Upload a photo of the issue
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    PNG, JPG or Camera snapshot up to 5MB
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          {/* SECTION 4: AI ANALYSIS RESULT CARD */}
          {(isAnalyzing || aiAnalysis) && (
            <div className="bg-gradient-to-br from-amber-950 via-slate-900 to-amber-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-900/70 animate-in fade-in zoom-in-95 duration-200 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-amber-900/60">
                <div className="flex items-center gap-3">
                  <AdvancedAnimatedIcon name="neural-core" size="sm" />
                  <div>
                    <h3 className="text-lg font-extrabold text-white tracking-tight">
                      Depioro AI Analysis
                    </h3>
                    <span className="text-[11px] text-amber-200 block">
                      Automated Multilingual NLP & Priority Intelligence
                    </span>
                  </div>
                </div>
                <div>
                  {aiAnalysis && (
                    <div className="flex items-center gap-2.5 bg-slate-950/70 py-1.5 px-3 rounded-2xl border border-amber-500/40 shadow-inner">
                      <CircularProgressRing
                        value={aiAnalysis.aiConfidence}
                        size="sm"
                        variant="goldwood"
                        id="portal-ai-analysis-confidence-ring"
                      />
                      <div className="text-left">
                        <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-wider leading-tight">
                          AI Confidence
                        </span>
                        <span className="text-xs font-black text-amber-300 font-mono leading-tight">
                          {aiAnalysis.aiConfidence}% Verified
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {isAnalyzing ? (
                <div className="py-8 text-center space-y-3">
                  <div className="w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-xs text-amber-200">
                    “Depioro AI is understanding your request in {currentLangObj.name}…”
                  </p>
                </div>
              ) : (
                aiAnalysis && (
                  <div className="space-y-4">
                    {/* Top Row Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/60">
                        <span className="text-slate-400 text-[10px] block">Category</span>
                        <strong className="text-white font-bold text-sm">{aiAnalysis.category} Infrastructure</strong>
                      </div>

                      <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/60">
                        <span className="text-slate-400 text-[10px] block">Urgency</span>
                        <div className="flex items-center gap-1 mt-0.5">
                          <span
                            className={`w-2.5 h-2.5 rounded-full ${
                              aiAnalysis.urgency === 'Critical'
                                ? 'bg-red-500 animate-ping'
                                : aiAnalysis.urgency === 'High'
                                ? 'bg-amber-500'
                                : 'bg-amber-600'
                            }`}
                          />
                          <strong className="text-white font-bold text-sm">{aiAnalysis.urgency}</strong>
                        </div>
                      </div>

                      <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/60">
                        <span className="text-slate-400 text-[10px] block">Language</span>
                        <strong className="text-white font-bold text-sm">{aiAnalysis.detectedLanguage}</strong>
                      </div>

                      <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/60">
                        <span className="text-slate-400 text-[10px] block">Location</span>
                        <strong className="text-white font-bold text-sm">{district}, {stateName}</strong>
                      </div>
                    </div>

                    {/* Summary */}
                    <div className="p-3.5 bg-slate-800/90 rounded-2xl border border-slate-700/80 text-xs space-y-1">
                      <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                        Executive AI Summary
                      </span>
                      <p className="text-slate-200 text-xs sm:text-sm font-medium leading-relaxed">
                        “{aiAnalysis.summary}”
                      </p>
                    </div>

                    {/* Keywords & Similar nearby */}
                    <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-slate-400 text-[11px]">Keywords:</span>
                        {aiAnalysis.keywords.map((kw, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-md bg-amber-950/80 border border-amber-800 text-amber-200 text-[11px]"
                          >
                            {kw}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 bg-amber-400/10 border border-amber-400/30 px-3 py-1 rounded-xl text-amber-300 font-semibold text-xs">
                        <span>Similar Requests Nearby:</span>
                        <strong className="text-white">{aiAnalysis.similarNearbyCount} requests</strong>
                      </div>
                    </div>

                    {/* View on Demand Map CTA button inside AI Card */}
                    <div className="pt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedDistrict(district);
                          setCurrentRoute('dashboard');
                        }}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5"
                      >
                        <MapPin className="w-3.5 h-3.5 text-yellow-300" />
                        <span>View on Demand Map</span>
                      </button>
                    </div>
                  </div>
                )
              )}
            </div>
          )}

          {/* SUBMIT BUTTON */}
          <div className="pt-2">
            <button
              type="submit"
              id="submit-development-request-btn"
              disabled={isSubmitting}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 hover:from-amber-500 hover:to-yellow-500 text-white text-base sm:text-lg font-bold shadow-xl shadow-amber-900/30 hover:shadow-2xl hover:shadow-amber-900/40 transition-all active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Submitting & Clustered Into Intelligence Engine...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 text-yellow-300" />
                  <span>Submit Development Request</span>
                  <ArrowRight className="w-5 h-5 ml-1" />
                </>
              )}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
