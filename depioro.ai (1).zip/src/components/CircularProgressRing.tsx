import React from 'react';

export interface CircularProgressRingProps {
  value: number;
  max?: number;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
  strokeWidth?: number;
  showPercent?: boolean;
  showLabel?: boolean;
  subLabel?: string;
  variant?: 'emerald' | 'goldwood' | 'blue' | 'indigo' | 'amber' | 'gradient' | 'auto' | 'dark';
  className?: string;
  id?: string;
  animate?: boolean;
}

const SIZE_MAP: Record<string, { dimension: number; defaultStroke: number; fontSize: string; subFontSize: string }> = {
  xs: { dimension: 32, defaultStroke: 3, fontSize: 'text-[9px] font-bold', subFontSize: 'text-[7px]' },
  sm: { dimension: 42, defaultStroke: 3.5, fontSize: 'text-[11px] font-extrabold', subFontSize: 'text-[8px]' },
  md: { dimension: 56, defaultStroke: 4.5, fontSize: 'text-xs font-black', subFontSize: 'text-[9px]' },
  lg: { dimension: 72, defaultStroke: 5.5, fontSize: 'text-sm font-black', subFontSize: 'text-[10px]' },
  xl: { dimension: 96, defaultStroke: 7, fontSize: 'text-lg font-black', subFontSize: 'text-xs' },
};

export const CircularProgressRing: React.FC<CircularProgressRingProps> = ({
  value,
  max = 100,
  size = 'md',
  strokeWidth,
  showPercent = true,
  showLabel = true,
  subLabel,
  variant = 'auto',
  className = '',
  id,
  animate = true,
}) => {
  const normalizedValue = Math.min(Math.max(Number.isFinite(value) ? value : 0, 0), max);
  const percentage = Math.round((normalizedValue / max) * 100);

  // Determine sizing specifications
  let dimension = 56;
  let stroke = 4.5;
  let fontClasses = 'text-xs font-black';
  let subFontClasses = 'text-[9px]';

  if (typeof size === 'number') {
    dimension = size;
    stroke = strokeWidth ?? Math.max(2.5, Math.round(size * 0.08));
    fontClasses = size < 40 ? 'text-[9px] font-bold' : size < 60 ? 'text-xs font-black' : 'text-base font-black';
    subFontClasses = size < 40 ? 'text-[7px]' : 'text-[9px]';
  } else if (SIZE_MAP[size]) {
    const config = SIZE_MAP[size];
    dimension = config.dimension;
    stroke = strokeWidth ?? config.defaultStroke;
    fontClasses = config.fontSize;
    subFontClasses = config.subFontSize;
  }

  const radius = (dimension - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  // Variant color mappings
  let strokeColor = '#10b981'; // Emerald default
  let trackColor = 'rgba(255, 255, 255, 0.12)';
  let textColor = 'text-emerald-400';
  let glowColor = 'rgba(16, 185, 129, 0.25)';

  if (variant === 'auto') {
    if (percentage >= 90) {
      strokeColor = '#b68535'; // golden wood
      textColor = 'text-amber-700 dark:text-amber-300';
      glowColor = 'rgba(182, 133, 53, 0.35)';
    } else if (percentage >= 75) {
      strokeColor = '#cca25a'; // warm golden teak
      textColor = 'text-amber-600 dark:text-amber-400';
      glowColor = 'rgba(204, 162, 90, 0.3)';
    } else if (percentage >= 60) {
      strokeColor = '#d97706'; // warm amber
      textColor = 'text-amber-700 dark:text-amber-400';
      glowColor = 'rgba(217, 119, 6, 0.3)';
    } else {
      strokeColor = '#dc2626'; // red
      textColor = 'text-red-500';
      glowColor = 'rgba(220, 38, 38, 0.3)';
    }
  } else if (variant === 'goldwood') {
    strokeColor = '#b68535';
    textColor = 'text-amber-700 dark:text-amber-300';
    glowColor = 'rgba(182, 133, 53, 0.4)';
  } else if (variant === 'emerald') {
    strokeColor = '#10b981';
    textColor = 'text-emerald-400';
    glowColor = 'rgba(16, 185, 129, 0.35)';
  } else if (variant === 'blue') {
    strokeColor = '#b68535';
    textColor = 'text-amber-700';
    glowColor = 'rgba(182, 133, 53, 0.3)';
  } else if (variant === 'indigo') {
    strokeColor = '#986923';
    textColor = 'text-amber-600';
    glowColor = 'rgba(152, 105, 35, 0.3)';
  } else if (variant === 'amber') {
    strokeColor = '#cca25a';
    textColor = 'text-amber-600';
    glowColor = 'rgba(204, 162, 90, 0.3)';
  } else if (variant === 'dark') {
    strokeColor = '#e0c08b'; // golden bamboo
    trackColor = 'rgba(255, 255, 255, 0.15)';
    textColor = 'text-amber-200';
    glowColor = 'rgba(224, 192, 139, 0.3)';
  }

  // Unique ID for gradients or SVG identifiers
  const elementId = id || `circular-progress-${Math.random().toString(36).substring(2, 9)}`;
  const gradientId = `${elementId}-gradient`;

  return (
    <div
      id={elementId}
      className={`relative inline-flex flex-col items-center justify-center select-none ${className}`}
      role="progressbar"
      aria-valuenow={percentage}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={`AI Confidence ${percentage}%`}
    >
      <div
        className="relative flex items-center justify-center"
        style={{ width: dimension, height: dimension }}
      >
        <svg
          width={dimension}
          height={dimension}
          viewBox={`0 0 ${dimension} ${dimension}`}
          className="transform -rotate-90 origin-center"
        >
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
              {variant === 'emerald' ? (
                <>
                  <stop offset="0%" stopColor="#34d399" />
                  <stop offset="100%" stopColor="#059669" />
                </>
              ) : variant === 'dark' ? (
                <>
                  <stop offset="0%" stopColor="#cca25a" />
                  <stop offset="100%" stopColor="#7a5019" />
                </>
              ) : (
                <>
                  <stop offset="0%" stopColor="#cca25a" />
                  <stop offset="100%" stopColor="#986923" />
                </>
              )}
            </linearGradient>
            <filter id={`${elementId}-glow`} x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor={glowColor} />
            </filter>
          </defs>

          {/* Background Track */}
          <circle
            cx={dimension / 2}
            cy={dimension / 2}
            r={radius}
            fill="none"
            stroke={trackColor}
            strokeWidth={stroke}
            className="transition-colors duration-300"
          />

          {/* Foreground Animated Progress Ring */}
          <circle
            cx={dimension / 2}
            cy={dimension / 2}
            r={radius}
            fill="none"
            stroke={`url(#${gradientId})`}
            strokeWidth={stroke}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            filter={`url(#${elementId}-glow)`}
            style={{
              transition: animate
                ? 'stroke-dashoffset 0.9s cubic-bezier(0.34, 1.56, 0.64, 1), stroke 0.3s ease'
                : 'none',
            }}
          />
        </svg>

        {/* Center Percentage Display */}
        {showPercent && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
            <span className={`${fontClasses} ${textColor} leading-none tracking-tight font-mono`}>
              {percentage}%
            </span>
          </div>
        )}
      </div>

      {/* Optional Sub-label underneath ring */}
      {showLabel && subLabel && (
        <span className={`mt-1 font-semibold uppercase tracking-wider ${subFontClasses} text-slate-400 text-center leading-tight whitespace-nowrap`}>
          {subLabel}
        </span>
      )}
    </div>
  );
};
