import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  MapPin,
  Sparkles,
  AlertTriangle,
  Users,
  Layers,
  ArrowUpRight,
  Filter,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  FileSpreadsheet,
  Download,
  Eye,
  RefreshCw,
  Bell,
  Radio,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useDepioro } from '../context/DepioroContext';
import { DemandHotspotMap } from './DemandHotspotMap';
import { CATEGORY_STATS, REGION_STATS, DEMAND_TREND } from '../data/mockData';
import { IssueCategory, AIRecommendation } from '../types';
import { CircularProgressRing } from './CircularProgressRing';
import { NotifyStakeholdersModal, DispatchInfo } from './NotifyStakeholdersModal';
import { AdvancedAnimatedIcon } from './AdvancedAnimatedIcon';
import { PrintDossierHeader, PrintSignatureBlock } from './PrintDossierHeader';

export const PolicymakerDashboard: React.FC = () => {
  const {
    stats,
    selectedDistrict,
    setSelectedDistrict,
    selectedCategory,
    setSelectedCategory,
    recommendations,
    setSelectedRecommendation,
    setCurrentRoute,
    requests,
    updateRequestStatus,
  } = useDepioro();

  const [dateRange, setDateRange] = useState('Last 30 Days');
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'recommendations' | 'feed'>('overview');
  const [notifyModalRec, setNotifyModalRec] = useState<AIRecommendation | null>(null);
  const [notifiedMap, setNotifiedMap] = useState<Record<string, DispatchInfo>>({});

  const handleOpenRec = (rec: AIRecommendation) => {
    setSelectedRecommendation(rec);
    setCurrentRoute('recommendations');
  };

  // Calculate dynamic urgency breakdown from requests
  const urgencyCounts = requests.reduce(
    (acc, r) => {
      acc[r.priority] = (acc[r.priority] || 0) + 1;
      return acc;
    },
    { Critical: 0, High: 0, Medium: 0, Low: 0 } as Record<string, number>
  );

  const totalReqs = requests.length || 1;

  const handlePrintDossier = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 print:p-0 print:m-0 print:max-w-none print:space-y-4">
      {/* Official Government Print Header */}
      <PrintDossierHeader
        title="Development Intelligence & Infrastructure Demand Summary"
        documentType="EXECUTIVE INFRASTRUCTURE INTELLIGENCE DOSSIER"
        documentRef={`DEPIORO/DASH/2026/${selectedDistrict === 'All' ? 'MP-STATE' : selectedDistrict.toUpperCase().slice(0, 3)}-${stats.totalRequests}`}
        district={selectedDistrict === 'All' ? 'Statewide (All 52 Districts)' : `${selectedDistrict} District`}
        state="Madhya Pradesh"
        classification="OFFICIAL • FOR POLICYMAKER & COLLECTORATE REVIEW"
      />

      {/* 1. TOP HEADER & GLOBAL GOV FILTERS */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-950/60 space-y-6 print:hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-semibold mb-2">
              <BarChart3 className="w-3.5 h-3.5 text-amber-400" />
              <span>Public Infrastructure Planning Division</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Development Intelligence Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              “AI-powered insights from citizen development requests.”
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setCurrentRoute('jan-sunwai')}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Jan Sunwai Live Hearing Copilot"
            >
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>Jan Sunwai Copilot</span>
            </button>

            <button
              onClick={() => setCurrentRoute('budget-optimizer')}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Vikas Budget & ROI Capital Allocation Simulator"
            >
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span>Budget Optimizer</span>
            </button>

            <button
              onClick={() => setCurrentRoute('recommendations')}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs sm:text-sm font-semibold shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>AI Recommendations ({stats.aiRecommendationsCount})</span>
            </button>

            <button
              onClick={handlePrintDossier}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Print or Save PDF Executive Summary"
            >
              <Download className="w-4 h-4 text-amber-400" />
              <span>Export Dossier (PDF)</span>
            </button>
          </div>
        </div>

        {/* Global Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="text-slate-400 text-[11px] block mb-1 font-medium">State / Jurisdiction</label>
            <select className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:ring-2 focus:ring-amber-500">
              <option value="Madhya Pradesh">Madhya Pradesh (State Hub)</option>
              <option value="Uttar Pradesh">Uttar Pradesh (Central Zone)</option>
              <option value="Rajasthan">Rajasthan (Western Zone)</option>
              <option value="Maharashtra">Maharashtra (Southern Zone)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1 font-medium">District Filter</label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:ring-2 focus:ring-amber-500"
            >
              <option value="All">All 52 Districts</option>
              <option value="Shivpuri">Shivpuri (1,284 Requests)</option>
              <option value="Gwalior">Gwalior (1,890 Requests)</option>
              <option value="Bhopal">Bhopal (2,410 Requests)</option>
              <option value="Indore">Indore (2,180 Requests)</option>
              <option value="Jabalpur">Jabalpur (1,450 Requests)</option>
              <option value="Ujjain">Ujjain (1,120 Requests)</option>
              <option value="Chhindwara">Chhindwara (940 Requests)</option>
              <option value="Rewa">Rewa (820 Requests)</option>
              <option value="Sagar">Sagar (790 Requests)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1 font-medium">Domain Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:ring-2 focus:ring-amber-500"
            >
              <option value="All">All Categories</option>
              <option value="Water">Water Infrastructure</option>
              <option value="Roads">Roads & Connectivity</option>
              <option value="Healthcare">Primary Healthcare</option>
              <option value="Education">Public Education</option>
              <option value="Electricity">Electricity & Power</option>
              <option value="Sanitation">Sanitation & Solid Waste</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1 font-medium">Time Horizon</label>
            <div className="relative">
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:ring-2 focus:ring-amber-500"
              >
                <option value="Last 7 Days">Last 7 Days</option>
                <option value="Last 30 Days">Last 30 Days</option>
                <option value="Last Quarter">Last Quarter (Q1 2026)</option>
                <option value="Year to Date">Year to Date (FY 2025-26)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* 2. FOUR HERO KPI CARDS */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6"
      >
        {/* Card 1: Citizen Requests */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-stone-200 shadow-xs space-y-1 hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Citizen Requests
            </span>
            <AdvancedAnimatedIcon name="voice-wave" size="sm" />
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {(stats?.totalRequests ?? 12482).toLocaleString()}
            </span>
            <span className="text-xs text-emerald-600 font-bold flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" /> +14.2%
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium pt-1">
            Across 52 administrative districts
          </p>
        </div>

        {/* Card 2: High Priority Issues */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-stone-200 shadow-xs space-y-1 hover:border-red-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              High Priority Issues
            </span>
            <AdvancedAnimatedIcon name="flame-urgency" size="sm" />
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl sm:text-3xl font-black text-red-600 tracking-tight">
              {(stats?.highPriorityIssues ?? stats?.highPriorityCount ?? 3240).toLocaleString()}
            </span>
            <span className="text-[11px] text-red-600 font-bold font-mono px-1.5 py-0.5 bg-red-50 rounded border border-red-100">
              ! CRITICAL
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium pt-1">
            26% require immediate intervention
          </p>
        </div>

        {/* Card 3: Demand Hotspots */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-stone-200 shadow-xs space-y-1 hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Demand Hotspots
            </span>
            <AdvancedAnimatedIcon name="geo-pulse" size="sm" />
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {stats.hotspotsCount}
            </span>
            <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded font-bold">
              Needs Action
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium pt-1">
            Shivpuri & Gwalior highest severity
          </p>
        </div>

        {/* Card 4: AI Recommendations */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-amber-200 shadow-xs space-y-1 ring-2 ring-amber-500/10 hover:border-amber-400 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-800 uppercase tracking-wider">
              AI Recommendations
            </span>
            <AdvancedAnimatedIcon name="ai-sparkle" size="sm" />
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl sm:text-3xl font-black text-amber-950 tracking-tight">
              {stats.aiRecommendationsCount}
            </span>
            <span className="text-xs text-amber-700 italic font-medium">
              Ready for review
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium pt-1">
            ₹340Cr+ scheme capital mapped
          </p>
        </div>
      </motion.div>

      {/* 3. INTERACTIVE DEMAND HOTSPOT MAP */}
      <DemandHotspotMap />

      {/* 4. ANALYTICS CHARTS & LINGUISTIC INGESTION METRICS */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">
              Development Demand Analytics & Telemetry
            </h3>
            <p className="text-xs text-slate-500">
              Aggregated distribution across categories, linguistic intake, regional severity tiers, and temporal trend.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Chart 1: Linguistic Breakdown */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Multilingual Intake
              </h4>
              <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                12 Indian Langs
              </span>
            </div>

            <div className="space-y-2.5">
              {[
                { lang: 'Hindi (हिंदी)', pct: 52, count: '6,490' },
                { lang: 'Marathi (मराठी)', pct: 18, count: '2,246' },
                { lang: 'Bengali (বাংলা)', pct: 12, count: '1,497' },
                { lang: 'Tamil (தமிழ்)', pct: 10, count: '1,248' },
                { lang: 'Others (Telugu/Gujarati)', pct: 8, count: '998' },
              ].map((item) => (
                <div key={item.lang} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-700">{item.lang}</span>
                    <span className="font-bold text-slate-900">{item.pct}% ({item.count})</span>
                  </div>
                  <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-600 h-full rounded-full"
                      style={{ width: `${item.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Chart 2: Requests by Category */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Domain Categories
              </h4>
              <span className="text-[11px] text-slate-400">Total: {(stats?.totalRequests ?? 12482).toLocaleString()}</span>
            </div>

            <div className="space-y-2.5">
              {CATEGORY_STATS.slice(0, 5).map((cat) => (
                <div key={cat.category} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-700">{cat.category}</span>
                    <span className="font-bold text-slate-900">
                      {(cat.count ?? 0).toLocaleString()} ({cat.percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-700 h-full rounded-full transition-all duration-500"
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Chart 3: Urgency Distribution */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Severity Distribution
              </h4>
              <span className="text-[11px] text-slate-400">Triage Tiers</span>
            </div>

            <div className="space-y-2.5">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-red-700 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500" /> Critical
                  </span>
                  <span className="font-bold text-slate-900">26% (3,240)</span>
                </div>
                <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-red-500 h-full rounded-full" style={{ width: '26%' }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-amber-800 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-600" /> High
                  </span>
                  <span className="font-bold text-slate-900">42% (5,242)</span>
                </div>
                <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-amber-600 h-full rounded-full" style={{ width: '42%' }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-yellow-700 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-yellow-500" /> Medium
                  </span>
                  <span className="font-bold text-slate-900">22% (2,745)</span>
                </div>
                <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-yellow-500 h-full rounded-full" style={{ width: '22%' }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Low
                  </span>
                  <span className="font-bold text-slate-900">10% (1,255)</span>
                </div>
                <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '10%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Chart 4: Citizen Demand Trend */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                30-Day Ingestion Trend
              </h4>
              <span className="text-[11px] font-bold text-emerald-600">+24% surge</span>
            </div>

            {/* Visual Spark Bars */}
            <div className="h-24 flex items-end justify-between gap-1 pt-2">
              {DEMAND_TREND.map((item, i) => {
                const heightPercent = Math.min(100, Math.max(15, (item.requests / 600) * 100));
                return (
                  <div
                    key={i}
                    className="flex-1 flex flex-col items-center gap-1 group relative cursor-pointer"
                  >
                    <div
                      className="w-full bg-amber-100 group-hover:bg-amber-600 rounded-t transition-all duration-200"
                      style={{ height: `${heightPercent}%` }}
                    />
                    <div className="absolute -top-7 hidden group-hover:block bg-slate-900 text-white text-[9px] px-1.5 py-0.5 rounded whitespace-nowrap z-20 pointer-events-none">
                      {item.date}: {item.requests}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-100">
              <span>Day 1</span>
              <span>Day 15</span>
              <span>Today</span>
            </div>
          </div>
        </div>
      </div>

      {/* 5. AI DEVELOPMENT RECOMMENDATIONS SHOWCASE */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">
                AI Development Recommendations
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Evidence-based priority interventions computed by synthesizing grassroots citizen clusters and central schemes.
            </p>
          </div>

          <button
            onClick={() => setCurrentRoute('recommendations')}
            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View All {recommendations.length} Executive Recommendations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3 Featured Recommendation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
          {recommendations.slice(0, 3).map((rec) => (
            <div
              key={rec.id}
              className="bg-white rounded-xl p-5 sm:p-6 shadow-xs border border-stone-200 hover:border-amber-400 transition-all flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200">
                        Priority: {rec.priorityScore} / 100
                      </span>
                      <span className="text-xs font-bold text-amber-900 font-mono bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                        {rec.estimatedBudget}
                      </span>
                    </div>

                    <h4 className="text-sm font-extrabold text-slate-900 leading-snug group-hover:text-amber-700 transition-colors">
                      {rec.title}
                    </h4>
                  </div>

                  <div className="shrink-0 flex flex-col items-center pt-0.5">
                    <CircularProgressRing
                      value={rec.aiConfidence || 95}
                      size="sm"
                      variant="goldwood"
                      id={`policy-rec-card-ring-${rec.id}`}
                      showLabel={true}
                      subLabel="Confidence"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <MapPin className="w-3.5 h-3.5 text-amber-600" />
                  <span>
                    {rec.district}, {rec.state}
                  </span>
                  <span>•</span>
                  <span>{rec.category}</span>
                </div>

                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                  {rec.aiReasoning}
                </p>

                <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                  <div className="bg-stone-50 p-2 rounded-lg border border-stone-200/60">
                    <span className="text-slate-400 block text-[10px]">Citizen Demand</span>
                    <strong className="text-slate-800 font-mono">
                      {(rec.citizenDemandCount ?? rec.citizenRequestsCount ?? 0).toLocaleString()} requests
                    </strong>
                  </div>
                  <div className="bg-stone-50 p-2 rounded-lg border border-stone-200/60">
                    <span className="text-slate-400 block text-[10px]">Beneficiary Impact</span>
                    <strong className="text-slate-800 font-mono">
                      {(rec.affectedPopulation ?? 0).toLocaleString()} pop.
                    </strong>
                  </div>
                </div>

                {notifiedMap[rec.id] && (
                  <div className="py-1 px-2 rounded-md bg-amber-100/90 text-amber-950 text-[10px] font-bold flex items-center justify-between border border-amber-300">
                    <div className="flex items-center gap-1 truncate">
                      <Bell className="w-3 h-3 text-amber-700 shrink-0" />
                      <span>Notified ({notifiedMap[rec.id].officesCount} Offices)</span>
                    </div>
                    <span className="font-mono text-[9px] text-amber-800">{notifiedMap[rec.id].dispatchId}</span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setNotifyModalRec(rec)}
                  className="py-2 px-3 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                >
                  <Bell className="w-3.5 h-3.5 text-amber-700" />
                  <span>{notifiedMap[rec.id] ? 'Re-Notify' : 'Notify Stakeholders'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenRec(rec)}
                  className="py-2 px-3 rounded-lg bg-slate-900 hover:bg-amber-950 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span>View Brief</span>
                  <ArrowRight className="w-3.5 h-3.5 text-yellow-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. RECENT CITIZEN REQUESTS LIVE FEED */}
      <div className="bg-white rounded-xl p-5 sm:p-6 shadow-xs border border-stone-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 uppercase tracking-tight">
              Live Grassroots Ingestion Feed
            </h3>
            <p className="text-xs text-slate-500">
              Real-time incoming complaints verified and tagged by Depioro AI.
            </p>
          </div>
          <button
            onClick={() => setCurrentRoute('requests')}
            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
          >
            <span>View All Stream</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                <th className="pb-3 pr-4">Request ID</th>
                <th className="pb-3 pr-4">Category</th>
                <th className="pb-3 pr-4">Location</th>
                <th className="pb-3 pr-4">Urgency</th>
                <th className="pb-3 pr-4">AI Summary</th>
                <th className="pb-3 pr-4">Status</th>
                <th className="pb-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              {requests.slice(0, 5).map((req) => (
                <tr key={req.id} className="hover:bg-stone-50/80 transition-colors">
                  <td className="py-3 pr-4 font-mono font-bold text-amber-800">{req.id}</td>
                  <td className="py-3 pr-4">
                    <span className="px-2 py-0.5 rounded bg-stone-100 text-slate-800 font-semibold text-[11px]">
                      {req.category}
                    </span>
                  </td>
                  <td className="py-3 pr-4">
                    {req.cityVillageWard}, {req.district}
                  </td>
                  <td className="py-3 pr-4">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        req.priority === 'Critical'
                          ? 'bg-red-100 text-red-700'
                          : req.priority === 'High'
                          ? 'bg-amber-100 text-amber-900'
                          : 'bg-amber-50 text-amber-800'
                      }`}
                    >
                      {req.priority}
                    </span>
                  </td>
                  <td className="py-3 pr-4 max-w-xs truncate text-slate-600">
                    {req.aiSummary || req.description}
                  </td>
                  <td className="py-3 pr-4">
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-bold text-[10px]">
                      {req.status}
                    </span>
                  </td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => {
                        // Advance status for instant interactive demo feedback
                        if (req.status === 'Submitted') updateRequestStatus(req.id, 'AI Analysed');
                        else if (req.status === 'AI Analysed') updateRequestStatus(req.id, 'Clustered');
                        else if (req.status === 'Clustered') updateRequestStatus(req.id, 'Under Review');
                        else if (req.status === 'Under Review') updateRequestStatus(req.id, 'Development Planning');
                        else updateRequestStatus(req.id, 'Resolved');
                      }}
                      className="px-2.5 py-1 rounded bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-[11px] border border-amber-200 transition-colors"
                    >
                      Advance Status →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Signature Block for Printed Dashboard Dossier */}
      <PrintSignatureBlock
        preparedBy="Depioro AI Telemetry & Infrastructure Analytics Engine"
        reviewedBy="District Development Commissioner / Chief Planning Officer"
        sanctioningAuthority="Principal Secretary, Urban & Rural Development"
      />

      {/* Stakeholder Notification Trigger Modal */}
      <NotifyStakeholdersModal
        isOpen={!!notifyModalRec}
        onClose={() => setNotifyModalRec(null)}
        recommendation={notifyModalRec}
        onNotifySuccess={(recId, info) => {
          setNotifiedMap((prev) => ({ ...prev, [recId]: info }));
        }}
      />
    </div>
  );
};
