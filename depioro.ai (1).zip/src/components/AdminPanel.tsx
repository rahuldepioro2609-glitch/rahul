import React, { useState } from 'react';
import {
  ShieldAlert,
  Server,
  Activity,
  Cpu,
  Database,
  RefreshCw,
  Sparkles,
  Users,
  Layers,
  FileCheck,
  CheckCircle2,
  AlertTriangle,
  Globe,
  Radio,
  Sliders,
  Terminal,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDepioro } from '../context/DepioroContext';
import { LANGUAGES, CATEGORY_STATS } from '../data/mockData';

export const AdminPanel: React.FC = () => {
  const { stats, requests, hotspots, recommendations, resetToDefault } = useDepioro();

  const [simulatingBatch, setSimulatingBatch] = useState(false);
  const [logs, setLogs] = useState<Array<{ time: string; msg: string; type: string }>>([
    { time: '10:42:15', msg: 'System initialized. 12,482 baseline requests indexed.', type: 'info' },
    { time: '10:43:02', msg: 'NLP engine online. Language detector initialized for 10 Indic languages.', type: 'success' },
    { time: '10:44:18', msg: 'Shivpuri hotspot cluster recalculation completed. Priority score: 92/100.', type: 'warning' },
    { time: '10:45:00', msg: 'Gemini 3.7 Flash API connected for policy briefs synthesis.', type: 'success' },
  ]);

  const handleSeedBatch = () => {
    setSimulatingBatch(true);
    setTimeout(() => {
      setSimulatingBatch(false);
      setLogs((prev) => [
        {
          time: new Date().toLocaleTimeString(),
          msg: 'Batch ingested: 50 synthetic multi-lingual voice reports added across 8 districts.',
          type: 'success',
        },
        ...prev,
      ]);
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch (err) {}
    }, 1200);
  };

  const handleResetData = () => {
    if (confirm('Reset system data to baseline state?')) {
      resetToDefault();
      setLogs((prev) => [
        {
          time: new Date().toLocaleTimeString(),
          msg: 'System data reset to default seed state.',
          type: 'info',
        },
        ...prev,
      ]);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-amber-300 border border-slate-700 text-xs font-semibold mb-2">
            <Server className="w-3.5 h-3.5" />
            <span>Platform Infrastructure & System Operations</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight">
            Depioro Platform Administration
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Monitor API throughput, multilingual NLP pipeline latency, spatial clustering nodes, and system health.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSeedBatch}
            disabled={simulatingBatch}
            className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-yellow-200" />
            <span>{simulatingBatch ? 'Ingesting Batch...' : '+ Simulate Ingestion (50 Calls)'}</span>
          </button>

          <button
            onClick={handleResetData}
            className="px-3.5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-slate-700 text-xs font-semibold border border-stone-300 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Data</span>
          </button>
        </div>
      </div>

      {/* SYSTEM TELEMETRY CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-stone-200 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Gemini AI Status
            </span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            Connected (Healthy)
          </div>
          <p className="text-xs text-slate-500">
            Model: <strong className="text-slate-800">gemini-3.7-flash</strong>
          </p>
        </div>

        <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-stone-200 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Avg NLP Latency
            </span>
            <Cpu className="w-4 h-4 text-amber-700" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-800">
            1.82 seconds
          </div>
          <p className="text-xs text-emerald-600 font-semibold">
            99.9% uptime SLA
          </p>
        </div>

        <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-stone-200 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Live Hotspot Nodes
            </span>
            <Layers className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-900">
            {stats.hotspotsCount} Clusters Active
          </div>
          <p className="text-xs text-slate-500">
            52 districts monitored
          </p>
        </div>

        <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-stone-200 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Total Ingested Data
            </span>
            <Database className="w-4 h-4 text-amber-700" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-950">
            {(stats?.totalRequests ?? 12482).toLocaleString()} Reports
          </div>
          <p className="text-xs text-slate-500">
            100% geo-indexed
          </p>
        </div>
      </div>

      {/* LANGUAGE BREAKDOWN & SYSTEM LOGS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Language Breakdown */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 shadow-xs border border-stone-200 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-amber-700" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Language Ingestion Share
              </h3>
            </div>
            <span className="text-xs text-slate-400">10 Indic Dialects</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-700">Hindi (हिन्दी)</span>
                <span className="font-bold text-slate-900">46% (5,741 reports)</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-600 h-full rounded-full" style={{ width: '46%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-700">English</span>
                <span className="font-bold text-slate-900">22% (2,746 reports)</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-700 h-full rounded-full" style={{ width: '22%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-700">Marathi (मराठी)</span>
                <span className="font-bold text-slate-900">12% (1,497 reports)</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '12%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-700">Gujarati (ગુજરાતી)</span>
                <span className="font-bold text-slate-900">8% (998 reports)</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-600 h-full rounded-full" style={{ width: '8%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-700">Bengali (বাংলা)</span>
                <span className="font-bold text-slate-900">6% (748 reports)</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '6%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="text-slate-700">Tamil (தமிழ்) & Telugu (తెలుగు)</span>
                <span className="font-bold text-slate-900">6% (752 reports)</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-800 h-full rounded-full" style={{ width: '6%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Live System Event Log Terminal */}
        <div className="lg:col-span-7 bg-slate-950 text-slate-200 rounded-3xl p-6 shadow-xl border border-amber-950/60 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300 font-bold uppercase tracking-wider">
                System Ingestion & NLP Activity Logs
              </span>
            </div>
            <span className="text-[10px] text-slate-500">Live Buffer</span>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-2">
            {logs.map((log, index) => (
              <div key={index} className="flex items-start gap-2 text-[11px] leading-relaxed">
                <span className="text-slate-500 shrink-0">[{log.time}]</span>
                <span
                  className={
                    log.type === 'success'
                      ? 'text-emerald-400'
                      : log.type === 'warning'
                      ? 'text-amber-400'
                      : 'text-yellow-300'
                  }
                >
                  {log.msg}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
            <span>Spatial clustering worker active</span>
            <span className="text-emerald-400">● 0 errors detected</span>
          </div>
        </div>
      </div>
    </div>
  );
};
