import React from 'react';
import { motion } from 'motion/react';
import {
  Brain,
  Sparkles,
  Activity,
  Radio,
  Cpu,
  Flame,
  ShieldCheck,
  Zap,
  Globe,
  Waves,
  CheckCircle2,
  AlertTriangle,
  Layers,
  MapPin,
  TrendingUp,
} from 'lucide-react';

interface AnimatedIconProps {
  name:
    | 'brain-pulse'
    | 'voice-wave'
    | 'ai-sparkle'
    | 'satellite-beacon'
    | 'neural-core'
    | 'flame-urgency'
    | 'shield-secure'
    | 'geo-pulse'
    | 'live-radar'
    | 'quantum-zap';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  badge?: string;
  glow?: boolean;
}

const sizeClasses = {
  xs: 'w-4 h-4',
  sm: 'w-5 h-5',
  md: 'w-6 h-6',
  lg: 'w-8 h-8',
  xl: 'w-10 h-10',
};

const containerSizeClasses = {
  xs: 'w-6 h-6',
  sm: 'w-8 h-8',
  md: 'w-10 h-10',
  lg: 'w-12 h-12',
  xl: 'w-16 h-16',
};

export const AdvancedAnimatedIcon: React.FC<AnimatedIconProps> = ({
  name,
  size = 'md',
  className = '',
  badge,
  glow = true,
}) => {
  const iconSize = sizeClasses[size];
  const containerSize = containerSizeClasses[size];

  switch (name) {
    case 'brain-pulse':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          {glow && (
            <motion.div
              animate={{
                scale: [1, 1.25, 1],
                opacity: [0.35, 0.7, 0.35],
              }}
              transition={{
                duration: 2.4,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="absolute inset-0 rounded-xl bg-amber-500/30 blur-md pointer-events-none"
            />
          )}
          <motion.div
            animate={{
              rotate: [0, 2, -2, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className={`relative z-10 flex items-center justify-center rounded-xl bg-gradient-to-tr from-amber-700 via-amber-600 to-yellow-500 text-white shadow-md border border-amber-400/40`}
          >
            <Brain className={`${iconSize} p-1`} />
          </motion.div>
          {badge && (
            <span className="absolute -top-1 -right-1 z-20 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" />
            </span>
          )}
        </div>
      );

    case 'voice-wave':
      return (
        <div className={`relative inline-flex items-center justify-center gap-0.5 ${containerSize} ${className}`}>
          {glow && (
            <div className="absolute inset-0 rounded-full bg-emerald-500/20 blur-sm pointer-events-none" />
          )}
          {[0.6, 1, 0.7, 0.4].map((scaleFactor, i) => (
            <motion.span
              key={i}
              animate={{
                height: ['30%', '95%', '30%'],
              }}
              transition={{
                duration: 0.8 + i * 0.15,
                repeat: Infinity,
                repeatType: 'reverse',
                ease: 'easeInOut',
                delay: i * 0.12,
              }}
              className="w-1 bg-gradient-to-t from-emerald-600 to-teal-400 rounded-full shadow-2xs"
            />
          ))}
        </div>
      );

    case 'ai-sparkle':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'linear',
            }}
            className="absolute inset-0 rounded-full border border-dashed border-amber-400/50"
          />
          <motion.div
            animate={{
              scale: [0.9, 1.15, 0.9],
              rotate: [0, 15, -15, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative z-10 text-amber-500 drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]"
          >
            <Sparkles className={iconSize} />
          </motion.div>
        </div>
      );

    case 'satellite-beacon':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              scale: [0.8, 1.8],
              opacity: [0.8, 0],
            }}
            transition={{
              duration: 1.8,
              repeat: Infinity,
              ease: 'easeOut',
            }}
            className="absolute inset-0 rounded-full border-2 border-amber-500 pointer-events-none"
          />
          <motion.div
            animate={{
              scale: [0.8, 2.2],
              opacity: [0.5, 0],
            }}
            transition={{
              duration: 1.8,
              repeat: Infinity,
              ease: 'easeOut',
              delay: 0.5,
            }}
            className="absolute inset-0 rounded-full border border-yellow-400 pointer-events-none"
          />
          <div className="relative z-10 w-4 h-4 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-white shadow-md">
            <Radio className="w-2.5 h-2.5" />
          </div>
        </div>
      );

    case 'neural-core':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              rotate: 360,
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: 'linear',
            }}
            className="absolute inset-0 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/10 to-amber-600/20 border border-amber-500/30"
          />
          <motion.div
            animate={{
              scale: [1, 1.08, 1],
            }}
            transition={{
              duration: 1.6,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative z-10 text-amber-400"
          >
            <Cpu className={iconSize} />
          </motion.div>
        </div>
      );

    case 'flame-urgency':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              scale: [1, 1.25, 1],
              opacity: [0.4, 0.8, 0.4],
            }}
            transition={{
              duration: 1.2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="absolute inset-0 rounded-full bg-red-500/30 blur-sm pointer-events-none"
          />
          <motion.div
            animate={{
              y: [0, -2, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 0.9,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative z-10 text-red-500 drop-shadow-[0_0_6px_rgba(239,68,68,0.6)]"
          >
            <Flame className={iconSize} />
          </motion.div>
        </div>
      );

    case 'shield-secure':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              scale: [0.95, 1.05, 0.95],
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative z-10 text-emerald-600 drop-shadow-[0_0_6px_rgba(16,185,129,0.3)]"
          >
            <ShieldCheck className={iconSize} />
          </motion.div>
        </div>
      );

    case 'geo-pulse':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              scale: [0.8, 1.7],
              opacity: [0.7, 0],
            }}
            transition={{
              duration: 1.6,
              repeat: Infinity,
              ease: 'easeOut',
            }}
            className="absolute -inset-1 rounded-full bg-amber-500/40 pointer-events-none"
          />
          <motion.div
            animate={{
              y: [0, -3, 0],
            }}
            transition={{
              duration: 1.4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative z-10 text-amber-600 drop-shadow-xs"
          >
            <MapPin className={iconSize} />
          </motion.div>
        </div>
      );

    case 'quantum-zap':
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              scale: [1, 1.2, 0.9, 1.1, 1],
              rotate: [0, 5, -5, 3, 0],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative z-10 text-amber-500 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]"
          >
            <Zap className={iconSize} />
          </motion.div>
        </div>
      );

    case 'live-radar':
    default:
      return (
        <div className={`relative inline-flex items-center justify-center ${containerSize} ${className}`}>
          <motion.div
            animate={{
              rotate: 360,
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: 'linear',
            }}
            className="absolute inset-0 rounded-full border-t-2 border-r-2 border-amber-500 pointer-events-none opacity-80"
          />
          <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shadow-[0_0_6px_#f59e0b]" />
        </div>
      );
  }
};
