import React, { useState } from 'react';
import {
  Brain,
  MapPin,
  Mic,
  BarChart3,
  Sparkles,
  ShieldCheck,
  Globe,
  Layers,
  ChevronDown,
  Menu,
  X,
  FileText,
  UserCheck,
} from 'lucide-react';
import { useDepioro } from '../context/DepioroContext';
import { LANGUAGES } from '../data/mockData';
import { LanguageCode } from '../types';

export const Navbar: React.FC = () => {
  const {
    currentRoute,
    setCurrentRoute,
    selectedLanguage,
    setSelectedLanguage,
    activeRole,
    setActiveRole,
    stats,
  } = useDepioro();

  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const currentLangObj = LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0];

  const handleNav = (route: string) => {
    setCurrentRoute(route);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top GovTech Banner */}
      <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4 sm:px-8 flex flex-wrap justify-between items-center border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-medium text-slate-300">
            Citizen Intelligence Platform of India
          </span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-400">
            Prototype / GovTech AI Initiative
          </span>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-3 text-slate-300 text-[11px]">
            <span>
              Live Reports: <strong className="text-emerald-400">{(stats?.totalRequests ?? 12482).toLocaleString()}</strong>
            </span>
            <span className="text-slate-600">|</span>
            <span>
              Hotspots: <strong className="text-amber-400">{stats.hotspotsCount}</strong>
            </span>
            <span className="text-slate-600">|</span>
            <span>
              AI Recs: <strong className="text-sky-400">{stats.aiRecommendationsCount}</strong>
            </span>
          </div>

          {/* Role switcher pill */}
          <div className="flex items-center bg-slate-800/80 rounded-full p-0.5 border border-slate-700">
            <button
              id="role-btn-citizen"
              onClick={() => {
                setActiveRole('citizen');
                if (currentRoute === 'admin' || currentRoute === 'dashboard') {
                  setCurrentRoute('citizen');
                }
              }}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium transition-all ${
                activeRole === 'citizen'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              Citizen
            </button>
            <button
              id="role-btn-policymaker"
              onClick={() => {
                setActiveRole('policymaker');
                if (currentRoute === 'citizen' || currentRoute === 'requests') {
                  setCurrentRoute('dashboard');
                }
              }}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium transition-all ${
                activeRole === 'policymaker'
                  ? 'bg-amber-700 text-amber-100 shadow-xs'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              Policymaker
            </button>
            <button
              id="role-btn-admin"
              onClick={() => {
                setActiveRole('admin');
                setCurrentRoute('admin');
              }}
              className={`px-2 py-0.5 rounded-full text-[11px] font-medium transition-all ${
                activeRole === 'admin'
                  ? 'bg-slate-700 text-amber-300 shadow-xs'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              Admin
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => handleNav('home')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-900 via-amber-700 to-yellow-500 flex items-center justify-center text-white shadow-md shadow-amber-900/20 ring-2 ring-amber-500/30 group-hover:scale-105 transition-transform">
              <div className="relative">
                <Brain className="w-5 h-5 text-amber-100" />
                <MapPin className="w-3 h-3 text-yellow-300 absolute -bottom-1 -right-1" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-extrabold tracking-tight text-slate-900">
                  Depioro<span className="text-amber-600">.ai</span>
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-amber-50 text-amber-800 rounded-md border border-amber-200/80 uppercase tracking-wider">
                  India
                </span>
              </div>
              <p className="text-[10px] font-medium text-slate-500 hidden sm:block">
                Citizen Development Intelligence
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              id="nav-link-home"
              onClick={() => handleNav('home')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentRoute === 'home'
                  ? 'bg-amber-50/80 text-amber-900 font-bold border border-amber-200/50'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              Home
            </button>
            <button
              id="nav-link-how-it-works"
              onClick={() => handleNav('how-it-works')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentRoute === 'how-it-works'
                  ? 'bg-amber-50/80 text-amber-900 font-bold border border-amber-200/50'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              How It Works
            </button>
            <button
              id="nav-link-citizen"
              onClick={() => handleNav('citizen')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentRoute === 'citizen'
                  ? 'bg-amber-100/70 text-amber-900 font-bold border border-amber-300/60'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              <Mic className="w-4 h-4 text-amber-600" />
              Citizen Portal
            </button>
            <button
              id="nav-link-requests"
              onClick={() => handleNav('requests')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentRoute === 'requests'
                  ? 'bg-amber-50/80 text-amber-900 font-bold border border-amber-200/50'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              Track Requests
            </button>
            <button
              id="nav-link-dashboard"
              onClick={() => handleNav('dashboard')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentRoute === 'dashboard'
                  ? 'bg-amber-100/70 text-amber-950 font-bold border border-amber-300/60'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-amber-700" />
              Intelligence Hub
            </button>
            <button
              id="nav-link-recommendations"
              onClick={() => handleNav('recommendations')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentRoute === 'recommendations'
                  ? 'bg-amber-100/70 text-amber-950 font-bold border border-amber-300/60'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-600" />
              AI Projects
            </button>
            <button
              id="nav-link-admin"
              onClick={() => handleNav('admin')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentRoute === 'admin'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/40'
              }`}
            >
              Admin
            </button>
          </nav>

          {/* Right Action Section */}
          <div className="flex items-center gap-2.5">
            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                id="lang-dropdown-btn"
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 hover:border-amber-300 bg-white hover:bg-amber-50/40 text-slate-700 text-xs font-semibold shadow-2xs transition-colors"
                title="Change language"
              >
                <Globe className="w-3.5 h-3.5 text-amber-600" />
                <span>{currentLangObj.nativeName}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {langDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-amber-100 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onClick={() => setLangDropdownOpen(false)}
                >
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                    Select Language / भाषा
                  </div>
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setSelectedLanguage(lang.code as LanguageCode)}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                        selectedLanguage === lang.code
                          ? 'bg-amber-50 text-amber-800 font-bold'
                          : 'text-slate-700 hover:bg-amber-50/40'
                      }`}
                    >
                      <span className="font-medium">{lang.nativeName}</span>
                      <span className="text-[11px] text-slate-400">{lang.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Primary Action Buttons */}
            <button
              id="cta-report-issue"
              onClick={() => handleNav('citizen')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs sm:text-sm font-semibold shadow-xs shadow-amber-900/20 hover:shadow-md transition-all active:scale-[0.98]"
            >
              <Mic className="w-4 h-4 text-amber-200" />
              <span>Report an Issue</span>
            </button>

            <button
              id="cta-dashboard"
              onClick={() => handleNav('dashboard')}
              className="hidden md:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold shadow-xs hover:shadow-md transition-all active:scale-[0.98]"
            >
              <BarChart3 className="w-4 h-4 text-amber-400" />
              <span>Policymaker Portal</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              id="mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-amber-900 hover:bg-amber-50"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-amber-950/10 bg-white px-4 pt-3 pb-6 space-y-2 shadow-lg animate-in slide-in-from-top duration-200">
          <div className="grid grid-cols-2 gap-2 pb-2">
            <button
              onClick={() => handleNav('citizen')}
              className="w-full py-2.5 px-3 bg-gradient-to-r from-amber-600 to-amber-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Mic className="w-4 h-4 text-amber-200" />
              Report Issue
            </button>
            <button
              onClick={() => handleNav('dashboard')}
              className="w-full py-2.5 px-3 bg-slate-900 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs"
            >
              <BarChart3 className="w-4 h-4 text-amber-400" />
              Dashboard
            </button>
          </div>

          <div className="space-y-1">
            <button
              onClick={() => handleNav('home')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'home' ? 'bg-amber-50 text-amber-900 font-bold' : 'text-slate-700'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('how-it-works')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'how-it-works' ? 'bg-amber-50 text-amber-900 font-bold' : 'text-slate-700'
              }`}
            >
              How It Works
            </button>
            <button
              onClick={() => handleNav('citizen')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'citizen' ? 'bg-amber-100/70 text-amber-900 font-bold' : 'text-slate-700'
              }`}
            >
              Citizen Voice Portal
            </button>
            <button
              onClick={() => handleNav('requests')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'requests' ? 'bg-amber-50 text-amber-900 font-bold' : 'text-slate-700'
              }`}
            >
              Track My Requests
            </button>
            <button
              onClick={() => handleNav('dashboard')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'dashboard' ? 'bg-amber-100/70 text-amber-900 font-bold' : 'text-slate-700'
              }`}
            >
              Policymaker Dashboard & Map
            </button>
            <button
              onClick={() => handleNav('recommendations')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'recommendations' ? 'bg-amber-50 text-amber-900 font-bold' : 'text-slate-700'
              }`}
            >
              AI Project Recommendations
            </button>
            <button
              onClick={() => handleNav('admin')}
              className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentRoute === 'admin' ? 'bg-slate-100 text-slate-900 font-bold' : 'text-slate-700'
              }`}
            >
              Platform Administration
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

export const Footer: React.FC = () => {
  const { setCurrentRoute } = useDepioro();

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-amber-950/20 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-slate-800">
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-700 to-amber-500 flex items-center justify-center text-white shadow-md shadow-amber-900/30">
                <Brain className="w-4 h-4" />
              </div>
              <span className="text-xl font-bold text-white tracking-tight">
                Depioro<span className="text-amber-400">.ai</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              From Citizen Voice to Development Intelligence. An AI-powered multilingual platform converting local grievances into structured policy decisions across India.
            </p>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>National Civic GovTech Prototype</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">
              Citizen Services
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => setCurrentRoute('citizen')} className="hover:text-amber-300 transition-colors">
                  🎙️ Speak Your Issue (Voice)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRoute('citizen')} className="hover:text-amber-300 transition-colors">
                  ✍️ Text Issue Reporting
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRoute('requests')} className="hover:text-amber-300 transition-colors">
                  📍 Track Request Status
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRoute('how-it-works')} className="hover:text-amber-300 transition-colors">
                  ❓ How Voice AI Works
                </button>
              </li>
            </ul>
          </div>

          {/* Policymaker Links */}
          <div>
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">
              Government Intelligence
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => setCurrentRoute('dashboard')} className="hover:text-amber-300 transition-colors">
                  📊 District Demand Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRoute('dashboard')} className="hover:text-amber-300 transition-colors">
                  🗺️ Madhya Pradesh Hotspot Map
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRoute('recommendations')} className="hover:text-amber-300 transition-colors">
                  ✨ AI Project Recommendations
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentRoute('admin')} className="hover:text-amber-300 transition-colors">
                  ⚙️ System Throughput & Latency
                </button>
              </li>
            </ul>
          </div>

          {/* Transparency & AI Notice */}
          <div>
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-3">
              Institutional Framework
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              Depioro.ai is built to empower District Magistrates, Gram Panchayats, and State Planning Boards with transparent, clustered data directly from grassroots voices.
            </p>
            <div className="p-2.5 rounded-lg bg-slate-900 border border-amber-950/40 text-[10px] text-slate-400">
              <strong className="text-amber-200">GovTech MVP Notice:</strong> Illustrated with sample Indian civic datasets. AI-assisted prioritization — final sanctioning rests with authorized officers.
            </div>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-500">
          <p>© 2026 Depioro.ai. Built with AI Studio for Indian Public Infrastructure.</p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Supported in 10+ Indian Languages</span>
            <span>•</span>
            <span>Zero Data Monopolies</span>
            <span>•</span>
            <span>Open Civic Architecture</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
