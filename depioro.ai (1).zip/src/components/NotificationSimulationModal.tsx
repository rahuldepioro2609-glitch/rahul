import React, { useState } from 'react';
import {
  MessageSquare,
  Smartphone,
  CheckCircle2,
  Clock,
  Send,
  Volume2,
  Copy,
  Check,
  Languages,
  ShieldCheck,
  Sparkles,
  X,
  ExternalLink,
  ChevronRight,
  UserCheck,
  FileText,
  AlertTriangle,
  Play,
  RotateCcw,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CitizenRequest, RequestStatus } from '../types';
import { AdvancedAnimatedIcon } from './AdvancedAnimatedIcon';

interface NotificationSimulationModalProps {
  request: CitizenRequest;
  isOpen: boolean;
  onClose: () => void;
}

type ChannelType = 'whatsapp' | 'sms';
type LanguageType = 'hi' | 'en' | 'bundelkhandi';

interface NotificationMessage {
  stage: RequestStatus;
  timestamp: string;
  sender: string;
  hiText: string;
  enText: string;
  bundelkhandiText: string;
  actionRequired?: string;
  trackingLink: string;
}

export const NotificationSimulationModal: React.FC<NotificationSimulationModalProps> = ({
  request,
  isOpen,
  onClose,
}) => {
  const [channel, setChannel] = useState<ChannelType>('whatsapp');
  const [language, setLanguage] = useState<LanguageType>('hi');
  const [activeStageIndex, setActiveStageIndex] = useState<number>(() => {
    const stages: RequestStatus[] = [
      'Submitted',
      'AI Analysed',
      'Clustered',
      'Under Review',
      'Development Planning',
      'Resolved',
    ];
    const idx = stages.indexOf(request.status);
    return idx >= 0 ? idx : 2;
  });
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isSimulatingSend, setIsSimulatingSend] = useState<boolean>(false);
  const [simulatedSentAlert, setSimulatedSentAlert] = useState<string | null>(null);

  if (!isOpen) return null;

  const refId = request.id;
  const citizenName = request.citizenName || 'Nagarik Ji';
  const district = request.district;
  const village = request.cityVillageWard;
  const category = request.category;

  const messages: NotificationMessage[] = [
    {
      stage: 'Submitted',
      timestamp: '10:14 AM • Day 1',
      sender: 'DEPIORO-GOV / MP-JANSEVA',
      enText: `Namaste ${citizenName}! Your civic demand for [${category}] at ${village}, ${district} has been registered successfully.
Ref ID: ${refId}.
Status: AI Intake & Geo-tagging in progress. Track: https://depioro.mp.gov.in/t/${refId}`,
      hiText: `नमस्ते ${citizenName} जी! ${village}, ${district} में [${category}] संबंधी आपकी मांग सफलतापूर्वक दर्ज कर ली गई है।
संदर्भ क्रमांक (Ref ID): ${refId}
स्थिति: AI सत्यापन एवं भू-स्थानिक अंकन प्रक्रियाधीन है। ट्रैकिंग लिंक: https://depioro.mp.gov.in/t/${refId}`,
      bundelkhandiText: `राम-राम ${citizenName} जी! ${village}, ${district} में [${category}] की अर्जी दर्ज हो गई है।
आईडी नंबर: ${refId}
अबै ईको AI द्वारा जांचो जा रओ है। https://depioro.mp.gov.in/t/${refId}`,
      trackingLink: `https://depioro.mp.gov.in/t/${refId}`,
    },
    {
      stage: 'AI Analysed',
      timestamp: '10:15 AM • Day 1 (1 min later)',
      sender: 'DEPIORO-AI-ENGINE',
      enText: `AI Analysis Complete: Your request "${request.title}" has been verified with ${request.aiConfidence}% confidence and tagged as ${request.priority} Priority.
Assigned Scheme: ${request.matchedScheme || 'State Infrastructure Fund'}.`,
      hiText: `AI विश्लेषण पूर्ण: आपके आवेदन "${request.title}" को ${request.aiConfidence}% विश्वसनीयता के साथ सत्यापित किया गया है और ${request.priority} प्राथमिकता श्रेणी दी गई है।
संबद्ध योजना: ${request.matchedScheme || 'राज्य अवसंरचना विकास निधि'}।`,
      bundelkhandiText: `AI जांच पूरी भई: आपकी अर्जी को ${request.priority} प्राथमिकता में राखो गओ है (${request.aiConfidence}% सही)।
सरकारी योजना: ${request.matchedScheme || 'मध्य प्रदेश विकास योजना'} से जोड़ो गओ।`,
      trackingLink: `https://depioro.mp.gov.in/t/${refId}`,
    },
    {
      stage: 'Clustered',
      timestamp: '02:30 PM • Day 2',
      sender: 'DEPIORO-CLUSTER',
      enText: `Collective Impact Update: ${request.similarNearbyCount.toLocaleString()} similar civic demands identified in ${district}.
Your issue is now part of the Priority Cluster "${category} Need in ${district}". Stronger collective weight!`,
      hiText: `सामूहिक प्रभाव अपडेट: ${district} क्षेत्र में ${request.similarNearbyCount.toLocaleString()} नागरिकों की ऐसी ही मांगें चिन्हित हुई हैं।
आपकी समस्या अब "${district} ${category} क्लस्टर" का मुख्य हिस्सा बन चुकी है। सामूहिक मांग के तहत त्वरित कार्यवाही होगी!`,
      bundelkhandiText: `बड़ी खबर: ${district} में आप जैसे ${request.similarNearbyCount.toLocaleString()} लोगों ने भी यही समस्या बताई है।
सबकी अर्जी मिलाकर बड़ा क्लस्टर बना दओ गओ है ताकि जल्द काम शुरू होय।`,
      trackingLink: `https://depioro.mp.gov.in/t/${refId}`,
    },
    {
      stage: 'Under Review',
      timestamp: '11:00 AM • Day 4',
      sender: 'MP-COLLECTORATE',
      enText: `Administrative Review: District Collectorate (${district}) and Department Officers have initiated field verification and DPR preparation.
Officer Contact: Shri R. K. Sharma (Executive Engineer).`,
      hiText: `प्रशासनिक समीक्षा: जिला कलेक्ट्रेट (${district}) एवं संबंधित विभागीय अधिकारियों द्वारा स्थल निरीक्षण एवं विस्तृत कार्ययोजना (DPR) तैयार करने का निर्देश दिया गया है।
प्रभारी अधिकारी: श्री आर. के. शर्मा (कार्यपालन यंत्री)।`,
      bundelkhandiText: `सरकारी मुआयना: ${district} के कलेक्ट्रेट और इंजीनियर साहिब ने मौका मुआयना शुरू कर दओ है।
काम की फाइल आगे बढ़ गई है।`,
      trackingLink: `https://depioro.mp.gov.in/t/${refId}`,
    },
    {
      stage: 'Development Planning',
      timestamp: '04:15 PM • Day 7',
      sender: 'MP-FINANCE-DEPT',
      enText: `Budget Approved: Estimated budget of ₹${((request.budgetEstimate || 450000) / 100000).toFixed(2)} Lakh allocated under ${request.matchedScheme || 'M.P. Vikas Nidhi'}.
Tendering / Work Order stage initiated. Work target: Next fiscal cycle.`,
      hiText: `बजट स्वीकृति: ${request.matchedScheme || 'म.प्र. विकास निधि'} के अंतर्गत ₹${((request.budgetEstimate || 450000) / 100000).toFixed(2)} लाख की अनुमानित वित्तीय स्वीकृति प्रदान कर दी गई है।
निविदा (Work Order) प्रक्रिया प्रारंभ।`,
      bundelkhandiText: `पैसा मंजूर: योजना के तहत ₹${((request.budgetEstimate || 450000) / 100000).toFixed(2)} लाख का बजट पास हो गओ है।
ठेका और काम की तैयारी चालू हो गई है।`,
      trackingLink: `https://depioro.mp.gov.in/t/${refId}`,
    },
    {
      stage: 'Resolved',
      timestamp: '05:00 PM • Day 14',
      sender: 'MP-JAN-SUNWAI-PORTAL',
      enText: `Work Complete & Verified! The ${category} civic demand (${refId}) has been successfully addressed on-site with photographic proof.
Please rate your citizen satisfaction: https://depioro.mp.gov.in/feedback/${refId}`,
      hiText: `कार्य पूर्ण एवं सत्यापित! ${village}, ${district} में आपकी ${category} मांग (${refId}) का कार्य धरातल पर पूर्ण कर दिया गया है।
कृपया अपनी संतुष्टि रेटिंग (Feedback) दर्ज करें: https://depioro.mp.gov.in/feedback/${refId}`,
      bundelkhandiText: `काम पूरा हो गओ! आपके गांव ${village} में ${category} का काम पूरा हो गओ है और फोटो भी आ गई है।
अपनी राय और रेटिंग जरूर देवें: https://depioro.mp.gov.in/feedback/${refId}`,
      trackingLink: `https://depioro.mp.gov.in/feedback/${refId}`,
    },
  ];

  const handleCopyText = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleSimulateInstantPush = (stageName: string) => {
    setIsSimulatingSend(true);
    setSimulatedSentAlert(null);
    setTimeout(() => {
      setIsSimulatingSend(false);
      setSimulatedSentAlert(`Dispatch Successful: ${channel.toUpperCase()} notification sent to ${request.contactNumber || '+91 98260 •••••'}`);
      setTimeout(() => setSimulatedSentAlert(null), 3500);
    }, 900);
  };

  const activeMessage = messages[activeStageIndex];

  const getMessageBody = (msg: NotificationMessage) => {
    if (language === 'hi') return msg.hiText;
    if (language === 'bundelkhandi') return msg.bundelkhandiText;
    return msg.enText;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl shadow-2xl border border-stone-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-700 via-amber-800 to-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AdvancedAnimatedIcon name="satellite-beacon" size="sm" />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                  Citizen SMS & WhatsApp Tracker
                </h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Live Dispatch Simulator
                </span>
              </div>
              <p className="text-xs text-amber-200/90 flex items-center gap-1.5 mt-0.5">
                <span>Request: <strong>{request.id}</strong></span>
                <span>•</span>
                <span>{request.cityVillageWard}, {request.district}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Controls Bar */}
        <div className="p-3 sm:p-4 bg-stone-50 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3">
          {/* Channel Selector */}
          <div className="flex items-center bg-stone-200/80 p-1 rounded-xl">
            <button
              onClick={() => setChannel('whatsapp')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                channel === 'whatsapp'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp Alert</span>
            </button>
            <button
              onClick={() => setChannel('sms')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                channel === 'sms'
                  ? 'bg-amber-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Gov SMS Gateway</span>
            </button>
          </div>

          {/* Multilingual Selector */}
          <div className="flex items-center gap-1.5">
            <Languages className="w-3.5 h-3.5 text-stone-500" />
            <span className="text-xs font-semibold text-slate-600">Language:</span>
            <div className="flex items-center bg-stone-200/80 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  language === 'hi'
                    ? 'bg-white text-amber-900 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                हिंदी (Hindi)
              </button>
              <button
                onClick={() => setLanguage('bundelkhandi')}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  language === 'bundelkhandi'
                    ? 'bg-white text-amber-900 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                बुंदेली (Regional)
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  language === 'en'
                    ? 'bg-white text-amber-900 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                English
              </button>
            </div>
          </div>
        </div>

        {/* Main Content: Phone Screen Simulator & Progression Timeline */}
        <div className="p-4 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-5 overflow-y-auto flex-1 bg-stone-100/60">
          {/* Left Column: Interactive Stage Stepper */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Select Lifecycle Stage
              </span>
              <span className="text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                Step {activeStageIndex + 1} of 6
              </span>
            </div>

            <div className="space-y-1.5">
              {messages.map((m, idx) => {
                const isSelected = activeStageIndex === idx;
                const isReached = idx <= messages.findIndex((x) => x.stage === request.status);

                return (
                  <button
                    key={m.stage}
                    type="button"
                    onClick={() => setActiveStageIndex(idx)}
                    className={`w-full text-left p-3 rounded-2xl transition-all border flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-amber-800 text-white border-amber-800 shadow-md ring-2 ring-amber-400/40'
                        : isReached
                        ? 'bg-white hover:bg-stone-50 border-stone-200 text-slate-800'
                        : 'bg-stone-50/80 hover:bg-white border-stone-200/80 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                          isSelected
                            ? 'bg-white text-amber-900 font-extrabold'
                            : isReached
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-stone-200 text-slate-500'
                        }`}
                      >
                        {idx + 1}
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-bold truncate leading-tight">
                          {m.stage}
                        </div>
                        <div
                          className={`text-[10px] truncate ${
                            isSelected ? 'text-amber-200' : 'text-slate-400'
                          }`}
                        >
                          {m.timestamp}
                        </div>
                      </div>
                    </div>

                    <ChevronRight
                      className={`w-4 h-4 shrink-0 ${
                        isSelected ? 'text-white' : 'text-stone-400'
                      }`}
                    />
                  </button>
                );
              })}
            </div>

            {/* Recipient Card */}
            <div className="p-3 bg-white rounded-2xl border border-stone-200 text-xs space-y-1">
              <div className="flex items-center justify-between text-slate-500 text-[10px]">
                <span>Registered Citizen Contact:</span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Aadhaar Linked
                </span>
              </div>
              <div className="font-bold text-slate-900 flex items-center justify-between">
                <span>{request.citizenName || 'Citizen User'}</span>
                <span className="font-mono text-slate-600">{request.contactNumber || '+91 98260 74120'}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Phone Screen Realistic Simulation */}
          <div className="md:col-span-7 flex flex-col">
            {/* Phone Bezel */}
            <div className="bg-slate-900 p-3 sm:p-4 rounded-3xl shadow-xl border-4 border-slate-800 flex-1 flex flex-col text-slate-900">
              {/* Phone Speaker & Camera Notch */}
              <div className="flex justify-center mb-2">
                <div className="w-20 h-3 bg-slate-950 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-slate-800 mr-2" />
                  <div className="w-6 h-1 bg-slate-800 rounded-full" />
                </div>
              </div>

              {/* Inside Screen */}
              <div className="bg-[#efeae2] rounded-2xl flex-1 flex flex-col overflow-hidden border border-stone-300">
                {/* Chat App Header */}
                <div
                  className={`p-3 text-white flex items-center justify-between ${
                    channel === 'whatsapp' ? 'bg-[#075e54]' : 'bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-white/20 border border-white/30 flex items-center justify-center font-bold text-xs">
                      {channel === 'whatsapp' ? 'MP' : 'GOV'}
                    </div>
                    <div>
                      <div className="text-xs font-bold leading-tight flex items-center gap-1">
                        <span>
                          {channel === 'whatsapp'
                            ? 'MP Jan Seva (Govt. of MP)'
                            : activeMessage.sender}
                        </span>
                        {channel === 'whatsapp' && (
                          <CheckCircle2 className="w-3 h-3 text-emerald-300 fill-emerald-300 inline" />
                        )}
                      </div>
                      <div className="text-[10px] text-emerald-100/80">
                        Official Citizen Dispatch Gateway
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono opacity-80">Online</span>
                </div>

                {/* Chat Message View Area */}
                <div className="p-3 sm:p-4 flex-1 space-y-3 overflow-y-auto flex flex-col justify-end">
                  {/* Date Stamp */}
                  <div className="text-center">
                    <span className="text-[9px] bg-white/80 px-2 py-0.5 rounded-full text-slate-600 font-medium shadow-2xs">
                      {activeMessage.timestamp}
                    </span>
                  </div>

                  {/* Active Message Bubble */}
                  <motion.div
                    key={`${activeStageIndex}-${language}-${channel}`}
                    initial={{ opacity: 0, y: 10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className={`max-w-[92%] rounded-2xl p-3 shadow-md relative text-left self-start ${
                      channel === 'whatsapp'
                        ? 'bg-white text-slate-900 rounded-tl-xs'
                        : 'bg-white text-slate-900 border border-stone-200 rounded-tl-xs'
                    }`}
                  >
                    {/* Channel Tag */}
                    <div className="flex items-center justify-between gap-2 border-b border-stone-100 pb-1 mb-1.5">
                      <span className="text-[9px] font-mono font-bold text-amber-800 uppercase">
                        {activeMessage.stage} Notice
                      </span>
                      <span className="text-[9px] text-slate-400 font-mono">
                        {activeMessage.timestamp.split('•')[0]}
                      </span>
                    </div>

                    {/* Body Text */}
                    <p className="text-xs leading-relaxed text-slate-800 whitespace-pre-line font-normal">
                      {getMessageBody(activeMessage)}
                    </p>

                    {/* Simulated Work / Tracking Card */}
                    <div className="mt-2.5 p-2 rounded-xl bg-amber-50/80 border border-amber-200/80 text-[11px] space-y-1">
                      <div className="flex items-center justify-between text-amber-900 font-bold">
                        <span>Official Gov Verification Token</span>
                        <span className="font-mono text-[10px]">#VERIFIED</span>
                      </div>
                      <div className="text-[10px] text-slate-600 truncate">
                        Tracking URL: <u>{activeMessage.trackingLink}</u>
                      </div>
                    </div>

                    {/* Bubble Footer & Copy Action */}
                    <div className="mt-2 pt-1 flex items-center justify-between text-[10px] text-slate-400">
                      <button
                        type="button"
                        onClick={() => handleCopyText(getMessageBody(activeMessage), activeStageIndex)}
                        className="text-amber-700 hover:text-amber-900 font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        {copiedIndex === activeStageIndex ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-700">Copied text!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy Message</span>
                          </>
                        )}
                      </button>

                      <div className="flex items-center gap-1 font-mono text-[9px]">
                        <span>Delivered</span>
                        <CheckCircle2 className="w-2.5 h-2.5 text-blue-500 fill-blue-500 inline" />
                      </div>
                    </div>
                  </motion.div>
                </div>

                {/* Bottom Test Push Bar */}
                <div className="p-2.5 bg-white border-t border-stone-200 flex items-center justify-between gap-2">
                  <div className="text-[11px] text-slate-500 truncate flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>Real-time webhook simulated</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSimulateInstantPush(activeMessage.stage)}
                    disabled={isSimulatingSend}
                    className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-amber-950 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isSimulatingSend ? (
                      <>
                        <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                        <span>Dispatching...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3 h-3 text-amber-300" />
                        <span>Simulate Push Alert</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Success Toast */}
            <AnimatePresence>
              {simulatedSentAlert && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="mt-2 p-2.5 rounded-xl bg-emerald-800 text-white text-xs font-semibold flex items-center justify-between shadow-md"
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                    <span>{simulatedSentAlert}</span>
                  </div>
                  <button onClick={() => setSimulatedSentAlert(null)}>
                    <X className="w-3 h-3 text-emerald-200" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Modal Footer Summary */}
        <div className="p-3 sm:p-4 bg-white border-t border-stone-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="text-slate-500 text-[11px]">
            Citizens receive transparent updates automatically whenever officers update the 6-stage lifecycle.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-slate-800 font-bold transition-colors cursor-pointer"
          >
            Close Tracker
          </button>
        </div>
      </motion.div>
    </div>
  );
};
