import React, { useState, useMemo } from 'react';
import {
  Clock,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Search,
  Filter,
  ArrowRight,
  Eye,
  Sparkles,
  Layers,
  ChevronRight,
  User,
  X,
  Tag,
  Hash,
  SlidersHorizontal,
  RotateCcw,
  Copy,
  Check,
  Building,
  TrendingUp,
  FileText,
  Map,
  List,
  Compass,
  MessageSquare,
  Smartphone,
  Send,
  Printer,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useDepioro } from '../context/DepioroContext';
import { CitizenRequest, IssueCategory, RequestStatus, UrgencyLevel } from '../types';
import { CircularProgressRing } from './CircularProgressRing';
import { CitizenRequestsMiniMap } from './CitizenRequestsMiniMap';
import { NotificationSimulationModal } from './NotificationSimulationModal';
import { PrintDossierHeader, PrintSignatureBlock } from './PrintDossierHeader';

const STATUS_STEPS: RequestStatus[] = [
  'Submitted',
  'AI Analysed',
  'Clustered',
  'Under Review',
  'Development Planning',
  'Resolved',
];

type SearchScope = 'all' | 'location' | 'id' | 'keyword';
type ViewMode = 'list' | 'map';

export const CitizenRequestTracking: React.FC = () => {
  const { requests, setInspectingRequest, setCurrentRoute } = useDepioro();

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [searchScope, setSearchScope] = useState<SearchScope>('all');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedKeyword, setSelectedKeyword] = useState<string>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // View Mode: List vs Spatial Mini-Map
  const [viewMode, setViewMode] = useState<ViewMode>('list');

  // SMS / WhatsApp Simulation Modal State
  const [simulatingReq, setSimulatingReq] = useState<CitizenRequest | null>(null);

  // Selected Request for detailed inspection
  const [selectedReqId, setSelectedReqId] = useState<string | null>(requests[0]?.id || null);

  // Extract unique districts with counts
  const districtStats = useMemo(() => {
    const counts: Record<string, number> = {};
    requests.forEach((r) => {
      counts[r.district] = (counts[r.district] || 0) + 1;
    });
    return counts;
  }, [requests]);

  // Extract all unique keywords with counts
  const keywordStats = useMemo(() => {
    const counts: Record<string, number> = {};
    requests.forEach((r) => {
      r.keywords?.forEach((kw) => {
        counts[kw] = (counts[kw] || 0) + 1;
      });
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15);
  }, [requests]);

  // Filter requests based on search term, scope, and all filter criteria
  const filteredRequests = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    return requests.filter((r) => {
      // 1. Text & Scope Matching
      let matchesSearch = true;
      if (query) {
        if (searchScope === 'id') {
          matchesSearch = r.id.toLowerCase().includes(query);
        } else if (searchScope === 'location') {
          matchesSearch =
            r.district.toLowerCase().includes(query) ||
            r.cityVillageWard.toLowerCase().includes(query) ||
            (r.state && r.state.toLowerCase().includes(query));
        } else if (searchScope === 'keyword') {
          const kwMatch = r.keywords?.some((k) => k.toLowerCase().includes(query));
          const titleMatch = r.title.toLowerCase().includes(query);
          const descMatch = r.description.toLowerCase().includes(query);
          const summaryMatch = r.aiSummary.toLowerCase().includes(query);
          matchesSearch = Boolean(kwMatch || titleMatch || descMatch || summaryMatch);
        } else {
          // 'all' scope
          const idMatch = r.id.toLowerCase().includes(query);
          const locMatch =
            r.district.toLowerCase().includes(query) ||
            r.cityVillageWard.toLowerCase().includes(query) ||
            (r.state && r.state.toLowerCase().includes(query));
          const kwMatch = r.keywords?.some((k) => k.toLowerCase().includes(query));
          const titleMatch = r.title.toLowerCase().includes(query);
          const descMatch = r.description.toLowerCase().includes(query);
          const summaryMatch = r.aiSummary.toLowerCase().includes(query);
          const transcriptMatch = r.originalVoiceTranscript?.toLowerCase().includes(query);
          matchesSearch = Boolean(idMatch || locMatch || kwMatch || titleMatch || descMatch || summaryMatch || transcriptMatch);
        }
      }

      // 2. Specific District Filter
      const matchesDistrict = selectedDistrict === 'All' || r.district === selectedDistrict;

      // 3. Specific Keyword Filter
      const matchesKeyword =
        selectedKeyword === 'All' ||
        r.keywords?.some((k) => k.toLowerCase() === selectedKeyword.toLowerCase());

      // 4. Category Filter
      const matchesCat = categoryFilter === 'All' || r.category === categoryFilter;

      // 5. Status Filter
      const matchesStatus = statusFilter === 'All' || r.status === statusFilter;

      // 6. Priority Filter
      const matchesPriority = priorityFilter === 'All' || r.priority === priorityFilter;

      return matchesSearch && matchesDistrict && matchesKeyword && matchesCat && matchesStatus && matchesPriority;
    });
  }, [
    requests,
    searchTerm,
    searchScope,
    selectedDistrict,
    selectedKeyword,
    categoryFilter,
    statusFilter,
    priorityFilter,
  ]);

  // Selected request object
  const selectedReq = useMemo(() => {
    return requests.find((r) => r.id === selectedReqId) || filteredRequests[0] || requests[0] || null;
  }, [requests, selectedReqId, filteredRequests]);

  const hasActiveFilters =
    searchTerm !== '' ||
    selectedDistrict !== 'All' ||
    selectedKeyword !== 'All' ||
    categoryFilter !== 'All' ||
    statusFilter !== 'All' ||
    priorityFilter !== 'All' ||
    searchScope !== 'all';

  const resetAllFilters = () => {
    setSearchTerm('');
    setSearchScope('all');
    setSelectedDistrict('All');
    setSelectedKeyword('All');
    setCategoryFilter('All');
    setStatusFilter('All');
    setPriorityFilter('All');
  };

  const copyRequestId = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getStatusIndex = (status: RequestStatus) => {
    return STATUS_STEPS.indexOf(status);
  };

  const getPlaceholderText = () => {
    switch (searchScope) {
      case 'location':
        return 'Filter by District, Village, Ward, or State (e.g. Shivpuri, Pohari, Gwalior)...';
      case 'id':
        return 'Filter by exact or partial Request ID (e.g. DEP-MP-2026-8912, 8912)...';
      case 'keyword':
        return 'Filter by specific keyword or topic (e.g. Handpump, Potholes, PHC, Transformer)...';
      case 'all':
      default:
        return 'Search by Location (District/Village), Request ID, or Specific Keyword...';
    }
  };

  const handlePrintRequestsDossier = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 print:p-0 print:m-0 print:max-w-none print:space-y-4">
      {/* Official Government Print Header */}
      <PrintDossierHeader
        title="Citizen Development Grievances & Telemetry Dossier"
        documentType="OFFICIAL CITIZEN REQUEST LOG & TRACKING AUDIT"
        documentRef={`DEPIORO/LOGS/2026/${selectedDistrict === 'All' ? 'MP-ALL' : selectedDistrict.toUpperCase().slice(0, 3)}-${filteredRequests.length}`}
        district={selectedDistrict === 'All' ? 'Statewide (All Districts)' : `${selectedDistrict} District`}
        state="Madhya Pradesh"
        classification="OFFICIAL • DISTRICT GRIEVANCE AUDIT"
      />

      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-xs font-semibold mb-1">
            <Clock className="w-3.5 h-3.5 text-amber-700" />
            <span>Citizen Grievance & Development Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Citizen Development Requests
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Real-time verification, multi-variable filtering, and 6-stage progression lifecycle for district administrators.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* View Mode Toggle: List vs Spatial Mini-Map */}
          <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 text-xs shadow-2xs">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List ({filteredRequests.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setViewMode('map')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'map'
                  ? 'bg-amber-700 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>Mini-Map Pins ({filteredRequests.length})</span>
            </button>
          </div>

          <button
            onClick={handlePrintRequestsDossier}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            title="Print or Export PDF of Citizen Requests"
          >
            <Printer className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Print Dossier</span>
          </button>

          <button
            onClick={() => setCurrentRoute('citizen')}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs sm:text-sm font-semibold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span>+ Submit New Request</span>
          </button>
        </div>
      </div>

      {/* ADVANCED SEARCH & FILTER PANEL */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-stone-200 space-y-4">
        {/* Search Bar Input Row */}
        <div className="space-y-3">
          <div className="relative flex items-center">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4 text-amber-700" />
            </div>

            <input
              id="citizen-request-search-input"
              type="text"
              placeholder={getPlaceholderText()}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-10 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 placeholder:text-slate-400 bg-stone-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all font-medium"
            />

            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Search Mode Quick Selector Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-b border-stone-100 pb-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1">
                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" /> Search Mode:
              </span>

              <button
                type="button"
                onClick={() => setSearchScope('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  searchScope === 'all'
                    ? 'bg-slate-900 text-amber-400 shadow-2xs'
                    : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                }`}
              >
                All Fields
              </button>

              <button
                type="button"
                onClick={() => setSearchScope('location')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer ${
                  searchScope === 'location'
                    ? 'bg-amber-700 text-white shadow-2xs'
                    : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                }`}
              >
                <MapPin className="w-3 h-3" />
                <span>Location Only</span>
              </button>

              <button
                type="button"
                onClick={() => setSearchScope('id')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer ${
                  searchScope === 'id'
                    ? 'bg-amber-700 text-white shadow-2xs'
                    : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                }`}
              >
                <Hash className="w-3 h-3" />
                <span>Request ID</span>
              </button>

              <button
                type="button"
                onClick={() => setSearchScope('keyword')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer ${
                  searchScope === 'keyword'
                    ? 'bg-amber-700 text-white shadow-2xs'
                    : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                }`}
              >
                <Tag className="w-3 h-3" />
                <span>Specific Keywords</span>
              </button>
            </div>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetAllFilters}
                className="text-xs font-semibold text-amber-700 hover:text-amber-900 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset All Filters</span>
              </button>
            )}
          </div>
        </div>

        {/* 4 Multi-Select Dropdowns Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Location / District Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-amber-700" />
              <span>District / Location</span>
            </label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-stone-50/70 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
            >
              <option value="All">All Districts ({requests.length})</option>
              {Object.entries(districtStats).map(([dist, count]) => (
                <option key={dist} value={dist}>
                  {dist} ({count} {count === 1 ? 'request' : 'requests'})
                </option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1 flex items-center gap-1">
              <Building className="w-3 h-3 text-amber-700" />
              <span>Issue Category</span>
            </label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-stone-50/70 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
            >
              <option value="All">All Categories / सभी श्रेणियां</option>
              <option value="Water">Water Infrastructure</option>
              <option value="Roads">Roads & Connectivity</option>
              <option value="Healthcare">Primary Healthcare</option>
              <option value="Education">Public Education</option>
              <option value="Electricity">Electricity & Grid</option>
              <option value="Sanitation">Sanitation & Waste</option>
              <option value="Transport">Transport & Mobility</option>
              <option value="Agriculture">Agriculture Support</option>
              <option value="Other">Other Issues</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1 flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-700" />
              <span>Lifecycle Status</span>
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-stone-50/70 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
            >
              <option value="All">All Statuses / सभी स्थिति</option>
              {STATUS_STEPS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* Urgency / Priority Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-amber-700" />
              <span>Priority Level</span>
            </label>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-stone-50/70 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
            >
              <option value="All">All Priorities / सभी प्राथमिकता</option>
              <option value="Critical">Critical Urgency</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>
          </div>
        </div>

        {/* Popular Civic Keyword Tags Quick Pill Cloud */}
        <div className="pt-2 border-t border-stone-100 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1 mr-1">
            <Tag className="w-3 h-3 text-amber-700" /> Quick Keyword Filters:
          </span>

          <button
            type="button"
            onClick={() => setSelectedKeyword('All')}
            className={`text-[11px] font-semibold px-2 py-0.5 rounded-full transition-all cursor-pointer ${
              selectedKeyword === 'All'
                ? 'bg-amber-100 text-amber-900 border border-amber-300 font-bold'
                : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
            }`}
          >
            All Keywords
          </button>

          {keywordStats.map(([kw, count]) => {
            const isKwActive = selectedKeyword.toLowerCase() === kw.toLowerCase();
            return (
              <button
                key={kw}
                type="button"
                onClick={() => setSelectedKeyword(isKwActive ? 'All' : kw)}
                className={`text-[11px] font-semibold px-2 py-0.5 rounded-full transition-all flex items-center gap-1 cursor-pointer ${
                  isKwActive
                    ? 'bg-amber-700 text-white shadow-2xs'
                    : 'bg-amber-50/80 text-amber-900 border border-amber-200/80 hover:bg-amber-100'
                }`}
              >
                <span>{kw}</span>
                <span className={`text-[9px] px-1 rounded-full ${isKwActive ? 'bg-amber-900 text-amber-200' : 'bg-amber-200/70 text-amber-900'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Filters Summary Strip */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-xs border-t border-stone-100 text-slate-600">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-slate-900">
              Showing <span className="text-amber-800 font-bold">{filteredRequests.length}</span> of {requests.length} requests
            </span>

            {/* Active Pills */}
            {searchTerm && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                Search: “{searchTerm}” ({searchScope})
                <X className="w-3 h-3 cursor-pointer hover:text-red-700" onClick={() => setSearchTerm('')} />
              </span>
            )}

            {selectedDistrict !== 'All' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                District: {selectedDistrict}
                <X className="w-3 h-3 cursor-pointer hover:text-red-700" onClick={() => setSelectedDistrict('All')} />
              </span>
            )}

            {selectedKeyword !== 'All' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                Keyword: {selectedKeyword}
                <X className="w-3 h-3 cursor-pointer hover:text-red-700" onClick={() => setSelectedKeyword('All')} />
              </span>
            )}

            {categoryFilter !== 'All' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                Category: {categoryFilter}
                <X className="w-3 h-3 cursor-pointer hover:text-red-700" onClick={() => setCategoryFilter('All')} />
              </span>
            )}

            {statusFilter !== 'All' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                Status: {statusFilter}
                <X className="w-3 h-3 cursor-pointer hover:text-red-700" onClick={() => setStatusFilter('All')} />
              </span>
            )}

            {priorityFilter !== 'All' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-medium text-[11px]">
                Priority: {priorityFilter}
                <X className="w-3 h-3 cursor-pointer hover:text-red-700" onClick={() => setPriorityFilter('All')} />
              </span>
            )}
          </div>

          <div className="text-[11px] text-slate-500">
            Click any request card to inspect timeline and AI extraction
          </div>
        </div>
      </div>

      {/* REQUESTS LIST / MINI-MAP & DETAILED INSPECTOR GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: List of Requests OR Spatial Mini-Map */}
        <div className="lg:col-span-6 space-y-3">
          {/* Sub-header with live count & view toggle */}
          <div className="flex items-center justify-between pb-1 px-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-tight flex items-center gap-1.5">
                {viewMode === 'list' ? (
                  <>
                    <List className="w-3.5 h-3.5 text-amber-700" />
                    <span>Filtered Requests Feed</span>
                  </>
                ) : (
                  <>
                    <MapPin className="w-3.5 h-3.5 text-amber-700" />
                    <span>Spatial Mini-Map Pins</span>
                  </>
                )}
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-stone-200 text-slate-800 font-bold">
                {filteredRequests.length} {filteredRequests.length === 1 ? 'item' : 'items'}
              </span>
            </div>

            {/* Quick Segmented Toggle */}
            <div className="flex items-center bg-stone-100 p-0.5 rounded-lg border border-stone-200 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all flex items-center gap-1 cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-white text-slate-900 shadow-2xs font-bold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="View requests as a list"
              >
                <List className="w-3 h-3" />
                <span>List</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('map')}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all flex items-center gap-1 cursor-pointer ${
                  viewMode === 'map'
                    ? 'bg-amber-700 text-white shadow-2xs font-bold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="View requests as pins on a mini-map"
              >
                <MapPin className="w-3 h-3" />
                <span>Mini-Map</span>
              </button>
            </div>
          </div>

          {viewMode === 'map' ? (
            /* MINI-MAP VIEW */
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.2 }}
            >
              <CitizenRequestsMiniMap
                requests={filteredRequests}
                selectedRequestId={selectedReq?.id || null}
                onSelectRequest={(req) => setSelectedReqId(req.id)}
                selectedDistrict={selectedDistrict}
                onDistrictSelect={(dist) => setSelectedDistrict(dist)}
              />
            </motion.div>
          ) : (
            /* LIST VIEW */
            filteredRequests.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-2xl p-8 text-center border border-stone-200 text-slate-500 space-y-4 shadow-xs"
              >
                <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mx-auto">
                  <Search className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-900">No matching citizen requests found</h3>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    No requests matched your query “{searchTerm}” with the active filters. Try searching for a different district (e.g., Shivpuri, Gwalior), Request ID, or reset filters.
                  </p>
                </div>

                <div className="pt-2 flex justify-center gap-2">
                  <button
                    onClick={resetAllFilters}
                    className="px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                  >
                    Clear All Search Filters
                  </button>
                </div>
              </motion.div>
            ) : (
              filteredRequests.map((req) => {
                const isSelected = selectedReq?.id === req.id;
                return (
                  <div
                    key={req.id}
                    onClick={() => setSelectedReqId(req.id)}
                    className={`cursor-pointer rounded-2xl p-4 sm:p-5 transition-all border ${
                      isSelected
                        ? 'bg-amber-50/80 border-amber-500 shadow-md ring-1 ring-amber-500'
                        : 'bg-white hover:bg-stone-50/90 border-stone-200 shadow-2xs'
                    }`}
                  >
                    {/* Top Bar: ID, Priority, Copy, and Status */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={(e) => copyRequestId(req.id, e)}
                            title="Click to copy Request ID"
                            className="font-mono text-xs font-bold text-amber-900 bg-amber-100/90 hover:bg-amber-200/80 px-2 py-0.5 rounded-md border border-amber-300 flex items-center gap-1 transition-colors"
                          >
                            <span>{req.id}</span>
                            {copiedId === req.id ? (
                              <Check className="w-3 h-3 text-emerald-700" />
                            ) : (
                              <Copy className="w-2.5 h-2.5 text-amber-700 opacity-60" />
                            )}
                          </button>

                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              req.priority === 'Critical'
                                ? 'bg-red-100 text-red-700'
                                : req.priority === 'High'
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-amber-50 text-amber-800'
                            }`}
                          >
                            {req.priority} Priority
                          </span>

                          <span className="text-[10px] font-semibold text-slate-500">
                            {req.category}
                          </span>
                        </div>

                        <h3 className="text-sm font-bold text-slate-900 line-clamp-1 mt-1">{req.title}</h3>
                      </div>

                      <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-slate-900 text-white whitespace-nowrap shrink-0 shadow-2xs">
                        {req.status}
                      </span>
                    </div>

                    {/* Description */}
                    <p className="text-xs text-slate-600 line-clamp-2 mt-2 leading-relaxed">
                      {req.description}
                    </p>

                    {/* Extracted Keywords Pills */}
                    {req.keywords && req.keywords.length > 0 && (
                      <div className="mt-2.5 flex flex-wrap gap-1">
                        {req.keywords.slice(0, 4).map((kw) => {
                          const isKwMatch =
                            (searchTerm && kw.toLowerCase().includes(searchTerm.toLowerCase())) ||
                            selectedKeyword.toLowerCase() === kw.toLowerCase();
                          return (
                            <button
                              key={kw}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedKeyword(kw);
                              }}
                              className={`text-[10px] font-medium px-2 py-0.5 rounded-md transition-colors ${
                                isKwMatch
                                  ? 'bg-amber-700 text-white font-bold'
                                  : 'bg-stone-100 text-slate-600 hover:bg-amber-100 hover:text-amber-900'
                              }`}
                            >
                              #{kw}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Card Footer: Location, Meta, and Locate on Map CTA */}
                    <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-slate-500">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedDistrict(req.district);
                        }}
                        className="flex items-center gap-1 text-slate-700 hover:text-amber-800 font-medium transition-colors"
                        title="Filter by this district"
                      >
                        <MapPin className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        <span className="underline underline-offset-2 decoration-amber-300">
                          {req.cityVillageWard}, {req.district}
                        </span>
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSimulatingReq(req);
                          }}
                          className="text-[10px] font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-200/80 flex items-center gap-1 transition-colors cursor-pointer"
                          title="Simulate WhatsApp / SMS citizen alerts"
                        >
                          <MessageSquare className="w-3 h-3 text-emerald-600" />
                          <span>SMS/WhatsApp</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReqId(req.id);
                            setViewMode('map');
                          }}
                          className="text-[10px] font-semibold text-amber-700 hover:text-amber-900 flex items-center gap-1 hover:underline cursor-pointer"
                          title="View this request pin on the mini-map"
                        >
                          <Compass className="w-3 h-3" />
                          <span>Pin on Map</span>
                        </button>
                        <span className="font-mono text-slate-400">{req.submittedAt}</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )
          )}
        </div>

        {/* Right Detail & 6-Stage Timeline Inspector */}
        <div className="lg:col-span-6">
          {selectedReq ? (
            <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-sm border border-stone-200 space-y-6 sticky top-20">
              {/* Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => copyRequestId(selectedReq.id)}
                      className="font-mono text-sm font-extrabold text-amber-900 bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-lg border border-amber-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <span>{selectedReq.id}</span>
                      {copiedId === selectedReq.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                      ) : (
                        <Copy className="w-3 h-3 text-amber-700" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setSimulatingReq(selectedReq)}
                      className="text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Open Citizen SMS & WhatsApp Notification Simulator"
                    >
                      <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Citizen SMS/WhatsApp Alerts</span>
                    </button>
                    <span className="text-xs font-semibold text-slate-500">
                      {selectedReq.submittedAt}
                    </span>
                  </div>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 mt-1">
                    {selectedReq.title}
                  </h2>
                </div>

                <span
                  className={`text-xs font-bold px-3 py-1 rounded-full ${
                    selectedReq.priority === 'Critical'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-amber-100 text-amber-900'
                  }`}
                >
                  {selectedReq.priority} Urgency
                </span>
              </div>

              {/* Citizen Original Voice / Description */}
              <div className="space-y-2 text-xs">
                <span className="font-bold text-slate-700 uppercase tracking-wider block text-[10px]">
                  Original Citizen Report ({selectedReq.language})
                </span>
                <p className="text-slate-700 bg-stone-50 p-3.5 rounded-xl border border-stone-200 leading-relaxed font-sans">
                  {selectedReq.description}
                </p>
                {selectedReq.originalVoiceTranscript && (
                  <div className="text-[11px] text-amber-900/90 bg-amber-50/60 p-2.5 rounded-lg border border-amber-200/80 italic">
                    <strong className="not-italic text-amber-950">Spoken Audio Transcript:</strong> “{selectedReq.originalVoiceTranscript}”
                  </div>
                )}
              </div>

              {/* Extracted Keywords */}
              {selectedReq.keywords && selectedReq.keywords.length > 0 && (
                <div className="space-y-1.5">
                  <span className="font-bold text-slate-700 uppercase tracking-wider block text-[10px] flex items-center gap-1">
                    <Tag className="w-3 h-3 text-amber-700" /> AI Extracted Keywords (Click to Filter)
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedReq.keywords.map((kw) => (
                      <button
                        key={kw}
                        type="button"
                        onClick={() => setSelectedKeyword(kw)}
                        className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 hover:bg-amber-200/80 border border-amber-300 transition-colors cursor-pointer"
                      >
                        #{kw}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 6-STAGE TIMELINE SECTION */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Request Progression Timeline
                </h4>

                <div className="relative pl-6 space-y-4 border-l-2 border-stone-200 ml-2">
                  {STATUS_STEPS.map((step, idx) => {
                    const currentIndex = getStatusIndex(selectedReq.status);
                    const isCompleted = idx <= currentIndex;
                    const isCurrent = idx === currentIndex;

                    return (
                      <div key={step} className="relative group">
                        {/* Dot indicator */}
                        <div
                          className={`absolute -left-[31px] top-0.5 w-4 h-4 rounded-full border-2 transition-all flex items-center justify-center ${
                            isCurrent
                              ? 'bg-amber-600 border-amber-200 ring-4 ring-amber-100'
                              : isCompleted
                              ? 'bg-emerald-500 border-emerald-300 text-white'
                              : 'bg-white border-slate-300'
                          }`}
                        >
                          {isCompleted && !isCurrent && <CheckCircle2 className="w-3 h-3 text-white" />}
                        </div>

                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-xs font-bold ${
                                isCurrent
                                  ? 'text-amber-800 font-extrabold'
                                  : isCompleted
                                  ? 'text-slate-900'
                                  : 'text-slate-400'
                              }`}
                            >
                              {step}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full animate-pulse">
                                Active Stage
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 leading-tight">
                            {idx === 0 && 'Citizen recorded request in ' + selectedReq.language}
                            {idx === 1 && `Gemini AI verified ${selectedReq.aiConfidence}% confidence and extracted keywords`}
                            {idx === 2 && `Grouped with ${selectedReq.similarNearbyCount} nearby reports in ${selectedReq.district}`}
                            {idx === 3 && 'District Officer and Executive Engineer assigned for site verification'}
                            {idx === 4 && 'DPR and scheme budget alignment approved by Planning Committee'}
                            {idx === 5 && 'Remediation completed and verified with local citizens'}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* AI Analysis Summary Box */}
              <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-700 font-bold">
                  <span className="flex items-center gap-1.5 text-amber-800">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" /> Depioro AI Intelligence
                  </span>
                  <div className="flex items-center gap-2">
                    <CircularProgressRing
                      value={selectedReq.aiConfidence}
                      size="xs"
                      variant="goldwood"
                      id={`track-req-ring-${selectedReq.id}`}
                      showLabel={false}
                    />
                    <span className="text-amber-900 font-semibold font-mono text-[11px]">
                      {selectedReq.aiConfidence}% Confidence
                    </span>
                  </div>
                </div>
                <p className="text-slate-700 italic">“{selectedReq.aiSummary}”</p>
                <div className="pt-2 border-t border-stone-200/80 text-[11px] text-slate-600">
                  <strong>Suggested Policy Action:</strong> {selectedReq.suggestedIntervention}
                </div>
              </div>

              {/* Location & Meta info */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedDistrict(selectedReq.district)}
                  className="p-3 bg-stone-50 hover:bg-amber-50/60 text-left rounded-xl border border-stone-100 transition-colors"
                  title="Filter all requests in this district"
                >
                  <span className="text-slate-400 text-[10px] block">Location (Click to filter)</span>
                  <strong className="text-slate-800 font-bold block truncate">
                    {selectedReq.cityVillageWard}, {selectedReq.district}
                  </strong>
                </button>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-100">
                  <span className="text-slate-400 text-[10px] block">Clustered Demand</span>
                  <strong className="text-amber-800 font-bold block">
                    {selectedReq.similarNearbyCount.toLocaleString()} similar nearby
                  </strong>
                </div>
              </div>

              {/* View in Dashboard and Mini-Map Buttons */}
              <div className="pt-1 space-y-2">
                {viewMode === 'list' && (
                  <button
                    type="button"
                    onClick={() => setViewMode('map')}
                    className="w-full py-2.5 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
                  >
                    <Compass className="w-4 h-4 text-amber-200" />
                    <span>Focus Pin on Spatial Mini-Map</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setCurrentRoute('dashboard')}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-amber-950 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
                >
                  <Layers className="w-4 h-4 text-yellow-400" />
                  <span>Inspect in Policymaker Intelligence Dashboard</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-8 text-center border border-stone-200 text-slate-400">
              Select a request from the list to view its progression timeline.
            </div>
          )}
        </div>
      </div>

      {/* Official Signature Block for Printed Request Dossier */}
      <PrintSignatureBlock
        preparedBy="Depioro Citizen Intake & Grievance Telemetry Division"
        reviewedBy="District Public Grievance Officer / Nodal Officer"
        sanctioningAuthority="District Collector & District Magistrate"
      />

      {/* Citizen SMS & WhatsApp Notification Simulation Modal */}
      {simulatingReq && (
        <NotificationSimulationModal
          request={simulatingReq}
          isOpen={!!simulatingReq}
          onClose={() => setSimulatingReq(null)}
        />
      )}
    </div>
  );
};

