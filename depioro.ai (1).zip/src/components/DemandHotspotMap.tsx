import React, { useState } from 'react';
import {
  MapPin,
  Sparkles,
  AlertTriangle,
  Users,
  TrendingUp,
  Layers,
  ArrowRight,
  Maximize2,
  Filter,
  BarChart2,
  Droplet,
  Car,
  HeartPulse,
  Trash2,
  Zap,
} from 'lucide-react';
import { useDepioro } from '../context/DepioroContext';
import { DemandHotspot, UrgencyLevel } from '../types';

export const DemandHotspotMap: React.FC<{ onInspectHotspot?: (h: DemandHotspot) => void }> = ({
  onInspectHotspot,
}) => {
  const { hotspots, selectedDistrict, setSelectedDistrict, setCurrentRoute, setSelectedRecommendation, recommendations } =
    useDepioro();

  const [activeHotspot, setActiveHotspot] = useState<DemandHotspot>(
    hotspots.find((h) => h.district === 'Shivpuri') || hotspots[0]
  );
  const [severityFilter, setSeverityFilter] = useState<string>('All');
  const [mapViewMode, setMapViewMode] = useState<'heat' | 'pins' | 'clusters'>('pins');

  const filteredHotspots = hotspots.filter((h) => {
    const matchesDistrict = selectedDistrict === 'All' || h.district === selectedDistrict;
    const matchesSeverity = severityFilter === 'All' || h.severity === severityFilter;
    return matchesDistrict && matchesSeverity;
  });

  const getSeverityBg = (sev: UrgencyLevel) => {
    switch (sev) {
      case 'Critical':
        return 'bg-red-500 text-white ring-red-300';
      case 'High':
        return 'bg-amber-500 text-white ring-amber-300';
      case 'Medium':
        return 'bg-yellow-500 text-slate-900 ring-yellow-300';
      default:
        return 'bg-emerald-500 text-white ring-emerald-300';
    }
  };

  const getSeverityBorder = (sev: UrgencyLevel) => {
    switch (sev) {
      case 'Critical':
        return 'border-red-500 bg-red-50 text-red-700';
      case 'High':
        return 'border-amber-500 bg-amber-50 text-amber-700';
      case 'Medium':
        return 'border-yellow-500 bg-yellow-50 text-yellow-800';
      default:
        return 'border-emerald-500 bg-emerald-50 text-emerald-700';
    }
  };

  const handleHotspotClick = (h: DemandHotspot) => {
    setActiveHotspot(h);
    if (onInspectHotspot) {
      onInspectHotspot(h);
    }
  };

  const handleViewIntelligence = (h: DemandHotspot) => {
    const matchingRec = recommendations.find(
      (r) => r.district.toLowerCase() === h.district.toLowerCase() || r.category === h.topIssue
    );
    if (matchingRec) {
      setSelectedRecommendation(matchingRec);
    }
    setCurrentRoute('recommendations');
  };

  return (
    <div className="bg-white rounded-xl p-5 sm:p-6 shadow-xs border border-stone-200 space-y-6">
      {/* Top Header & Map Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 uppercase tracking-tight">
              Citizen Demand Hotspots Map
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Geospatial clustering of citizen development requests across Madhya Pradesh & regional zones.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-stone-100 rounded-lg p-1 text-xs">
            <button
              onClick={() => setSeverityFilter('All')}
              className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                severityFilter === 'All' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSeverityFilter('Critical')}
              className={`px-2 py-1 rounded-md font-medium transition-all flex items-center gap-1 ${
                severityFilter === 'Critical' ? 'bg-red-500 text-white shadow-2xs font-bold' : 'text-red-700'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
              Critical
            </button>
            <button
              onClick={() => setSeverityFilter('High')}
              className={`px-2 py-1 rounded-md font-medium transition-all flex items-center gap-1 ${
                severityFilter === 'High' ? 'bg-amber-600 text-white shadow-2xs font-bold' : 'text-amber-800'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              High
            </button>
            <button
              onClick={() => setSeverityFilter('Medium')}
              className={`px-2 py-1 rounded-md font-medium transition-all flex items-center gap-1 ${
                severityFilter === 'Medium' ? 'bg-yellow-500 text-slate-900 shadow-2xs font-bold' : 'text-yellow-700'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
              Med
            </button>
          </div>

          <div className="hidden md:flex items-center bg-stone-100 rounded-lg p-1 text-xs">
            <button
              onClick={() => setMapViewMode('pins')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                mapViewMode === 'pins' ? 'bg-white font-bold text-slate-900 shadow-2xs' : 'text-slate-600'
              }`}
            >
              Pins
            </button>
            <button
              onClick={() => setMapViewMode('heat')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                mapViewMode === 'heat' ? 'bg-white font-bold text-slate-900 shadow-2xs' : 'text-slate-600'
              }`}
            >
              Heatmap
            </button>
          </div>
        </div>
      </div>

      {/* Main Map & Hotspot Detail Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Interactive Stylized Geo-Visualizer Stage (Left 8 Cols) */}
        <div className="lg:col-span-8 bg-gradient-to-br from-slate-900 via-stone-950 to-amber-950 rounded-xl p-4 sm:p-6 text-white relative overflow-hidden min-h-[380px] sm:min-h-[460px] flex flex-col justify-between border border-amber-950/60 shadow-inner">
          {/* Subtle India & MP Geographic Grid */}
          <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

          {/* Map Region Header */}
          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-2 bg-slate-800/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-stone-700/80 text-xs">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-bold text-white">Madhya Pradesh & Central India Hub</span>
              <span className="text-slate-400 text-[11px]">• 52 Administrative Districts</span>
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-stone-700/60 hidden sm:block">
              Scale: 1:2,500,000 • Live Sensor Feed
            </div>
          </div>

          {/* SVG Map Canvas with District Hotspot Pins & Heat Radii */}
          <div className="relative w-full h-[280px] sm:h-[340px] my-2">
            {/* Stylized Madhya Pradesh State Outline Shape */}
            <svg
              className="absolute inset-0 w-full h-full text-stone-800/40 pointer-events-none"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
            >
              {/* Abstract MP Regional Land Polygon */}
              <path
                d="M 22,25 Q 40,8 60,10 T 88,28 Q 95,50 82,75 T 45,92 Q 20,85 15,60 Z"
                fill="currentColor"
                stroke="#44403c"
                strokeWidth="0.8"
                strokeDasharray="2,2"
              />
              {/* Internal Division Boundaries */}
              <line x1="22" y1="45" x2="80" y2="45" stroke="#292524" strokeWidth="0.5" />
              <line x1="50" y1="12" x2="50" y2="88" stroke="#292524" strokeWidth="0.5" />
            </svg>

            {/* Render Hotspot Pins */}
            {filteredHotspots.map((h) => {
              const isSelected = activeHotspot?.id === h.id;
              return (
                <div
                  key={h.id}
                  onClick={() => handleHotspotClick(h)}
                  className="absolute cursor-pointer transition-all duration-300 transform -translate-x-1/2 -translate-y-1/2 group"
                  style={{ left: `${h.x}%`, top: `${h.y}%` }}
                >
                  {/* Heatmap blur radius halo if in heat mode or critical */}
                  {(mapViewMode === 'heat' || h.severity === 'Critical') && (
                    <div
                      className={`absolute -inset-4 rounded-full blur-md opacity-40 animate-pulse pointer-events-none ${
                        h.severity === 'Critical'
                          ? 'bg-red-500'
                          : h.severity === 'High'
                          ? 'bg-amber-500'
                          : 'bg-amber-600'
                      }`}
                    />
                  )}

                  {/* Pulsing Ripple */}
                  {h.severity === 'Critical' && (
                    <div className="absolute -inset-2 rounded-full bg-red-400/40 animate-ping pointer-events-none" />
                  )}

                  {/* Marker Pin Icon / Badge */}
                  <div
                    className={`relative z-10 px-2 py-1 rounded-xl shadow-lg flex items-center gap-1.5 transition-all ${
                      isSelected
                        ? 'ring-4 ring-white scale-110 ' + getSeverityBg(h.severity)
                        : 'hover:scale-105 ' + getSeverityBg(h.severity)
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    <span className="text-[11px] font-bold whitespace-nowrap">{h.district}</span>
                    <span className="text-[9px] font-mono bg-black/30 px-1 rounded">
                      {h.requestsCount}
                    </span>
                  </div>

                  {/* Hover Tooltip Preview */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-30 pointer-events-none whitespace-nowrap bg-slate-900 text-white text-[10px] p-2 rounded-lg shadow-xl border border-stone-700">
                    <p className="font-bold text-amber-300">
                      {h.district} — {h.topIssue}
                    </p>
                    <p className="text-slate-300">
                      {h.requestsCount} requests • {(h.affectedPopulation ?? 0).toLocaleString()} pop.
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Map Legend */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 text-[11px] pt-3 border-t border-stone-800/80 text-slate-400">
            <div className="flex items-center gap-3">
              <span className="font-bold text-slate-300">Severity:</span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-red-500" /> 🔴 Critical (&gt;88)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-500" /> 🟠 High (80-87)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-yellow-400" /> 🟡 Medium (70-79)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400" /> 🟢 Low (&lt;70)
              </span>
            </div>

            <span className="text-slate-400">Click any marker pin to inspect telemetric card</span>
          </div>
        </div>

        {/* Hotspot Inspection Card (Right 4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          {activeHotspot ? (
            <div className="bg-stone-50 rounded-xl p-5 border border-stone-200 space-y-4 shadow-xs">
              {/* Header */}
              <div className="flex items-start justify-between pb-3 border-b border-stone-200">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    District Telemetry Card
                  </span>
                  <h4 className="text-lg font-extrabold text-slate-900 mt-0.5">
                    {activeHotspot.district}
                  </h4>
                  <span className="text-xs text-slate-500">{activeHotspot.state}</span>
                </div>

                <span
                  className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${getSeverityBorder(
                    activeHotspot.severity
                  )}`}
                >
                  {activeHotspot.severity} Urgency
                </span>
              </div>

              {/* Core Metrics Grid matching spec */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-white p-2.5 rounded-lg border border-stone-200 shadow-2xs">
                  <span className="text-slate-500 text-[10px] block font-medium">Top Issue</span>
                  <strong className="text-slate-900 font-bold text-xs truncate block">
                    {activeHotspot.topIssue}
                  </strong>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-stone-200 shadow-2xs">
                  <span className="text-slate-500 text-[10px] block font-medium">Citizen Requests</span>
                  <strong className="text-amber-800 font-bold text-xs font-mono">
                    {(activeHotspot.requestsCount ?? 0).toLocaleString()}
                  </strong>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-stone-200 shadow-2xs">
                  <span className="text-slate-500 text-[10px] block font-medium">Affected Population</span>
                  <strong className="text-slate-900 font-bold text-xs font-mono">
                    {(activeHotspot.affectedPopulation ?? 0).toLocaleString()}
                  </strong>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-stone-200 shadow-2xs">
                  <span className="text-slate-500 text-[10px] block font-medium">Infrastructure Score</span>
                  <div className="flex items-baseline gap-1">
                    <strong className="text-rose-600 font-bold text-xs font-mono">
                      {activeHotspot.infrastructureScore}
                    </strong>
                    <span className="text-[10px] text-slate-400">/ 100</span>
                  </div>
                </div>
              </div>

              {/* Priority Score Gauge */}
              <div className="bg-white p-3 rounded-lg border border-stone-200 shadow-2xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">AI Priority Score</span>
                  <div className="flex items-baseline gap-1">
                    <strong className="text-sm font-extrabold text-amber-700">
                      {activeHotspot.priorityScore}
                    </strong>
                    <span className="text-xs text-slate-400">/ 100</span>
                  </div>
                </div>
                <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      activeHotspot.priorityScore >= 88
                        ? 'bg-red-500'
                        : activeHotspot.priorityScore >= 80
                        ? 'bg-amber-600'
                        : 'bg-amber-700'
                    }`}
                    style={{ width: `${activeHotspot.priorityScore}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                  <span>Recent Surge: {activeHotspot.recentTrend}</span>
                  <span>96% AI Confidence</span>
                </div>
              </div>

              {/* Keywords Tag Cloud */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Dominant Keyword Cluster
                </span>
                <div className="flex flex-wrap gap-1">
                  {activeHotspot.topKeywords.map((kw, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded bg-white border border-stone-200 text-slate-700 text-[10px] font-medium"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Recommended Project preview */}
              <div className="p-3 bg-amber-50/70 rounded-lg border border-amber-200/80 text-xs space-y-1">
                <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
                  AI Recommended Intervention
                </span>
                <p className="text-amber-950 font-bold text-xs leading-snug">{activeHotspot.recommendedProject}</p>
                <div className="flex flex-wrap gap-1 pt-1">
                  {activeHotspot.schemes.map((sch, i) => (
                    <span
                      key={i}
                      className="text-[10px] bg-amber-200/70 text-amber-950 px-1.5 py-0.2 rounded font-semibold"
                    >
                      {sch}
                    </span>
                  ))}
                </div>
              </div>

              {/* View Intelligence CTA */}
              <button
                onClick={() => handleViewIntelligence(activeHotspot)}
                className="w-full py-2.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
                <span>View Intelligence Brief</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="bg-stone-50 rounded-xl p-6 text-center text-slate-400 border border-stone-200 text-xs">
              Click a hotspot marker on the map to inspect district metrics.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
