import React, { useState, useMemo } from 'react';
import {
  MapPin,
  Sparkles,
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Layers,
  Eye,
  Droplet,
  Car,
  HeartPulse,
  GraduationCap,
  Zap,
  Trash2,
  Bus,
  Wheat,
  HelpCircle,
  Activity,
  Flame,
  CheckCircle2,
  Clock,
  Compass,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CitizenRequest, IssueCategory, UrgencyLevel } from '../types';

interface CitizenRequestsMiniMapProps {
  requests: CitizenRequest[];
  selectedRequestId: string | null;
  onSelectRequest: (req: CitizenRequest) => void;
  selectedDistrict?: string;
  onDistrictSelect?: (district: string) => void;
}

// Map central India coordinates (Madhya Pradesh bounding box) to SVG percentage (x, y)
const MP_BOUNDS = {
  minLat: 21.0,
  maxLat: 26.9,
  minLng: 74.0,
  maxLng: 82.8,
};

const DISTRICT_COORDS: Record<string, { x: number; y: number }> = {
  Shivpuri: { x: 48, y: 24 },
  Gwalior: { x: 52, y: 13 },
  Ujjain: { x: 31, y: 59 },
  Bhopal: { x: 46, y: 55 },
  Indore: { x: 29, y: 69 },
  Jabalpur: { x: 69, y: 53 },
  Chhindwara: { x: 62, y: 81 },
  Rewa: { x: 82, y: 32 },
  Sagar: { x: 55, y: 44 },
  Satna: { x: 76, y: 34 },
  Khargone: { x: 34, y: 80 },
  Hoshangabad: { x: 48, y: 68 },
  Ratlam: { x: 23, y: 52 },
  Vidisha: { x: 49, y: 48 },
};

export const CitizenRequestsMiniMap: React.FC<CitizenRequestsMiniMapProps> = ({
  requests,
  selectedRequestId,
  onSelectRequest,
  selectedDistrict,
  onDistrictSelect,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showHeatmap, setShowHeatmap] = useState<boolean>(true);
  const [showLabels, setShowLabels] = useState<boolean>(true);
  const [hoveredReqId, setHoveredReqId] = useState<string | null>(null);

  // Compute spatial pin positions with intelligent offset clustering for same-district requests
  const mappedPins = useMemo(() => {
    // Group by location key to disperse coincident pins
    const locationGroups: Record<string, CitizenRequest[]> = {};

    requests.forEach((req) => {
      const locKey = req.lat && req.lng ? `${req.lat.toFixed(2)}_${req.lng.toFixed(2)}` : req.district;
      if (!locationGroups[locKey]) {
        locationGroups[locKey] = [];
      }
      locationGroups[locKey].push(req);
    });

    return requests.map((req) => {
      let baseX = 50;
      let baseY = 50;

      if (req.lat && req.lng) {
        // Project lat/lng to percentage
        baseX = ((req.lng - MP_BOUNDS.minLng) / (MP_BOUNDS.maxLng - MP_BOUNDS.minLng)) * 82 + 9;
        baseY = ((MP_BOUNDS.maxLat - req.lat) / (MP_BOUNDS.maxLat - MP_BOUNDS.minLat)) * 82 + 9;
      } else if (DISTRICT_COORDS[req.district]) {
        baseX = DISTRICT_COORDS[req.district].x;
        baseY = DISTRICT_COORDS[req.district].y;
      }

      // Disperse coincident pins radially if multiple exist at the same place
      const locKey = req.lat && req.lng ? `${req.lat.toFixed(2)}_${req.lng.toFixed(2)}` : req.district;
      const group = locationGroups[locKey] || [];
      const indexInGroup = group.findIndex((r) => r.id === req.id);

      let offsetX = 0;
      let offsetY = 0;
      if (group.length > 1 && indexInGroup > 0) {
        const angle = (indexInGroup / group.length) * 2 * Math.PI;
        const radius = 3.5; // percent offset
        offsetX = Math.cos(angle) * radius;
        offsetY = Math.sin(angle) * radius;
      }

      const finalX = Math.max(6, Math.min(94, baseX + offsetX));
      const finalY = Math.max(8, Math.min(92, baseY + offsetY));

      return {
        request: req,
        x: finalX,
        y: finalY,
      };
    });
  }, [requests]);

  const getCategoryIcon = (cat: IssueCategory) => {
    switch (cat) {
      case 'Water':
        return <Droplet className="w-3 h-3" />;
      case 'Roads':
        return <Car className="w-3 h-3" />;
      case 'Healthcare':
        return <HeartPulse className="w-3 h-3" />;
      case 'Education':
        return <GraduationCap className="w-3 h-3" />;
      case 'Electricity':
        return <Zap className="w-3 h-3" />;
      case 'Sanitation':
        return <Trash2 className="w-3 h-3" />;
      case 'Transport':
        return <Bus className="w-3 h-3" />;
      case 'Agriculture':
        return <Wheat className="w-3 h-3" />;
      default:
        return <HelpCircle className="w-3 h-3" />;
    }
  };

  const getPriorityStyle = (priority: UrgencyLevel, isSelected: boolean) => {
    switch (priority) {
      case 'Critical':
        return {
          bg: isSelected ? 'bg-red-600 text-white' : 'bg-red-500 text-white',
          halo: 'bg-red-500/50',
          ring: 'ring-red-400',
          border: 'border-red-300',
        };
      case 'High':
        return {
          bg: isSelected ? 'bg-amber-600 text-white' : 'bg-amber-500 text-white',
          halo: 'bg-amber-500/50',
          ring: 'ring-amber-400',
          border: 'border-amber-300',
        };
      case 'Medium':
        return {
          bg: isSelected ? 'bg-yellow-500 text-slate-950' : 'bg-yellow-400 text-slate-900',
          halo: 'bg-yellow-400/40',
          ring: 'ring-yellow-300',
          border: 'border-yellow-300',
        };
      default:
        return {
          bg: isSelected ? 'bg-emerald-600 text-white' : 'bg-emerald-500 text-white',
          halo: 'bg-emerald-500/40',
          ring: 'ring-emerald-300',
          border: 'border-emerald-300',
        };
    }
  };

  const criticalCount = requests.filter((r) => r.priority === 'Critical').length;
  const highCount = requests.filter((r) => r.priority === 'High').length;
  const uniqueDistricts = Array.from(new Set(requests.map((r) => r.district)));

  return (
    <div className="bg-slate-950 rounded-2xl border border-stone-800 shadow-xl overflow-hidden flex flex-col relative text-white">
      {/* Top Map Action Bar */}
      <div className="p-3.5 sm:p-4 bg-slate-900/90 border-b border-stone-800/80 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 relative z-20">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-white tracking-wide">
                Spatial Request Geo-Matrix
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800/60 font-bold">
                {requests.length} {requests.length === 1 ? 'Pin Plotted' : 'Pins Plotted'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Interactive pin distribution across Central India & Madhya Pradesh
            </p>
          </div>
        </div>

        {/* Map Control Buttons */}
        <div className="flex items-center gap-2">
          {/* Heat Halo Toggle */}
          <button
            type="button"
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              showHeatmap
                ? 'bg-amber-600/90 text-white border border-amber-400/50 shadow-2xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-stone-700'
            }`}
            title="Toggle heat halo radiuses"
          >
            <Flame className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Heat Radius</span>
          </button>

          {/* Labels Toggle */}
          <button
            type="button"
            onClick={() => setShowLabels(!showLabels)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              showLabels
                ? 'bg-slate-700 text-amber-300 border border-amber-500/40 shadow-2xs'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700 border border-stone-700'
            }`}
            title="Toggle pin badges"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Labels</span>
          </button>

          {/* Zoom Controls */}
          <div className="flex items-center bg-slate-800 rounded-lg border border-stone-700 p-0.5">
            <button
              type="button"
              onClick={() => setZoomLevel((z) => Math.min(1.8, +(z + 0.2).toFixed(1)))}
              disabled={zoomLevel >= 1.8}
              className="p-1 text-slate-300 hover:text-white hover:bg-slate-700 rounded disabled:opacity-40 cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setZoomLevel((z) => Math.max(0.8, +(z - 0.2).toFixed(1)))}
              disabled={zoomLevel <= 0.8}
              className="p-1 text-slate-300 hover:text-white hover:bg-slate-700 rounded disabled:opacity-40 cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setZoomLevel(1)}
              className="p-1 text-slate-300 hover:text-amber-400 hover:bg-slate-700 rounded cursor-pointer"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Interactive Map Viewport */}
      <div className="relative w-full h-[420px] sm:h-[480px] bg-gradient-to-b from-slate-950 via-stone-950 to-amber-950/90 overflow-hidden select-none flex items-center justify-center">
        {/* Topographic Background Pattern */}
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

        {/* Scalable Container for Zoom */}
        <div
          className="relative w-full h-full transition-transform duration-300 ease-out origin-center"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          {/* Stylized Central India & MP Geographic Polygon SVG Layer */}
          <svg
            className="absolute inset-0 w-full h-full text-stone-800/50 pointer-events-none"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
          >
            {/* Ambient Grid Lines */}
            <line x1="10" y1="25" x2="90" y2="25" stroke="#292524" strokeWidth="0.4" strokeDasharray="3,3" />
            <line x1="10" y1="50" x2="90" y2="50" stroke="#292524" strokeWidth="0.4" strokeDasharray="3,3" />
            <line x1="10" y1="75" x2="90" y2="75" stroke="#292524" strokeWidth="0.4" strokeDasharray="3,3" />
            <line x1="30" y1="10" x2="30" y2="90" stroke="#292524" strokeWidth="0.4" strokeDasharray="3,3" />
            <line x1="50" y1="10" x2="50" y2="90" stroke="#292524" strokeWidth="0.4" strokeDasharray="3,3" />
            <line x1="70" y1="10" x2="70" y2="90" stroke="#292524" strokeWidth="0.4" strokeDasharray="3,3" />

            {/* Abstract Madhya Pradesh Regional Polygon */}
            <path
              d="M 22,25 Q 40,8 60,10 T 88,28 Q 95,50 82,75 T 45,92 Q 20,85 15,60 Z"
              fill="rgba(41, 37, 36, 0.45)"
              stroke="#57534e"
              strokeWidth="0.75"
              strokeDasharray="2,2"
            />
            {/* River Narmada Stylized Waterway Curve */}
            <path
              d="M 20,72 Q 45,68 65,70 T 85,62"
              fill="none"
              stroke="#0284c7"
              strokeWidth="0.8"
              strokeOpacity="0.4"
              strokeDasharray="4,2"
            />
          </svg>

          {/* District Geographic Landmark Markers (Subtle Labels) */}
          <div className="absolute inset-0 pointer-events-none">
            <span className="absolute left-[48%] top-[18%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Shivpuri
            </span>
            <span className="absolute left-[52%] top-[8%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Gwalior
            </span>
            <span className="absolute left-[44%] top-[49%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Bhopal
            </span>
            <span className="absolute left-[26%] top-[62%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Indore
            </span>
            <span className="absolute left-[28%] top-[53%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Ujjain
            </span>
            <span className="absolute left-[68%] top-[48%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Jabalpur
            </span>
            <span className="absolute left-[60%] top-[76%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Chhindwara
            </span>
            <span className="absolute left-[80%] top-[27%] text-[9px] font-mono text-stone-500 font-bold tracking-widest uppercase">
              • Rewa
            </span>
          </div>

          {/* RENDER ALL FILTERED PINS ON MINI-MAP */}
          {mappedPins.length === 0 ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10">
              <div className="w-12 h-12 rounded-full bg-slate-900 border border-stone-700 flex items-center justify-center text-slate-400 mb-2">
                <MapPin className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-200">No request pins match current filters</h4>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Try widening your search terms or clearing location/status filters above.
              </p>
            </div>
          ) : (
            mappedPins.map(({ request: req, x, y }) => {
              const isSelected = selectedRequestId === req.id;
              const isHovered = hoveredReqId === req.id;
              const style = getPriorityStyle(req.priority, isSelected);

              return (
                <div
                  key={req.id}
                  onClick={() => onSelectRequest(req)}
                  onMouseEnter={() => setHoveredReqId(req.id)}
                  onMouseLeave={() => setHoveredReqId(null)}
                  className="absolute cursor-pointer transition-all duration-200 -translate-x-1/2 -translate-y-1/2 group z-10"
                  style={{
                    left: `${x}%`,
                    top: `${y}%`,
                    zIndex: isSelected ? 40 : isHovered ? 35 : req.priority === 'Critical' ? 25 : 20,
                  }}
                >
                  {/* Heat Halo Radius (Pulsing for Critical) */}
                  {showHeatmap && (
                    <div
                      className={`absolute -inset-3 rounded-full blur-md opacity-40 pointer-events-none transition-all ${
                        style.halo
                      } ${req.priority === 'Critical' ? 'animate-pulse scale-125' : ''}`}
                    />
                  )}

                  {/* Ping Animation for Critical Priority */}
                  {req.priority === 'Critical' && (
                    <div className="absolute -inset-2 rounded-full bg-red-400/40 animate-ping pointer-events-none" />
                  )}

                  {/* Pin Node Capsule */}
                  <motion.div
                    whileHover={{ scale: 1.15 }}
                    whileTap={{ scale: 0.95 }}
                    className={`relative flex items-center gap-1.5 px-2 py-1 rounded-xl shadow-lg border transition-all ${
                      style.bg
                    } ${
                      isSelected
                        ? 'ring-4 ring-white shadow-2xl scale-110 border-white'
                        : `${style.border} shadow-md`
                    }`}
                  >
                    {/* Category Icon */}
                    <div className="shrink-0">{getCategoryIcon(req.category)}</div>

                    {/* Pin Label (District or Request ID) */}
                    {showLabels && (
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] font-extrabold whitespace-nowrap">
                          {req.district}
                        </span>
                        <span className="text-[8px] font-mono bg-black/35 px-1 py-0.2 rounded font-semibold">
                          {req.id.split('-').pop()}
                        </span>
                      </div>
                    )}

                    {/* Confidence / Status dot */}
                    <span className="w-1.5 h-1.5 rounded-full bg-white shrink-0 animate-pulse" />
                  </motion.div>

                  {/* HOVER DETAIL CARD TOOLTIP */}
                  <AnimatePresence>
                    {isHovered && (
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.92 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.92 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-64 p-3 rounded-xl bg-slate-900/95 backdrop-blur-md text-white border border-stone-700 shadow-2xl z-50 pointer-events-none space-y-1.5 text-left"
                      >
                        {/* Header */}
                        <div className="flex items-center justify-between gap-1 border-b border-stone-800 pb-1.5">
                          <span className="font-mono text-[10px] font-bold text-amber-400">
                            {req.id}
                          </span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                              req.priority === 'Critical'
                                ? 'bg-red-500/80 text-white'
                                : req.priority === 'High'
                                ? 'bg-amber-500/80 text-white'
                                : 'bg-yellow-500/80 text-slate-900'
                            }`}
                          >
                            {req.priority}
                          </span>
                        </div>

                        {/* Title */}
                        <p className="text-xs font-bold text-white line-clamp-2 leading-tight">
                          {req.title}
                        </p>

                        {/* Location and Category */}
                        <div className="text-[10px] text-slate-300 flex items-center justify-between pt-0.5">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-amber-400" />
                            {req.cityVillageWard}, {req.district}
                          </span>
                          <span className="text-amber-200 font-semibold">{req.category}</span>
                        </div>

                        {/* Status & Confidence */}
                        <div className="text-[9px] text-slate-400 flex items-center justify-between pt-1 border-t border-stone-800/80">
                          <span className="text-emerald-400 font-semibold">{req.status}</span>
                          <span className="font-mono">{req.aiConfidence}% Verified</span>
                        </div>

                        {/* Click CTA */}
                        <p className="text-[9px] text-amber-300/80 text-center font-medium pt-0.5">
                          Click to inspect full 6-stage lifecycle →
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })
          )}
        </div>

        {/* Compass Watermark */}
        <div className="absolute top-4 right-4 pointer-events-none opacity-20">
          <div className="w-16 h-16 rounded-full border border-amber-400/40 flex items-center justify-center">
            <span className="text-[10px] font-mono text-amber-300 font-bold">N ↑</span>
          </div>
        </div>

        {/* Legend Overlay at Bottom-Left */}
        <div className="absolute bottom-3 left-3 bg-slate-900/90 backdrop-blur-md p-2 rounded-xl border border-stone-800 text-[10px] space-y-1 z-20 pointer-events-none hidden sm:block">
          <div className="font-bold text-slate-300 text-[9px] uppercase tracking-wider">
            Urgency Palette
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-red-500" />
              <span>Critical ({criticalCount})</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>High ({highCount})</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-yellow-400" />
              <span>Med/Low</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Quick District Selector Strip */}
      <div className="p-3 bg-slate-900 border-t border-stone-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 z-10">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-semibold text-slate-300 mr-1 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-amber-400" /> Filtered Districts:
          </span>

          <button
            type="button"
            onClick={() => onDistrictSelect && onDistrictSelect('All')}
            className={`px-2 py-0.5 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
              !selectedDistrict || selectedDistrict === 'All'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All ({requests.length})
          </button>

          {uniqueDistricts.map((dist) => {
            const count = requests.filter((r) => r.district === dist).length;
            const isActive = selectedDistrict === dist;
            return (
              <button
                key={dist}
                type="button"
                onClick={() => onDistrictSelect && onDistrictSelect(isActive ? 'All' : dist)}
                className={`px-2 py-0.5 rounded-md text-[11px] font-semibold transition-colors cursor-pointer flex items-center gap-1 ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <span>{dist}</span>
                <span className={`text-[9px] px-1 rounded ${isActive ? 'bg-amber-700 text-white' : 'bg-slate-900 text-slate-400'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="text-[11px] text-slate-400">
          Click any pin on the map to inspect timeline
        </div>
      </div>
    </div>
  );
};
