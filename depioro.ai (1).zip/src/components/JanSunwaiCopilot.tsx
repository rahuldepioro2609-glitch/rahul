import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Clock,
  MapPin,
  Building,
  User,
  Shield,
  FileText,
  Printer,
  Send,
  ArrowRight,
  Radio,
  RefreshCw,
  Sliders,
  Check,
  Award,
  Layers,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useDepioro } from '../context/DepioroContext';
import { analyzeJanSunwaiHearing, JanSunwaiAnalysisResult } from '../services/aiService';
import { PrintDossierHeader, PrintSignatureBlock } from './PrintDossierHeader';

interface PresetHearingCase {
  id: string;
  citizenName: string;
  citizenRole: string;
  village: string;
  district: string;
  category: 'Water' | 'Roads' | 'Healthcare' | 'Electricity' | 'Sanitation';
  audioDuration: string;
  statementHindi: string;
  statementEnglish: string;
  avatarColor: string;
}

const PRESET_CASES: PresetHearingCase[] = [
  {
    id: 'case-1',
    citizenName: 'रामेश्वर पटेल (Rameshwar Patel)',
    citizenRole: 'Pohari Gram Panchayat Resident',
    village: 'Pohari Block, Ward 4',
    district: 'Shivpuri',
    category: 'Water',
    audioDuration: '0:34',
    statementHindi:
      'श्रीमान कलेक्टर महोदय, हमारे पोहरी ब्लॉक के वार्ड 4 में पिछले 18 दिनों से पानी की पाइपलाइन टूटी पड़ी है। 400 से ज्यादा परिवार 3 किलोमीटर दूर से पीने का पानी सिर पर ढोकर लाने को मजबूर हैं। हैंडपंप से भी खारा पानी आ रहा है। कृपया तुरंत टैंकर और नई बोरवेल की व्यवस्था करवाएं।',
    statementEnglish:
      'Respected District Collector, in our Pohari block Ward 4, the main potable pipeline has been broken for 18 days. Over 400 families are forced to fetch water from 3 km away. Please sanction emergency tankers and deep-aquifer borewells.',
    avatarColor: 'bg-blue-600',
  },
  {
    id: 'case-2',
    citizenName: 'सुनीता देवी (Sunita Devi)',
    citizenRole: 'Mahidpur ASHA Worker / Villager',
    village: 'Mahidpur Rural Hub',
    district: 'Ujjain',
    category: 'Healthcare',
    audioDuration: '0:28',
    statementHindi:
      'साहब, महिदपुर प्राथमिक स्वास्थ्य केंद्र में पिछले एक महीने से कोई डॉक्टर नहीं बैठ रहे हैं। प्रसव वार्ड का फ्रिज खराब होने से बच्चों के टीके खराब हो रहे हैं। आपातकाल में गर्भवती महिलाओं को 45 किलोमीटर दूर उज्जैन ले जाना पड़ता है।',
    statementEnglish:
      'Sir, no MBBS doctor has been present at Mahidpur PHC for a month. Vaccine storage refrigerator is broken, and pregnant mothers have to travel 45 km to Ujjain.',
    avatarColor: 'bg-rose-600',
  },
  {
    id: 'case-3',
    citizenName: 'बलजीत सिंह (Baljit Singh)',
    citizenRole: 'Commercial Transporter & Local Resident',
    village: 'Morar - Maharajpura Bypass',
    district: 'Gwalior',
    category: 'Roads',
    audioDuration: '0:30',
    statementHindi:
      'कलेक्टर साहब, मुरार से महाराजपुरा एयरपोर्ट मार्ग पर 4 किलोमीटर में इतने गहरे गड्ढे हैं कि पिछले 10 दिनों में दो स्कूल बसें पलटते-पलटते बची हैं। रात के अंधेरे में बाइक सवार गिरकर घायल हो रहे हैं। तुरंत डामरीकरण और पुलिया निर्माण की आवश्यकता है।',
    statementEnglish:
      'Collector Sir, on the 4 km Morar-Maharajpura bypass, there are deep hazardous craters. Two school buses almost overturned. Immediate asphalt resurfacing and culverts are needed.',
    avatarColor: 'bg-amber-600',
  },
  {
    id: 'case-4',
    citizenName: 'शिवराज गुर्जर (Shivraj Gurjar)',
    citizenRole: 'Farmer / Krishi Sahakari Member',
    village: 'Depalpur Agro Cluster',
    district: 'Indore',
    category: 'Electricity',
    audioDuration: '0:26',
    statementHindi:
      'मान्यवर, देपालपुर क्षेत्र में गेहूं की बोआई के समय 100 kVA का ट्रांसफॉर्मर तीसरी बार जल गया है। वोल्टेज 160V से नीचे गिर जाने से हमारी सिंचाई की मोटरें फुंक रही हैं और 12 घंटे बिजली गुल रहती है। हमें 200 kVA का नया ट्रांसफॉर्मर दिया जाए।',
    statementEnglish:
      'Respected Sir, our 100 kVA agricultural transformer in Depalpur has burned out thrice during wheat sowing. Low voltage is burning our pump motors. We need a 200 kVA upgrade.',
    avatarColor: 'bg-emerald-600',
  },
];

export const JanSunwaiCopilot: React.FC = () => {
  const { addCitizenRequest, setToastMessage, setCurrentRoute } = useDepioro();

  const [activeCase, setActiveCase] = useState<PresetHearingCase>(PRESET_CASES[0]);
  const [customStatement, setCustomStatement] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioSpeechSynthesis, setAudioSpeechSynthesis] = useState<SpeechSynthesisUtterance | null>(null);

  const [hearingOrder, setHearingOrder] = useState<JanSunwaiAnalysisResult | null>(null);
  const [orderDispatched, setOrderDispatched] = useState(false);
  const [sanctionToken, setSanctionToken] = useState('JS-MP/2026/ORD-8419');

  // Trigger analysis for active preset or custom statement
  const handleAnalyzeHearing = async (caseObj?: PresetHearingCase, textOverride?: string) => {
    const targetCase = caseObj || activeCase;
    const textToAnalyze = textOverride || customStatement || targetCase.statementHindi;

    setIsAnalyzing(true);
    setOrderDispatched(false);

    try {
      const result = await analyzeJanSunwaiHearing(
        textToAnalyze,
        'Hindi',
        targetCase.village,
        targetCase.district
      );
      setHearingOrder(result);
      setSanctionToken(`JS-MP/2026/ORD-${Math.floor(1000 + Math.random() * 9000)}`);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    handleAnalyzeHearing(PRESET_CASES[0]);
  }, []);

  // Browser speech synthesis for Collector's verbal decree
  const handlePlayCollectorSpeech = (text: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on this browser.');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'hi-IN';
    utterance.rate = 0.95;

    // Try to find a Hindi voice if available
    const voices = window.speechSynthesis.getVoices();
    const hindiVoice = voices.find((v) => v.lang.includes('hi') || v.name.toLowerCase().includes('hindi'));
    if (hindiVoice) {
      utterance.voice = hindiVoice;
    }

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setAudioSpeechSynthesis(utterance);
    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleSimulateVoiceRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    setIsRecording(true);
    setTimeout(() => {
      setIsRecording(false);
      setCustomStatement(
        'कलेक्टर महोदय, ग्राम पंचायत बिछिया में प्राथमिक शाला की छत बारिश में टपक रही है और बालिकाओं के लिए शौचालय की कोई व्यवस्था नहीं है। कृपया तुरंत मरम्मत स्वीकृत करें।'
      );
      setToastMessage('Live Citizen Voice Transcribed (Hindi NLP Stream)');
      handleAnalyzeHearing(activeCase, 'कलेक्टर महोदय, ग्राम पंचायत बिछिया में प्राथमिक शाला की छत बारिश में टपक रही है और बालिकाओं के लिए शौचालय की कोई व्यवस्था नहीं है।');
    }, 2800);
  };

  const handleDispatchOrder = () => {
    setOrderDispatched(true);
    setToastMessage(`Action Order #${sanctionToken} formally dispatched to ${hearingOrder?.assignedOfficer}`);

    // Also auto-add to citizen requests tracker
    if (hearingOrder) {
      addCitizenRequest({
        title: hearingOrder.actionOrderTitle,
        description: hearingOrder.summary,
        category: hearingOrder.grievanceCategory,
        state: 'Madhya Pradesh',
        district: activeCase.district,
        cityVillageWard: activeCase.village,
        priority: hearingOrder.urgency,
        status: 'Under Review',
        aiConfidence: 97,
        keywords: [hearingOrder.grievanceCategory, 'Jan Sunwai Order', activeCase.district],
        affectedPopulation: 25000,
        imageUrl: undefined,
        lat: 24.5,
        lng: 78.0,
        aiSummary: hearingOrder.summary,
        suggestedIntervention: hearingOrder.actionDirectives.join('; '),
        language: 'Hindi',
        originalVoiceTranscript: activeCase.statementHindi,
      });
    }
  };

  const handlePrintSanctionOrder = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 print:p-0 print:m-0 print:max-w-none print:space-y-4">
      {/* Official Government Print Header */}
      <PrintDossierHeader
        title="District Collectorate Jan Sunwai Grievance Resolution Order"
        documentType="OFFICIAL DIRECTIVE & STATUTORY ADMINISTRATIVE SANCTION"
        documentRef={sanctionToken}
        district={`${activeCase.district} District`}
        state="Madhya Pradesh"
        classification="OFFICIAL DIRECTIVE • 7-DAY STATUTORY SLA"
      />

      {/* Screen Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-950/60 space-y-6 print:hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-semibold mb-2">
              <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
              <span>Live Public Hearing Copilot • समाधान दिवस & जन सुनवाई</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <span>Jan Sunwai AI Voice Copilot</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium">
                Live Resolution Engine
              </span>
            </h1>
            <p className="text-slate-300 text-sm mt-1 max-w-3xl">
              Assisting District Magistrates, Block Development Officers, and Gram Panchayat Assemblies in real-time multilingual citizen voice transcription, statutory scheme mapping, and instant 7-day executive action orders.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handlePrintSanctionOrder}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Print Official Jan Sunwai Order"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>Print Order (PDF)</span>
            </button>
            <button
              onClick={() => setCurrentRoute('recommendations')}
              className="px-3.5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <FileText className="w-4 h-4 text-yellow-200" />
              <span>View District DPRs</span>
            </button>
          </div>
        </div>

        {/* Preset Hearing Testimony Cards */}
        <div>
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
            <span>Select Hearing Citizen Case or Record Live:</span>
            <span className="text-amber-400">4 Active Cases in Queue</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {PRESET_CASES.map((item) => {
              const isSelected = activeCase.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveCase(item);
                    setCustomStatement('');
                    handleAnalyzeHearing(item);
                  }}
                  className={`p-3.5 rounded-2xl text-left transition-all border cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-amber-950/40 border-amber-500/80 shadow-lg shadow-amber-900/20 ring-1 ring-amber-400'
                      : 'bg-slate-800/80 border-slate-700/80 hover:bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full ${item.avatarColor} text-white flex items-center justify-center text-xs font-bold shrink-0`}>
                        {item.citizenName.charAt(0)}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 line-clamp-1">
                          {item.citizenName.split('(')[0]}
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1">
                          <MapPin className="w-2.5 h-2.5 text-amber-400" />
                          <span>{item.district}</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700 text-slate-300 font-medium shrink-0">
                      {item.category}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 line-clamp-2 italic mb-2">
                    "{item.statementHindi}"
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-amber-300/90 pt-2 border-t border-slate-700/60 font-medium">
                    <span className="flex items-center gap-1">
                      <Volume2 className="w-3 h-3 text-amber-400" />
                      <span>Audio: {item.audioDuration}</span>
                    </span>
                    <span className="text-slate-400">{isSelected ? 'Active Case' : 'Click to Hear'}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Grid: Live Hearing Audio Feed & Executive Resolution Order */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Live Audio Stream & Citizen Testimony */}
        <div className="lg:col-span-5 space-y-5 print:hidden">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center font-bold text-sm">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900">Citizen Audio Intake</h2>
                  <p className="text-xs text-slate-500">Multilingual Acoustic NLP Stream</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleSimulateVoiceRecording}
                  disabled={isAnalyzing}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                    isRecording
                      ? 'bg-red-600 text-white animate-pulse shadow-md shadow-red-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                  }`}
                >
                  {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{isRecording ? 'Listening...' : 'Live Microphone'}</span>
                </button>
              </div>
            </div>

            {/* Audio Wave Visualizer Simulation */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white relative overflow-hidden flex flex-col justify-between h-36">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="font-mono text-emerald-300">Live Speech Feed: {activeCase.district}</span>
                </span>
                <span className="font-mono text-[11px] text-amber-400">{activeCase.village}</span>
              </div>

              {/* Animated wave bars */}
              <div className="flex items-center justify-center gap-1.5 my-2">
                {[18, 35, 65, 45, 85, 95, 40, 75, 60, 90, 50, 80, 45, 65, 30, 20].map((h, i) => (
                  <motion.div
                    key={i}
                    animate={{
                      height: isRecording || isPlayingAudio ? [h * 0.4, h, h * 0.6] : [h * 0.3, h * 0.4, h * 0.3],
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: 0.6 + (i % 5) * 0.1,
                      ease: 'easeInOut',
                    }}
                    className={`w-1.5 rounded-full ${
                      isRecording ? 'bg-red-500' : isPlayingAudio ? 'bg-amber-400' : 'bg-slate-600'
                    }`}
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px]">Speaker: {activeCase.citizenName.split('(')[0]}</span>
                <button
                  onClick={() => handleAnalyzeHearing(activeCase)}
                  disabled={isAnalyzing}
                  className="text-[11px] text-amber-300 hover:text-amber-200 flex items-center gap-1 font-medium cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${isAnalyzing ? 'animate-spin' : ''}`} />
                  <span>Re-parse AI</span>
                </button>
              </div>
            </div>

            {/* Transcript Display */}
            <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/70 space-y-2">
              <div className="text-[11px] font-bold text-amber-900 flex items-center justify-between">
                <span>VERBATIM CITIZEN TRANSCRIPT (HINDI):</span>
                <span className="text-amber-700 text-[10px] font-normal">Confidence: 98%</span>
              </div>
              <p className="text-xs text-slate-800 font-medium leading-relaxed">
                "{customStatement || activeCase.statementHindi}"
              </p>
              <div className="pt-2 border-t border-amber-200/50">
                <span className="text-[10px] font-semibold text-slate-500 uppercase block mb-0.5">
                  English Semantic Translation:
                </span>
                <p className="text-[11px] text-slate-600 italic leading-normal">
                  "{activeCase.statementEnglish}"
                </p>
              </div>
            </div>

            {/* Hearing Officer Interaction Note */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <User className="w-3.5 h-3.5 text-slate-600" />
                <span>Hearing Bench: District Collector & Sub-Divisional Officer</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Depioro AI automatically synthesizes the grievance against District Master Infrastructure Maps and active central/state schemes to generate a binding 7-day administrative decree.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: AI Action Order (Jan Sunwai Samadhan Aadesh) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/80 space-y-6">
            {/* Order Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold font-mono px-2.5 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300">
                    {sanctionToken}
                  </span>
                  <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    Statutory Fast-Track (7-Day SLA)
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 mt-2">
                  {hearingOrder?.actionOrderTitle || 'जन सुनवाई त्वरित समाधान आदेश (Jan Sunwai Action Order)'}
                </h3>
              </div>

              {orderDispatched && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Sanction Issued & Dispatched</span>
                </div>
              )}
            </div>

            {/* Quick Intelligence Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">Grievance Category</span>
                <span className="text-xs font-bold text-slate-900">{hearingOrder?.grievanceCategory || activeCase.category}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">Target Location</span>
                <span className="text-xs font-bold text-slate-900 line-clamp-1">{activeCase.village}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">Priority / Urgency</span>
                <span className="text-xs font-bold text-rose-700">{hearingOrder?.urgency || 'High'}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block mb-1">Resolution SLA</span>
                <span className="text-xs font-bold text-amber-700">7 Calendar Days</span>
              </div>
            </div>

            {/* Executive Directives Section */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-600" />
                <span>Statutory Administrative Directives (कार्रवाई निर्देश):</span>
              </h4>

              <div className="space-y-2.5">
                {(hearingOrder?.actionDirectives || [
                  'Deploy emergency relief unit within 24 hours.',
                  'Complete field inspection and technical survey within 72 hours.',
                  'Submit compliance signoff to District Collectorate by Day 7.',
                ]).map((directive, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-slate-50 hover:bg-amber-50/40 border border-slate-200/80 flex items-start gap-3 transition-colors"
                  >
                    <div className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </div>
                    <div className="text-xs text-slate-800 font-medium leading-relaxed">
                      {directive}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Scheme Alignment & Officer Assignment */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80">
                <div className="text-[10px] font-bold text-amber-900 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-amber-700" />
                  <span>Funding Scheme Alignment:</span>
                </div>
                <div className="text-xs font-bold text-slate-900">
                  {hearingOrder?.eligibleScheme || 'Jal Jeevan Mission / AMRUT 2.0'}
                </div>
                <div className="text-[11px] text-slate-600 mt-1">
                  Co-funded through State Rural Infrastructure & Central matching grant.
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-100 border border-slate-200">
                <div className="text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-700" />
                  <span>Assigned Nodal Officer:</span>
                </div>
                <div className="text-xs font-bold text-slate-900">
                  {hearingOrder?.assignedOfficer || `Executive Engineer (PHED), ${activeCase.district}`}
                </div>
                <div className="text-[11px] text-slate-600 mt-1">
                  Designated Compliance Authority • SLA monitored by Collectorate.
                </div>
              </div>
            </div>

            {/* District Collector's Verbal Spoken Decree in Hindi */}
            {hearingOrder?.speechResponseHindi && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 text-white space-y-3 print:bg-slate-100 print:text-slate-900 print:border print:border-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Volume2 className="w-4 h-4 text-amber-400" />
                    <span>Collectorate Spoken Decree (आदेश मौखिक वाचन):</span>
                  </span>
                  <button
                    onClick={() => handlePlayCollectorSpeech(hearingOrder.speechResponseHindi)}
                    className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                      isPlayingAudio
                        ? 'bg-red-600 text-white animate-pulse'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold'
                    }`}
                  >
                    {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    <span>{isPlayingAudio ? 'Stop Speech' : 'Listen Hindi Audio'}</span>
                  </button>
                </div>

                <p className="text-xs sm:text-sm text-slate-200 italic font-serif leading-relaxed">
                  "{hearingOrder.speechResponseHindi}"
                </p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-200 print:hidden">
              <button
                onClick={handlePrintSanctionOrder}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-300"
              >
                <Printer className="w-4 h-4 text-slate-600" />
                <span>Export & Print Order (PDF)</span>
              </button>

              <button
                onClick={handleDispatchOrder}
                disabled={orderDispatched || isAnalyzing}
                className={`w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  orderDispatched
                    ? 'bg-emerald-600 text-white cursor-default'
                    : 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white'
                }`}
              >
                {orderDispatched ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Order Formally Issued</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 text-amber-200" />
                    <span>Issue Official Sanction Order</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Official Signature Block for Printed Order */}
      <PrintSignatureBlock
        preparedBy="Depioro AI Jan Sunwai Transcription & Order Drafting Copilot"
        reviewedBy="Sub-Divisional Magistrate (SDM) / Nodal Grievance Officer"
        sanctioningAuthority="District Magistrate & District Collector, Madhya Pradesh"
      />
    </div>
  );
};
