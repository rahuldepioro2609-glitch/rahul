/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Brain,
  BarChart3,
  Mic,
  Clock,
  Sparkles,
  Shield,
  HelpCircle,
  Home,
  Layers,
  Globe,
  ChevronDown,
  Menu,
  X,
  MapPin,
  FileSpreadsheet,
  CheckCircle2,
  RefreshCw,
  Sliders,
  Bell,
  Cpu,
  ArrowUp,
  Radio,
  Coins,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DepioroProvider, useDepioro } from './context/DepioroContext';
import { LandingPage } from './components/LandingPage';
import { CitizenPortal } from './components/CitizenPortal';
import { CitizenRequestTracking } from './components/CitizenRequestTracking';
import { PolicymakerDashboard } from './components/PolicymakerDashboard';
import { ProjectIntelligence } from './components/ProjectIntelligence';
import { JanSunwaiCopilot } from './components/JanSunwaiCopilot';
import { BudgetOptimizer } from './components/BudgetOptimizer';
import { AdminPanel } from './components/AdminPanel';
import { HowItWorksPage } from './components/HowItWorksPage';
import { AdvancedAnimatedIcon } from './components/AdvancedAnimatedIcon';
import { LANGUAGES } from './data/mockData';
import { LanguageCode } from './types';

const TechnicalDashboardLayout: React.FC = () => {
  const {
    currentRoute,
    setCurrentRoute,
    selectedLanguage,
    setSelectedLanguage,
    activeRole,
    setActiveRole,
    stats,
  } = useDepioro();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const mainRef = useRef<HTMLElement>(null);

  const handleScroll = () => {
    if (!mainRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = mainRef.current;
    const totalScroll = scrollHeight - clientHeight;
    if (totalScroll > 0) {
      setScrollProgress((scrollTop / totalScroll) * 100);
    } else {
      setScrollProgress(0);
    }
    setShowScrollTop(scrollTop > 200);
  };

  const scrollToTop = () => {
    mainRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to top on route change
  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    setScrollProgress(0);
    setShowScrollTop(false);
  }, [currentRoute]);

  const currentLangObj = LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0];


  const navItems = [
    { id: 'dashboard', label: 'Intelligence Dashboard', icon: BarChart3, badge: 'Live' },
    { id: 'jan-sunwai', label: 'Jan Sunwai Copilot', icon: Radio, badge: 'Hearing AI' },
    { id: 'budget-optimizer', label: 'Vikas Budget Optimizer', icon: Coins, badge: 'Simulator' },
    { id: 'citizen', label: 'Voice Reporting', icon: Mic, badge: 'Multilingual' },
    { id: 'requests', label: 'Citizen Requests', icon: Clock, count: stats.totalRequests },
    { id: 'recommendations', label: 'AI Policy Briefs', icon: Sparkles, count: stats.aiRecommendationsCount },
    { id: 'how-it-works', label: 'How It Works', icon: HelpCircle },
    { id: 'admin', label: 'System Admin', icon: Cpu, badge: 'Telemetry' },
    { id: 'home', label: 'Platform Overview', icon: Home },
  ];

  const getPageTitle = () => {
    switch (currentRoute) {
      case 'dashboard':
        return 'Development Intelligence Dashboard';
      case 'jan-sunwai':
        return 'Jan Sunwai Live Hearing AI Copilot';
      case 'budget-optimizer':
        return 'Vikas Budget & ROI Capital Allocation Engine';
      case 'citizen':
        return 'Citizen Voice & Text Reporting Portal';
      case 'requests':
        return 'Grassroots Requests & Telemetry';
      case 'recommendations':
        return 'AI Project Recommendations & DPR Dossiers';
      case 'admin':
        return 'System Performance & AI Throughput';
      case 'how-it-works':
        return 'How Depioro AI Semantic Pipeline Works';
      case 'home':
      default:
        return 'Depioro.ai Public Infrastructure Hub';
    }
  };

  const renderCurrentView = () => {
    switch (currentRoute) {
      case 'home':
        return <LandingPage />;
      case 'citizen':
        return <CitizenPortal />;
      case 'requests':
        return <CitizenRequestTracking />;
      case 'dashboard':
        return <PolicymakerDashboard />;
      case 'jan-sunwai':
        return <JanSunwaiCopilot />;
      case 'budget-optimizer':
        return <BudgetOptimizer />;
      case 'recommendations':
        return <ProjectIntelligence />;
      case 'admin':
        return <AdminPanel />;
      case 'how-it-works':
        return <HowItWorksPage />;
      default:
        return <PolicymakerDashboard />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-100 font-sans text-slate-800 antialiased overflow-hidden">
      {/* Mobile Drawer Backdrop */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* TECHNICAL DASHBOARD SIDEBAR */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col shrink-0 transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Logo Header */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-950/40">
          <div
            onClick={() => {
              setCurrentRoute('dashboard');
              setSidebarOpen(false);
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <AdvancedAnimatedIcon name="brain-pulse" size="sm" />
            <div>
              <span className="font-extrabold text-base tracking-tight text-white block leading-tight">
                Depioro<span className="text-amber-400">.ai</span>
              </span>
              <span className="text-[10px] text-amber-200/70 font-medium tracking-wide">
                GovTech Intelligence
              </span>
            </div>
          </div>

          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-slate-400 hover:text-white p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sidebar Nav Items */}
        <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold text-amber-400/80 uppercase tracking-widest">
            Core Modules
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentRoute === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentRoute(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white font-bold shadow-sm shadow-amber-900/30 ring-1 ring-amber-400/30'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-amber-200'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-100' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                      isActive ? 'bg-amber-800 text-amber-100' : 'bg-slate-800 text-amber-300 border border-amber-500/20'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {item.count !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                      isActive ? 'bg-amber-800 text-amber-100' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {(item.count ?? 0).toLocaleString()}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User Role Profile Box */}
        <div className="p-4 border-t border-slate-800">
          <div className="bg-slate-800/60 p-3 rounded-xl border border-amber-900/30 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-amber-200/70">Active Profile</span>
              <span className="text-amber-400 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                Verified
              </span>
            </div>
            <div className="text-xs font-bold text-white truncate">
              {activeRole === 'policymaker'
                ? 'Min. Development Office'
                : activeRole === 'admin'
                ? 'System Lead Administrator'
                : 'Citizen Ingestion Mode'}
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-700/50">
              <span>Madhya Pradesh, IN</span>
              <span className="font-mono text-amber-300/80">DP-992</span>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN VIEWPORT */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* TOP TECHNICAL HEADER */}
        <header className="h-16 bg-white border-b border-amber-950/10 px-4 sm:px-8 flex items-center justify-between shrink-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-amber-900 hover:bg-amber-50"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 uppercase tracking-tight">
                {getPageTitle()}
              </h2>
              <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                <span>Region: <strong className="text-amber-800 font-semibold">Madhya Pradesh</strong></span>
                <span>|</span>
                <span>Data Status: Live (Demo Ingestion)</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Live AI Status Pill */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-amber-50/80 text-amber-800 border border-amber-200/80 rounded-full text-xs font-semibold">
              <AdvancedAnimatedIcon name="live-radar" size="xs" glow={false} />
              <span>AI Processor Active</span>
            </div>

            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 hover:border-amber-300 bg-white hover:bg-amber-50/50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors"
              >
                <Globe className="w-3.5 h-3.5 text-amber-600" />
                <span>{currentLangObj.nativeName}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {langDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-amber-100 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onClick={() => setLangDropdownOpen(false)}
                >
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                    Language / भाषा
                  </div>
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setSelectedLanguage(lang.code as LanguageCode)}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                        selectedLanguage === lang.code
                          ? 'bg-amber-50 text-amber-800 font-bold'
                          : 'text-slate-700 hover:bg-amber-50/50'
                      }`}
                    >
                      <span className="font-medium">{lang.nativeName}</span>
                      <span className="text-[11px] text-slate-400">{lang.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Action Button */}
            {currentRoute !== 'citizen' && (
              <button
                onClick={() => setCurrentRoute('citizen')}
                className="px-3.5 py-1.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white rounded-lg text-xs font-semibold shadow-xs shadow-amber-900/20 flex items-center gap-1.5 transition-all"
              >
                <Mic className="w-3.5 h-3.5 text-amber-200" />
                <span className="hidden sm:inline">Report Issue</span>
              </button>
            )}

            {currentRoute !== 'dashboard' && (
              <button
                onClick={() => setCurrentRoute('dashboard')}
                className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-all"
              >
                <BarChart3 className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Dashboard</span>
              </button>
            )}
          </div>
        </header>

        {/* Animated Scroll Progress Bar */}
        <div className="w-full h-1 bg-amber-950/5 relative overflow-hidden shrink-0">
          <div
            className="h-full bg-gradient-to-r from-amber-700 via-amber-500 to-yellow-500 transition-all duration-100 ease-out"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>

        {/* SCROLLABLE MAIN CONTENT AREA */}
        <main
          ref={mainRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto scroll-smooth bg-slate-100/70 p-4 sm:p-6 lg:p-8 space-y-6 relative"
        >
          {renderCurrentView()}

          {/* Floating Back to Top Button */}
          <AnimatePresence>
            {showScrollTop && (
              <motion.button
                initial={{ opacity: 0, scale: 0.7, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.7, y: 15 }}
                transition={{ duration: 0.2 }}
                onClick={scrollToTop}
                aria-label="Scroll to top"
                className="fixed bottom-12 right-6 sm:right-8 z-40 p-3 rounded-full bg-slate-900 text-amber-400 hover:bg-amber-600 hover:text-white shadow-2xl border border-amber-500/40 transition-all flex items-center justify-center cursor-pointer group hover:scale-105 active:scale-95"
              >
                <ArrowUp className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform" />
              </motion.button>
            )}
          </AnimatePresence>
        </main>

        {/* TECHNICAL TELEMETRY STATUS BAR FOOTER */}
        <footer className="h-8 bg-slate-900 text-slate-400 text-[10px] flex items-center justify-between px-4 sm:px-8 border-t border-slate-800 uppercase tracking-widest font-medium shrink-0">
          <div className="flex items-center gap-3 sm:gap-4">
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> System: Normal
            </span>
            <span className="hidden sm:inline text-slate-600">|</span>
            <span className="hidden sm:inline">Encrypted Data Flow</span>
            <span className="hidden sm:inline text-slate-600">|</span>
            <span>Session ID: DP-992-AIX</span>
          </div>
          <div>© 2026 Depioro.ai • Citizen Development Intelligence India</div>
        </footer>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <DepioroProvider>
      <TechnicalDashboardLayout />
    </DepioroProvider>
  );
}


