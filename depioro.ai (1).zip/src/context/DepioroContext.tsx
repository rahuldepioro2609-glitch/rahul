import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  CitizenRequest,
  DemandHotspot,
  AIRecommendation,
  LanguageCode,
  IssueCategory,
  UrgencyLevel,
} from '../types';
import {
  INITIAL_REQUESTS,
  INITIAL_HOTSPOTS,
  INITIAL_RECOMMENDATIONS,
  LANGUAGES,
} from '../data/mockData';

interface DepioroContextType {
  requests: CitizenRequest[];
  hotspots: DemandHotspot[];
  recommendations: AIRecommendation[];
  selectedLanguage: LanguageCode;
  setSelectedLanguage: (lang: LanguageCode) => void;
  activeRole: 'citizen' | 'policymaker' | 'admin';
  setActiveRole: (role: 'citizen' | 'policymaker' | 'admin') => void;
  currentRoute: string;
  setCurrentRoute: (route: string) => void;
  selectedDistrict: string;
  setSelectedDistrict: (district: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedHotspot: DemandHotspot | null;
  setSelectedHotspot: (hotspot: DemandHotspot | null) => void;
  selectedRecommendation: AIRecommendation | null;
  setSelectedRecommendation: (rec: AIRecommendation | null) => void;
  inspectingRequest: CitizenRequest | null;
  setInspectingRequest: (req: CitizenRequest | null) => void;
  stats: {
    totalRequests: number;
    highPriorityCount: number;
    highPriorityIssues: number;
    hotspotsCount: number;
    aiRecommendationsCount: number;
  };
  addCitizenRequest: (newReq: Omit<CitizenRequest, 'id' | 'submittedAt' | 'similarNearbyCount'>) => Promise<CitizenRequest>;
  updateRequestStatus: (id: string, newStatus: CitizenRequest['status']) => void;
  resetToInitialDemoData: () => void;
  toastMessage: string | null;
  setToastMessage: (msg: string | null) => void;
}

const DepioroContext = createContext<DepioroContextType | undefined>(undefined);

const STORAGE_KEYS = {
  REQUESTS: 'depioro_requests_v1',
  HOTSPOTS: 'depioro_hotspots_v1',
  RECS: 'depioro_recs_v1',
};

export const DepioroProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode>('hi');
  const [activeRole, setActiveRole] = useState<'citizen' | 'policymaker' | 'admin'>('citizen');
  const [currentRoute, setCurrentRoute] = useState<string>('home');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedHotspot, setSelectedHotspot] = useState<DemandHotspot | null>(null);
  const [selectedRecommendation, setSelectedRecommendation] = useState<AIRecommendation | null>(null);
  const [inspectingRequest, setInspectingRequest] = useState<CitizenRequest | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [requests, setRequests] = useState<CitizenRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REQUESTS);
      return saved ? JSON.parse(saved) : INITIAL_REQUESTS;
    } catch {
      return INITIAL_REQUESTS;
    }
  });

  const [hotspots, setHotspots] = useState<DemandHotspot[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HOTSPOTS);
      return saved ? JSON.parse(saved) : INITIAL_HOTSPOTS;
    } catch {
      return INITIAL_HOTSPOTS;
    }
  });

  const [recommendations, setRecommendations] = useState<AIRecommendation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.RECS);
      return saved ? JSON.parse(saved) : INITIAL_RECOMMENDATIONS;
    } catch {
      return INITIAL_RECOMMENDATIONS;
    }
  });

  // Save to LocalStorage whenever modified
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [requests]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.HOTSPOTS, JSON.stringify(hotspots));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [hotspots]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.RECS, JSON.stringify(recommendations));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [recommendations]);

  // Derived KPI Stats
  const baseBaseline = 12482;
  const userAddedCount = requests.length - INITIAL_REQUESTS.length;
  const totalRequests = baseBaseline + Math.max(0, userAddedCount);
  const highPriorityCount = 3240 + requests.filter((r) => r.priority === 'Critical' || r.priority === 'High').length - 5;
  const hotspotsCount = hotspots.length;
  const aiRecommendationsCount = recommendations.length;

  const addCitizenRequest = async (
    reqData: Omit<CitizenRequest, 'id' | 'submittedAt' | 'similarNearbyCount'>
  ): Promise<CitizenRequest> => {
    const newId = `DEP-MP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
      now.getDate()
    ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newRequest: CitizenRequest = {
      ...reqData,
      id: newId,
      submittedAt: formattedDate,
      similarNearbyCount: Math.floor(Math.random() * 30) + 127,
    };

    // Add to requests list (front)
    setRequests((prev) => [newRequest, ...prev]);

    // Update or link to hotspot in the district
    setHotspots((prevHotspots) => {
      const matchIndex = prevHotspots.findIndex(
        (h) =>
          h.district.toLowerCase() === newRequest.district.toLowerCase() &&
          (h.topIssue.toLowerCase() === newRequest.category.toLowerCase() || prevHotspots.length < 5)
      );

      if (matchIndex >= 0) {
        const updated = [...prevHotspots];
        const current = updated[matchIndex];
        updated[matchIndex] = {
          ...current,
          requestsCount: current.requestsCount + 1,
          affectedPopulation: current.affectedPopulation + Math.floor(Math.random() * 50) + 15,
          priorityScore: Math.min(99, current.priorityScore + 1),
          severity: current.priorityScore >= 88 ? 'Critical' : current.severity,
          recentTrend: `+${parseInt(current.recentTrend) || 28}% surging`,
          activeRequests: [newId, ...current.activeRequests],
        };
        return updated;
      } else {
        // Create new dynamic hotspot if none exists for this district
        const newHotspot: DemandHotspot = {
          id: `hotspot-${newRequest.district.toLowerCase().replace(/\s+/g, '-')}`,
          district: newRequest.district,
          state: newRequest.state || 'Madhya Pradesh',
          topIssue: newRequest.category,
          requestsCount: 42,
          affectedPopulation: newRequest.affectedPopulation || 18000,
          infrastructureScore: 48,
          priorityScore: 84,
          severity: newRequest.priority,
          lat: newRequest.lat || 24.5,
          lng: newRequest.lng || 78.0,
          x: Math.floor(Math.random() * 50) + 25,
          y: Math.floor(Math.random() * 50) + 25,
          topKeywords: newRequest.keywords,
          recentTrend: '+100% newly emerged',
          recommendedProject: `${newRequest.district} Rapid ${newRequest.category} Augmentation Initiative`,
          schemes: ['State Emergency Infrastructure Grant', 'Centrally Sponsored Scheme'],
          activeRequests: [newId],
        };
        return [newHotspot, ...prevHotspots];
      }
    });

    setToastMessage(`Development request ${newId} submitted and clustered into Intelligence Engine!`);
    setTimeout(() => setToastMessage(null), 5000);

    return newRequest;
  };

  const updateRequestStatus = (id: string, newStatus: CitizenRequest['status']) => {
    setRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: newStatus } : r))
    );
    setToastMessage(`Request #${id} status updated to: ${newStatus}`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const resetToInitialDemoData = () => {
    setRequests(INITIAL_REQUESTS);
    setHotspots(INITIAL_HOTSPOTS);
    setRecommendations(INITIAL_RECOMMENDATIONS);
    localStorage.removeItem(STORAGE_KEYS.REQUESTS);
    localStorage.removeItem(STORAGE_KEYS.HOTSPOTS);
    localStorage.removeItem(STORAGE_KEYS.RECS);
    setToastMessage('Reset system data to initial Indian civic baseline dataset.');
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <DepioroContext.Provider
      value={{
        requests,
        hotspots,
        recommendations,
        selectedLanguage,
        setSelectedLanguage,
        activeRole,
        setActiveRole,
        currentRoute,
        setCurrentRoute,
        selectedDistrict,
        setSelectedDistrict,
        selectedCategory,
        setSelectedCategory,
        selectedHotspot,
        setSelectedHotspot,
        selectedRecommendation,
        setSelectedRecommendation,
        inspectingRequest,
        setInspectingRequest,
        stats: {
          totalRequests: totalRequests || 12482,
          highPriorityCount: highPriorityCount || 3240,
          highPriorityIssues: highPriorityCount || 3240,
          hotspotsCount: hotspotsCount || hotspots.length,
          aiRecommendationsCount: aiRecommendationsCount || recommendations.length,
        },
        addCitizenRequest,
        updateRequestStatus,
        resetToInitialDemoData,
        toastMessage,
        setToastMessage,
      }}
    >
      {children}
    </DepioroContext.Provider>
  );
};

export const useDepioro = () => {
  const context = useContext(DepioroContext);
  if (!context) {
    throw new Error('useDepioro must be used within a DepioroProvider');
  }
  return context;
};
