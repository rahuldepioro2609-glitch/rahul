import React from 'react';
import { motion } from 'motion/react';
import { useApp, NavigationTab } from '../../context/AppContext';
import {
  LayoutDashboard,
  Video,
  FileText,
  FileSpreadsheet,
  UserCheck,
  CreditCard,
  CalendarCheck,
  BookOpen,
  Bus,
  Users,
  Sparkles,
  CheckCircle2,
  BookMarked,
  Palette,
  Settings,
  ShieldCheck,
  Award,
  LogOut,
  X,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen = false, onClose }) => {
  const { activeTab, setActiveTab, user, tenant, setIsAuthModalOpen } = useApp();

  interface NavItem {
    id: NavigationTab;
    label: string;
    icon: React.ElementType;
    badge?: string;
    roles?: ('super_admin' | 'educator' | 'student')[];
  }

  interface NavSection {
    sectionTitle: string;
    items: NavItem[];
  }

  const navSections: NavSection[] = [
    {
      sectionTitle: 'Academic Hub',
      items: [
        { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'live_classes', label: 'Live Class & VOD', icon: Video, badge: 'LIVE' },
        { id: 'resources', label: 'Resources & Notes', icon: FileText },
        { id: 'assessments', label: 'Assessments & CBT', icon: FileSpreadsheet }
      ]
    },
    {
      sectionTitle: 'Institution Ops',
      items: [
        { id: 'fees', label: 'Fees & Finance', icon: CreditCard },
        { id: 'attendance', label: 'Attendance & Biometrics', icon: CalendarCheck },
        { id: 'admissions', label: 'Admissions Desk', icon: UserCheck, roles: ['super_admin', 'educator'] },
        { id: 'id_report_cards', label: 'ID & Report Cards', icon: Award },
        { id: 'library_transport', label: 'Fleet & Library', icon: Bus },
        { id: 'crm_pipeline', label: 'CRM & Enquiries', icon: Users, roles: ['super_admin', 'educator'] }
      ]
    },
    {
      sectionTitle: 'AI Suite',
      items: [
        { id: 'ai_paper_gen', label: 'Paper Generator', icon: Sparkles, badge: 'AI', roles: ['super_admin', 'educator'] },
        { id: 'ai_evaluator', label: 'Auto-Evaluator', icon: CheckCircle2, badge: 'AI', roles: ['super_admin', 'educator'] },
        { id: 'ai_lesson_planner', label: 'Lesson Planner', icon: BookMarked, badge: 'AI', roles: ['super_admin', 'educator'] },
        { id: 'ai_marketing_banner', label: 'Banner Creator', icon: Palette, badge: 'AI', roles: ['super_admin'] }
      ]
    },
    {
      sectionTitle: 'Configuration',
      items: [
        { id: 'whitelabel_settings', label: 'White-Label Branding', icon: Settings, roles: ['super_admin'] }
      ]
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden transition-opacity"
        />
      )}

      <aside
        className={`fixed lg:static top-0 left-0 bottom-0 z-40 w-64 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex flex-col shrink-0 transition-transform duration-200 ease-in-out select-none border-r border-sky-100 dark:border-slate-800 shadow-xs ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Block with White & Soft Sky Blue Accents */}
        <div className="p-5 border-b border-sky-50 dark:border-slate-800 flex items-center justify-between bg-gradient-to-b from-sky-50/40 to-transparent dark:from-transparent">
          <div 
            onClick={() => setActiveTab('overview')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <motion.div 
              whileHover={{ scale: 1.05, rotate: 2 }}
              whileTap={{ scale: 0.96 }}
              className="w-9 h-9 rounded-xl flex items-center justify-center font-black text-white text-base shadow-sm bg-gradient-to-br from-sky-500 via-sky-600 to-blue-600 relative overflow-hidden"
            >
              <span className="relative z-10">S</span>
              <div className="absolute inset-0 bg-white/15 opacity-0 group-hover:opacity-100 transition-opacity" />
            </motion.div>
            <div className="overflow-hidden">
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-black tracking-tight block leading-tight text-slate-900 dark:text-white">
                  Sabio<span className="text-sky-600 dark:text-sky-400">Mind</span>
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-sky-500 animate-pulse" />
              </div>
              <span className="text-[10px] text-sky-700/80 dark:text-sky-400/80 font-mono tracking-wider font-semibold truncate block">
                {tenant.code} &bull; Enterprise
              </span>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 text-slate-400 hover:text-sky-600 rounded-lg hover:bg-sky-50 dark:hover:bg-slate-800 transition-colors"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation Section Links */}
        <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto scrollbar-thin">
          {navSections.map((section, idx) => {
            const visibleItems = section.items.filter(
              item => !item.roles || item.roles.includes(user.role)
            );

            if (visibleItems.length === 0) return null;

            return (
              <div key={idx} className={idx > 0 ? 'mt-5' : ''}>
                <div className="text-[10px] font-bold text-sky-900/60 dark:text-sky-400/60 uppercase tracking-widest mb-1.5 px-3">
                  {section.sectionTitle}
                </div>
                <div className="space-y-0.5">
                  {visibleItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;

                    return (
                      <motion.button
                        key={item.id}
                        whileHover={{ x: 2 }}
                        whileTap={{ scale: 0.99 }}
                        onClick={() => {
                          setActiveTab(item.id);
                          if (onClose) onClose();
                        }}
                        className={`w-full relative flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isActive
                            ? 'text-sky-900 dark:text-sky-100 font-bold bg-sky-50/90 dark:bg-sky-950/50 border border-sky-200/90 dark:border-sky-800/80 shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-sky-800 dark:hover:text-sky-300 hover:bg-sky-50/50 dark:hover:bg-slate-800/60 border border-transparent'
                        }`}
                      >
                        {/* Active left indicator accent */}
                        {isActive && (
                          <motion.div
                            layoutId="sidebarActivePill"
                            className="absolute left-1 top-1.5 bottom-1.5 w-1 rounded-full bg-sky-500 shadow-xs"
                            transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                          />
                        )}

                        <div className="flex items-center gap-2.5 truncate pl-1.5">
                          <Icon
                            className={`w-4 h-4 shrink-0 transition-colors ${
                              isActive
                                ? 'text-sky-600 dark:text-sky-400'
                                : 'text-slate-400 group-hover:text-sky-500'
                            }`}
                          />
                          <span className="truncate">{item.label}</span>
                        </div>

                        {item.badge && (
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase font-mono tracking-wider ${
                              item.badge === 'LIVE'
                                ? 'bg-rose-50 text-rose-600 border border-rose-200 animate-pulse'
                                : 'bg-sky-100 text-sky-700 border border-sky-200'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </nav>

        {/* Verified User Card at Bottom with White & Little Blue Theme */}
        <div className="p-3 border-t border-sky-100/80 dark:border-slate-800 bg-gradient-to-t from-sky-50/30 to-transparent dark:from-transparent">
          <motion.div 
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsAuthModalOpen(true)}
            className="flex items-center gap-2.5 bg-sky-50/60 dark:bg-slate-800/60 hover:bg-sky-50 dark:hover:bg-slate-800 p-2.5 rounded-xl cursor-pointer transition-all border border-sky-200/60 dark:border-slate-700 shadow-2xs group"
            title="Click to manage login or OTP"
          >
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white shrink-0 shadow-xs bg-gradient-to-br from-sky-500 to-blue-600"
            >
              {user.name.split(' ').map(n => n[0]).join('').slice(0, 2) || 'SA'}
            </div>
            <div className="flex-1 overflow-hidden text-left">
              <p className="text-xs font-bold truncate text-slate-800 dark:text-slate-200 group-hover:text-sky-700 transition-colors">
                {user.phoneNumber}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                  Verified (OTP)
                </p>
              </div>
            </div>
            <LogOut className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-600 transition-colors" />
          </motion.div>
        </div>
      </aside>
    </>
  );
};

