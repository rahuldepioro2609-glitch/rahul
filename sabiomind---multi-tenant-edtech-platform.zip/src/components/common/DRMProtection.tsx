import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, ShieldAlert, X } from 'lucide-react';

export const DRMProtection: React.FC = () => {
  const { drmActive, user, tenant, securityNotice, triggerSecurityBreachNotice, clearSecurityNotice } = useApp();
  const [isWindowBlurred, setIsWindowBlurred] = useState(false);

  useEffect(() => {
    if (!drmActive) return;

    // Prevent context menu (right click)
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      triggerSecurityBreachNotice('Right-click context menu is disabled by SabioMind DRM Anti-Piracy Policy.');
    };

    // Prevent keyboard shortcuts: Ctrl+P / Cmd+P (Print), Ctrl+S (Save), Ctrl+Shift+I / F12 (Inspect)
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCmdOrCtrl = e.ctrlKey || e.metaKey;

      if (isCmdOrCtrl && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        triggerSecurityBreachNotice('Printing and export are restricted under institutional DRM anti-piracy rules.');
      } else if (isCmdOrCtrl && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        triggerSecurityBreachNotice('Local file saving is disabled to protect proprietary curriculum assets.');
      } else if (e.key === 'F12' || (isCmdOrCtrl && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'C' || e.key === 'c'))) {
        e.preventDefault();
        triggerSecurityBreachNotice('Developer tools access is restricted in secure DRM examination/content mode.');
      }
    };

    // Deterrent when switching tabs / launching screen capture
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsWindowBlurred(true);
      } else {
        setIsWindowBlurred(false);
      }
    };

    const handleBlur = () => {
      setIsWindowBlurred(true);
    };

    const handleFocus = () => {
      setIsWindowBlurred(false);
    };

    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('focus', handleFocus);

    return () => {
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('focus', handleFocus);
    };
  }, [drmActive, triggerSecurityBreachNotice]);

  if (!drmActive) return null;

  const watermarkString = `${tenant.code} • ${user.phoneNumber} • ${user.studentId || 'SECURE'} • ${new Date().toLocaleDateString()}`;

  return (
    <>
      {/* Tiled diagonal dynamic watermark across application */}
      <div 
        className="pointer-events-none fixed inset-0 z-40 select-none overflow-hidden opacity-10 dark:opacity-15"
        style={{ mixBlendMode: 'difference' }}
      >
        <div className="flex flex-wrap w-[150vw] -ml-[25vw] -mt-[10vh] rotate-[-22deg] gap-16 text-xs font-mono font-bold tracking-widest text-slate-800 dark:text-slate-200">
          {Array.from({ length: 48 }).map((_, i) => (
            <div key={i} className="whitespace-nowrap px-4 py-2 border border-dashed border-slate-500/20 rounded">
              {watermarkString}
            </div>
          ))}
        </div>
      </div>

      {/* Screen blur deterrent overlay when window is blurred during sensitive content */}
      {isWindowBlurred && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md transition-all">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-xl p-6 text-center max-w-md mx-4 shadow-2xl">
            <Shield className="w-12 h-12 text-emerald-400 mx-auto mb-3 animate-pulse" />
            <h3 className="text-lg font-semibold text-white mb-2">DRM Content Guard Active</h3>
            <p className="text-sm text-slate-300 mb-4">
              Window focus was altered. In-app curriculum materials are encrypted and watermarked with your registered identifier ({user.phoneNumber}).
            </p>
            <p className="text-xs text-emerald-400 font-mono">
              Click anywhere inside the SabioMind portal to resume viewing.
            </p>
          </div>
        </div>
      )}

      {/* Security alert toast */}
      {securityNotice && (
        <div className="fixed bottom-6 right-6 z-50 flex items-start gap-3 bg-red-950/95 text-red-100 border border-red-500/50 rounded-lg p-4 shadow-2xl max-w-md animate-bounce">
          <ShieldAlert className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold text-sm text-red-200">Anti-Piracy Security Triggered</h4>
            <p className="text-xs text-red-300 mt-1 leading-relaxed">{securityNotice}</p>
          </div>
          <button 
            onClick={clearSecurityNotice}
            className="text-red-400 hover:text-white p-1 rounded transition-colors"
            title="Dismiss notice"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </>
  );
};
