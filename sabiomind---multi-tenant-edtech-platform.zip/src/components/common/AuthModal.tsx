import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { Shield, Phone, MessageSquare, Smartphone, CheckCircle, ArrowRight, X, AlertCircle } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, loginWithOtp, tenant } = useApp();
  const [phoneNumber, setPhoneNumber] = useState('+91 98765 43210');
  const [channel, setChannel] = useState<'sms' | 'whatsapp'>('whatsapp');
  const [selectedRole, setSelectedRole] = useState<UserRole>('super_admin');
  const [step, setStep] = useState<'input' | 'otp'>('input');
  const [otpCode, setOtpCode] = useState(['', '', '', '']);
  const [simulatedIncomingOtp, setSimulatedIncomingOtp] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(30);

  if (!isAuthModalOpen) return null;

  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.trim().length < 8) {
      setErrorMsg('Please enter a valid mobile phone number.');
      return;
    }
    setErrorMsg(null);
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setSimulatedIncomingOtp(code);
    setStep('otp');
    setCountdown(30);
  };

  const handleOtpChange = (index: number, val: string) => {
    if (val.length > 1) val = val[0];
    const newOtp = [...otpCode];
    newOtp[index] = val;
    setOtpCode(newOtp);

    // Auto focus next input
    if (val && index < 3) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleAutoFillOtp = () => {
    if (simulatedIncomingOtp) {
      setOtpCode(simulatedIncomingOtp.split(''));
    }
  };

  const handleVerify = () => {
    const entered = otpCode.join('');
    if (entered.length < 4) {
      setErrorMsg('Please enter the 4-digit code.');
      return;
    }
    if (simulatedIncomingOtp && entered !== simulatedIncomingOtp && entered !== '1234') {
      setErrorMsg(`Invalid verification code. Use ${simulatedIncomingOtp} or 1234.`);
      return;
    }

    loginWithOtp(phoneNumber, channel, selectedRole);
    setStep('input');
    setOtpCode(['', '', '', '']);
    setSimulatedIncomingOtp(null);
    setErrorMsg(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header with institute branding */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700/50 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-tight leading-none text-white">
                SabioMind Secure Gateway
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Passwordless OTP for {tenant.name}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {step === 'input' ? (
            <form onSubmit={handleRequestOtp} className="space-y-4">
              <div className="text-left">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  Institutional Mobile Number
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Zero password policy: Authentication token is dispatched via your preferred secure channel.
                </p>
              </div>

              {/* Delivery channel toggle */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  Verification Channel
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setChannel('whatsapp')}
                    className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                      channel === 'whatsapp'
                        ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 ring-1 ring-emerald-500'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-500" />
                    <span>WhatsApp OTP</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setChannel('sms')}
                    className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                      channel === 'sms'
                        ? 'bg-blue-500/10 border-blue-500 text-blue-600 dark:text-blue-400 ring-1 ring-blue-500'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-blue-500" />
                    <span>Direct SMS OTP</span>
                  </button>
                </div>
              </div>

              {/* Role selection */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                  Select Login Role
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { role: 'super_admin' as UserRole, label: 'Super Admin', sub: 'Director' },
                    { role: 'educator' as UserRole, label: 'Educator', sub: 'Teacher/Admin' },
                    { role: 'student' as UserRole, label: 'Student', sub: 'Learner/Parent' }
                  ].map(item => (
                    <button
                      key={item.role}
                      type="button"
                      onClick={() => setSelectedRole(item.role)}
                      className={`p-2.5 rounded-lg border text-left transition-all ${
                        selectedRole === item.role
                          ? 'border-indigo-500 bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 ring-1 ring-indigo-500'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-xs font-bold leading-tight">{item.label}</div>
                      <div className="text-[10px] opacity-75 mt-0.5">{item.sub}</div>
                    </button>
                  ))}
                </div>
              </div>

              {errorMsg && (
                <div className="flex items-center gap-2 p-2.5 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-600 dark:text-red-400">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg shadow-sm flex items-center justify-center gap-2 transition-colors text-sm"
              >
                <span>Send One-Time Passcode</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <div className="space-y-5">
              {/* Simulated notification banner */}
              {simulatedIncomingOtp && (
                <div 
                  onClick={handleAutoFillOtp}
                  className="cursor-pointer bg-slate-900 border border-emerald-500/40 rounded-xl p-3 text-white text-xs shadow-lg transition-transform hover:scale-[1.01]"
                >
                  <div className="flex items-center justify-between text-emerald-400 font-semibold mb-1">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5" />
                      {channel === 'whatsapp' ? 'WhatsApp Message Received' : 'SMS Notification'}
                    </span>
                    <span className="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded text-emerald-300">Click to Auto-Fill</span>
                  </div>
                  <p className="text-slate-300">
                    &quot;Your SabioMind OTP is <strong className="text-white font-mono text-sm bg-slate-800 px-1.5 py-0.5 rounded tracking-widest">{simulatedIncomingOtp}</strong> for {tenant.name}. Valid for 5 mins.&quot;
                  </p>
                </div>
              )}

              <div className="text-center">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Enter 4-digit code dispatched to <span className="font-semibold text-slate-800 dark:text-slate-200">{phoneNumber}</span> via {channel.toUpperCase()}
                </p>

                <div className="flex justify-center gap-3 my-4">
                  {otpCode.map((digit, idx) => (
                    <input
                      key={idx}
                      id={`otp-input-${idx}`}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      className="w-12 h-13 text-center font-mono text-xl font-bold rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  ))}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 px-2">
                  <span>Resend in {countdown}s</span>
                  <button
                    type="button"
                    onClick={() => {
                      const code = Math.floor(1000 + Math.random() * 9000).toString();
                      setSimulatedIncomingOtp(code);
                      setCountdown(30);
                    }}
                    className="text-emerald-500 hover:underline font-medium"
                  >
                    Resend Code
                  </button>
                </div>
              </div>

              {errorMsg && (
                <div className="flex items-center gap-2 p-2.5 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-600 dark:text-red-400">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('input')}
                  className="w-1/3 py-2.5 px-3 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium rounded-lg text-xs"
                >
                  Change Phone
                </button>
                <button
                  type="button"
                  onClick={handleVerify}
                  className="w-2/3 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg shadow-sm flex items-center justify-center gap-2 text-sm transition-colors"
                >
                  <span>Verify & Enter Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
