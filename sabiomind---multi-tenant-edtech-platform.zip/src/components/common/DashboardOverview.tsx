import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Video,
  IndianRupee,
  Sparkles,
  CheckCircle2,
  Lock,
  Play,
  ArrowRight,
  Bus,
  Award,
  Clock,
  ShieldCheck,
  TrendingUp,
  FileText,
  MapPin,
  Building,
  Activity,
  Radio
} from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.07
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 12 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.25, ease: 'easeOut' } }
};

export const DashboardOverview: React.FC = () => {
  const {
    tenant,
    user,
    setActiveTab,
    drmActive,
    setDrmActive,
    leads,
    liveClasses,
    fees
  } = useApp();

  const totalFeeCollected = fees.reduce((sum, f) => sum + f.paidAmount, 0);
  const liveClass = liveClasses[0] || {
    title: 'Advanced Calculus - Module 4',
    teacher: 'Prof. Satish Sharma',
    viewersCount: 842
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Top Banner / Breadcrumb info for mobile/tablet */}
      <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1 border-b border-sky-100/70 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black tracking-tight text-slate-900 dark:text-slate-100">
              Institutional Command Center
            </h2>
            <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
              Live Feed
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-1 font-medium">
            <MapPin className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />
            <span>{tenant.address || 'Campus'}, {tenant.city}, {tenant.state} - {tenant.pincode} &bull; Affiliation: {tenant.affiliationNumber || tenant.code}</span>
          </p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          <span className="bg-sky-50 dark:bg-slate-800 text-sky-800 dark:text-sky-300 text-[10px] px-2.5 py-1 rounded-lg font-mono uppercase tracking-wider border border-sky-200/80 dark:border-slate-700 font-bold shadow-2xs">
            {tenant.board || 'CBSE Board'}
          </span>
          <span className="bg-emerald-50 text-emerald-700 dark:text-emerald-400 text-[10px] px-2.5 py-1 rounded-lg font-mono uppercase tracking-wider flex items-center gap-1.5 border border-emerald-200 font-bold shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Online
          </span>
        </div>
      </motion.div>

      {/* Main 12-column grid from Professional Polish Design */}
      <div className="grid grid-cols-12 gap-6">
        {/* Left Column (8 cols) */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
          {/* Key Metric Stats Cards (3 cards) with White & Little Blue Theme */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Stat 1: Students Online */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -3, transition: { duration: 0.15 } }}
              className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs hover:border-sky-200 transition-colors"
            >
              <div className="flex items-center justify-between mb-1">
                <p className="text-slate-500 dark:text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                  Students Online
                </p>
                <Users className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              </div>
              <p className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                1,248
              </p>
              <div className="mt-2.5 h-1.5 bg-sky-50 dark:bg-slate-800 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '72%' }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="h-full rounded-full bg-gradient-to-r from-sky-500 to-blue-600 shadow-xs"
                />
              </div>
              <p className="text-[10px] text-sky-700 dark:text-sky-300 font-bold mt-2">
                72% attendance quota active
              </p>
            </motion.div>

            {/* Stat 2: Live Sessions */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -3, transition: { duration: 0.15 } }}
              className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs hover:border-sky-200 transition-colors"
            >
              <div className="flex items-center justify-between mb-1">
                <p className="text-slate-500 dark:text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                  Live Sessions
                </p>
                <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
              </div>
              <p className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                14
              </p>
              <div className="mt-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                <span className="text-[11px] text-slate-600 dark:text-slate-400 font-mono font-semibold">
                  4.2k Active Viewers
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 font-medium">
                DRM AES-128 stream active
              </p>
            </motion.div>

            {/* Stat 3: Fees Collected */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -3, transition: { duration: 0.15 } }}
              className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs hover:border-sky-200 transition-colors"
            >
              <div className="flex items-center justify-between mb-1">
                <p className="text-slate-500 dark:text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                  Fees Collected
                </p>
                <IndianRupee className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              </div>
              <p className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                ₹{(totalFeeCollected > 0 ? totalFeeCollected : 3850000).toLocaleString('en-IN')}
              </p>
              <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-2 font-bold flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>+18.4% this term (GST Verified)</span>
              </p>
            </motion.div>
          </div>

          {/* AI Automation Lab Card with White & Little Blue Theme */}
          <motion.div
            variants={itemVariants}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs overflow-hidden flex flex-col"
          >
            <div className="p-4 border-b border-sky-100/80 dark:border-slate-800 bg-sky-50/40 dark:bg-slate-800/40 flex justify-between items-center">
              <h2 className="text-sm font-black flex items-center gap-2 text-slate-900 dark:text-white">
                <span className="w-2 h-4 rounded-full inline-block bg-gradient-to-b from-sky-500 to-blue-600" />
                AI Academic Automation Lab
              </h2>
              <span className="text-[10px] font-mono text-sky-800 dark:text-sky-300 font-bold bg-sky-100/70 dark:bg-slate-800 px-2 py-0.5 rounded-full border border-sky-200">
                SabioMind v2.4
              </span>
            </div>

            <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Feature 1: Smart MCQ Generator */}
              <motion.div
                whileHover={{ scale: 1.01 }}
                className="flex items-start gap-4 p-4 rounded-xl bg-sky-50/30 dark:bg-slate-800/50 border border-sky-100 dark:border-slate-700/60 transition-all hover:bg-sky-50/60"
              >
                <div className="p-2.5 bg-sky-100 dark:bg-sky-950/80 rounded-xl text-sky-700 dark:text-sky-300 shrink-0 shadow-2xs">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Smart MCQ & Paper Studio
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Generate 50 CBSE/JEE question sets with Bloom's taxonomy in 4s.
                  </p>
                  <motion.button
                    whileTap={{ scale: 0.96 }}
                    onClick={() => setActiveTab('ai_paper_gen')}
                    className="mt-3 text-[10px] bg-sky-600 hover:bg-sky-700 text-white px-3.5 py-1.5 rounded-xl font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <span>Launch Generator</span>
                    <ArrowRight className="w-3 h-3" />
                  </motion.button>
                </div>
              </motion.div>

              {/* Feature 2: Answer Sheet Evaluator */}
              <motion.div
                whileHover={{ scale: 1.01 }}
                className="flex items-start gap-4 p-4 rounded-xl bg-sky-50/30 dark:bg-slate-800/50 border border-sky-100 dark:border-slate-700/60 transition-all hover:bg-sky-50/60"
              >
                <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/80 rounded-xl text-emerald-700 dark:text-emerald-300 shrink-0 shadow-2xs">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Vision Answer Evaluator
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Vision AI OCR grading for Term-1 handwritten exam papers.
                  </p>
                  <motion.button
                    whileTap={{ scale: 0.96 }}
                    onClick={() => setActiveTab('ai_evaluator')}
                    className="mt-3 text-[10px] bg-white dark:bg-slate-800 border border-sky-200 dark:border-slate-700 text-sky-900 dark:text-slate-100 px-3.5 py-1.5 rounded-xl font-bold uppercase tracking-wider hover:bg-sky-50 dark:hover:bg-slate-700 transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <span>Queue 85 Sheets</span>
                    <ArrowRight className="w-3 h-3" />
                  </motion.button>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Row: Live Stream Spotlight & Anti-Piracy DRM Card */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Live Stream Spotlight with Deep Azure Blue styling */}
            <motion.div
              variants={itemVariants}
              whileHover={{ y: -2 }}
              className="bg-gradient-to-br from-slate-900 via-sky-950 to-blue-950 text-white p-5 rounded-2xl flex items-center justify-between border border-sky-900/50 shadow-sm relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />
              <div className="space-y-1 relative z-10">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  <p className="text-[10px] text-sky-300 font-bold uppercase tracking-widest">
                    Current Live Stream
                  </p>
                </div>
                <h4 className="text-base font-bold mt-1 text-white">
                  {liveClass.title}
                </h4>
                <p className="text-xs text-sky-200/80">
                  {liveClass.teacher} &bull; {liveClass.viewersCount} watching
                </p>
                <button
                  onClick={() => setActiveTab('live_classes')}
                  className="mt-2 text-xs text-sky-400 hover:text-sky-300 font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  Open Stream Console <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                onClick={() => setActiveTab('live_classes')}
                className="w-12 h-12 rounded-2xl bg-sky-600/30 border border-sky-400/30 flex items-center justify-center cursor-pointer hover:bg-sky-600/50 transition-all shrink-0 ml-4 shadow-sm"
                title="Enter Classroom"
              >
                <Play className="w-5 h-5 text-sky-300 ml-0.5 fill-sky-300" />
              </motion.button>
            </motion.div>

            {/* Anti-Piracy Status Banner */}
            <motion.div 
              variants={itemVariants}
              whileHover={{ y: -2 }}
              className={`p-5 rounded-2xl flex flex-col justify-between shadow-sm transition-all border text-white relative overflow-hidden ${
                drmActive
                  ? 'bg-gradient-to-br from-sky-700 via-blue-700 to-indigo-800 border-sky-500/40'
                  : 'bg-slate-800 border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <p className="text-[10px] text-sky-200 font-bold uppercase tracking-widest">
                  Anti-Piracy Status
                </p>
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-mono font-bold">
                  AES-128 DRM
                </span>
              </div>

              <div className="mt-3 flex items-center justify-between">
                <div>
                  <p className="text-xl font-bold">
                    {drmActive ? 'DRM Hardened' : 'DRM Paused'}
                  </p>
                  <p className="text-[10px] text-sky-100/90 mt-0.5">
                    {drmActive
                      ? 'Right-click, Download & Print Disabled'
                      : 'Protections temporarily lifted for testing'}
                  </p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setDrmActive(!drmActive)}
                  className="p-2.5 rounded-xl bg-white/15 hover:bg-white/25 transition-colors cursor-pointer"
                  title="Toggle DRM Protection"
                >
                  <Lock className="w-6 h-6 text-white" />
                </motion.button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Right Column (4 cols) */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          {/* Recent Enquiries (CRM) with White & Little Blue Theme */}
          <motion.div
            variants={itemVariants}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs p-5"
          >
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-sky-50 dark:border-slate-800">
              <h3 className="text-xs font-bold text-sky-900/70 dark:text-sky-400 uppercase tracking-wider">
                Recent Enquiries (CRM)
              </h3>
              <span className="text-[10px] font-mono text-sky-800 dark:text-sky-300 bg-sky-50 dark:bg-slate-800 px-2.5 py-0.5 rounded-full font-bold border border-sky-200/80">
                {leads.length} Active Leads
              </span>
            </div>

            <div className="space-y-3">
              {leads.slice(0, 3).map((lead, idx) => {
                const colors = [
                  { bg: 'bg-sky-50 dark:bg-sky-950/50', text: 'text-sky-700 dark:text-sky-300' },
                  { bg: 'bg-blue-50 dark:bg-blue-950/50', text: 'text-blue-700 dark:text-blue-300' },
                  { bg: 'bg-cyan-50 dark:bg-cyan-950/50', text: 'text-cyan-700 dark:text-cyan-300' }
                ];
                const color = colors[idx % colors.length];
                const initials = lead.studentName
                  .split(' ')
                  .map(n => n[0])
                  .join('')
                  .slice(0, 2);

                return (
                  <motion.div
                    key={lead.id}
                    whileHover={{ x: 2 }}
                    className="flex items-center gap-3 p-2 rounded-xl hover:bg-sky-50/40 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <div className={`w-9 h-9 rounded-xl ${color.bg} ${color.text} flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs`}>
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {lead.studentName}
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 italic truncate">
                        {lead.targetGrade} &bull; {lead.stage}
                      </p>
                    </div>
                    <span className="text-[9px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-600 dark:text-slate-400 shrink-0 font-mono">
                      {lead.lastUpdated}
                    </span>
                  </motion.div>
                );
              })}
            </div>

            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab('crm_pipeline')}
              className="w-full mt-4 py-2 bg-sky-50/70 hover:bg-sky-100/70 dark:bg-slate-800 dark:hover:bg-slate-700 border border-sky-200/80 dark:border-slate-700 rounded-xl text-xs font-bold text-sky-800 dark:text-sky-300 transition-colors cursor-pointer"
            >
              View Pipeline
            </motion.button>
          </motion.div>

          {/* Fleet & Transport Card */}
          <motion.div
            variants={itemVariants}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-sky-100 dark:border-slate-800 shadow-xs p-5"
          >
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-sky-50 dark:border-slate-800">
              <h3 className="text-xs font-bold text-sky-900/70 dark:text-sky-400 uppercase tracking-wider">
                Fleet & Transport GPS
              </h3>
              <button
                onClick={() => setActiveTab('library_transport')}
                className="text-[10px] text-sky-600 dark:text-sky-400 font-bold hover:underline cursor-pointer"
              >
                Live Tracking &rarr;
              </button>
            </div>

            <div className="space-y-4">
              {/* Route 1 */}
              <div>
                <div className="flex justify-between text-[10px] font-bold mb-1.5 text-slate-700 dark:text-slate-300">
                  <span>Route 04 (South Campus)</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">On Time</span>
                </div>
                <div className="h-1.5 bg-sky-50 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 w-[60%] rounded-full" />
                </div>
              </div>

              {/* Route 2 */}
              <div>
                <div className="flex justify-between text-[10px] font-bold mb-1.5 text-slate-700 dark:text-slate-300">
                  <span>Route 12 (City Center)</span>
                  <span className="text-amber-600 dark:text-amber-400 font-bold">Delayed (5m)</span>
                </div>
                <div className="h-1.5 bg-sky-50 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 w-[45%] rounded-full" />
                </div>
              </div>
            </div>
          </motion.div>

          {/* ID & Report Card Studio Action Box */}
          <motion.div
            variants={itemVariants}
            whileHover={{ y: -2 }}
            className="bg-gradient-to-b from-sky-50/50 to-white dark:from-slate-900/60 dark:to-slate-900 border border-dashed border-sky-300 dark:border-slate-700 rounded-2xl p-5 flex flex-col items-center text-center shadow-xs"
          >
            <div className="w-11 h-11 bg-sky-100 dark:bg-sky-950/80 rounded-2xl flex items-center justify-center text-sky-700 dark:text-sky-300 mb-2 shadow-2xs">
              <Award className="w-6 h-6" />
            </div>
            <p className="text-xs font-black text-slate-900 dark:text-white">
              ID & Report Card Studio
            </p>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">
              32 batches pending print for {tenant.name}
            </p>
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={() => setActiveTab('id_report_cards')}
              className="mt-3 w-full bg-sky-600 hover:bg-sky-700 text-white py-2 rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              Bulk Generate
            </motion.button>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};
