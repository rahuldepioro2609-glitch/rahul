import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { TENANTS } from '../../data/mockData';
import { UserRole } from '../../types';
import {
  ShieldCheck,
  ShieldAlert,
  Sun,
  Moon,
  Building2,
  ChevronDown,
  Menu,
  Zap,
  GraduationCap,
  Atom,
  Check,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar }) => {
  const {
    tenant,
    setTenant,
    user,
    switchRole,
    theme,
    toggleTheme,
    drmActive,
    setDrmActive,
    activeTab
  } = useApp();

  const [isTenantMenuOpen, setIsTenantMenuOpen] = useState(false);
  const [isRoleMenuOpen, setIsRoleMenuOpen] = useState(false);

  const getTabTitle = () => {
    switch (activeTab) {
      case 'overview':
        return user.role === 'super_admin' ? 'Super Admin Dashboard' : user.role === 'educator' ? 'Educator Command Desk' : 'Student Academic Hub';
      case 'live_classes':
        return 'Live Classroom & VODs';
      case 'resources':
        return 'Protected Digital Repository';
      case 'assessments':
        return 'Computer-Based Testing (CBT)';
      case 'admissions':
        return 'Admissions & Onboarding Portal';
      case 'id_report_cards':
        return 'ID Badges & Term Report Cards';
      case 'fees':
        return 'Institutional Fee Ledger';
      case 'attendance':
        return 'Biometric Attendance Tracker';
      case 'library_transport':
        return 'Fleet GPS & Library Catalog';
      case 'crm_pipeline':
        return 'Prospective Student CRM';
      case 'ai_paper_gen':
        return 'AI Exam Paper & MCQ Studio';
      case 'ai_evaluator':
        return 'AI Vision Answer Evaluator';
      case 'ai_lesson_planner':
        return 'AI Curriculum & Lesson Planner';
      case 'ai_marketing_banner':
        return 'AI Marketing & Social Banner Studio';
      case 'whitelabel_settings':
        return 'White-Label & Domain Settings';
      default:
        return 'Institution Dashboard';
    }
  };

  return (
    <header className="h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-sky-100 dark:border-slate-800 px-4 sm:px-8 flex items-center justify-between shrink-0 transition-colors z-30 shadow-2xs">
      {/* Left section: Hamburger for mobile + Active View Title + Multi-Tenant Badge */}
      <div className="flex items-center gap-3 sm:gap-4">
        {onToggleSidebar && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-sky-50 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5 text-sky-700 dark:text-sky-400" />
          </motion.button>
        )}

        <div className="flex items-center gap-3">
          <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate tracking-tight">
            {getTabTitle()}
          </h1>

          {/* Multi-Tenant Active Pill Badge with drop-down */}
          <div className="relative hidden md:block">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setIsTenantMenuOpen(!isTenantMenuOpen)}
              className="bg-sky-50 hover:bg-sky-100/80 dark:bg-slate-800 dark:hover:bg-slate-700 text-sky-800 dark:text-sky-300 text-[10px] px-2.5 py-1 rounded-full font-mono uppercase tracking-wider flex items-center gap-1.5 transition-all border border-sky-200/80 dark:border-slate-700 shadow-2xs font-semibold cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-sky-500 animate-pulse" />
              <span>Multi-Tenant: ACTIVE</span>
              <ChevronDown className={`w-3 h-3 text-sky-600 dark:text-sky-400 transition-transform ${isTenantMenuOpen ? 'rotate-180' : ''}`} />
            </motion.button>

            <AnimatePresence>
              {isTenantMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 6, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 4, scale: 0.97 }}
                  transition={{ duration: 0.15 }}
                  className="absolute left-0 mt-2 w-72 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-sky-100 dark:border-slate-700 py-2 z-50 overflow-hidden"
                >
                  <div className="px-3 py-1.5 text-[10px] font-bold text-sky-800/70 dark:text-sky-400 uppercase tracking-wider bg-sky-50/50 dark:bg-slate-900/50 border-b border-sky-50 dark:border-slate-700">
                    Switch Active Institutional Tenant
                  </div>
                  <div className="p-1">
                    {TENANTS.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => {
                          setTenant(t);
                          setIsTenantMenuOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center justify-between text-xs hover:bg-sky-50 dark:hover:bg-slate-700/70 transition-colors cursor-pointer ${
                          t.id === tenant.id
                            ? 'bg-sky-50 text-sky-900 dark:text-sky-300 font-bold border border-sky-200/70 dark:border-sky-900'
                            : 'text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="w-3 h-3 rounded-full shrink-0 shadow-xs" style={{ backgroundColor: t.primaryColor }} />
                          <div className="overflow-hidden">
                            <p className="truncate font-semibold">{t.name}</p>
                            <p className="text-[10px] text-slate-400 font-mono">{t.customDomain}</p>
                          </div>
                        </div>
                        {t.id === tenant.id && <Check className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Right Section: DRM Guard + Divider + Institutional Brand Info + Persona & Theme toggles */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* DRM Guard Status */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setDrmActive(!drmActive)}
          className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-sky-50/60 dark:hover:bg-slate-700/80 transition-all text-xs"
          title="Toggle DRM Anti-Piracy Guard"
        >
          <div className={`w-2 h-2 rounded-full ${drmActive ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 hidden sm:inline">
            {drmActive ? 'DRM Shielded' : 'DRM Paused'}
          </span>
        </motion.button>

        {/* Vertical Divider */}
        <div className="h-6 sm:h-8 w-px bg-sky-100 dark:bg-slate-800" />

        {/* Role Persona Switcher */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsRoleMenuOpen(!isRoleMenuOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-sky-200/80 dark:border-slate-700 bg-sky-50/50 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-sky-100/70 dark:hover:bg-slate-700/80 transition-all cursor-pointer shadow-2xs"
          >
            <span className="text-sky-800/60 dark:text-sky-400/60 hidden md:inline text-[11px] font-bold">Role:</span>
            <span className="font-bold capitalize text-sky-900 dark:text-white text-xs">
              {user.role === 'super_admin' ? 'Admin' : user.role === 'educator' ? 'Faculty' : 'Student'}
            </span>
            <ChevronDown className={`w-3 h-3 text-sky-600 dark:text-sky-400 transition-transform ${isRoleMenuOpen ? 'rotate-180' : ''}`} />
          </motion.button>

          <AnimatePresence>
            {isRoleMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: 6, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 4, scale: 0.97 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 mt-2 w-52 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-sky-100 dark:border-slate-700 p-1.5 z-50 overflow-hidden"
              >
                <div className="px-3 py-1 text-[10px] font-bold text-sky-800/70 dark:text-sky-400 uppercase tracking-wider">
                  Select Persona
                </div>
                {[
                  { role: 'super_admin' as UserRole, title: 'Super Admin', desc: 'Enterprise controls' },
                  { role: 'educator' as UserRole, title: 'Educator', desc: 'Grading & teaching' },
                  { role: 'student' as UserRole, title: 'Student', desc: 'VODs & exams' }
                ].map((item) => (
                  <button
                    key={item.role}
                    onClick={() => {
                      switchRole(item.role);
                      setIsRoleMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-sky-50 dark:hover:bg-slate-700 transition-colors cursor-pointer ${
                      user.role === item.role
                        ? 'font-bold text-sky-900 dark:text-sky-300 bg-sky-50/90 dark:bg-sky-950/40 border border-sky-200/60 dark:border-sky-900'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="font-bold">{item.title}</div>
                    <div className="text-[10px] text-slate-400">{item.desc}</div>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Theme Toggle Button */}
        <motion.button
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          onClick={toggleTheme}
          className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-sky-700 dark:hover:text-slate-200 hover:bg-sky-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Toggle theme"
          title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
        >
          {theme === 'dark' ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4 text-sky-700" />
          )}
        </motion.button>

        {/* Institutional Identifier matching White & Little Blue Design */}
        <div className="hidden lg:flex items-center gap-3 pl-1 border-l border-sky-100 dark:border-slate-800">
          <div className="text-right">
            <p className="text-xs font-bold text-slate-900 dark:text-slate-200 leading-tight">
              {tenant.name}
            </p>
            <p className="text-[10px] text-sky-700 dark:text-sky-400 font-mono font-semibold leading-tight">
              {tenant.code} &bull; Verified
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};

