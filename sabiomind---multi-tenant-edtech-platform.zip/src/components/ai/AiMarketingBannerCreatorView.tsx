import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Megaphone,
  Sparkles,
  Download,
  Calendar,
  Share2,
  Layers,
  Palette,
  Eye,
  CheckCircle,
  Plus
} from 'lucide-react';

interface CampaignSchedule {
  id: string;
  name: string;
  channel: 'Instagram' | 'WhatsApp Broadcast' | 'LinkedIn' | 'Campus Poster';
  scheduledDate: string;
  status: 'Scheduled' | 'Live' | 'Draft';
  targetAudience: string;
}

export const AiMarketingBannerCreatorView: React.FC = () => {
  const { tenant } = useApp();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Banner states
  const [headline, setHeadline] = useState('ADMISSIONS OPEN 2026 - 2027');
  const [subtitle, setSubtitle] = useState('Master JEE Advanced, NEET & Olympiads with India’s Top Faculty');
  const [callToAction, setCallToAction] = useState('Apply Online • Up to 100% Scholarship Test');
  const [badgeText, setBadgeText] = useState('SUPER 30 BATCH • LIMITED 60 SEATS');
  const [themeStyle, setThemeStyle] = useState<'navy' | 'indigo' | 'emerald'>('navy');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9'>('1:1');

  // Scheduled campaigns
  const [campaigns, setCampaigns] = useState<CampaignSchedule[]>([
    {
      id: 'CMP-101',
      name: 'All India Scholarship Entrance Test (AISET)',
      channel: 'Instagram',
      scheduledDate: 'Tomorrow, 10:00 AM',
      status: 'Scheduled',
      targetAudience: 'Parents of Grade 10 & 11 STEM aspirants'
    },
    {
      id: 'CMP-102',
      name: 'Olympiad Rankers Felicitation Announcement',
      channel: 'WhatsApp Broadcast',
      scheduledDate: 'Sept 15, 2026',
      status: 'Draft',
      targetAudience: 'Enrolled students & alumni network'
    },
    {
      id: 'CMP-103',
      name: 'Free Crash Course: Wave Optics & Calculus',
      channel: 'LinkedIn',
      scheduledDate: 'Sept 20, 2026',
      status: 'Live',
      targetAudience: 'Senior secondary students nationwide'
    }
  ]);

  // Render to dynamic HTML5 Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = aspectRatio === '1:1' ? 600 : 720;
    const height = aspectRatio === '1:1' ? 600 : 405;
    canvas.width = width;
    canvas.height = height;

    // Background gradient based on themeStyle
    let bgGrad = ctx.createLinearGradient(0, 0, width, height);
    if (themeStyle === 'navy') {
      bgGrad.addColorStop(0, '#0f172a');
      bgGrad.addColorStop(1, '#1e293b');
    } else if (themeStyle === 'indigo') {
      bgGrad.addColorStop(0, '#1e1b4b');
      bgGrad.addColorStop(1, '#312e81');
    } else {
      bgGrad.addColorStop(0, '#064e3b');
      bgGrad.addColorStop(1, '#022c22');
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Decorative geometric accents
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1.5;
    for (let r = 80; r < width; r += 90) {
      ctx.beginPath();
      ctx.arc(width * 0.85, height * 0.2, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Tenant Header Pill
    ctx.fillStyle = tenant.primaryColor;
    ctx.beginPath();
    ctx.roundRect(40, 40, 220, 44, 22);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 15px sans-serif';
    ctx.fillText(tenant.name.toUpperCase(), 58, 67);

    // Pill Badge (Top Right)
    ctx.fillStyle = 'rgba(245, 158, 11, 0.2)';
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(width - 260, 40, 220, 36, 18);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 11px monospace';
    ctx.fillText(badgeText, width - 248, 62);

    // Main Headline Text
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 32px sans-serif';
    ctx.fillText(headline, 40, height * 0.42);

    // Subtitle text (wrapped)
    ctx.fillStyle = '#cbd5e1';
    ctx.font = '16px sans-serif';
    ctx.fillText(subtitle, 40, height * 0.52);

    // Highlight Box for Call to Action
    const boxY = height * 0.64;
    const boxH = 70;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.07)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(40, boxY, width - 80, boxH, 16);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('⭐ ' + callToAction, 65, boxY + 41);

    // Footer Contact Info
    ctx.fillStyle = '#94a3b8';
    ctx.font = '13px monospace';
    ctx.fillText(`Official Portal: ${tenant.customDomain}  |  Helpline: ${tenant.supportPhone}`, 40, height - 35);

  }, [headline, subtitle, callToAction, badgeText, themeStyle, aspectRatio, tenant]);

  const handleDownloadBanner = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `sabiomind-marketing-banner-${Date.now()}.png`;
    link.href = url;
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <Megaphone className="w-6 h-6 text-indigo-500" />
            AI Marketing Planner & Social Banner Studio
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Dynamic HTML5 Canvas rendering for promotional social media banners and multi-channel campaign scheduler.
          </p>
        </div>

        <button
          onClick={handleDownloadBanner}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-sm flex items-center gap-2 self-start transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Download High-Res PNG</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Banner Studio Customizer (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Palette className="w-4 h-4 text-indigo-500" />
            Social Banner Creative Controls
          </h3>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Canvas Aspect Ratio</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAspectRatio('1:1')}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  aspectRatio === '1:1'
                    ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                    : 'border-slate-200 dark:border-slate-700 text-slate-500'
                }`}
              >
                1:1 Square (Instagram / Post)
              </button>
              <button
                type="button"
                onClick={() => setAspectRatio('16:9')}
                className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                  aspectRatio === '16:9'
                    ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                    : 'border-slate-200 dark:border-slate-700 text-slate-500'
                }`}
              >
                16:9 Landscape (Web / YouTube)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Color Atmosphere</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'navy', label: 'Deep Navy' },
                { id: 'indigo', label: 'Tech Indigo' },
                { id: 'emerald', label: 'Emerald Mint' }
              ].map(t => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setThemeStyle(t.id as any)}
                  className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                    themeStyle === t.id
                      ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                      : 'border-slate-200 dark:border-slate-700 text-slate-500'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Headline Text</label>
            <input
              type="text"
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Secondary Tagline / Subtitle</label>
            <input
              type="text"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Call to Action Highlight</label>
            <input
              type="text"
              value={callToAction}
              onChange={(e) => setCallToAction(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Urgency Pill Badge</label>
            <input
              type="text"
              value={badgeText}
              onChange={(e) => setBadgeText(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
            />
          </div>
        </div>

        {/* Live Canvas Preview (7 cols) */}
        <div className="lg:col-span-7 bg-slate-100 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col items-center justify-center shadow-inner">
          <div className="w-full flex items-center justify-between text-xs text-slate-400 mb-3">
            <span className="flex items-center gap-1.5 font-bold">
              <Eye className="w-3.5 h-3.5 text-indigo-500" />
              Live Vector Render Preview ({aspectRatio})
            </span>
            <span className="font-mono text-[11px]">Dynamic Institute Metadata: {tenant.name}</span>
          </div>

          <div className="w-full max-w-[540px] rounded-2xl overflow-hidden shadow-2xl border border-slate-300 dark:border-slate-700">
            <canvas
              ref={canvasRef}
              className="w-full h-auto block"
            />
          </div>
        </div>
      </div>

      {/* Multi-Channel Campaign Scheduler */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Multi-Channel Promotion Schedule
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Automated publishing pipeline across WhatsApp, Instagram, and web announcements.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400">
            {campaigns.length} Active Campaigns
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {campaigns.map((camp) => (
            <div
              key={camp.id}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 text-xs space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1.5">
                  <span className="font-mono">{camp.id}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full font-bold uppercase ${
                      camp.status === 'Live'
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                        : camp.status === 'Scheduled'
                        ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                        : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {camp.status}
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm leading-snug">
                  {camp.name}
                </h4>

                <p className="text-[11px] text-slate-500 mt-1">
                  Target: {camp.targetAudience}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                  {camp.channel}
                </span>
                <span className="text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {camp.scheduledDate}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
