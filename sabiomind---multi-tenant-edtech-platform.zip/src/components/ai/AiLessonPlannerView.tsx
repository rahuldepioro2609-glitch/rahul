import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BookMarked,
  Sparkles,
  Calendar,
  Printer,
  CheckCircle,
  Clock,
  Target,
  RefreshCw,
  Compass,
  FileSpreadsheet
} from 'lucide-react';

interface DayPlan {
  day: string;
  focus: string;
  outcomes: string[];
  instruction: string;
  practice: string;
  exitTicket: string;
}

export const AiLessonPlannerView: React.FC = () => {
  const { tenant } = useApp();
  const [subject, setSubject] = useState('Physics');
  const [grade, setGrade] = useState('Grade 12 - Senior STEM Track');
  const [unitTitle, setUnitTitle] = useState('Thermodynamics & Heat Engines');
  const [isGenerating, setIsGenerating] = useState(false);

  const [weeklyPlans, setWeeklyPlans] = useState<DayPlan[]>([
    {
      day: 'Monday (Day 1)',
      focus: 'First Law of Thermodynamics & P-V Work Diagrams',
      outcomes: [
        'State the first law ΔU = Q - W mathematically with sign conventions.',
        'Calculate mechanical work done by integrating under P-V indicator diagrams.'
      ],
      instruction: 'Derivation of work done in isobaric, isochoric, and isothermal thermodynamic processes using live interactive visualizer.',
      practice: 'Paired problem set calculating net work in cyclic clockwise and counter-clockwise thermodynamic loops.',
      exitTicket: 'Derive work done in an isothermal expansion W = nRT ln(V₂/V₁).'
    },
    {
      day: 'Tuesday (Day 2)',
      focus: 'Adiabatic Expansions & Polytropic Gas Processes',
      outcomes: [
        'Apply the adiabatic relations PVᵞ = const and TV^(γ-1) = const.',
        'Distinguish between slopes of isothermal and adiabatic curves on P-V axes.'
      ],
      instruction: 'Detailed comparison of steepness of adiabatic vs isothermal curves (dP/dV = -γ P/V).',
      practice: 'Numerical drills on piston compression with monoatomic (γ = 5/3) and diatomic gases (γ = 7/5).',
      exitTicket: 'Calculate temperature drop when air expands adiabatically by a factor of 8.'
    },
    {
      day: 'Wednesday (Day 3)',
      focus: 'The Ideal Carnot Cycle & Reversible Heat Engines',
      outcomes: [
        'Sketch the four thermodynamic legs of the Carnot cycle.',
        'Compute maximum theoretical thermal efficiency η = 1 - T_C / T_H.'
      ],
      instruction: 'Historical and pedagogical conceptual breakdown of Carnot theorem and absolute thermodynamic temperature scale.',
      practice: 'Calculating COP for Carnot refrigerators and heat pumps operating between specified kelvin reservoirs.',
      exitTicket: 'Explain why 100% efficiency violates Kelvin-Planck statement of Second Law.'
    },
    {
      day: 'Thursday (Day 4)',
      focus: 'Second Law of Thermodynamics & Clausius Inequality',
      outcomes: [
        'Formulate the concept of entropy S as a state variable dS = dQ_rev / T.',
        'Demonstrate that entropy of an isolated system always increases for irreversible processes.'
      ],
      instruction: 'Conceptual exploration of microscopic statistical states (Boltzmann S = k ln Ω) vs macroscopic Clausius definition.',
      practice: 'Calculating entropy change during phase changes (ice melting into water) and free expansions.',
      exitTicket: 'Compute entropy change when 100g of ice at 0°C melts into water at 0°C.'
    },
    {
      day: 'Friday (Day 5)',
      focus: 'Formative Assessment & Olympiad Problem Drill',
      outcomes: [
        'Synthesize cyclic thermodynamic efficiency with real-world Otto and Diesel engine models.',
        'Score ≥80% on SabioMind weekly benchmark quiz.'
      ],
      instruction: 'Rapid review of major pitfalls: sign conventions in work, differentiating Cp and Cv ratios.',
      practice: '30-Minute timed competitive classroom sprint via SabioMind Assessment Portal.',
      exitTicket: 'Submit self-reflection on conceptual gaps before upcoming mid-term exam.'
    }
  ]);

  const handleRegenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <BookMarked className="w-6 h-6 text-indigo-500" />
            AI Lesson & Curriculum Unit Planner
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Generate pedagogical 5-day unit plans, learning outcomes (SWBAT), and formative exit tickets for {tenant.name}.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Export Unit Plan</span>
          </button>
        </div>
      </div>

      {/* Configuration bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Subject</label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option>Physics</option>
              <option>Chemistry</option>
              <option>Mathematics</option>
              <option>Biology</option>
              <option>Computer Science & AI</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Target Academic Cohort</label>
            <input
              type="text"
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Unit / Topic Title</label>
            <input
              type="text"
              value={unitTitle}
              onChange={(e) => setUnitTitle(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleRegenerate}
            disabled={isGenerating}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow flex items-center gap-2 transition-colors"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Formulating Lesson Modules...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Regenerate 5-Day Curriculum</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 5-Day Weekly Unit Plan Cards */}
      <div className="space-y-4">
        {weeklyPlans.map((plan, idx) => (
          <div
            key={idx}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-bold flex items-center justify-center text-xs">
                  {idx + 1}
                </span>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-sm">
                    {plan.day}: {plan.focus}
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">
                    Aligned with Bloom&apos;s Revised Cognitive Taxonomy
                  </span>
                </div>
              </div>

              <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-full self-start">
                60 Mins Total Duration
              </span>
            </div>

            {/* Learning Outcomes */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 text-xs space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                <Target className="w-3.5 h-3.5" />
                Measurable Learning Outcomes (SWBAT):
              </span>
              <ul className="list-disc pl-4 space-y-0.5 text-slate-700 dark:text-slate-300">
                {plan.outcomes.map((out, oIdx) => (
                  <li key={oIdx}>{out}</li>
                ))}
              </ul>
            </div>

            {/* Lesson Segments Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Direct Instruction (20 min)
                </span>
                <p className="text-slate-700 dark:text-slate-300">{plan.instruction}</p>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-500 block">
                  Collaborative Practice (25 min)
                </span>
                <p className="text-slate-700 dark:text-slate-300">{plan.practice}</p>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-500 block">
                  Formative Exit Ticket (15 min)
                </span>
                <p className="text-slate-700 dark:text-slate-300 font-medium">{plan.exitTicket}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
