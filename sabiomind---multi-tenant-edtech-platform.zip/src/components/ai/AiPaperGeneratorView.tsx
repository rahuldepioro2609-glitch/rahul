import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SAMPLE_AI_EXAM_PAPER } from '../../data/mockData';
import { GeneratedExamPaper } from '../../types';
import {
  Sparkles,
  Printer,
  Download,
  Copy,
  Check,
  RefreshCw,
  FileText,
  Sliders,
  Award,
  Layers,
  HelpCircle,
  Clock
} from 'lucide-react';

export const AiPaperGeneratorView: React.FC = () => {
  const { tenant } = useApp();
  const [subject, setSubject] = useState('Physics');
  const [grade, setGrade] = useState('Grade 12 (JEE Advanced & Olympiad Standard)');
  const [topic, setTopic] = useState('Electromagnetic Induction & Alternating Current');
  const [difficulty, setDifficulty] = useState('Advanced (Competitive)');
  const [numMcqs, setNumMcqs] = useState(5);
  const [numShort, setNumShort] = useState(3);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPaper, setGeneratedPaper] = useState<GeneratedExamPaper>(SAMPLE_AI_EXAM_PAPER);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'paper' | 'answer_key'>('paper');

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      // Dynamic paper generation logic matching selections
      const newPaper: GeneratedExamPaper = {
        title: `${tenant.name} AI Benchmark Examination - ${subject}`,
        grade: `${grade} • Term Diagnostic`,
        subject: `${subject}: ${topic}`,
        timeAllowed: '60 Minutes',
        maximumMarks: numMcqs * 4 + numShort * 4,
        instructions: [
          `Section A consists of ${numMcqs} Multiple Choice Questions (+4 for correct, -1 for incorrect).`,
          `Section B consists of ${numShort} Analytical Numerical Problems (4 marks each).`,
          'All answers must be marked in accordance with SabioMind proctored rubric.',
          'Scientific calculators are strictly prohibited.'
        ],
        sections: [
          {
            title: 'Section A: Multiple Choice Questions',
            type: 'MCQ',
            marksPerQuestion: 4,
            questions: Array.from({ length: numMcqs }).map((_, i) => ({
              qNum: i + 1,
              text: i === 0
                ? `A conducting circular loop of radius r and resistance R is placed in a uniform magnetic field B(t) = B₀(1 - αt²). What is the instantaneous induced current at time t?`
                : i === 1
                ? `In a resonant series circuit operating at angular frequency ω₀, calculate the quality factor Q when resistance R is halved while L and C remain constant.`
                : `A particle of mass m and charge q enters a uniform perpendicular magnetic field B at velocity v. Determine the kinetic energy change after 10 complete orbits.`,
              options: i === 0
                ? ['(2π r² B₀ α t) / R', '(π r² B₀ α t²) / R', '(4π r² B₀ α t) / R', 'Zero due to Lenz law symmetry']
                : i === 1
                ? ['Q doubles (2Q₀)', 'Q halves (Q₀ / 2)', 'Q increases by factor of 4', 'Q remains unchanged']
                : ['Zero (Magnetic forces do zero work)', '10 × qvB', '½ m v²', '2π m v² / qB'],
              answerKey: i === 0
                ? 'Option A: (2π r² B₀ α t) / R. Flux Φ = B·A. Induced EMF = |dΦ/dt| = 2π r² B₀ α t. Current I = EMF / R.'
                : i === 1
                ? 'Option A: Quality factor Q = (1/R) √(L/C). Halving R multiplies Q by 2.'
                : 'Option A: Magnetic Lorentz force F = q(v × B) is always perpendicular to instantaneous displacement ds, hence work done W = ∫ F·ds = 0.',
              rubricPoints: ['Identification of core physical conservation principle', 'Differentiation and dimensional consistency', 'Final accurate option selection']
            }))
          },
          {
            title: 'Section B: Short Analytical & Numerical Questions',
            type: 'Short Answer',
            marksPerQuestion: 4,
            questions: Array.from({ length: numShort }).map((_, i) => ({
              qNum: numMcqs + i + 1,
              text: i === 0
                ? `A solenoid of length 0.5 m, cross-sectional area 20 cm², and 500 turns has an iron core of relative permeability μr = 800. Calculate its self-inductance L in Henries (Take μ₀ = 4π × 10⁻⁷ T·m/A).`
                : `State Faraday's law in differential Maxwell form (curl of E = -∂B/∂t) and explain why the induced electric field is non-conservative in nature.`,
              answerKey: i === 0
                ? 'Formula L = (μr μ₀ N² A) / l. Substituting values: L = 800 × 4π×10⁻⁷ × 250000 × 0.002 / 0.5 ≈ 1.61 H.'
                : 'Differential form ∇ × E = -∂B/∂t indicates line integral ∮ E·dl ≠ 0 over a closed loop, proving work done is path-dependent.',
              rubricPoints: ['Mathematical formula definition: 1 Mark', 'SI unit conversions: 1 Mark', 'Step-by-step substitution: 2 Marks']
            }))
          }
        ]
      };

      setGeneratedPaper(newPaper);
      setIsGenerating(false);
    }, 1000);
  };

  const handleCopyText = () => {
    const text = JSON.stringify(generatedPaper, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <Sparkles className="w-6 h-6 text-indigo-500" />
            AI School Paper & Dynamic MCQ Generator
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Produce customized examination papers, marking schemes, and answer keys in seconds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Exam Paper</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Generator Parameters */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-indigo-500" />
            Exam Blueprint Configurations
          </h3>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Subject Area</label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option>Physics</option>
              <option>Chemistry</option>
              <option>Mathematics</option>
              <option>Biology</option>
              <option>Computer Science & AI</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Target Grade & Standard</label>
            <select
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option>Grade 12 (JEE Advanced & Olympiad Standard)</option>
              <option>Grade 12 (NEET Medical Standard)</option>
              <option>Grade 11 (Foundation STEM)</option>
              <option>Grade 10 (Secondary Board Standard)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Curriculum Topic / Unit</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Electromagnetic Induction & AC"
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Cognitive Difficulty Level</label>
            <div className="grid grid-cols-3 gap-2">
              {['Easy', 'Moderate', 'Advanced (Competitive)'].map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setDifficulty(lvl)}
                  className={`py-2 px-1 text-center rounded-lg border text-[11px] font-semibold transition-all ${
                    difficulty === lvl
                      ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {lvl.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">MCQs Count ({numMcqs})</label>
              <input
                type="range"
                min={2}
                max={10}
                value={numMcqs}
                onChange={(e) => setNumMcqs(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">Numerical/Short ({numShort})</label>
              <input
                type="range"
                min={1}
                max={5}
                value={numShort}
                onChange={(e) => setNumShort(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md flex items-center justify-center gap-2 transition-colors mt-4"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Synthesizing Exam Questions...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Exam Paper & Key</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Generated Paper & Answer Key */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('paper')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'paper'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Question Paper
              </button>
              <button
                onClick={() => setActiveTab('answer_key')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'answer_key'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Master Answer Key & Rubrics
              </button>
            </div>

            <button
              onClick={handleCopyText}
              className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 font-medium"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
          </div>

          {/* Exam Paper Sheet */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
            {/* Header of paper */}
            <div className="border-b border-slate-200 dark:border-slate-800 pb-5 text-center space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400">
                {tenant.name} AI EXAMINATION SERIES
              </span>
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                {generatedPaper.title}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {generatedPaper.grade} • {generatedPaper.subject}
              </p>

              <div className="flex items-center justify-between text-xs font-mono text-slate-500 pt-3 max-w-md mx-auto">
                <span>Time Allowed: {generatedPaper.timeAllowed}</span>
                <span>Max Marks: {generatedPaper.maximumMarks}</span>
              </div>
            </div>

            {activeTab === 'paper' ? (
              <div className="space-y-6">
                {/* General Instructions */}
                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
                  <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[10px]">
                    General Instructions:
                  </h4>
                  <ul className="list-decimal pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                    {generatedPaper.instructions.map((inst, i) => (
                      <li key={i}>{inst}</li>
                    ))}
                  </ul>
                </div>

                {/* Question Sections */}
                {generatedPaper.sections.map((sec, sIdx) => (
                  <div key={sIdx} className="space-y-4">
                    <div className="bg-slate-100 dark:bg-slate-800/80 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-800 dark:text-slate-200">
                      {sec.title} ({sec.marksPerQuestion} Marks each)
                    </div>

                    <div className="space-y-4 pl-2">
                      {sec.questions.map((q) => (
                        <div key={q.qNum} className="space-y-2 text-xs">
                          <div className="flex items-start gap-2">
                            <span className="font-bold text-slate-900 dark:text-white shrink-0">
                              Q{q.qNum}.
                            </span>
                            <p className="font-medium text-slate-800 dark:text-slate-200 leading-relaxed">
                              {q.text}
                            </p>
                          </div>

                          {q.options && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-6 mt-2">
                              {q.options.map((opt, oIdx) => (
                                <div
                                  key={oIdx}
                                  className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 text-slate-700 dark:text-slate-300 text-[11px]"
                                >
                                  <span className="font-bold text-indigo-600 dark:text-indigo-400 mr-1.5">
                                    {String.fromCharCode(65 + oIdx)}.
                                  </span>
                                  <span>{opt}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* Master Answer Key & Rubric View */
              <div className="space-y-6">
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Confidential AI Master Marking Scheme & Pedagogical Step Breakdown</span>
                </div>

                {generatedPaper.sections.flatMap(s => s.questions).map((q) => (
                  <div
                    key={q.qNum}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-xs space-y-2"
                  >
                    <div className="font-bold text-slate-900 dark:text-white">
                      Question {q.qNum} Solution Key:
                    </div>
                    <p className="text-emerald-600 dark:text-emerald-400 font-medium">
                      {q.answerKey}
                    </p>

                    {q.rubricPoints && (
                      <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-[11px] text-slate-500">
                        <span className="font-bold block text-slate-700 dark:text-slate-300 mb-1">Grading Rubric Allocation:</span>
                        <ul className="list-disc pl-4 space-y-0.5">
                          {q.rubricPoints.map((pt, pIdx) => (
                            <li key={pIdx}>{pt}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
