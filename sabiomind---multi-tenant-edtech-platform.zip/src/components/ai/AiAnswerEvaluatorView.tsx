import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Sliders,
  ChevronRight,
  Eye,
  Check,
  RotateCcw,
  Zap,
  Bookmark
} from 'lucide-react';

export const AiAnswerEvaluatorView: React.FC = () => {
  const { tenant } = useApp();

  const mockSubmissions = [
    {
      id: 'SUB-0491',
      studentName: 'Aarav Patel',
      rollNo: 'AP-12-042',
      examTitle: 'Advanced Physics (Electromagnetic Dynamics)',
      question: 'Q3: Derive the mutual inductance M between a long straight wire and a rectangular loop coplanar with it at distance d.',
      studentScriptSnippet: `Let current I flow through the straight wire.
Magnetic field at distance x from wire is B(x) = (μ₀ I) / (2π x).
Consider a differential strip of width dx and length L parallel to the wire.
Magnetic flux through this elemental strip:
dΦ = B(x) · dA = [ (μ₀ I) / (2π x) ] · (L dx)
Total flux Φ = ∫ [ (μ₀ I L) / (2π) ] (dx / x) from x = d to x = d + w
Φ = (μ₀ I L / 2π) · ln((d + w) / d)
Since Φ = M · I, the mutual inductance is:
M = (μ₀ L / 2π) · ln(1 + w/d)  [Q.E.D.]`,
      totalMaxMarks: 10,
      aiProposedMarks: 9.5,
      aiConfidence: '99.2%',
      rubricBreakdown: [
        { criterion: 'Magnetic field formulation B(x)', max: 2, awarded: 2, remark: 'Accurate Biot-Savart / Ampere relation used.' },
        { criterion: 'Differential strip integration setup', max: 3, awarded: 3, remark: 'Clean limits d to d+w with length L.' },
        { criterion: 'Logarithmic integral evaluation', max: 3, awarded: 3, remark: 'Perfect derivation to ln(1 + w/d).' },
        { criterion: 'SI units & diagram cleanliness', max: 2, awarded: 1.5, remark: 'Minor: Diagram sketch was omitted; formulation was flawless.' }
      ],
      aiFeedback: 'Exceptional mathematical rigor. Candidate correctly identified spatial variation of B field and carried out logarithmic integration without typical reciprocal algebraic errors.',
      status: 'pending'
    },
    {
      id: 'SUB-0492',
      studentName: 'Kavya Subramanian',
      rollNo: 'KS-12-019',
      examTitle: 'Advanced Physics (Electromagnetic Dynamics)',
      question: 'Q2: A 10 μF capacitor is discharged through a 100 Ω resistor. Compute energy dissipated after 2 milliseconds.',
      studentScriptSnippet: `Initial energy stored U₀ = ½ C V₀²
Charge decay q(t) = Q₀ e^(-t / RC)
Time constant τ = R × C = 100 × (10 × 10⁻⁶) = 10⁻³ s = 1 ms.
At t = 2 ms, t = 2τ.
Energy remaining in capacitor = U₀ · e^(-2t/τ) = U₀ · e^(-4)
Energy dissipated in resistor = U₀ - U(t) = U₀ (1 - e⁻⁴) ≈ 0.9817 U₀
Dissipation percentage = 98.2% of initial electrostatic energy.`,
      totalMaxMarks: 10,
      aiProposedMarks: 10,
      aiConfidence: '98.7%',
      rubricBreakdown: [
        { criterion: 'Time constant computation τ = RC', max: 2, awarded: 2, remark: 'Accurate value calculated (1 ms).' },
        { criterion: 'Transient charge equation q(t)', max: 3, awarded: 3, remark: 'Correct exponential decay form applied.' },
        { criterion: 'Energy ratio proportionality U ∝ q²', max: 3, awarded: 3, remark: 'Accurately recognized energy decays with e^(-2t/τ).' },
        { criterion: 'Final numerical percentage', max: 2, awarded: 2, remark: 'Precise decimal result (98.2%).' }
      ],
      aiFeedback: 'Flawless step-by-step mathematical reasoning. Successfully accounted for the quadratic power factor in capacitor electrostatic energy decay.',
      status: 'graded'
    }
  ];

  const [selectedIdx, setSelectedIdx] = useState(0);
  const current = mockSubmissions[selectedIdx];
  const [teacherOverride, setTeacherOverride] = useState<number>(current.aiProposedMarks);
  const [isApproved, setIsApproved] = useState(false);

  const handleSelectSubmission = (idx: number) => {
    setSelectedIdx(idx);
    setTeacherOverride(mockSubmissions[idx].aiProposedMarks);
    setIsApproved(mockSubmissions[idx].status === 'graded');
  };

  const handleApprove = () => {
    setIsApproved(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <FileCheck className="w-6 h-6 text-emerald-500" />
            AI Automated Answer Sheet Evaluator
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Visual OCR handwritten script grading, pedagogical rubric checks, and teacher override controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>AI Model: Vision Pro Multi-Modal OCR</span>
          </span>
        </div>
      </div>

      {/* Submissions Roster */}
      <div className="flex gap-3 overflow-x-auto pb-2">
        {mockSubmissions.map((sub, i) => (
          <button
            key={sub.id}
            onClick={() => handleSelectSubmission(i)}
            className={`p-3 rounded-xl border text-left min-w-[260px] transition-all ${
              selectedIdx === i
                ? 'bg-white dark:bg-slate-900 border-indigo-500 shadow-md ring-1 ring-indigo-500'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span className="font-mono">{sub.id}</span>
              <span className="text-indigo-600 dark:text-indigo-400 font-bold">{sub.rollNo}</span>
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white truncate">
              {sub.studentName}
            </div>
            <div className="text-[11px] text-slate-500 truncate mt-0.5">
              {sub.examTitle}
            </div>
            <div className="mt-2 flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px]">
              <span className="text-slate-400">Score: {sub.aiProposedMarks}/{sub.totalMaxMarks}</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">{sub.aiConfidence} Match</span>
            </div>
          </button>
        ))}
      </div>

      {/* Side-by-Side Evaluation Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LEFT COLUMN: Student Handwriting OCR & Script Viewer */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                OCR Digitized Handwriting Scan
              </span>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {current.studentName} • Script Answer Sheet
              </h3>
            </div>
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              Exam: {current.id}
            </span>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-semibold">
            {current.question}
          </div>

          {/* Handwritten simulated notebook page with margin */}
          <div className="relative bg-amber-50/40 dark:bg-slate-950 border border-amber-200/60 dark:border-slate-800 rounded-xl p-6 min-h-[340px] font-mono text-xs leading-relaxed text-slate-800 dark:text-slate-200 select-none overflow-x-auto">
            {/* Red notebook margin line */}
            <div className="absolute left-8 top-0 bottom-0 w-px bg-rose-300/40 dark:bg-rose-900/40" />

            <div className="pl-6 space-y-3 font-mono text-[11px]">
              <div className="text-[10px] text-indigo-500 font-sans font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>AI OPTICAL TEXT RECOGNITION BOUNDING BOX VERIFIED</span>
              </div>
              <pre className="whitespace-pre-wrap font-mono leading-relaxed font-semibold text-slate-800 dark:text-slate-200">
                {current.studentScriptSnippet}
              </pre>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: AI Grading Rubric & Teacher Verification */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-500">
                  AI Multi-Criteria Scoring
                </span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                  Automated Pedagogical Breakdown
                </h3>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400">Awarded:</span>
                <span className="text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono ml-1.5">
                  {teacherOverride} / {current.totalMaxMarks}
                </span>
              </div>
            </div>

            {/* Rubric Criteria Items */}
            <div className="space-y-3">
              {current.rubricBreakdown.map((rub, rIdx) => (
                <div
                  key={rIdx}
                  className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                    <span>{rub.criterion}</span>
                    <span className="font-mono text-indigo-600 dark:text-indigo-400">
                      {rub.awarded} / {rub.max}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {rub.remark}
                  </p>
                </div>
              ))}
            </div>

            {/* AI Teacher Feedback */}
            <div className="p-3.5 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-xl text-xs space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                AI Diagnostic Summary:
              </span>
              <p className="text-slate-700 dark:text-slate-300 text-[11px] leading-relaxed">
                {current.aiFeedback}
              </p>
            </div>

            {/* Teacher Override Slider */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-indigo-500" />
                  Teacher Final Override:
                </span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">
                  {teacherOverride} Marks
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={current.totalMaxMarks}
                step={0.5}
                value={teacherOverride}
                onChange={(e) => setTeacherOverride(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">
              {isApproved ? 'Status: Approved & Synced to Portal' : 'Pending Teacher Sign-off'}
            </span>

            <button
              onClick={handleApprove}
              disabled={isApproved}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold shadow flex items-center gap-1.5 transition-colors ${
                isApproved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>{isApproved ? 'Score Published' : 'Confirm & Publish Score'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
