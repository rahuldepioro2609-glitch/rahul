import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MOCK_EXAM_QUESTIONS } from '../../data/mockData';
import { QuizQuestion } from '../../types';
import {
  FileSpreadsheet,
  Clock,
  CheckCircle,
  AlertCircle,
  Award,
  ChevronRight,
  RotateCcw,
  Bookmark,
  ShieldAlert,
  ArrowRight,
  TrendingUp,
  BarChart2,
  Check,
  X
} from 'lucide-react';

export const AssessmentPortalView: React.FC = () => {
  const { user, tenant, triggerSecurityBreachNotice } = useApp();
  const [examState, setExamState] = useState<'intro' | 'active' | 'results'>('intro');
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Record<number, boolean>>({});
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes

  const questions: QuizQuestion[] = MOCK_EXAM_QUESTIONS;

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (examState === 'active' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setExamState('results');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [examState, timeLeft]);

  const handleStartExam = () => {
    setSelectedAnswers({});
    setFlaggedQuestions({});
    setCurrentQIndex(0);
    setTimeLeft(600);
    setExamState('active');
  };

  const handleSelectOption = (qId: number, optionIdx: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optionIdx }));
  };

  const toggleFlag = (qId: number) => {
    setFlaggedQuestions((prev) => ({ ...prev, [qId]: !prev[qId] }));
  };

  const handleSubmitExam = () => {
    setExamState('results');
  };

  // Calculate score
  let correctCount = 0;
  let wrongCount = 0;
  let totalScore = 0;

  questions.forEach((q) => {
    const answered = selectedAnswers[q.id];
    if (answered !== undefined) {
      if (answered === q.correctAnswer) {
        correctCount += 1;
        totalScore += q.marks;
      } else {
        wrongCount += 1;
        totalScore = Math.max(0, totalScore - 1); // -1 negative mark
      }
    }
  });

  const maxScore = questions.reduce((acc, q) => acc + q.marks, 0);
  const percentage = Math.round((totalScore / maxScore) * 100) || 0;
  const percentile = Math.min(99.8, Math.max(45, Math.round(percentage * 1.05 * 10) / 10));

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <FileSpreadsheet className="w-6 h-6 text-emerald-500" />
            Automated Online Test & Assessment Portal
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Timed examination engine with instant evaluation, negative marking, and performance analytics.
          </p>
        </div>

        {examState === 'active' && (
          <div className="flex items-center gap-3 bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 px-4 py-2 rounded-xl text-xs font-bold font-mono">
            <Clock className="w-4 h-4 animate-spin" />
            <span>TIME REMAINING: {formatTime(timeLeft)}</span>
          </div>
        )}
      </div>

      {/* STATE 1: INTRO / EXAM LIST */}
      {examState === 'intro' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                  All-India Benchmark Series
                </span>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-2">
                  JEE & NEET Comprehensive Science Assessment (Diagnostic Mock)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Subjects covered: Kinematics, Chemical Bonding, Definite Integrals & Cellular Respiration.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Questions</div>
                <div className="text-base font-bold text-slate-900 dark:text-white mt-0.5">{questions.length} MCQs</div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Duration</div>
                <div className="text-base font-bold text-slate-900 dark:text-white mt-0.5">10 Minutes</div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Max Score</div>
                <div className="text-base font-bold text-slate-900 dark:text-white mt-0.5">{maxScore} Marks</div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-400">Negative Mark</div>
                <div className="text-base font-bold text-rose-500 mt-0.5">-1 per Wrong</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
              <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-emerald-500" />
                Anti-Piracy & Proctoring Regulations:
              </h4>
              <ul className="list-disc pl-5 space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                <li>Session is bound to {user.phoneNumber} with active DRM screen tracking.</li>
                <li>Switching windows or opening DevTools flags an instant proctor notice.</li>
                <li>Instant score card & detailed step-by-step solutions are rendered upon submission.</li>
              </ul>
            </div>

            <button
              onClick={handleStartExam}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm"
            >
              <span>Begin Timed Examination</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Past Performance Record Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              Candidate Profile
            </h3>
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 text-xs space-y-1">
              <div className="text-slate-500">Student Name:</div>
              <div className="font-bold text-slate-900 dark:text-white">{user.name}</div>
              <div className="text-slate-500 mt-2">Enrolled Track:</div>
              <div className="font-medium text-slate-700 dark:text-slate-300">{user.grade || 'IIT-JEE Batch'}</div>
              <div className="text-slate-500 mt-2">Verified Phone:</div>
              <div className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{user.phoneNumber}</div>
            </div>

            <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/30 rounded-xl border border-indigo-200/60 dark:border-indigo-900/40 text-xs">
              <div className="font-bold text-indigo-700 dark:text-indigo-300 mb-1">
                Batch Average Percentile: 84.2%
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Completing this test automatically calculates your institutional standing across all {tenant.name} branches.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* STATE 2: ACTIVE EXAMINATION ENGINE */}
      {examState === 'active' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Question View (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
              {/* Question Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600 text-white">
                    Question {currentQIndex + 1} of {questions.length}
                  </span>
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                    {questions[currentQIndex].subject} • {questions[currentQIndex].topic}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                    +{questions[currentQIndex].marks} / -1 Mark
                  </span>
                  <button
                    onClick={() => toggleFlag(questions[currentQIndex].id)}
                    className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-colors ${
                      flaggedQuestions[questions[currentQIndex].id]
                        ? 'bg-amber-500/10 border-amber-500 text-amber-600'
                        : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>{flaggedQuestions[questions[currentQIndex].id] ? 'Flagged' : 'Flag'}</span>
                  </button>
                </div>
              </div>

              {/* Question Statement */}
              <div className="py-6">
                <p className="text-sm sm:text-base font-medium text-slate-900 dark:text-white leading-relaxed">
                  {questions[currentQIndex].question}
                </p>
              </div>

              {/* Multiple Choice Options */}
              <div className="space-y-3">
                {questions[currentQIndex].options.map((opt, optIdx) => {
                  const isSelected = selectedAnswers[questions[currentQIndex].id] === optIdx;
                  const letter = String.fromCharCode(65 + optIdx);

                  return (
                    <button
                      key={optIdx}
                      onClick={() => handleSelectOption(questions[currentQIndex].id, optIdx)}
                      className={`w-full p-4 rounded-xl border text-left text-xs sm:text-sm font-medium flex items-center gap-3 transition-all ${
                        isSelected
                          ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-indigo-700 dark:text-indigo-300 ring-1 ring-indigo-500'
                          : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span
                        className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          isSelected
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                        }`}
                      >
                        {letter}
                      </span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>

              {/* Bottom Nav Controls */}
              <div className="flex items-center justify-between pt-6 mt-6 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => {
                    const newAns = { ...selectedAnswers };
                    delete newAns[questions[currentQIndex].id];
                    setSelectedAnswers(newAns);
                  }}
                  className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  Clear Selection
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCurrentQIndex(Math.max(0, currentQIndex - 1))}
                    disabled={currentQIndex === 0}
                    className="px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold disabled:opacity-40"
                  >
                    Previous
                  </button>
                  {currentQIndex < questions.length - 1 ? (
                    <button
                      onClick={() => setCurrentQIndex(currentQIndex + 1)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold"
                    >
                      Next Question
                    </button>
                  ) : (
                    <button
                      onClick={handleSubmitExam}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold"
                    >
                      Submit Exam
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Question Palette Sidebar (1 col) */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Question Palette
            </h3>

            <div className="grid grid-cols-4 gap-2.5">
              {questions.map((q, idx) => {
                const isCurrent = currentQIndex === idx;
                const isAnswered = selectedAnswers[q.id] !== undefined;
                const isFlagged = flaggedQuestions[q.id];

                let bgClass = 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400';
                if (isAnswered) bgClass = 'bg-emerald-600 text-white font-bold';
                else if (isFlagged) bgClass = 'bg-amber-500 text-white font-bold';

                return (
                  <button
                    key={q.id}
                    onClick={() => setCurrentQIndex(idx)}
                    className={`h-10 rounded-xl text-xs font-semibold transition-all relative ${bgClass} ${
                      isCurrent ? 'ring-2 ring-indigo-500 ring-offset-2 dark:ring-offset-slate-900' : ''
                    }`}
                  >
                    {idx + 1}
                    {isFlagged && (
                      <span className="w-2 h-2 rounded-full bg-amber-300 absolute top-1 right-1" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Legend */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-[11px] text-slate-500">
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded bg-emerald-600 inline-block" />
                <span>Answered ({Object.keys(selectedAnswers).length})</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded bg-amber-500 inline-block" />
                <span>Marked for Review ({Object.values(flaggedQuestions).filter(Boolean).length})</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded bg-slate-200 dark:bg-slate-700 inline-block" />
                <span>Not Attempted ({questions.length - Object.keys(selectedAnswers).length})</span>
              </div>
            </div>

            <button
              onClick={handleSubmitExam}
              className="w-full mt-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow transition-colors"
            >
              Finish & View Scoring
            </button>
          </div>
        </div>
      )}

      {/* STATE 3: INSTANT SCORING & PERFORMANCE ANALYTICS */}
      {examState === 'results' && (
        <div className="space-y-6">
          {/* Metrics summary banner */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <Award className="w-6 h-6 text-amber-500" />
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    Evaluation Complete • Instant AI Grading
                  </span>
                </div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                  Test Score: {totalScore} / {maxScore} Marks ({percentage}%)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Calculated against standard All-India benchmark ranking criteria.
                </p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-center p-3 px-5 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-900">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Estimated Percentile</div>
                  <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">{percentile}%ile</div>
                </div>
                <button
                  onClick={handleStartExam}
                  className="px-4 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold text-xs flex items-center gap-2 hover:opacity-90 transition-opacity"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Test</span>
                </button>
              </div>
            </div>

            {/* Score Breakdown Cards */}
            <div className="grid grid-cols-3 gap-4 pt-6 text-center">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 rounded-xl border border-emerald-200/50">
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">Correct Questions</span>
                <p className="text-xl font-black text-emerald-600 mt-1">{correctCount}</p>
              </div>
              <div className="p-3 bg-rose-50 dark:bg-rose-950/20 rounded-xl border border-rose-200/50">
                <span className="text-xs font-bold text-rose-700 dark:text-rose-400">Incorrect (-1 each)</span>
                <p className="text-xl font-black text-rose-600 mt-1">{wrongCount}</p>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-400">Unanswered</span>
                <p className="text-xl font-black text-slate-600 dark:text-slate-300 mt-1">
                  {questions.length - (correctCount + wrongCount)}
                </p>
              </div>
            </div>
          </div>

          {/* Detailed Question by Question Solution Keys */}
          <div className="space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Comprehensive Solutions & Step Explanations
            </h3>

            {questions.map((q, idx) => {
              const studentAnswer = selectedAnswers[q.id];
              const isCorrect = studentAnswer === q.correctAnswer;
              const isAnswered = studentAnswer !== undefined;

              return (
                <div
                  key={q.id}
                  className={`p-5 rounded-2xl border ${
                    !isAnswered
                      ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                      : isCorrect
                      ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-500/30'
                      : 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="font-bold text-slate-500">Question {idx + 1} ({q.subject})</span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded text-[10px] uppercase ${
                        !isAnswered
                          ? 'bg-slate-200 text-slate-600'
                          : isCorrect
                          ? 'bg-emerald-500 text-white'
                          : 'bg-rose-500 text-white'
                      }`}
                    >
                      {!isAnswered ? 'Unanswered (0)' : isCorrect ? 'Correct (+4)' : 'Incorrect (-1)'}
                    </span>
                  </div>

                  <p className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                    {q.question}
                  </p>

                  <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                    <div>
                      <span className="font-bold">Correct Answer:</span> {String.fromCharCode(65 + q.correctAnswer)} - {q.options[q.correctAnswer]}
                    </div>
                    {isAnswered && !isCorrect && (
                      <div className="text-rose-600 dark:text-rose-400">
                        <span className="font-bold">Your Response:</span> {String.fromCharCode(65 + studentAnswer)} - {q.options[studentAnswer]}
                      </div>
                    )}
                  </div>

                  <div className="mt-3 p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-300">
                    <span className="font-bold text-indigo-600 dark:text-indigo-400">Detailed Explanation: </span>
                    {q.explanation}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
