import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LiveClass } from '../../types';
import {
  Video,
  Radio,
  Users,
  Send,
  Pin,
  Hand,
  Volume2,
  Maximize2,
  Settings,
  ShieldCheck,
  CheckCircle,
  HelpCircle,
  Sparkles,
  Play,
  Clock,
  BookOpen
} from 'lucide-react';

export const LiveClassesView: React.FC = () => {
  const { liveClasses, chatMessages, sendChatMessage, user, tenant, triggerSecurityBreachNotice } = useApp();
  const [activeClass, setActiveClass] = useState<LiveClass>(liveClasses[0]);
  const [chatInput, setChatInput] = useState('');
  const [activeTab, setActiveTab] = useState<'live' | 'vod'>('live');
  const [streamQuality, setStreamQuality] = useState('1080p (60fps DRM-Protected)');
  const [handRaised, setHandRaised] = useState(false);
  const [pollVotes, setPollVotes] = useState<Record<number, number>>({ 0: 64, 1: 182, 2: 24 });
  const [userVoted, setUserVoted] = useState<number | null>(null);

  const pollOptions = [
    'Substitute u = 1 - x²',
    'Substitute x = sin(θ)',
    'Integration by parts directly'
  ];

  const handleVote = (idx: number) => {
    if (userVoted !== null) return;
    setUserVoted(idx);
    setPollVotes(prev => ({ ...prev, [idx]: (prev[idx] || 0) + 1 }));
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    sendChatMessage(chatInput);
    setChatInput('');
  };

  const totalVotes: number = (Object.values(pollVotes) as number[]).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <Radio className="w-6 h-6 text-rose-500 animate-pulse" />
            Live Classroom & Video On-Demand (VOD)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Low-latency encrypted streaming with real-time interactive QA and anti-piracy DRM watermarking.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 self-start">
          <button
            onClick={() => setActiveTab('live')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'live'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            Live Stream
          </button>
          <button
            onClick={() => setActiveTab('vod')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'vod'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
            Recorded VOD Library
          </button>
        </div>
      </div>

      {activeTab === 'live' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Video Player (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="relative aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-800 group select-none">
              {/* Video Element */}
              <video
                key={activeClass.videoUrl}
                src={activeClass.videoUrl}
                controls={false}
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover pointer-events-none"
              />

              {/* Dynamic Anti-Piracy Watermark overlay inside player */}
              <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 opacity-35 select-none">
                <div className="flex justify-between items-start text-[11px] font-mono text-white/70 bg-black/40 backdrop-blur-xs px-2 py-1 rounded">
                  <span>AES-128 DRM ENCRYPTED</span>
                  <span>SESSION: {user.studentId || 'STUDENT'} • {user.phoneNumber}</span>
                </div>
                <div className="text-center font-mono text-sm tracking-widest text-emerald-400/50 uppercase rotate-[-8deg] font-bold">
                  {tenant.name} • FOR PERSONAL USE ONLY • {user.phoneNumber}
                </div>
                <div className="text-right text-[10px] font-mono text-white/50">
                  TOKEN: 8x92-f04b-drm-{Date.now().toString().slice(-6)}
                </div>
              </div>

              {/* Player Top Controls Bar */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-white text-xs z-10">
                <div className="flex items-center gap-2 bg-slate-950/70 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700/60">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                  <span className="font-bold uppercase tracking-wider text-[11px]">LIVE</span>
                  <span className="text-slate-400">|</span>
                  <span className="flex items-center gap-1 text-slate-300">
                    <Users className="w-3.5 h-3.5 text-slate-400" />
                    {activeClass.viewersCount} watching
                  </span>
                </div>

                <div className="flex items-center gap-2 bg-slate-950/70 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700/60">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300 text-[11px] font-medium hidden sm:inline">Widevine L1 DRM</span>
                </div>
              </div>

              {/* Player Bottom Controls Bar */}
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-4 flex items-center justify-between text-white text-xs z-10">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  <span className="font-semibold text-sm truncate max-w-[240px] sm:max-w-md">
                    {activeClass.title}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <select
                    value={streamQuality}
                    onChange={(e) => setStreamQuality(e.target.value)}
                    className="bg-slate-900/80 border border-slate-700 text-white text-[11px] rounded px-2 py-1 focus:outline-none"
                  >
                    <option>1080p (60fps DRM-Protected)</option>
                    <option>720p (Adaptive Stream)</option>
                    <option>480p (Data Saver)</option>
                  </select>

                  <button 
                    onClick={() => triggerSecurityBreachNotice('Full-screen streaming capture deterrence is activated.')}
                    className="text-slate-300 hover:text-white p-1"
                    title="Fullscreen"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Class Details & Student Interaction Actions */}
            <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {activeClass.title}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    {activeClass.topic} • Instructor: <span className="font-semibold text-slate-700 dark:text-slate-300">{activeClass.teacher}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setHandRaised(!handRaised)}
                    className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                      handRaised
                        ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/25'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <Hand className={`w-4 h-4 ${handRaised ? 'animate-bounce' : ''}`} />
                    <span>{handRaised ? 'Hand Raised (Pos #3)' : 'Raise Hand'}</span>
                  </button>
                </div>
              </div>

              {/* Live Interactive In-Class Poll */}
              <div className="mt-4 p-4 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/50 dark:border-indigo-900/40">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-indigo-500 text-white">
                      Live Class Poll
                    </span>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                      Which mathematical substitution resolves this ODE fastest?
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-500">{totalVotes} students responded</span>
                </div>

                <div className="space-y-2 mt-3">
                  {pollOptions.map((opt, idx) => {
                    const count = pollVotes[idx] || 0;
                    const percent = Math.round((count / totalVotes) * 100) || 0;
                    const isChosen = userVoted === idx;

                    return (
                      <button
                        key={idx}
                        onClick={() => handleVote(idx)}
                        disabled={userVoted !== null}
                        className={`w-full relative overflow-hidden rounded-lg border p-2.5 text-left text-xs transition-all ${
                          isChosen
                            ? 'border-indigo-500 bg-indigo-500/10 font-bold'
                            : 'border-slate-200 dark:border-slate-700/80 hover:bg-white dark:hover:bg-slate-800'
                        }`}
                      >
                        {/* Progress fill bar */}
                        <div
                          className="absolute inset-y-0 left-0 bg-indigo-500/15 dark:bg-indigo-500/25 transition-all duration-500"
                          style={{ width: `${percent}%` }}
                        />
                        <div className="relative flex items-center justify-between">
                          <span className="text-slate-800 dark:text-slate-200">{opt}</span>
                          <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">
                            {percent}% ({count})
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Real-time Student Chat & QA (1 col) */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col h-[600px] shadow-sm overflow-hidden">
            {/* Chat header */}
            <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/50 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  Live Classroom Chat
                </h3>
                <p className="text-[10px] text-slate-400">Moderated & DRM-Identified</p>
              </div>
              <span className="text-[10px] bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded text-slate-700 dark:text-slate-300 font-semibold">
                Slow Mode: 2s
              </span>
            </div>

            {/* Chat message stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
              {chatMessages.map((msg) => {
                const isTeacher = msg.role === 'educator';
                const isSystem = msg.role === 'super_admin';

                return (
                  <div
                    key={msg.id}
                    className={`rounded-xl p-3 text-xs ${
                      msg.isPinned
                        ? 'bg-amber-500/10 border border-amber-500/30'
                        : isTeacher
                        ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/60'
                        : 'bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        {msg.isPinned && <Pin className="w-3 h-3 text-amber-500" />}
                        <span className="font-bold text-slate-900 dark:text-white">
                          {msg.sender}
                        </span>
                        {isTeacher && (
                          <span className="text-[9px] bg-indigo-600 text-white font-bold px-1.5 py-0.2 rounded">
                            FACULTY
                          </span>
                        )}
                        {isSystem && (
                          <span className="text-[9px] bg-slate-700 text-white font-bold px-1.5 py-0.2 rounded">
                            SECURITY
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                    </div>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      {msg.text}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Chat input box */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              <div className="relative">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask instructor or answer question..."
                  className="w-full pl-3 pr-10 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1.5 p-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[9px] text-slate-400 mt-1 text-center">
                Your mobile ({user.phoneNumber}) is linked to your chat messages for code of conduct audit.
              </p>
            </form>
          </div>
        </div>
      ) : (
        /* VOD Library Archive */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {liveClasses.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md transition-all group"
            >
              <div className="relative aspect-video bg-slate-950 flex items-center justify-center">
                <video
                  src={item.videoUrl}
                  className="w-full h-full object-cover opacity-60"
                  muted
                />
                <button
                  onClick={() => {
                    setActiveClass(item);
                    setActiveTab('live');
                  }}
                  className="absolute w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform"
                >
                  <Play className="w-5 h-5 ml-0.5" />
                </button>
                <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded font-mono">
                  {item.subject}
                </div>
                <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded font-mono">
                  {item.duration}
                </div>
              </div>

              <div className="p-4 space-y-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {item.topic}
                </p>
                <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span>{item.teacher}</span>
                  <span className="flex items-center gap-1 font-mono text-[11px]">
                    <Clock className="w-3 h-3" />
                    {item.time}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
