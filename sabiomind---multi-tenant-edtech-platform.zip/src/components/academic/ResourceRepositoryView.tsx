import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StudyResource } from '../../types';
import { STUDY_RESOURCES } from '../../data/mockData';
import {
  BookOpen,
  FileText,
  FileSpreadsheet,
  Lock,
  Shield,
  Eye,
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Printer,
  Search,
  CheckCircle2,
  AlertTriangle,
  FolderLock
} from 'lucide-react';

export const ResourceRepositoryView: React.FC = () => {
  const { user, tenant, triggerSecurityBreachNotice } = useApp();
  const [resources] = useState<StudyResource[]>(STUDY_RESOURCES);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewingResource, setViewingResource] = useState<StudyResource | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [zoomLevel, setZoomLevel] = useState(100);

  const filteredResources = resources.filter(res => {
    const matchesType = selectedType === 'all' || res.type === selectedType;
    const matchesSearch = res.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          res.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const handleOpenReader = (res: StudyResource) => {
    setViewingResource(res);
    setCurrentPage(1);
    setZoomLevel(100);
  };

  const handleAttemptDownload = () => {
    triggerSecurityBreachNotice('Direct download of intellectual property is restricted. View in-app only.');
  };

  const handleAttemptPrint = () => {
    triggerSecurityBreachNotice('Printing of proprietary course notes is prohibited by SabioMind DRM.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <FolderLock className="w-6 h-6 text-indigo-500" />
            Digital Resource Repository (Non-Downloadable DRM)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Proprietary curriculum, formula compendia, and past question papers protected against piracy.
          </p>
        </div>

        {/* Security badge */}
        <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-400 px-3 py-1.5 rounded-xl text-xs font-semibold self-start">
          <Shield className="w-4 h-4 text-emerald-500" />
          <span>DRM Watermark Protection Active</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-wrap gap-1.5 w-full md:w-auto">
          {[
            { id: 'all', label: 'All Resources' },
            { id: 'ebook', label: 'eBooks & Guides' },
            { id: 'lecture_notes', label: 'Lecture Notes' },
            { id: 'pyq', label: 'Previous Papers (PYQ)' },
            { id: 'syllabus', label: 'Syllabi & Outlines' }
          ].map((btn) => (
            <button
              key={btn.id}
              onClick={() => setSelectedType(btn.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedType === btn.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search subjects or titles..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        {filteredResources.map((res) => (
          <div
            key={res.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900">
                  {res.type.replace('_', ' ')}
                </span>
                <span className="font-mono text-[11px] text-slate-500">{res.fileSize}</span>
              </div>

              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 leading-snug">
                {res.title}
              </h3>

              <div className="flex flex-wrap gap-2 text-xs text-slate-500 dark:text-slate-400 mb-4">
                <span className="font-semibold text-slate-700 dark:text-slate-300">{res.subject}</span>
                <span>•</span>
                <span>{res.grade}</span>
                <span>•</span>
                <span>{res.totalPages} Pages</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-100 dark:border-slate-800/80 mb-4">
                <div className="text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
                  Key Chapter Preview:
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300 italic">
                  &quot;{res.previewPages[0]}&quot;
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
                <Lock className="w-3 h-3 text-emerald-500" />
                <span>Anti-Print & Anti-Copy DRM</span>
              </div>

              <button
                onClick={() => handleOpenReader(res)}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-sm flex items-center gap-1.5 transition-colors"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Secure Reader</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* IN-APP DRM SECURE DOCUMENT READER MODAL */}
      {viewingResource && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-2 sm:p-4">
          <div className="relative w-full max-w-5xl h-[92vh] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-700 flex flex-col overflow-hidden select-none">
            {/* Modal Top Control Bar */}
            <div className="px-4 py-3 bg-slate-900 text-white border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3 overflow-hidden">
                <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shrink-0">
                  <Shield className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <h3 className="text-xs sm:text-sm font-bold truncate text-white">
                    {viewingResource.title}
                  </h3>
                  <p className="text-[10px] text-slate-400 font-mono">
                    DRM-PROTECTED VIEW • {tenant.code} • {user.phoneNumber}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Restricted actions */}
                <button
                  onClick={handleAttemptDownload}
                  title="Download restricted under DRM"
                  className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center gap-1 text-xs"
                >
                  <Lock className="w-4 h-4 text-rose-400" />
                  <span className="hidden sm:inline text-[10px] text-rose-300 font-semibold">Protected</span>
                </button>

                <button
                  onClick={handleAttemptPrint}
                  title="Printing restricted under DRM"
                  className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg bg-slate-800 hover:bg-slate-700"
                >
                  <Printer className="w-4 h-4" />
                </button>

                {/* Zoom Controls */}
                <div className="hidden sm:flex items-center gap-1 bg-slate-800 rounded-lg px-2 py-1 text-xs text-slate-300">
                  <button onClick={() => setZoomLevel(Math.max(75, zoomLevel - 15))} className="hover:text-white">
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-mono text-[10px]">{zoomLevel}%</span>
                  <button onClick={() => setZoomLevel(Math.min(150, zoomLevel + 15))} className="hover:text-white">
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={() => setViewingResource(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Canvas / Pages area */}
            <div className="flex-1 bg-slate-100 dark:bg-slate-950 overflow-y-auto p-4 sm:p-8 flex justify-center relative select-none">
              {/* Floating Diagonal Dynamic Watermark inside the reader */}
              <div className="pointer-events-none absolute inset-0 overflow-hidden flex flex-col justify-around opacity-15 select-none z-10">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div
                    key={i}
                    className="rotate-[-20deg] text-center font-mono text-xs sm:text-sm font-black tracking-widest text-slate-800 dark:text-emerald-300"
                  >
                    PROPERTY OF {tenant.name.toUpperCase()} • LICENSED TO {user.phoneNumber} • DO NOT DISTRIBUTE
                  </div>
                ))}
              </div>

              {/* Document Page Simulator */}
              <div 
                className="bg-white dark:bg-slate-900 w-full max-w-2xl min-h-[750px] shadow-2xl rounded-xl p-8 sm:p-12 border border-slate-200 dark:border-slate-800 transition-all text-slate-900 dark:text-slate-100 relative"
                style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  triggerSecurityBreachNotice('Text copying and context menu are strictly blocked.');
                }}
              >
                {/* Header in page */}
                <div className="border-b pb-4 mb-6 flex items-center justify-between text-xs text-slate-400 font-mono">
                  <span>{tenant.name} Academic Series</span>
                  <span>Page {currentPage} of {viewingResource.totalPages}</span>
                </div>

                <div className="space-y-6">
                  <h2 className="text-xl font-black tracking-tight text-indigo-600 dark:text-indigo-400">
                    Chapter Section {currentPage}: {viewingResource.subject} Foundations
                  </h2>

                  <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-300">
                    {viewingResource.previewPages[(currentPage - 1) % viewingResource.previewPages.length]}
                  </p>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/60 text-xs space-y-2">
                    <div className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[10px]">
                      Key Theoretical Postulates & Derivation Notes:
                    </div>
                    <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                      <li>Boundary condition conservation in homogeneous media.</li>
                      <li>Calculated error margins &lt; 0.05% under laboratory standard temperature and pressure.</li>
                      <li>Reference: Olympiad Problem Benchmark Series Vol 4, Section 9.</li>
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl border border-dashed border-indigo-300 dark:border-indigo-800 text-center font-mono text-xs text-indigo-600 dark:text-indigo-300">
                    [Encrypted Mathematical Formulae Rendered Securely in SabioMind Virtual Frame]
                  </div>
                </div>

                {/* Footer on page */}
                <div className="absolute bottom-6 inset-x-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>CONFIDENTIAL - ENCRYPTED STREAM</span>
                  <span>{user.phoneNumber}</span>
                </div>
              </div>
            </div>

            {/* Modal Bottom Page Navigation Bar */}
            <div className="px-4 py-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
              <div className="text-slate-500 text-xs">
                Watermarked with your authenticated number: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{user.phoneNumber}</span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="font-mono text-xs font-semibold">
                  {currentPage} / {viewingResource.totalPages}
                </span>
                <button
                  onClick={() => setCurrentPage(Math.min(viewingResource.totalPages, currentPage + 1))}
                  disabled={currentPage === viewingResource.totalPages}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
