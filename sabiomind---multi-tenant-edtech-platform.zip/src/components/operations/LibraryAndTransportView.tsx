import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BUS_ROUTES } from '../../data/mockData';
import { LibraryBook, BusTransportRoute } from '../../types';
import {
  BookOpen,
  Bus,
  Search,
  CheckCircle2,
  Clock,
  MapPin,
  Phone,
  Navigation,
  AlertCircle,
  Plus,
  ShieldCheck,
  Compass
} from 'lucide-react';

export const LibraryAndTransportView: React.FC = () => {
  const { books, issueBook, tenant } = useApp();
  const [activeTab, setActiveTab] = useState<'library' | 'transport'>('transport');
  const [routes] = useState<BusTransportRoute[]>(BUS_ROUTES);
  const [selectedBus, setSelectedBus] = useState<BusTransportRoute>(routes[0]);
  const [librarySearch, setLibrarySearch] = useState('');

  // Issue modal state
  const [issuingBook, setIssuingBook] = useState<LibraryBook | null>(null);
  const [studentNameToIssue, setStudentNameToIssue] = useState('Aarav Patel');

  const filteredBooks = books.filter(b =>
    b.title.toLowerCase().includes(librarySearch.toLowerCase()) ||
    b.author.toLowerCase().includes(librarySearch.toLowerCase()) ||
    b.category.toLowerCase().includes(librarySearch.toLowerCase())
  );

  const handleConfirmIssue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!issuingBook || !studentNameToIssue) return;
    issueBook(issuingBook.id, studentNameToIssue);
    setIssuingBook(null);
  };

  return (
    <div className="space-y-6">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <Bus className="w-6 h-6 text-indigo-500" />
            Library & Fleet GPS Transport Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time telemetry for school buses and automated library book issuing for {tenant.name}.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 self-start">
          <button
            onClick={() => setActiveTab('transport')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'transport'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-500" />
            <span>Bus GPS Tracker</span>
          </button>
          <button
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'library'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
            <span>Library Book Issuing</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: REAL-TIME BUS GPS TRACKING */}
      {activeTab === 'transport' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Bus Fleet List (1 col) */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Active Transit Fleet ({routes.length} Vehicles)
            </h3>

            <div className="space-y-3">
              {routes.map((bus) => (
                <button
                  key={bus.id}
                  onClick={() => setSelectedBus(bus)}
                  className={`w-full text-left p-4 rounded-2xl border transition-all ${
                    selectedBus.id === bus.id
                      ? 'bg-white dark:bg-slate-900 border-indigo-500 shadow-md ring-1 ring-indigo-500'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <Bus className="w-4 h-4 text-indigo-500" />
                      {bus.busNumber}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                      In Transit
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 line-clamp-1">
                    {bus.routeCode}
                  </p>

                  <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                    <div>
                      <span>Current Speed:</span>
                      <p className="font-mono font-bold text-slate-800 dark:text-slate-200">{bus.speedKmH} km/h</p>
                    </div>
                    <div>
                      <span>Occupancy:</span>
                      <p className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{bus.studentsOnBoard}/{bus.capacity}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Active Bus Live Route Map & Telemetry Dashboard (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
              {/* Telemetry Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-900 dark:text-white">
                      Vehicle: {selectedBus.busNumber}
                    </span>
                    <span className="text-xs text-slate-400">({selectedBus.routeCode})</span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Driver: <strong className="text-slate-700 dark:text-slate-300">{selectedBus.driverName}</strong> • Direct: <span className="font-mono text-emerald-600">{selectedBus.driverPhone}</span>
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block uppercase font-bold">ETA Next Stop</span>
                    <span className="text-sm font-black text-indigo-600 dark:text-indigo-400 font-mono">
                      {selectedBus.etaNextStop}
                    </span>
                  </div>
                </div>
              </div>

              {/* Simulated GPS Radar & Route Visualizer */}
              <div className="relative h-64 bg-slate-950 rounded-2xl overflow-hidden p-6 border border-slate-800 flex flex-col justify-between select-none">
                {/* Simulated Map Grid */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:24px_24px] opacity-30" />

                <div className="relative flex items-center justify-between text-xs text-white z-10">
                  <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur px-3 py-1.5 rounded-full border border-slate-700">
                    <Compass className="w-4 h-4 text-indigo-400 animate-spin" />
                    <span className="font-mono text-[11px]">GPS SATELLITE LOCK (14 BARS)</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-3 py-1 rounded-full text-[11px] font-bold">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Safe Corridor Speed Limit: 40 km/h</span>
                  </div>
                </div>

                {/* Simulated GPS Coordinate Waypoint Pins */}
                <div className="relative z-10 flex items-center justify-between px-4 my-auto">
                  {selectedBus.stops.map((st, i) => (
                    <div key={i} className="flex flex-col items-center text-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shadow-lg transition-transform ${
                          st.status === 'passed'
                            ? 'bg-emerald-600 text-white'
                            : st.status === 'current'
                            ? 'bg-amber-500 text-white ring-4 ring-amber-500/30 scale-125 animate-pulse'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {i + 1}
                      </div>
                      <span className="text-[10px] font-medium text-slate-300 mt-2 max-w-[80px] truncate">
                        {st.stopName}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400">{st.scheduledTime}</span>
                    </div>
                  ))}
                </div>

                <div className="relative flex items-center justify-between text-[11px] text-slate-400 z-10 font-mono">
                  <span>LAT: 12.9716° N, LON: 77.5946° E</span>
                  <span className="text-emerald-400">Current Station: {selectedBus.currentStop}</span>
                </div>
              </div>

              {/* Waypoints Timeline List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Scheduled Transit Stops Sequence
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {selectedBus.stops.map((s, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border flex items-center justify-between ${
                        s.status === 'current'
                          ? 'bg-amber-500/10 border-amber-500/40 text-slate-900 dark:text-white'
                          : s.status === 'passed'
                          ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-500'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <MapPin className={`w-4 h-4 shrink-0 ${s.status === 'current' ? 'text-amber-500' : 'text-slate-400'}`} />
                        <span className="font-semibold truncate">{s.stopName}</span>
                      </div>
                      <span className="font-mono text-[10px] uppercase font-bold shrink-0">
                        {s.scheduledTime}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: DIGITAL LIBRARY & BOOK ISSUING */}
      {activeTab === 'library' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Institutional Book Inventory ({books.length} Catalog Titles)
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={librarySearch}
                onChange={(e) => setLibrarySearch(e.target.value)}
                placeholder="Search by title, author, or ISBN..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredBooks.map((bk) => (
              <div
                key={bk.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold uppercase">
                      {bk.category}
                    </span>
                    <span className="font-mono text-[11px]">{bk.isbn}</span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {bk.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Author: {bk.author}
                  </p>

                  <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-slate-500">Available in Stacks:</span>
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {bk.availableCopies} of {bk.totalCopies} copies
                      </span>
                    </div>
                    {bk.issuedTo && bk.issuedTo.length > 0 && (
                      <div className="pt-2 border-t border-slate-200 dark:border-slate-700 text-[11px] text-slate-500">
                        <span>Currently Issued to: {bk.issuedTo.map(i => `${i.studentName} (Due: ${i.dueDate})`).join(', ')}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-[11px] text-slate-400 font-mono">ID: {bk.id}</span>
                  <button
                    onClick={() => setIssuingBook(bk)}
                    disabled={bk.availableCopies === 0}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Issue to Student</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* ISSUE BOOK MODAL */}
          {issuingBook && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
              <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                  <h3 className="font-bold text-sm">Issue Physical Library Resource</h3>
                  <button onClick={() => setIssuingBook(null)} className="text-slate-400 hover:text-white">✕</button>
                </div>

                <form onSubmit={handleConfirmIssue} className="p-6 space-y-4">
                  <div className="text-xs">
                    <span className="text-slate-400">Selected Book:</span>
                    <p className="font-bold text-slate-900 dark:text-white text-sm mt-0.5">{issuingBook.title}</p>
                    <p className="text-[11px] text-slate-500">by {issuingBook.author}</p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Student Borrower Full Name</label>
                    <input
                      type="text"
                      required
                      value={studentNameToIssue}
                      onChange={(e) => setStudentNameToIssue(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/20 text-xs text-indigo-700 dark:text-indigo-300">
                    Standard loan period: 14 calendar days. Automated WhatsApp return alert dispatched 2 days prior to expiry.
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIssuingBook(null)}
                      className="px-4 py-2 border rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
                    >
                      Confirm Checkout
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
