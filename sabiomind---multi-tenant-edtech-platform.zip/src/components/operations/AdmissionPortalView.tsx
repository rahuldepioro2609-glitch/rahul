import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdmissionApplication } from '../../types';
import {
  UserCheck,
  Plus,
  FileCheck,
  UploadCloud,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Eye,
  AlertCircle,
  FileText
} from 'lucide-react';

export const AdmissionPortalView: React.FC = () => {
  const { admissions, addAdmission, updateAdmissionStatus, tenant } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // New application form state
  const [applicantName, setApplicantName] = useState('');
  const [parentName, setParentName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [gradeApplying, setGradeApplying] = useState('Class 11 - Science (PCM / JEE)');
  const [previousSchool, setPreviousSchool] = useState('');
  const [uploadedDocs, setUploadedDocs] = useState([
    { name: 'Class 10 Board Marksheet (CBSE/ICSE/State)', type: 'PDF', verified: true },
    { name: 'School Leaving / Transfer Certificate (TC)', type: 'PDF', verified: true },
    { name: 'Student & Parent Aadhaar Identity Proof', type: 'JPG', verified: false },
    { name: 'Character & Migration Certificate', type: 'PDF', verified: false }
  ]);

  const filteredAdmissions = admissions.filter(item => {
    const matchesSearch = item.applicantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName || !phone) return;

    addAdmission({
      applicantName,
      parentName,
      phone,
      email,
      gradeApplying,
      previousSchool,
      documents: uploadedDocs
    });

    setIsModalOpen(false);
    setApplicantName('');
    setParentName('');
    setPhone('');
    setEmail('');
    setPreviousSchool('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <UserCheck className="w-6 h-6 text-indigo-500" />
            Digital Admission & Student Onboarding Portal
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            End-to-end applicant onboarding with encrypted document verification for {tenant.name}.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-sm flex items-center gap-2 self-start transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Admission Application</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          {['All', 'Pending Review', 'Documents Verified', 'Admitted'].map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                statusFilter === st
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search candidate name or ID..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Applications Cards / Table */}
      <div className="grid grid-cols-1 gap-4">
        {filteredAdmissions.map((app) => (
          <div
            key={app.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-bold flex items-center justify-center text-sm">
                  {app.applicantName.charAt(0)}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {app.applicantName}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Application ID: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{app.id}</span> • Applied: {app.appliedDate}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                    app.status === 'Admitted'
                      ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                      : app.status === 'Documents Verified'
                      ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/30'
                      : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                  }`}
                >
                  {app.status}
                </span>

                <select
                  value={app.status}
                  onChange={(e) => updateAdmissionStatus(app.id, e.target.value as any)}
                  className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs py-1 px-2 text-slate-700 dark:text-slate-300"
                >
                  <option value="Pending Review">Set: Pending Review</option>
                  <option value="Documents Verified">Set: Documents Verified</option>
                  <option value="Admitted">Set: Admitted & Issued</option>
                  <option value="Rejected">Set: Rejected</option>
                </select>
              </div>
            </div>

            {/* Academic & Contact details */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Grade Applying</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{app.gradeApplying}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Previous School</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{app.previousSchool}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Parent / Guardian</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{app.parentName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Contact Mobile</span>
                <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">{app.phone}</span>
              </div>
            </div>

            {/* Uploaded Documents List */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                Attached Digital Certificates & Transcripts ({app.documents.length})
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {app.documents.map((doc, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <FileText className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span className="truncate text-slate-700 dark:text-slate-300 text-[11px]">{doc.name}</span>
                    </div>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase shrink-0 ${
                        doc.verified
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {doc.verified ? 'Verified' : 'Pending'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* NEW APPLICATION MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm">New Digital Admission Onboarding</h3>
                <p className="text-xs text-slate-400">Institutional registration portal for {tenant.name}</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Student Full Name *</label>
                  <input
                    type="text"
                    required
                    value={applicantName}
                    onChange={(e) => setApplicantName(e.target.value)}
                    placeholder="e.g. Samarth Deshmukh"
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Parent / Guardian Name *</label>
                  <input
                    type="text"
                    required
                    value={parentName}
                    onChange={(e) => setParentName(e.target.value)}
                    placeholder="e.g. Anand Deshmukh"
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Mobile (for OTP verification) *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 00112"
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@example.com"
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Grade / Track Applying For</label>
                  <select
                    value={gradeApplying}
                    onChange={(e) => setGradeApplying(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option>Class 11 - Science (PCM / JEE Advanced)</option>
                    <option>Class 11 - Medical Track (PCB / NEET UG)</option>
                    <option>Class 11 - Commerce (Accountancy, Maths & Economics)</option>
                    <option>Class 11 - Humanities & Social Sciences</option>
                    <option>Class 9 - Foundation Olympiad & NTSE Track</option>
                    <option>Class 10 - CBSE / ICSE Board Track</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Previous School / Board</label>
                  <input
                    type="text"
                    value={previousSchool}
                    onChange={(e) => setPreviousSchool(e.target.value)}
                    placeholder="e.g. Kendriya Vidyalaya IIT"
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Document upload simulation */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center">
                <UploadCloud className="w-8 h-8 text-indigo-500 mx-auto mb-1.5" />
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Documents Attached Automatically
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Standard 3-document package: Marksheet, Transfer Certificate & ID Proof.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold shadow transition-colors"
                >
                  Submit & Log Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
