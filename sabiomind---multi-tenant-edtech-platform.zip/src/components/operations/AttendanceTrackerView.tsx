import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AttendanceEntry } from '../../types';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  Users,
  Search,
  CheckSquare,
  Calendar,
  Sparkles
} from 'lucide-react';

export const AttendanceTrackerView: React.FC = () => {
  const { attendance, toggleAttendanceStatus, bulkMarkAllPresent, tenant } = useApp();
  const [roleFilter, setRoleFilter] = useState<'all' | 'student' | 'staff'>('student');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const filteredEntries = attendance.filter(item => {
    const matchesRole = roleFilter === 'all' || item.role === roleFilter;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.rollNo.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRole && matchesSearch;
  });

  const presentCount = filteredEntries.filter(i => i.status === 'present').length;
  const absentCount = filteredEntries.filter(i => i.status === 'absent').length;
  const lateCount = filteredEntries.filter(i => i.status === 'late').length;
  const rate = Math.round((presentCount / (filteredEntries.length || 1)) * 100);

  const getStatusBadge = (status: AttendanceEntry['status']) => {
    switch (status) {
      case 'present':
        return (
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Present
          </span>
        );
      case 'absent':
        return (
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1">
            <XCircle className="w-3 h-3" /> Absent
          </span>
        );
      case 'late':
        return (
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center gap-1">
            <Clock className="w-3 h-3" /> Late
          </span>
        );
      case 'excused':
        return (
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/30 flex items-center gap-1">
            Excused
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <CalendarCheck className="w-6 h-6 text-indigo-500" />
            Daily Attendance & Biometric Logging Tracker
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Live attendance matrix for staff and students with monthly percentage alerts for {tenant.name}.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="text-xs p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono"
          />
          <button
            onClick={bulkMarkAllPresent}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5 transition-colors"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>Mark All Present</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Headcount</span>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">{filteredEntries.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-500">Present</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">{presentCount}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-500">Absent</span>
          <p className="text-2xl font-black text-rose-600 mt-1">{absentCount}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-500">Daily Attendance Rate</span>
          <p className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">{rate}%</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {[
            { id: 'student', label: 'Students Roster' },
            { id: 'staff', label: 'Faculty & Staff' },
            { id: 'all', label: 'All Personnel' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setRoleFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                roleFilter === tab.id
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter by name or roll number..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Attendance Roster Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500 uppercase font-bold text-[10px]">
                <th className="p-4">Candidate / Staff</th>
                <th className="p-4">Department / Class</th>
                <th className="p-4">Biometric Check-in</th>
                <th className="p-4">Current Status (Click to Toggle)</th>
                <th className="p-4">Monthly Standing</th>
                <th className="p-4 text-right">Audit Warning</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredEntries.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="p-4">
                    <div className="font-bold text-slate-900 dark:text-white">{row.name}</div>
                    <div className="text-[11px] font-mono text-slate-400">{row.rollNo}</div>
                  </td>
                  <td className="p-4 text-slate-600 dark:text-slate-300">
                    {row.grade || (row.role === 'staff' ? 'Faculty Member' : 'General')}
                  </td>
                  <td className="p-4 font-mono text-slate-500">
                    {row.checkInTime || '--:--'}
                  </td>
                  <td className="p-4">
                    <button
                      onClick={() => toggleAttendanceStatus(row.id)}
                      className="hover:scale-105 transition-transform"
                      title="Click to cycle status"
                    >
                      {getStatusBadge(row.status)}
                    </button>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-mono font-bold ${
                          row.monthlyPercent >= 90
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : row.monthlyPercent >= 75
                            ? 'text-amber-500'
                            : 'text-rose-500'
                        }`}
                      >
                        {row.monthlyPercent}%
                      </span>
                      <div className="w-16 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            row.monthlyPercent >= 75 ? 'bg-emerald-500' : 'bg-rose-500'
                          }`}
                          style={{ width: `${row.monthlyPercent}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    {row.monthlyPercent < 75 ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30">
                        <AlertTriangle className="w-3 h-3" /> Defaulter (&lt;75%)
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                        Satisfactory
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
