import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Award,
  CreditCard,
  Printer,
  Download,
  QrCode,
  Sparkles,
  CheckCircle,
  Building2,
  Calendar,
  FileCheck2,
  RefreshCw
} from 'lucide-react';

export const IdAndReportCardGeneratorView: React.FC = () => {
  const { tenant, user } = useApp();
  const [activeMode, setActiveMode] = useState<'id_card' | 'report_card'>('id_card');
  const [selectedStudent, setSelectedStudent] = useState({
    name: 'Aarav Patel',
    rollNumber: 'AP-12-042',
    apaarId: '9842 1084 3912',
    grade: 'Class 12 - Senior Secondary (JEE / CBSE Science)',
    bloodGroup: 'O+ Positive',
    emergencyPhone: '+91 98765 43210',
    validUntil: 'May 2027',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    academicYear: '2026 - 2027',
    term: 'Annual Board Assessment & Evaluation',
    subjects: [
      { name: 'Physics (Theory + Practical Lab)', maxMarks: 100, obtained: 95, grade: 'A1', remarks: 'Exceptional analytical problem-solving and lab precision.' },
      { name: 'Chemistry (Organic, Inorganic & Physical)', maxMarks: 100, obtained: 92, grade: 'A1', remarks: 'Strong conceptual clarity in chemical kinetics & synthesis.' },
      { name: 'Mathematics (Calculus, Probability & Vectors)', maxMarks: 100, obtained: 98, grade: 'A1', remarks: 'Top percentile in mathematical proofs and computational speed.' },
      { name: 'Computer Science (Python & SQL Database)', maxMarks: 100, obtained: 96, grade: 'A1', remarks: 'Exemplary coding aptitude and project architecture.' },
      { name: 'English Core & Literature', maxMarks: 100, obtained: 89, grade: 'A2', remarks: 'Insightful essay structuring and strong verbal fluency.' }
    ],
    attendancePercent: 96.4
  });

  const [idOrientation, setIdOrientation] = useState<'vertical' | 'horizontal'>('vertical');

  const totalMax = selectedStudent.subjects.reduce((a, s) => a + s.maxMarks, 0);
  const totalObtained = selectedStudent.subjects.reduce((a, s) => a + s.obtained, 0);
  const overallPercentage = Math.round((totalObtained / totalMax) * 1000) / 10;
  const cgpa = (overallPercentage / 9.5).toFixed(2);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <Award className="w-6 h-6 text-amber-500" />
            Automated ID Card & Official Report Card Generator
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Dynamic cryptographic verification templates for {tenant.name}.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 self-start">
          <button
            onClick={() => setActiveMode('id_card')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeMode === 'id_card'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-indigo-500" />
            <span>Digital ID Card</span>
          </button>
          <button
            onClick={() => setActiveMode('report_card')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeMode === 'report_card'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5 text-emerald-500" />
            <span>Term Report Card</span>
          </button>
        </div>
      </div>

      {/* MODE 1: DIGITAL ID CARD GENERATOR */}
      {activeMode === 'id_card' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controls & Customization */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              ID Badge Specifications
            </h3>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Recipient Name</label>
              <input
                type="text"
                value={selectedStudent.name}
                onChange={(e) => setSelectedStudent({ ...selectedStudent, name: e.target.value })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Roll / ID Number</label>
                <input
                  type="text"
                  value={selectedStudent.rollNumber}
                  onChange={(e) => setSelectedStudent({ ...selectedStudent, rollNumber: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Blood Group</label>
                <input
                  type="text"
                  value={selectedStudent.bloodGroup}
                  onChange={(e) => setSelectedStudent({ ...selectedStudent, bloodGroup: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Grade / Track</label>
              <input
                type="text"
                value={selectedStudent.grade}
                onChange={(e) => setSelectedStudent({ ...selectedStudent, grade: e.target.value })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div className="pt-2 flex gap-2">
              <button
                onClick={handlePrint}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow flex items-center justify-center gap-2 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Digital Badge</span>
              </button>
            </div>
          </div>

          {/* Live ID Card Preview (2 cols) */}
          <div className="lg:col-span-2 bg-slate-100 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 flex flex-col md:flex-row items-center justify-center gap-8 shadow-inner">
            {/* FRONT OF ID CARD */}
            <div className="w-[300px] h-[460px] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col justify-between relative text-slate-900 select-none transform hover:scale-105 transition-transform duration-300">
              {/* Card Header with institute background color */}
              <div 
                className="p-4 text-white text-center relative overflow-hidden"
                style={{ backgroundColor: tenant.primaryColor }}
              >
                <div className="text-[10px] uppercase font-bold tracking-widest opacity-80">
                  {tenant.code} OFFICIAL IDENTIFIER
                </div>
                <h4 className="font-black text-sm tracking-tight truncate mt-0.5">
                  {tenant.name}
                </h4>
                <div className="w-8 h-1 bg-white/40 rounded-full mx-auto mt-2" />
              </div>

              {/* Photo & Main Details */}
              <div className="px-6 text-center space-y-3">
                <div className="relative w-24 h-24 mx-auto rounded-full ring-4 ring-slate-100 shadow-md overflow-hidden bg-slate-100">
                  <img
                    src={selectedStudent.avatar}
                    alt={selectedStudent.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div>
                  <h3 className="text-base font-black text-slate-900 leading-tight">
                    {selectedStudent.name}
                  </h3>
                  <span className="text-[11px] font-mono font-bold text-indigo-600 px-2 py-0.5 rounded bg-indigo-50 mt-1 inline-block">
                    {selectedStudent.rollNumber}
                  </span>
                </div>

                <div className="text-left bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px] space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Track:</span>
                    <span className="font-semibold text-slate-700 truncate max-w-[130px]">{selectedStudent.grade}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Blood Group:</span>
                    <span className="font-bold text-rose-600">{selectedStudent.bloodGroup}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Emergency:</span>
                    <span className="font-mono text-slate-700">{selectedStudent.emergencyPhone}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer with QR Code & Barcode */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <div className="text-left text-[9px] text-slate-400 leading-tight">
                  <span className="font-bold text-slate-600 block">EXPIRES: {selectedStudent.validUntil}</span>
                  <span>Institutional Property</span>
                </div>
                <div className="w-10 h-10 bg-white p-1 rounded border border-slate-200 flex items-center justify-center">
                  <QrCode className="w-8 h-8 text-slate-800" />
                </div>
              </div>
            </div>

            {/* BACK OF ID CARD */}
            <div className="w-[300px] h-[460px] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col justify-between p-5 text-slate-800 select-none">
              <div className="space-y-3">
                <div className="h-9 bg-slate-900 rounded flex items-center px-3 text-white text-[10px] font-mono">
                  ||||| | |||| || |||||| | ||| |||| |
                </div>

                <div className="text-center pt-1">
                  <h4 className="text-xs font-bold text-slate-900 tracking-tight uppercase">{tenant.name}</h4>
                  <p className="text-[9px] text-slate-500 font-mono mt-0.5">
                    Affiliation: {tenant.affiliationNumber || 'CBSE/AFF/1930412'} • Board: {tenant.board || 'CBSE'}
                  </p>
                  <p className="text-[9px] text-slate-500 mt-1 leading-tight">
                    {tenant.address || 'Knowledge Park'}, {tenant.city || 'New Delhi'}, {tenant.state || 'Delhi'} - {tenant.pincode || '110075'}
                  </p>
                </div>

                <div className="pt-2">
                  <h5 className="text-[10px] font-bold text-slate-800 uppercase">Institutional Rules</h5>
                  <p className="text-[9px] text-slate-500 mt-1 leading-relaxed text-left">
                    1. Mandatory for campus entry, biometric attendance, and online DRM proctored examinations.
                    <br />
                    2. Non-transferable. Loss must be reported immediately to the School Administrative Cell.
                    <br />
                    3. If found, return to school desk or call {tenant.supportPhone}.
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 text-center space-y-1">
                <div className="font-serif italic text-xs text-indigo-950 font-bold">
                  Dr. Rameshwar Sharma, Ph.D.
                </div>
                <div className="text-[9px] text-slate-500 uppercase font-semibold">
                  Principal & Authorized Signatory
                </div>
                <div className="text-[8px] font-mono text-slate-400 pt-0.5">
                  DIGITALLY VERIFIED (UIDAI / APAAR COMPLIANT)
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODE 2: PRINTABLE TERM REPORT CARD */}
      {activeMode === 'report_card' && (
        <div className="space-y-4">
          <div className="flex justify-end gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print Official Grade Sheet</span>
            </button>
          </div>

          {/* Report Card Document Sheet */}
          <div className="bg-white text-slate-900 rounded-2xl border border-slate-300 shadow-xl p-8 sm:p-12 max-w-4xl mx-auto select-none print:shadow-none print:border-none">
            {/* Institution Letterhead Header */}
            <div className="text-center border-b-2 border-slate-900 pb-6 mb-6">
              <div 
                className="w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center text-white font-bold text-lg shadow"
                style={{ backgroundColor: tenant.primaryColor }}
              >
                {tenant.name.charAt(0)}
              </div>
              <h2 className="text-2xl font-black uppercase tracking-tight text-slate-900">
                {tenant.name}
              </h2>
              <p className="text-xs text-slate-700 font-medium mt-0.5">
                {tenant.address || 'Campus'}, {tenant.city || 'New Delhi'}, {tenant.state || 'Delhi NCR'} - {tenant.pincode || '110075'}
              </p>
              <p className="text-[11px] text-slate-600 font-semibold mt-0.5">
                Affiliated to {tenant.board || 'Central Board of Secondary Education (CBSE)'} • Affiliation No: <span className="font-mono">{tenant.affiliationNumber || 'CBSE/AFF/1930412'}</span> • School Code: <span className="font-mono">{tenant.code}</span>
              </p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                Portal: {tenant.customDomain} • Contact: {tenant.supportPhone}
              </p>
            </div>

            <div className="text-center mb-6">
              <span className="text-xs font-bold uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full border border-slate-300">
                Continuous & Comprehensive Evaluation (CCE) Annual Grade Sheet
              </span>
              <p className="text-sm font-bold text-slate-800 mt-2">
                Academic Session: {selectedStudent.academicYear} • {selectedStudent.term}
              </p>
            </div>

            {/* Student metadata grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs mb-6">
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Student Full Name</span>
                <span className="font-bold text-slate-900">{selectedStudent.name}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Roll No. / Enrollment</span>
                <span className="font-mono font-bold text-indigo-700">{selectedStudent.rollNumber}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">APAAR / PEN ID</span>
                <span className="font-mono font-semibold text-slate-800">{selectedStudent.apaarId}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Class / Stream</span>
                <span className="font-bold text-slate-900">{selectedStudent.grade}</span>
              </div>
            </div>

            {/* Subject Marks Table */}
            <div className="overflow-x-auto mb-6">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900 text-white font-bold uppercase text-[11px]">
                    <th className="p-3 border border-slate-700">Course Subject</th>
                    <th className="p-3 border border-slate-700 text-center w-24">Max Marks</th>
                    <th className="p-3 border border-slate-700 text-center w-24">Obtained</th>
                    <th className="p-3 border border-slate-700 text-center w-20">Grade</th>
                    <th className="p-3 border border-slate-700">Faculty Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedStudent.subjects.map((sub, i) => (
                    <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                      <td className="p-3 border border-slate-200 font-semibold text-slate-800">{sub.name}</td>
                      <td className="p-3 border border-slate-200 text-center font-mono">{sub.maxMarks}</td>
                      <td className="p-3 border border-slate-200 text-center font-mono font-bold text-indigo-700">{sub.obtained}</td>
                      <td className="p-3 border border-slate-200 text-center font-bold text-emerald-700">{sub.grade}</td>
                      <td className="p-3 border border-slate-200 text-slate-600 italic text-[11px]">{sub.remarks}</td>
                    </tr>
                  ))}
                  <tr className="bg-slate-100 font-black text-xs border-t-2 border-slate-900">
                    <td className="p-3 border border-slate-300">GRAND TOTAL AGGREGATE</td>
                    <td className="p-3 border border-slate-300 text-center font-mono">{totalMax}</td>
                    <td className="p-3 border border-slate-300 text-center font-mono text-indigo-800">{totalObtained}</td>
                    <td className="p-3 border border-slate-300 text-center text-emerald-800 font-mono">{overallPercentage}%</td>
                    <td className="p-3 border border-slate-300 text-slate-900">
                      Result: <span className="text-emerald-700 font-bold">PASS (FIRST CLASS WITH DISTINCTION)</span> • CGPA: <span className="text-indigo-700 font-bold font-mono">{cgpa}</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Official Signatures & Seal */}
            <div className="pt-8 border-t border-slate-200 grid grid-cols-3 gap-6 text-center text-xs">
              <div>
                <div className="font-serif italic font-bold text-slate-800 text-sm">Prof. A. Nambiar</div>
                <div className="border-t border-slate-400 mt-2 pt-1 text-[10px] uppercase text-slate-500 font-bold">Class Teacher</div>
              </div>

              <div>
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-indigo-700 text-indigo-800 flex items-center justify-center font-bold text-[9px] mx-auto uppercase">
                  INSTITUTE SEAL
                </div>
                <p className="text-[8px] text-slate-400 font-mono mt-1">AFFILIATION VERIFIED</p>
              </div>

              <div>
                <div className="font-serif italic font-bold text-slate-800 text-sm">Dr. Rameshwar Sharma</div>
                <div className="border-t border-slate-400 mt-2 pt-1 text-[10px] uppercase text-slate-500 font-bold">Principal / Head of Institution</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
