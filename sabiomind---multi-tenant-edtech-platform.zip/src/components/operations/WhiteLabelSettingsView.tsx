import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TENANTS } from '../../data/mockData';
import {
  Building2,
  Palette,
  Globe,
  Shield,
  CheckCircle2,
  Save,
  RotateCcw,
  Sparkles,
  PhoneCall,
  MapPin,
  FileBadge
} from 'lucide-react';

export const WhiteLabelSettingsView: React.FC = () => {
  const { tenant, setTenant, updateTenantSettings } = useApp();

  const [form, setForm] = useState({
    name: tenant.name,
    tagline: tenant.tagline,
    code: tenant.code,
    customDomain: tenant.customDomain,
    primaryColor: tenant.primaryColor,
    watermarkText: tenant.watermarkText,
    supportPhone: tenant.supportPhone,
    address: tenant.address || 'Knowledge City',
    city: tenant.city || 'New Delhi',
    state: tenant.state || 'Delhi NCR',
    pincode: tenant.pincode || '110075',
    gstin: tenant.gstin || '07AAAAA1234F1Z5',
    affiliationNumber: tenant.affiliationNumber || 'CBSE/AFF/1930412',
    board: tenant.board || 'CBSE Board'
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateTenantSettings(form);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const presetThemes = [
    { label: 'Indigo Core', hex: '#4f46e5' },
    { label: 'Apex Emerald', hex: '#059669' },
    { label: 'Crimson Pride', hex: '#dc2626' },
    { label: 'Royal Sapphire', hex: '#2563eb' },
    { label: 'Golden Amber', hex: '#d97706' },
    { label: 'Dark Slate', hex: '#334155' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-500" />
            White-Label & Multi-Tenant Studio
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Configure custom institutional identity, custom subdomain routing, and anti-piracy watermarking parameters.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {savedSuccess && (
            <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-lg border border-emerald-500/20">
              <CheckCircle2 className="w-4 h-4" />
              Settings Updated
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Settings Form */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-6">
          <form onSubmit={handleSave} className="space-y-6">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-xs border-b border-slate-100 dark:border-slate-800 pb-2 mb-4">
                Institutional Brand Profile
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Institute Name
                  </label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Apex Resonance Institute"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Institute Tagline / Motto
                  </label>
                  <input
                    type="text"
                    value={form.tagline}
                    onChange={(e) => setForm({ ...form, tagline: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Premier IIT-JEE & Medical Academy"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tenant Code / Acronym
                  </label>
                  <input
                    type="text"
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Custom Domain / CNAME
                  </label>
                  <div className="relative">
                    <Globe className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      value={form.customDomain}
                      onChange={(e) => setForm({ ...form, customDomain: e.target.value })}
                      className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      placeholder="portal.institute.edu.in"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Support Helpline / Parent Desk (India)
                  </label>
                  <div className="relative">
                    <PhoneCall className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      value={form.supportPhone}
                      onChange={(e) => setForm({ ...form, supportPhone: e.target.value })}
                      className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      placeholder="+91 11 4982 3000"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Indian Campus Address & Statutory Registry */}
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-xs border-b border-slate-100 dark:border-slate-800 pb-2 mb-4 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-500" />
                Indian Campus Address & Statutory Registry
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Campus Physical Address
                  </label>
                  <input
                    type="text"
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    placeholder="Plot 14, Institutional Area, Sector 12"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    placeholder="New Delhi / Bengaluru"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    State & PIN Code
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={form.state}
                      onChange={(e) => setForm({ ...form, state: e.target.value })}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      placeholder="Delhi NCR"
                    />
                    <input
                      type="text"
                      value={form.pincode}
                      onChange={(e) => setForm({ ...form, pincode: e.target.value })}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      placeholder="110075"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Board Affiliation (CBSE / ICSE / State)
                  </label>
                  <select
                    value={form.board}
                    onChange={(e) => setForm({ ...form, board: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option>CBSE (Central Board of Secondary Education)</option>
                    <option>CISCE (ICSE / ISC)</option>
                    <option>Karnataka State Pre-University Board</option>
                    <option>Maharashtra State Board</option>
                    <option>Telangana Board of Intermediate Education</option>
                    <option>IB / Cambridge International</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Board Affiliation Number
                  </label>
                  <input
                    type="text"
                    value={form.affiliationNumber}
                    onChange={(e) => setForm({ ...form, affiliationNumber: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                    placeholder="CBSE/AFF/1930412"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Institutional GSTIN (Tax Identification)
                  </label>
                  <input
                    type="text"
                    value={form.gstin}
                    onChange={(e) => setForm({ ...form, gstin: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                    placeholder="07AAAAA1234F1Z5"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Printed automatically on official fee tax invoices and academic transcripts under SAC 9992.
                  </p>
                </div>
              </div>
            </div>

            {/* Primary Brand Theme */}
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-xs border-b border-slate-100 dark:border-slate-800 pb-2 mb-4">
                Accent Theme & DRM Watermark
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Primary Brand Color
                  </label>
                  <div className="flex flex-wrap items-center gap-3">
                    {presetThemes.map(p => (
                      <button
                        type="button"
                        key={p.hex}
                        onClick={() => setForm({ ...form, primaryColor: p.hex })}
                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                          form.primaryColor === p.hex
                            ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300'
                            : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: p.hex }} />
                        {p.label}
                      </button>
                    ))}
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={form.primaryColor}
                        onChange={(e) => setForm({ ...form, primaryColor: e.target.value })}
                        className="w-7 h-7 rounded border border-slate-300 dark:border-slate-700 cursor-pointer"
                      />
                      <span className="font-mono text-xs text-slate-500">{form.primaryColor}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Anti-Piracy DRM Watermark Template
                  </label>
                  <input
                    type="text"
                    value={form.watermarkText}
                    onChange={(e) => setForm({ ...form, watermarkText: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                    placeholder="CONFIDENTIAL - SabioMind Anti-Piracy DRM Protected"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Rendered dynamically alongside the logged-in student's phone number, live timestamp, and IP hash across all video streams and documents.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setForm({
                  name: tenant.name,
                  tagline: tenant.tagline,
                  code: tenant.code,
                  customDomain: tenant.customDomain,
                  primaryColor: tenant.primaryColor,
                  watermarkText: tenant.watermarkText,
                  supportPhone: tenant.supportPhone,
                  address: tenant.address || 'Knowledge City',
                  city: tenant.city || 'New Delhi',
                  state: tenant.state || 'Delhi NCR',
                  pincode: tenant.pincode || '110075',
                  gstin: tenant.gstin || '07AAAAA1234F1Z5',
                  affiliationNumber: tenant.affiliationNumber || 'CBSE/AFF/1930412',
                  board: tenant.board || 'CBSE Board'
                })}
                className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Reset Changes
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold text-white shadow-sm hover:opacity-90 transition-opacity"
                style={{ backgroundColor: form.primaryColor }}
              >
                <Save className="w-3.5 h-3.5" />
                Save Institutional Settings
              </button>
            </div>
          </form>
        </div>

        {/* Live Preview Card */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
            <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-4">
              Live White-Label Preview
            </h4>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-4">
              {/* Header preview */}
              <div className="flex items-center gap-3">
                <div 
                  className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white text-sm shadow"
                  style={{ backgroundColor: form.primaryColor }}
                >
                  {form.code.slice(0, 2)}
                </div>
                <div className="overflow-hidden">
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {form.name}
                  </h5>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                    {form.customDomain}
                  </p>
                </div>
              </div>

              {/* Sample badge */}
              <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700">
                <div className="flex justify-between items-center text-[10px] font-bold">
                  <span className="text-slate-500">Student Portal</span>
                  <span 
                    className="px-1.5 py-0.5 rounded text-[9px] text-white"
                    style={{ backgroundColor: form.primaryColor }}
                  >
                    PRO LICENSED
                  </span>
                </div>
                <div className="mt-2 text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {form.tagline}
                </div>
                <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-500 space-y-0.5">
                  <div className="flex items-center gap-1 font-mono">
                    <MapPin className="w-3 h-3 text-emerald-500 shrink-0" />
                    <span>{form.city}, {form.state} - {form.pincode}</span>
                  </div>
                  <div className="text-[9px] font-mono text-indigo-600 dark:text-indigo-400">
                    Affiliation: {form.affiliationNumber} ({form.board})
                  </div>
                </div>
              </div>

              {/* DRM watermark simulation */}
              <div className="p-2.5 rounded bg-slate-900 text-slate-300 text-[10px] font-mono border border-slate-800">
                <div className="text-emerald-400 font-bold flex items-center gap-1 mb-1">
                  <Shield className="w-3 h-3" />
                  DRM Watermark Preview
                </div>
                <div className="opacity-80 break-words">
                  {form.watermarkText} • +91 98765 43210
                </div>
              </div>
            </div>
          </div>

          {/* Institutional Switcher Quick Switch */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
            <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">
              Switch Institutional Tenant
            </h4>
            <div className="space-y-2">
              {TENANTS.map(t => (
                <button
                  key={t.id}
                  onClick={() => {
                    setTenant(t);
                    setForm({
                      name: t.name,
                      tagline: t.tagline,
                      code: t.code,
                      customDomain: t.customDomain,
                      primaryColor: t.primaryColor,
                      watermarkText: t.watermarkText,
                      supportPhone: t.supportPhone,
                      address: t.address || 'Knowledge City',
                      city: t.city || 'New Delhi',
                      state: t.state || 'Delhi NCR',
                      pincode: t.pincode || '110075',
                      gstin: t.gstin || '07AAAAA1234F1Z5',
                      affiliationNumber: t.affiliationNumber || 'CBSE/AFF/1930412',
                      board: t.board || 'CBSE Board'
                    });
                  }}
                  className={`w-full flex items-center justify-between p-2.5 rounded-lg border text-left transition-all ${
                    t.id === tenant.id
                      ? 'border-indigo-500 bg-indigo-50/40 dark:bg-indigo-950/30'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: t.primaryColor }} />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {t.name}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate">
                        {t.customDomain}
                      </p>
                    </div>
                  </div>
                  {t.id === tenant.id && (
                    <span className="text-[9px] font-bold text-indigo-600 dark:text-indigo-400 uppercase">
                      Current
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
