import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FeeRecord } from '../../types';
import {
  CreditCard,
  CheckCircle,
  AlertCircle,
  MessageSquare,
  Printer,
  IndianRupee,
  Download,
  Calendar,
  Search,
  Filter,
  Receipt,
  X,
  Send,
  Smartphone,
  QrCode,
  Building
} from 'lucide-react';

export const FeeManagementView: React.FC = () => {
  const { fees, recordFeePayment, sendFeeReminder, tenant } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [payingRecord, setPayingRecord] = useState<FeeRecord | null>(null);
  const [receiptRecord, setReceiptRecord] = useState<FeeRecord | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [reminderToast, setReminderToast] = useState<string | null>(null);

  const filteredFees = fees.filter(item => {
    const matchesSearch = item.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.rollNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'All' || item.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const totalCollected = fees.reduce((acc, f) => acc + f.paidAmount, 0);
  const totalOutstanding = fees.reduce((acc, f) => acc + f.pendingAmount, 0);
  const totalBilled = totalCollected + totalOutstanding;
  const collectionRate = Math.round((totalCollected / totalBilled) * 100);

  const handleOpenPay = (rec: FeeRecord) => {
    setPayingRecord(rec);
    setPaymentAmount(rec.pendingAmount);
  };

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingRecord || paymentAmount <= 0) return;
    recordFeePayment(payingRecord.id, paymentAmount);
    setReceiptRecord({
      ...payingRecord,
      paidAmount: payingRecord.paidAmount + paymentAmount,
      pendingAmount: Math.max(0, payingRecord.pendingAmount - paymentAmount),
      lastPaymentDate: new Date().toISOString().split('T')[0]
    });
    setPayingRecord(null);
  };

  const handleSendReminder = (id: string) => {
    const msg = sendFeeReminder(id);
    setReminderToast(msg);
    setTimeout(() => setReminderToast(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <CreditCard className="w-6 h-6 text-emerald-500" />
            Institutional Fee Management Suite
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Online collection, automated tax receipt generation & automated WhatsApp due alerts.
          </p>
        </div>
      </div>

      {/* WhatsApp alert notification toast */}
      {reminderToast && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs flex items-center gap-2 animate-fade-in">
          <MessageSquare className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>{reminderToast}</span>
        </div>
      )}

      {/* Metrics Summary Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Fees Collected</span>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            ₹{totalCollected.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
            +18.4% vs previous academic term
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Pending Receivables</span>
          <h3 className="text-2xl font-black text-amber-500 mt-1">
            ₹{totalOutstanding.toLocaleString('en-IN')}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Across active installments
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Collection Ratio</span>
          <h3 className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">
            {collectionRate}%
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Target benchmark: 90%
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Overdue Alerts Sent</span>
          <h3 className="text-2xl font-black text-rose-500 mt-1">
            14 Accounts
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Via WhatsApp automated bots
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          {['All', 'Paid', 'Partial', 'Overdue'].map(st => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                filterStatus === st
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search student or roll number..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Fee Records Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500 uppercase font-bold text-[10px]">
                <th className="p-4">Student Details</th>
                <th className="p-4">Total Tuition</th>
                <th className="p-4">Paid Amount</th>
                <th className="p-4">Due Balance</th>
                <th className="p-4">Status</th>
                <th className="p-4">Due Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredFees.map((f) => (
                <tr key={f.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="p-4">
                    <div className="font-bold text-slate-900 dark:text-white">{f.studentName}</div>
                    <div className="text-[11px] font-mono text-slate-500">{f.rollNumber} • {f.grade}</div>
                  </td>
                  <td className="p-4 font-mono font-semibold text-slate-900 dark:text-white">
                    ₹{f.totalFee.toLocaleString('en-IN')}
                  </td>
                  <td className="p-4 font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                    ₹{f.paidAmount.toLocaleString('en-IN')}
                  </td>
                  <td className="p-4 font-mono font-bold text-rose-500">
                    ₹{f.pendingAmount.toLocaleString('en-IN')}
                  </td>
                  <td className="p-4">
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                        f.status === 'Paid'
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                          : f.status === 'Partial'
                          ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                          : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {f.status}
                    </span>
                  </td>
                  <td className="p-4 font-mono text-slate-500">
                    {f.dueDate}
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {f.pendingAmount > 0 ? (
                        <>
                          <button
                            onClick={() => handleOpenPay(f)}
                            className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold text-xs shadow-xs transition-colors"
                          >
                            Pay Online
                          </button>
                          <button
                            onClick={() => handleSendReminder(f.id)}
                            title="Dispatch WhatsApp Payment Reminder"
                            className="p-1.5 rounded-lg border border-emerald-500/40 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => setReceiptRecord(f)}
                          className="px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg font-medium text-xs flex items-center gap-1 transition-colors"
                        >
                          <Receipt className="w-3.5 h-3.5 text-indigo-500" />
                          <span>View Receipt</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ONLINE PAYMENT MODAL */}
      {payingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm">Online Fee Collection Gateway</h3>
                <p className="text-xs text-slate-400">{payingRecord.studentName} ({payingRecord.rollNumber})</p>
              </div>
              <button onClick={() => setPayingRecord(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleProcessPayment} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Amount to Pay (₹ INR)</label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-slate-400 font-bold">₹</span>
                  <input
                    type="number"
                    max={payingRecord.pendingAmount}
                    min={1}
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(Number(e.target.value))}
                    className="w-full text-base font-bold pl-8 pr-3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Outstanding balance: ₹{payingRecord.pendingAmount.toLocaleString('en-IN')}
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">Indian Payment Gateway Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'upi', label: 'UPI / QR (GPay, PhonePe)' },
                    { id: 'card', label: 'RuPay / Cards' },
                    { id: 'netbanking', label: 'Net Banking' }
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id as any)}
                      className={`p-2.5 rounded-lg border text-center text-xs font-medium transition-all ${
                        paymentMethod === m.id
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-1 ring-emerald-500'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300">
                Encrypted NPCI / RBI-compliant gateway. Instant tax receipt & WhatsApp SMS dispatch to parent mobile.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayingRecord(null)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow"
                >
                  Authorize Payment (₹{paymentAmount.toLocaleString('en-IN')})
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* OFFICIAL AUTOMATED RECEIPT MODAL */}
      {receiptRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
          <div className="bg-white text-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-300 overflow-hidden p-6 sm:p-8 space-y-5 select-none print:p-0 print:border-none print:shadow-none">
            {/* Receipt Letterhead Header */}
            <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <div 
                    className="w-8 h-8 rounded-lg text-white font-bold flex items-center justify-center text-sm shadow-sm"
                    style={{ backgroundColor: tenant.primaryColor }}
                  >
                    {tenant.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-base font-black uppercase text-slate-900 tracking-tight leading-tight">{tenant.name}</h3>
                    <p className="text-[11px] text-slate-600 font-medium">{tenant.tagline}</p>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-slate-500 leading-tight space-y-0.5">
                  <p>Campus: {tenant.address || 'Knowledge City'}, {tenant.city || 'New Delhi'}, {tenant.state || 'Delhi NCR'} - {tenant.pincode || '110075'}</p>
                  <p>GSTIN: <span className="font-mono font-semibold">{tenant.gstin || '07AAAAA1234F1Z5'}</span> • Affiliation Code: <span className="font-mono font-semibold">{tenant.affiliationNumber || 'CBSE/AFF/1930412'}</span></p>
                  <p>Helpline: {tenant.supportPhone} • Portal: {tenant.customDomain}</p>
                </div>
              </div>
              <div className="text-right">
                <button onClick={() => setReceiptRecord(null)} className="text-slate-400 hover:text-slate-800 print:hidden text-lg font-bold">✕</button>
                <div className="mt-2 text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded border border-slate-200">
                  <p className="font-bold text-slate-800">TAX INVOICE</p>
                  <p>INV-{Date.now().toString().slice(-6)}</p>
                </div>
              </div>
            </div>

            {/* Candidate & Payment Info */}
            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Student Full Name</span>
                <span className="font-bold text-slate-900">{receiptRecord.studentName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Enrollment / Roll No.</span>
                <span className="font-mono font-bold text-indigo-700">{receiptRecord.rollNumber}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Academic Grade / Track</span>
                <span className="font-medium text-slate-700">{receiptRecord.grade}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] font-bold uppercase">Transaction Clearance Date</span>
                <span className="font-mono text-slate-700">{receiptRecord.lastPaymentDate || 'Today (Electronic Clearance)'}</span>
              </div>
            </div>

            {/* Receipt Breakdown Table */}
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-300 text-slate-700 font-bold uppercase text-[10px] bg-slate-50">
                  <th className="p-2">Fee Head Description</th>
                  <th className="p-2 text-center w-20">SAC Code</th>
                  <th className="p-2 text-right">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="p-2 font-medium">Regular Tuition & Academic Instruction</td>
                  <td className="p-2 text-center font-mono text-slate-500">9992</td>
                  <td className="p-2 text-right font-mono font-semibold">₹{(receiptRecord.paidAmount * 0.65).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Composite Lab, Practical & Computer Facilities</td>
                  <td className="p-2 text-center font-mono text-slate-500">9992</td>
                  <td className="p-2 text-right font-mono font-semibold">₹{(receiptRecord.paidAmount * 0.20).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Examination, Assessment & DRM Digital Content</td>
                  <td className="p-2 text-center font-mono text-slate-500">9992</td>
                  <td className="p-2 text-right font-mono font-semibold">₹{(receiptRecord.paidAmount * 0.15).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</td>
                </tr>
                <tr className="text-[11px] text-slate-500 bg-slate-50/50">
                  <td className="p-2 italic" colSpan={2}>Goods and Services Tax (GST Exempt under SAC 9992 - Educational Services)</td>
                  <td className="p-2 text-right font-mono">₹0.00</td>
                </tr>
                <tr className="font-black text-sm border-t-2 border-slate-900 bg-slate-100">
                  <td className="p-2.5">Total Amount Received (INR)</td>
                  <td className="p-2.5 text-center font-mono text-xs text-emerald-700 font-bold">PAID</td>
                  <td className="p-2.5 text-right font-mono text-emerald-700">₹{receiptRecord.paidAmount.toLocaleString('en-IN')}</td>
                </tr>
              </tbody>
            </table>

            {/* Actions & Print */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-200">
              <div className="text-[10px] text-slate-400 space-y-0.5">
                <p className="font-bold text-slate-600">Computer Generated Document • No signature required</p>
                <p>Authorized under Indian Information Technology Act, 2000</p>
              </div>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow transition-colors print:hidden"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Tax Receipt</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
