import {
  TenantConfig,
  LiveClass,
  ChatMessage,
  StudyResource,
  QuizQuestion,
  AdmissionApplication,
  FeeRecord,
  AttendanceEntry,
  LibraryBook,
  BusTransportRoute,
  CrmLead,
  GeneratedExamPaper,
  LessonPlanUnit
} from '../types';

export const TENANTS: TenantConfig[] = [
  {
    id: 'apex_iit',
    name: 'Apex IIT & NEET Academy',
    tagline: 'Premier Institute for JEE Advanced, NEET-UG & Olympiads',
    code: 'APEX-KOTA-2026',
    logoIcon: 'Zap',
    primaryColor: '#2563eb', // Royal Blue
    accentColor: '#38bdf8', // Sky Blue
    customDomain: 'portal.apexiit.ac.in',
    supportPhone: '+91 (0744) 242-3944',
    watermarkText: 'APEX-KOTA-CONFIDENTIAL-DRM',
    address: 'Plot 4, Electronic Complex, Road No. 1, IPIA',
    city: 'Kota',
    state: 'Rajasthan',
    pincode: '324005',
    gstin: '08AAAAA1234F1Z5',
    affiliationNumber: 'NTA/JEE-NEET/REG-8491',
    board: 'CBSE & NTA Test Prep Forum',
    currencySymbol: '₹'
  },
  {
    id: 'horizon_school',
    name: 'Delhi Public International School',
    tagline: 'Affiliated to CBSE, New Delhi (Affiliation No. 1930412)',
    code: 'DPIS-DELHI',
    logoIcon: 'GraduationCap',
    primaryColor: '#059669', // Emerald
    accentColor: '#d97706', // Amber
    customDomain: 'learn.dpisdelhi.edu.in',
    supportPhone: '+91 (011) 2617-4411',
    watermarkText: 'DPIS-CBSE-STUDENT-COPY',
    address: 'Sector 14, Phase II, Dwarka',
    city: 'New Delhi',
    state: 'Delhi NCR',
    pincode: '110075',
    gstin: '07AAAAA9876E1Z2',
    affiliationNumber: 'CBSE/AFF/1930412/2026',
    board: 'Central Board of Secondary Education (CBSE)',
    currencySymbol: '₹'
  },
  {
    id: 'quantum_stem',
    name: 'Sri Chaitanya STEM Vidyapeeth',
    tagline: 'Advanced National Olympiad & Research Foundation',
    code: 'STEM-BLR',
    logoIcon: 'Atom',
    primaryColor: '#e11d48', // Rose
    accentColor: '#8b5cf6', // Violet
    customDomain: 'online.stemvidyapeeth.ac.in',
    supportPhone: '+91 (080) 4122-9920',
    watermarkText: 'STEM-VIDYAPEETH-DO-NOT-DISTRIBUTE',
    address: '80 Feet Road, 4th Block, Koramangala',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560034',
    gstin: '29AAAAA5544B1Z8',
    affiliationNumber: 'KSEEB/STEM/A-412',
    board: 'Karnataka State Board & STEM Olympiad Council',
    currencySymbol: '₹'
  }
];

export const INITIAL_LIVE_CLASSES: LiveClass[] = [
  {
    id: 'live_101',
    title: 'Advanced Calculus: Differential Equations & Applications',
    subject: 'Mathematics',
    teacher: 'Prof. Arvind Nambiar',
    time: 'Live Now (45m elapsed)',
    isLive: true,
    viewersCount: 248,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    topic: 'Ordinary Differential Equations & Harmonic Motion',
    grade: 'Grade 12 / IIT-JEE Batch A',
    duration: '90 mins'
  },
  {
    id: 'live_102',
    title: 'Organic Reaction Mechanisms & Stereochemistry',
    subject: 'Chemistry',
    teacher: 'Dr. Sarah Jenkins',
    time: 'Starts in 15 mins (04:00 PM)',
    isLive: false,
    viewersCount: 182,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    topic: 'Nucleophilic Substitution & Elimination Kinetics',
    grade: 'Grade 12 / NEET Premier',
    duration: '75 mins'
  },
  {
    id: 'vod_201',
    title: 'Rotational Dynamics & Moment of Inertia Masterclass',
    subject: 'Physics',
    teacher: 'Dr. Rajesh Khurana',
    time: 'Recorded Yesterday',
    isLive: false,
    viewersCount: 1420,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    topic: 'Parallel Axis Theorem & Rolling Without Slipping',
    grade: 'Grade 11 / Advanced Batch',
    duration: '1h 18m'
  },
  {
    id: 'vod_202',
    title: 'Molecular Genetics & CRISPR Technology Applications',
    subject: 'Biology',
    teacher: 'Dr. Emily Watson',
    time: 'Recorded 3 days ago',
    isLive: false,
    viewersCount: 980,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    topic: 'Gene Editing, Transcription Regulation & PCR',
    grade: 'Grade 12 / Olympiad Track',
    duration: '1h 05m'
  }
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg_1',
    sender: 'System Bot',
    role: 'super_admin',
    text: '🔒 DRM Anti-Piracy Stream Protection is ACTIVE. Screen capturing is monitored & watermarked.',
    timestamp: '15:15',
    isPinned: true
  },
  {
    id: 'msg_2',
    sender: 'Prof. Arvind Nambiar',
    role: 'educator',
    text: 'Welcome everyone! Today we will solve 4 JEE Advanced benchmark problems on non-homogeneous ODEs.',
    timestamp: '15:16',
    isPinned: true
  },
  {
    id: 'msg_3',
    sender: 'Rohan Sharma',
    role: 'student',
    text: 'Sir, in step 3 when substituting v = y/x, why did we disregard the singular solution?',
    timestamp: '15:22'
  },
  {
    id: 'msg_4',
    sender: 'Prof. Arvind Nambiar',
    role: 'educator',
    text: '@Rohan good catch! Look at boundary condition at x=0; the domain requires x > 0.',
    timestamp: '15:24'
  },
  {
    id: 'msg_5',
    sender: 'Ananya Deshmukh',
    role: 'student',
    text: 'Understood sir! The whiteboard diagram is crystal clear.',
    timestamp: '15:25'
  }
];

export const STUDY_RESOURCES: StudyResource[] = [
  {
    id: 'res_1',
    title: 'JEE Advanced Master Formula Compendium & Mechanics Handbook',
    type: 'ebook',
    subject: 'Physics',
    grade: 'Grade 12',
    totalPages: 148,
    fileSize: '18.4 MB (Encrypted)',
    lastUpdated: 'Updated 2 days ago',
    previewPages: [
      'Kinematics & Projectile Equations in Vector Form with Drag Coefficients.',
      'Conservation of Angular Momentum with Tensor Notation examples.',
      'Thermodynamics: Carnot Cycle, Entropy calculations, and Van der Waals corrections.',
      'Wave Optics: Young double slit intensity distribution & diffraction grating formulas.'
    ]
  },
  {
    id: 'res_2',
    title: 'Organic Chemistry Reactions Summary & Synthesis Roadmap',
    type: 'lecture_notes',
    subject: 'Chemistry',
    grade: 'Grade 12',
    totalPages: 84,
    fileSize: '9.2 MB (Encrypted)',
    lastUpdated: 'Updated yesterday',
    previewPages: [
      'Aliphatic Conversions: Grignard reagent synthesis pathways and reaction mechanisms.',
      'Aromatic Substitution: Directing groups, Friedel-Crafts alkylation and acylation.',
      'Named Reactions: Aldol Condensation, Cannizzaro, Reimer-Tiemann, and Gabriel Phthalimide.',
      'Spectroscopy Basics: NMR chemical shift table and IR functional group peaks.'
    ]
  },
  {
    id: 'res_3',
    title: 'Previous 10 Years All India Benchmark Papers with Solved Keys',
    type: 'pyq',
    subject: 'Mathematics',
    grade: 'Grade 11 & 12',
    totalPages: 210,
    fileSize: '24.1 MB (Encrypted)',
    lastUpdated: 'Updated last week',
    previewPages: [
      'Paper 2025: Full detailed step-by-step calculus solutions with alternative geometric methods.',
      'Paper 2024: Probability, Matrices & Determinants with high-yield shortcut strategies.',
      'Paper 2023: Complex Numbers and Coordinate Geometry analytical proofs.',
      'Paper 2022: Definite Integrals as limits of sum and differential equations.'
    ]
  },
  {
    id: 'res_4',
    title: 'Academic Year 2026-27 Comprehensive Syllabus & Modular Milestones',
    type: 'syllabus',
    subject: 'Academic Operations',
    grade: 'All Grades',
    totalPages: 42,
    fileSize: '4.8 MB (Encrypted)',
    lastUpdated: 'Current Academic Term',
    previewPages: [
      'Term 1 (April - August): Foundation mechanics, Algebra, Chemical Bonding.',
      'Term 2 (September - December): Electromagnetism, Organic Synthesis, Calculus.',
      'Term 3 (January - March): Modern Physics, Coordinate Geometry, Intensive Mock Drills.',
      'Internal Assessment Rubrics: Lab practicals, Viva-voce, Weekly Unit Tests.'
    ]
  }
];

export const MOCK_EXAM_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'A particle moves along a straight line such that its displacement x at time t is given by x = 2t³ - 9t² + 12t + 4. At what time(s) is the velocity of the particle zero?',
    options: ['t = 1 s and t = 2 s', 't = 0.5 s and t = 3 s', 't = 2 s and t = 4 s', 'Velocity is never zero'],
    correctAnswer: 0,
    explanation: 'Velocity v = dx/dt = 6t² - 18t + 12. Setting v = 0 => 6(t² - 3t + 2) = 0 => 6(t - 1)(t - 2) = 0 => t = 1 s and t = 2 s.',
    subject: 'Physics',
    topic: 'Kinematics',
    marks: 4
  },
  {
    id: 2,
    question: 'Which of the following molecules has a square planar geometry according to VSEPR theory?',
    options: ['SF4', 'XeF4', 'CH4', 'PCl5'],
    correctAnswer: 1,
    explanation: 'XeF4 has Xenon with 8 valence electrons + 4 bonding pairs = 12 electrons (6 electron pairs). 4 bonding pairs + 2 lone pairs gives an octahedral electron geometry with a square planar molecular shape.',
    subject: 'Chemistry',
    topic: 'Chemical Bonding',
    marks: 4
  },
  {
    id: 3,
    question: 'Evaluate the definite integral: ∫ from 0 to π/2 of (sin³ x) / (sin³ x + cos³ x) dx.',
    options: ['π', 'π/2', 'π/4', '1'],
    correctAnswer: 2,
    explanation: 'Using the King property ∫ f(x) dx = ∫ f(a+b - x) dx, let I = ∫ from 0 to π/2 sin³ x / (sin³ x + cos³ x). Then I = ∫ from 0 to π/2 cos³ x / (cos³ x + sin³ x). Adding both gives 2I = ∫ from 0 to π/2 1 dx = π/2 => I = π/4.',
    subject: 'Mathematics',
    topic: 'Definite Integrals',
    marks: 4
  },
  {
    id: 4,
    question: 'During cellular respiration, in which cellular compartment does the Krebs (Citric Acid) cycle take place in eukaryotic cells?',
    options: ['Cytosol', 'Mitochondrial matrix', 'Inner mitochondrial membrane', 'Golgi apparatus'],
    correctAnswer: 1,
    explanation: 'The citric acid cycle occurs within the mitochondrial matrix, where all necessary dehydrogenases and enzymes reside (except succinate dehydrogenase, which is bound to the inner membrane).',
    subject: 'Biology',
    topic: 'Cellular Respiration',
    marks: 4
  }
];

export const INITIAL_ADMISSIONS: AdmissionApplication[] = [
  {
    id: 'ADM-2026-081',
    applicantName: 'Vikramaditya Sengupta',
    parentName: 'Sanjay Sengupta',
    phone: '+91 98450 11234',
    email: 'sanjay.sen@example.com',
    gradeApplying: 'Grade 11 - Science (PCM)',
    previousSchool: 'Delhi Public School, R.K. Puram',
    status: 'Documents Verified',
    appliedDate: '2026-08-28',
    documents: [
      { name: 'Grade 10 Marksheet Transcript', type: 'PDF', verified: true },
      { name: 'Transfer & Migration Certificate', type: 'PDF', verified: true },
      { name: 'Aadhaar / National ID Proof', type: 'JPG', verified: true },
      { name: 'Character & Conduct Certificate', type: 'PDF', verified: false }
    ]
  },
  {
    id: 'ADM-2026-082',
    applicantName: 'Pooja Venkatesh',
    parentName: 'Venkatesh Raman',
    phone: '+91 98112 45890',
    email: 'venkat.raman@example.com',
    gradeApplying: 'Grade 12 - Medical Track (PCB)',
    previousSchool: 'National Public School, Indiranagar',
    status: 'Pending Review',
    appliedDate: '2026-09-01',
    documents: [
      { name: 'Grade 11 Term Transcript', type: 'PDF', verified: true },
      { name: 'Passport Copy & ID Proof', type: 'PDF', verified: false },
      { name: 'Medical Fitness Certificate', type: 'PDF', verified: false }
    ]
  },
  {
    id: 'ADM-2026-083',
    applicantName: 'Aditya Rajvardhan',
    parentName: 'Meenakshi Rajvardhan',
    phone: '+91 99201 88741',
    email: 'meenakshi.r@example.com',
    gradeApplying: 'Grade 9 - Foundation STEM',
    previousSchool: 'Bombay Scottish School',
    status: 'Admitted',
    appliedDate: '2026-08-15',
    documents: [
      { name: 'Grade 8 Report Card', type: 'PDF', verified: true },
      { name: 'Birth Certificate', type: 'PDF', verified: true },
      { name: 'Immunization Record', type: 'PDF', verified: true }
    ]
  }
];

export const INITIAL_FEES: FeeRecord[] = [
  {
    id: 'FEE-INV-9901',
    studentName: 'Aarav Patel',
    rollNumber: 'AP-12-042',
    grade: 'Grade 12 (JEE Super 30)',
    totalFee: 120000,
    paidAmount: 120000,
    pendingAmount: 0,
    dueDate: '2026-08-15',
    status: 'Paid',
    lastPaymentDate: '2026-08-10'
  },
  {
    id: 'FEE-INV-9902',
    studentName: 'Kavya Subramanian',
    rollNumber: 'AP-12-088',
    grade: 'Grade 12 (NEET Star)',
    totalFee: 120000,
    paidAmount: 80000,
    pendingAmount: 40000,
    dueDate: '2026-09-15',
    status: 'Partial',
    lastPaymentDate: '2026-07-20'
  },
  {
    id: 'FEE-INV-9903',
    studentName: 'Devansh Joshi',
    rollNumber: 'AP-11-019',
    grade: 'Grade 11 (Olympiad)',
    totalFee: 95000,
    paidAmount: 25000,
    pendingAmount: 70000,
    dueDate: '2026-08-30',
    status: 'Overdue',
    lastPaymentDate: '2026-06-15'
  },
  {
    id: 'FEE-INV-9904',
    studentName: 'Tanvi Mehra',
    rollNumber: 'AP-10-007',
    grade: 'Grade 10 (Foundation)',
    totalFee: 75000,
    paidAmount: 75000,
    pendingAmount: 0,
    dueDate: '2026-09-01',
    status: 'Paid',
    lastPaymentDate: '2026-08-25'
  }
];

export const INITIAL_ATTENDANCE: AttendanceEntry[] = [
  { id: 'att_1', name: 'Aarav Patel', rollNo: 'AP-12-042', role: 'student', grade: 'Grade 12-A', status: 'present', checkInTime: '07:54 AM', monthlyPercent: 96.2 },
  { id: 'att_2', name: 'Kavya Subramanian', rollNo: 'AP-12-088', role: 'student', grade: 'Grade 12-A', status: 'present', checkInTime: '08:02 AM', monthlyPercent: 92.5 },
  { id: 'att_3', name: 'Devansh Joshi', rollNo: 'AP-11-019', role: 'student', grade: 'Grade 11-B', status: 'late', checkInTime: '08:25 AM', monthlyPercent: 74.0 },
  { id: 'att_4', name: 'Tanvi Mehra', rollNo: 'AP-10-007', role: 'student', grade: 'Grade 10-A', status: 'present', checkInTime: '07:48 AM', monthlyPercent: 98.0 },
  { id: 'att_5', name: 'Zainab Qureshi', rollNo: 'AP-12-105', role: 'student', grade: 'Grade 12-A', status: 'absent', monthlyPercent: 81.4 },
  { id: 'att_6', name: 'Prof. Arvind Nambiar', rollNo: 'FAC-MATH-01', role: 'staff', status: 'present', checkInTime: '07:30 AM', monthlyPercent: 100 },
  { id: 'att_7', name: 'Dr. Sarah Jenkins', rollNo: 'FAC-CHEM-03', role: 'staff', status: 'present', checkInTime: '07:42 AM', monthlyPercent: 96.0 },
  { id: 'att_8', name: 'Dr. Rajesh Khurana', rollNo: 'FAC-PHY-02', role: 'staff', status: 'present', checkInTime: '07:35 AM', monthlyPercent: 98.5 }
];

export const INITIAL_BOOKS: LibraryBook[] = [
  {
    id: 'BK-101',
    isbn: '978-0131495081',
    title: 'Concepts of Physics (Vol 1 & 2)',
    author: 'Dr. H.C. Verma',
    category: 'Physics',
    availableCopies: 14,
    totalCopies: 20,
    issuedTo: [
      { studentName: 'Aarav Patel', issueDate: '2026-08-20', dueDate: '2026-09-10' },
      { studentName: 'Devansh Joshi', issueDate: '2026-08-15', dueDate: '2026-09-05' }
    ]
  },
  {
    id: 'BK-102',
    isbn: '978-0198007586',
    title: 'Problems in General Physics',
    author: 'I.E. Irodov',
    category: 'Physics (Advanced)',
    availableCopies: 8,
    totalCopies: 12
  },
  {
    id: 'BK-103',
    isbn: '978-8120349880',
    title: 'Higher Engineering Mathematics',
    author: 'Dr. B.S. Grewal',
    category: 'Mathematics',
    availableCopies: 6,
    totalCopies: 15
  },
  {
    id: 'BK-104',
    isbn: '978-0070669239',
    title: 'Organic Chemistry Structure & Mechanism',
    author: 'Morrison & Boyd',
    category: 'Chemistry',
    availableCopies: 11,
    totalCopies: 18
  }
];

export const BUS_ROUTES: BusTransportRoute[] = [
  {
    id: 'BUS-07',
    busNumber: 'KA-04-MB-4812',
    driverName: 'Rameshwar Yadav',
    driverPhone: '+91 94480 32190',
    routeCode: 'Route 7 (North Corridor - Hebbal to Campus)',
    currentStop: 'Manyata Tech Park Crossing',
    nextStop: 'Sahakara Nagar Junction',
    speedKmH: 38,
    studentsOnBoard: 28,
    capacity: 35,
    etaNextStop: '6 mins (08:14 AM)',
    stops: [
      { stopName: 'Yelahanka Satellite Town', scheduledTime: '07:35 AM', status: 'passed' },
      { stopName: 'Hebbal Flyover Depot', scheduledTime: '07:50 AM', status: 'passed' },
      { stopName: 'Manyata Tech Park Crossing', scheduledTime: '08:05 AM', status: 'current' },
      { stopName: 'Sahakara Nagar Junction', scheduledTime: '08:14 AM', status: 'upcoming' },
      { stopName: 'Academy Campus Main Gate', scheduledTime: '08:30 AM', status: 'upcoming' }
    ]
  },
  {
    id: 'BUS-12',
    busNumber: 'KA-01-EA-9924',
    driverName: 'Gurpreet Singh',
    driverPhone: '+91 98200 44911',
    routeCode: 'Route 12 (South Hub - Koramangala to Campus)',
    currentStop: 'HSR Layout 5th Main',
    nextStop: 'Silk Board Transit Hub',
    speedKmH: 26,
    studentsOnBoard: 31,
    capacity: 35,
    etaNextStop: '9 mins (08:21 AM)',
    stops: [
      { stopName: 'Koramangala BDA Complex', scheduledTime: '07:40 AM', status: 'passed' },
      { stopName: 'HSR Layout 5th Main', scheduledTime: '08:08 AM', status: 'current' },
      { stopName: 'Silk Board Transit Hub', scheduledTime: '08:21 AM', status: 'upcoming' },
      { stopName: 'Electronic City Express Depot', scheduledTime: '08:35 AM', status: 'upcoming' },
      { stopName: 'Academy Campus Main Gate', scheduledTime: '08:45 AM', status: 'upcoming' }
    ]
  }
];

export const CRM_LEADS: CrmLead[] = [
  {
    id: 'LEAD-501',
    parentName: 'Sunita & Deepak Verma',
    studentName: 'Harshita Verma',
    phone: '+91 97110 54321',
    targetGrade: 'Grade 11 - IIT-JEE 2-Year Program',
    source: 'Google Search',
    stage: 'New',
    notes: 'Inquired about batch sizes and scholarship test dates.',
    lastUpdated: 'Today at 09:30 AM',
    counselor: 'Priya Sharma'
  },
  {
    id: 'LEAD-502',
    parentName: 'Col. Rajesh Bakshi',
    studentName: 'Kunal Bakshi',
    phone: '+91 98234 11299',
    targetGrade: 'Grade 12 - NEET Repeater Dropper Batch',
    source: 'Meta Ad',
    stage: 'Contacted',
    notes: 'Father requested hostel accommodation details and previous year score card analysis.',
    lastUpdated: 'Yesterday at 04:15 PM',
    counselor: 'Amitabh Sen'
  },
  {
    id: 'LEAD-503',
    parentName: 'Nalini Chawla',
    studentName: 'Samir Chawla',
    phone: '+91 98990 77412',
    targetGrade: 'Grade 9 - STEM Olympiad Track',
    source: 'Walk-In',
    stage: 'Campus Visit',
    notes: 'Visited chemistry & robotics lab. Impressed by faculty credentials.',
    lastUpdated: '2 days ago',
    counselor: 'Priya Sharma'
  },
  {
    id: 'LEAD-504',
    parentName: 'Dr. Vivek Swaminathan',
    studentName: 'Meera Swaminathan',
    phone: '+91 94451 22890',
    targetGrade: 'Grade 11 - Medical Premier Track',
    source: 'Parent Referral',
    stage: 'Trial Attended',
    notes: 'Attended Dr. Sarah Jenkins demo lecture on Biomolecules. Scored 92% in entrance screening.',
    lastUpdated: '3 days ago',
    counselor: 'Amitabh Sen'
  },
  {
    id: 'LEAD-505',
    parentName: 'Anil & Sangeeta Aggarwal',
    studentName: 'Rohan Aggarwal',
    phone: '+91 98104 33678',
    targetGrade: 'Grade 12 - JEE Advanced Crash Course',
    source: 'Google Search',
    stage: 'Enrolled',
    notes: 'Paid first installment fee online (Receipt: FEE-INV-9901). Issued student ID card.',
    lastUpdated: 'Aug 26, 2026',
    counselor: 'Priya Sharma'
  }
];

export const SAMPLE_AI_EXAM_PAPER: GeneratedExamPaper = {
  title: 'Apex All-India Benchmark Assessment Series - Physics Unit 4',
  grade: 'Grade 12 (JEE Advanced & Olympiad Standard)',
  subject: 'Physics: Electromagnetic Induction & Alternating Current',
  timeAllowed: '60 Minutes',
  maximumMarks: 50,
  instructions: [
    'Section A contains 5 Single Correct MCQs (+4 for correct, -1 for incorrect).',
    'Section B contains 3 Short Numerical & Analytical questions (4 marks each, no negative marking).',
    'Section C contains 2 Comprehensive Long Problem solving questions (8 marks each).',
    'Use of log tables or calculators is strictly prohibited.',
    'DRM Watermark is stamped with candidate credentials. Any distribution will void test eligibility.'
  ],
  sections: [
    {
      title: 'Section A: Multiple Choice Questions (Single Option Correct)',
      type: 'MCQ',
      marksPerQuestion: 4,
      questions: [
        {
          qNum: 1,
          text: 'A conducting circular loop of radius r and resistance R is placed in a uniform magnetic field B perpendicular to the plane of the loop. If the magnetic field varies as B(t) = B₀(1 - αt²), what is the magnitude of induced current at time t?',
          options: [
            '(2π r² B₀ α t) / R',
            '(π r² B₀ α t²) / R',
            '(4π r² B₀ α t) / R',
            'Zero due to Lenz law symmetry'
          ],
          answerKey: 'Option A: (2π r² B₀ α t) / R. Flux Φ = B(t) · A = B₀(1 - αt²) π r². Induced EMF = |dΦ/dt| = 2π r² B₀ α t. Current I = EMF / R.',
          rubricPoints: ['Identification of magnetic flux formula', 'Differentiation with respect to time', 'Application of Ohm law in closed loop']
        },
        {
          qNum: 2,
          text: 'In an LCR series circuit connected to an AC source V = V₀ sin(ωt), at resonance the power factor of the circuit is:',
          options: ['0', '0.5', '1.0 (Unity)', 'Infinite'],
          answerKey: 'Option C: 1.0 (Unity). At resonance, inductive reactance XL equals capacitive reactance XC, so impedance Z = R. Phase angle φ = 0 => cos(φ) = 1.',
          rubricPoints: ['Condition for resonance XL = XC', 'Net impedance simplification', 'Power factor definition']
        }
      ]
    },
    {
      title: 'Section B: Short Analytical & Numerical Questions',
      type: 'Short Answer',
      marksPerQuestion: 4,
      questions: [
        {
          qNum: 3,
          text: 'A solenoid of length 0.5 m, cross-sectional area 20 cm², and 500 turns has an iron core of relative permeability μr = 800. Calculate its self-inductance L in Henries (Take μ₀ = 4π × 10⁻⁷ T·m/A).',
          answerKey: 'Formula L = (μr μ₀ N² A) / l. Substituting values gives L ≈ 1.61 H.',
          rubricPoints: ['Formula declaration: 1 mark', 'Unit conversions (cm² to m²): 1 mark', 'Accurate substitution & final result: 2 marks']
        }
      ]
    }
  ]
};

export const SAMPLE_LESSON_PLAN: LessonPlanUnit = {
  week: 14,
  unitTitle: 'Chemical Kinetics, Rate Laws & Collision Theory',
  grade: 'Grade 12 Advanced Chemistry',
  subject: 'Chemistry',
  totalHours: 5,
  bloomLevel: 'Analysis & Application (Level 4)',
  learningOutcomes: [
    'Derive integrated rate expressions for zero and first-order reactions.',
    'Differentiate between molecularity and order of complex multi-step reactions.',
    'Apply the Arrhenius equation to calculate activation energy from temperature-rate data.',
    'Interpret Maxwell-Boltzmann energy distribution curves in presence of positive catalysts.'
  ],
  dailyBreakdown: [
    {
      day: 'Monday (Day 1)',
      topic: 'Instantaneous vs Average Rate & Rate Law Formulation',
      pedagogy: 'Inquiry-based problem solving with real experimental decomposition data of N2O5.',
      activity: 'Live interactive graphing poll: Students plot 1/[A] vs time to identify reaction order.',
      homework: 'Solve textbook practice set 4.1 Q1-Q8 in digital workbook.'
    },
    {
      day: 'Tuesday (Day 2)',
      topic: 'First Order Kinetics & Half-Life Concept Derivations',
      pedagogy: 'Flipped classroom discussion linking radioactive decay to chemical half-life.',
      activity: 'Small group breakout: Calculate time for 99.9% completion of first-order hydrolysis.',
      homework: 'Review simulation on enzyme catalysis on SabioMind Resource Portal.'
    },
    {
      day: 'Wednesday (Day 3)',
      topic: 'Collision Theory, Steric Factor & Transition State Model',
      pedagogy: '3D Molecular visualization of effective vs ineffective molecular collisions.',
      activity: 'Interactive VR model demonstration of activated complex formation.',
      homework: 'Annotate energy profile diagram with ΔH and activation energies.'
    },
    {
      day: 'Thursday (Day 4)',
      topic: 'Arrhenius Equation: Graphical and Two-Temperature Analysis',
      pedagogy: 'Step-by-step mathematical derivation of ln(k2/k1) = (Ea/R)(1/T1 - 1/T2).',
      activity: 'Pair-share worksheet solving JEE Advanced 2024 problem on catalyst activation lowering.',
      homework: 'Complete timed 15-minute diagnostic quiz on SabioMind Test Portal.'
    },
    {
      day: 'Friday (Day 5)',
      topic: 'Weekly Formative Review & Doubt Clearance Clinic',
      pedagogy: 'Diagnostic mistake analysis and live whiteboarding.',
      activity: 'Speed test tournament with instant leaderboard ranking.',
      homework: 'Weekend comprehensive assignment submission before Sunday 8 PM.'
    }
  ]
};
