import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  TenantConfig,
  AuthUser,
  UserRole,
  AdmissionApplication,
  FeeRecord,
  AttendanceEntry,
  LibraryBook,
  CrmLead,
  LiveClass,
  ChatMessage
} from '../types';
import {
  TENANTS,
  INITIAL_ADMISSIONS,
  INITIAL_FEES,
  INITIAL_ATTENDANCE,
  INITIAL_BOOKS,
  CRM_LEADS,
  INITIAL_LIVE_CLASSES,
  INITIAL_CHAT_MESSAGES
} from '../data/mockData';

export type NavigationTab =
  | 'overview'
  | 'live_classes'
  | 'resources'
  | 'assessments'
  | 'admissions'
  | 'id_report_cards'
  | 'fees'
  | 'attendance'
  | 'library_transport'
  | 'crm_pipeline'
  | 'ai_paper_gen'
  | 'ai_evaluator'
  | 'ai_lesson_planner'
  | 'ai_marketing_banner'
  | 'whitelabel_settings';

interface AppContextType {
  tenant: TenantConfig;
  setTenant: (tenant: TenantConfig) => void;
  updateTenantSettings: (updated: Partial<TenantConfig>) => void;
  user: AuthUser;
  setUser: (user: AuthUser) => void;
  switchRole: (newRole: UserRole) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  loginWithOtp: (phone: string, channel: 'sms' | 'whatsapp', role: UserRole, name?: string) => boolean;
  logout: () => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  drmActive: boolean;
  setDrmActive: (active: boolean) => void;
  securityNotice: string | null;
  triggerSecurityBreachNotice: (reason: string) => void;
  clearSecurityNotice: () => void;
  
  // Data states
  admissions: AdmissionApplication[];
  addAdmission: (admission: Omit<AdmissionApplication, 'id' | 'appliedDate' | 'status'>) => void;
  updateAdmissionStatus: (id: string, status: AdmissionApplication['status']) => void;

  fees: FeeRecord[];
  recordFeePayment: (id: string, amount: number) => void;
  sendFeeReminder: (id: string) => string;

  attendance: AttendanceEntry[];
  toggleAttendanceStatus: (id: string) => void;
  bulkMarkAllPresent: () => void;

  books: LibraryBook[];
  issueBook: (bookId: string, studentName: string) => void;

  leads: CrmLead[];
  updateLeadStage: (id: string, stage: CrmLead['stage']) => void;
  addLead: (lead: Omit<CrmLead, 'id' | 'lastUpdated'>) => void;

  liveClasses: LiveClass[];
  chatMessages: ChatMessage[];
  sendChatMessage: (text: string) => void;
}

const DEFAULT_USER: AuthUser = {
  phoneNumber: '+91 98765 43210',
  channel: 'whatsapp',
  role: 'super_admin',
  name: 'Dr. Alistair Sterling',
  studentId: 'ADM-EXEC-001',
  tenantId: 'apex_iit',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tenant, setTenant] = useState<TenantConfig>(TENANTS[0]);
  const [user, setUser] = useState<AuthUser>(DEFAULT_USER);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');
  const [drmActive, setDrmActive] = useState<boolean>(true);
  const [securityNotice, setSecurityNotice] = useState<string | null>(null);

  // App domain states
  const [admissions, setAdmissions] = useState<AdmissionApplication[]>(INITIAL_ADMISSIONS);
  const [fees, setFees] = useState<FeeRecord[]>(INITIAL_FEES);
  const [attendance, setAttendance] = useState<AttendanceEntry[]>(INITIAL_ATTENDANCE);
  const [books, setBooks] = useState<LibraryBook[]>(INITIAL_BOOKS);
  const [leads, setLeads] = useState<CrmLead[]>(CRM_LEADS);
  const [liveClasses] = useState<LiveClass[]>(INITIAL_LIVE_CLASSES);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);

  // Sync theme with HTML document class
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const updateTenantSettings = (updated: Partial<TenantConfig>) => {
    setTenant(prev => ({ ...prev, ...updated }));
  };

  const switchRole = (newRole: UserRole) => {
    let newName = 'Dr. Alistair Sterling (Super Admin)';
    let studentId = 'ADM-EXEC-001';
    let grade = undefined;

    if (newRole === 'educator') {
      newName = 'Prof. Arvind Nambiar (Senior Faculty)';
      studentId = 'FAC-MATH-01';
    } else if (newRole === 'student') {
      newName = 'Aarav Patel (Student)';
      studentId = 'AP-12-042';
      grade = 'Grade 12 - Advanced JEE Batch';
    }

    setUser(prev => ({
      ...prev,
      role: newRole,
      name: newName,
      studentId,
      grade
    }));
  };

  const loginWithOtp = (phone: string, channel: 'sms' | 'whatsapp', role: UserRole, name?: string): boolean => {
    const roleName = name || (
      role === 'super_admin' ? 'Institute Director' :
      role === 'educator' ? 'Senior Educator' : 'Aarav Patel'
    );
    setUser({
      phoneNumber: phone,
      channel,
      role,
      name: roleName,
      studentId: role === 'student' ? 'AP-12-042' : role === 'educator' ? 'FAC-EDU-09' : 'EXEC-DIR-01',
      tenantId: tenant.id,
      grade: role === 'student' ? 'Grade 12 (JEE Super 30)' : undefined
    });
    setIsAuthModalOpen(false);
    return true;
  };

  const logout = () => {
    setIsAuthModalOpen(true);
  };

  const triggerSecurityBreachNotice = (reason: string) => {
    setSecurityNotice(reason);
    setTimeout(() => {
      setSecurityNotice(null);
    }, 4500);
  };

  const clearSecurityNotice = () => setSecurityNotice(null);

  const addAdmission = (data: Omit<AdmissionApplication, 'id' | 'appliedDate' | 'status'>) => {
    const newId = `ADM-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newEntry: AdmissionApplication = {
      ...data,
      id: newId,
      status: 'Pending Review',
      appliedDate: new Date().toISOString().split('T')[0]
    };
    setAdmissions(prev => [newEntry, ...prev]);
  };

  const updateAdmissionStatus = (id: string, status: AdmissionApplication['status']) => {
    setAdmissions(prev =>
      prev.map(item => (item.id === id ? { ...item, status } : item))
    );
  };

  const recordFeePayment = (id: string, amount: number) => {
    setFees(prev =>
      prev.map(item => {
        if (item.id === id) {
          const newPaid = item.paidAmount + amount;
          const newPending = Math.max(0, item.totalFee - newPaid);
          const newStatus = newPending === 0 ? 'Paid' : 'Partial';
          return {
            ...item,
            paidAmount: newPaid,
            pendingAmount: newPending,
            status: newStatus,
            lastPaymentDate: new Date().toISOString().split('T')[0]
          };
        }
        return item;
      })
    );
  };

  const sendFeeReminder = (id: string): string => {
    const record = fees.find(f => f.id === id);
    if (!record) return 'Record not found';
    return `WhatsApp reminder dispatched for ${record.studentName} regarding outstanding due of $${record.pendingAmount.toLocaleString()}.`;
  };

  const toggleAttendanceStatus = (id: string) => {
    setAttendance(prev =>
      prev.map(item => {
        if (item.id === id) {
          const cycle: AttendanceEntry['status'][] = ['present', 'absent', 'late', 'excused'];
          const currentIndex = cycle.indexOf(item.status);
          const nextStatus = cycle[(currentIndex + 1) % cycle.length];
          return { ...item, status: nextStatus };
        }
        return item;
      })
    );
  };

  const bulkMarkAllPresent = () => {
    setAttendance(prev =>
      prev.map(item => ({ ...item, status: 'present', checkInTime: '08:00 AM' }))
    );
  };

  const issueBook = (bookId: string, studentName: string) => {
    setBooks(prev =>
      prev.map(book => {
        if (book.id === bookId && book.availableCopies > 0) {
          const newIssue = {
            studentName,
            issueDate: new Date().toISOString().split('T')[0],
            dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          };
          return {
            ...book,
            availableCopies: book.availableCopies - 1,
            issuedTo: [...(book.issuedTo || []), newIssue]
          };
        }
        return book;
      })
    );
  };

  const updateLeadStage = (id: string, stage: CrmLead['stage']) => {
    setLeads(prev =>
      prev.map(lead =>
        lead.id === id
          ? { ...lead, stage, lastUpdated: 'Just now' }
          : lead
      )
    );
  };

  const addLead = (leadData: Omit<CrmLead, 'id' | 'lastUpdated'>) => {
    const newLead: CrmLead = {
      ...leadData,
      id: `LEAD-${Math.floor(500 + Math.random() * 500)}`,
      lastUpdated: 'Just now'
    };
    setLeads(prev => [newLead, ...prev]);
  };

  const sendChatMessage = (text: string) => {
    if (!text.trim()) return;
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: user.name,
      role: user.role,
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setChatMessages(prev => [...prev, newMsg]);
  };

  return (
    <AppContext.Provider
      value={{
        tenant,
        setTenant,
        updateTenantSettings,
        user,
        setUser,
        switchRole,
        isAuthModalOpen,
        setIsAuthModalOpen,
        loginWithOtp,
        logout,
        theme,
        toggleTheme,
        activeTab,
        setActiveTab,
        drmActive,
        setDrmActive,
        securityNotice,
        triggerSecurityBreachNotice,
        clearSecurityNotice,
        admissions,
        addAdmission,
        updateAdmissionStatus,
        fees,
        recordFeePayment,
        sendFeeReminder,
        attendance,
        toggleAttendanceStatus,
        bulkMarkAllPresent,
        books,
        issueBook,
        leads,
        updateLeadStage,
        addLead,
        liveClasses,
        chatMessages,
        sendChatMessage
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
