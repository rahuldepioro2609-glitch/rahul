export type UserRole = 'super_admin' | 'educator' | 'student';

export interface TenantConfig {
  id: string;
  name: string;
  tagline: string;
  code: string;
  logoIcon: string;
  primaryColor: string; // Hex or tailwind class
  accentColor: string;
  customDomain: string;
  supportPhone: string;
  watermarkText: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  gstin?: string;
  affiliationNumber?: string;
  board?: string;
  currencySymbol?: string;
}

export interface AuthUser {
  phoneNumber: string;
  channel: 'sms' | 'whatsapp';
  role: UserRole;
  name: string;
  studentId?: string;
  tenantId: string;
  avatarUrl?: string;
  grade?: string;
}

export interface LiveClass {
  id: string;
  title: string;
  subject: string;
  teacher: string;
  time: string;
  isLive: boolean;
  viewersCount: number;
  videoUrl: string;
  topic: string;
  grade: string;
  duration: string;
}

export interface ChatMessage {
  id: string;
  sender: string;
  role: UserRole;
  text: string;
  timestamp: string;
  isPinned?: boolean;
}

export interface StudyResource {
  id: string;
  title: string;
  type: 'ebook' | 'lecture_notes' | 'pyq' | 'syllabus';
  subject: string;
  grade: string;
  totalPages: number;
  fileSize: string;
  lastUpdated: string;
  previewPages: string[];
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  subject: string;
  topic: string;
  marks: number;
}

export interface ExamRecord {
  id: string;
  title: string;
  subject: string;
  durationMinutes: number;
  totalMarks: number;
  questions: QuizQuestion[];
}

export interface AdmissionApplication {
  id: string;
  applicantName: string;
  parentName: string;
  phone: string;
  email: string;
  gradeApplying: string;
  previousSchool: string;
  status: 'Pending Review' | 'Documents Verified' | 'Admitted' | 'Rejected';
  appliedDate: string;
  documents: {
    name: string;
    type: string;
    verified: boolean;
  }[];
}

export interface FeeRecord {
  id: string;
  studentName: string;
  rollNumber: string;
  grade: string;
  totalFee: number;
  paidAmount: number;
  pendingAmount: number;
  dueDate: string;
  status: 'Paid' | 'Partial' | 'Overdue';
  lastPaymentDate?: string;
}

export interface AttendanceEntry {
  id: string;
  name: string;
  rollNo: string;
  role: 'student' | 'staff';
  grade?: string;
  status: 'present' | 'absent' | 'late' | 'excused';
  checkInTime?: string;
  monthlyPercent: number;
}

export interface LibraryBook {
  id: string;
  isbn: string;
  title: string;
  author: string;
  category: string;
  availableCopies: number;
  totalCopies: number;
  issuedTo?: {
    studentName: string;
    issueDate: string;
    dueDate: string;
  }[];
}

export interface BusTransportRoute {
  id: string;
  busNumber: string;
  driverName: string;
  driverPhone: string;
  routeCode: string;
  currentStop: string;
  nextStop: string;
  speedKmH: number;
  studentsOnBoard: number;
  capacity: number;
  etaNextStop: string;
  stops: {
    stopName: string;
    scheduledTime: string;
    status: 'passed' | 'current' | 'upcoming';
  }[];
}

export interface CrmLead {
  id: string;
  parentName: string;
  studentName: string;
  phone: string;
  targetGrade: string;
  source: 'Google Search' | 'Meta Ad' | 'Walk-In' | 'Parent Referral' | 'Newspaper';
  stage: 'New' | 'Contacted' | 'Campus Visit' | 'Trial Attended' | 'Enrolled' | 'Lost';
  notes: string;
  lastUpdated: string;
  counselor: string;
}

export interface GeneratedExamPaper {
  title: string;
  grade: string;
  subject: string;
  timeAllowed: string;
  maximumMarks: number;
  instructions: string[];
  sections: {
    title: string;
    type: 'MCQ' | 'Short Answer' | 'Long Answer';
    marksPerQuestion: number;
    questions: {
      qNum: number;
      text: string;
      options?: string[];
      answerKey: string;
      rubricPoints?: string[];
    }[];
  }[];
}

export interface LessonPlanUnit {
  week: number;
  unitTitle: string;
  grade: string;
  subject: string;
  totalHours: number;
  bloomLevel: string;
  learningOutcomes: string[];
  dailyBreakdown: {
    day: string;
    topic: string;
    pedagogy: string;
    activity: string;
    homework: string;
  }[];
}
