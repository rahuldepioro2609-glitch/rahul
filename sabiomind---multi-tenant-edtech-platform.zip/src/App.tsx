import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { DRMProtection } from './components/common/DRMProtection';
import { AuthModal } from './components/common/AuthModal';
import { DashboardOverview } from './components/common/DashboardOverview';

// Academic Views
import { LiveClassesView } from './components/academic/LiveClassesView';
import { ResourceRepositoryView } from './components/academic/ResourceRepositoryView';
import { AssessmentPortalView } from './components/academic/AssessmentPortalView';

// Operations Views
import { AdmissionPortalView } from './components/operations/AdmissionPortalView';
import { IdAndReportCardGeneratorView } from './components/operations/IdAndReportCardGeneratorView';
import { FeeManagementView } from './components/operations/FeeManagementView';
import { AttendanceTrackerView } from './components/operations/AttendanceTrackerView';
import { LibraryAndTransportView } from './components/operations/LibraryAndTransportView';
import { CrmPipelineView } from './components/operations/CrmPipelineView';
import { WhiteLabelSettingsView } from './components/operations/WhiteLabelSettingsView';

// AI Suite Views
import { AiPaperGeneratorView } from './components/ai/AiPaperGeneratorView';
import { AiAnswerEvaluatorView } from './components/ai/AiAnswerEvaluatorView';
import { AiLessonPlannerView } from './components/ai/AiLessonPlannerView';
import { AiMarketingBannerCreatorView } from './components/ai/AiMarketingBannerCreatorView';

const MainLayout: React.FC = () => {
  const { activeTab, tenant, setActiveTab } = useApp();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const renderActiveView = () => {
    switch (activeTab) {
      // Main Hub
      case 'overview':
        return <DashboardOverview />;

      // Academic & Content
      case 'live_classes':
      case 'live-classes' as any:
        return <LiveClassesView />;
      case 'resources':
        return <ResourceRepositoryView />;
      case 'assessments':
        return <AssessmentPortalView />;

      // Operations & Logistics
      case 'fees':
        return <FeeManagementView />;
      case 'attendance':
        return <AttendanceTrackerView />;
      case 'admissions':
        return <AdmissionPortalView />;
      case 'id_report_cards':
      case 'id-report-cards' as any:
        return <IdAndReportCardGeneratorView />;
      case 'library_transport':
      case 'library-transport' as any:
        return <LibraryAndTransportView />;
      case 'crm_pipeline':
      case 'crm-pipeline' as any:
        return <CrmPipelineView />;

      // AI Productivity & Automation
      case 'ai_paper_gen':
      case 'ai-paper-gen' as any:
        return <AiPaperGeneratorView />;
      case 'ai_evaluator':
      case 'ai-evaluator' as any:
        return <AiAnswerEvaluatorView />;
      case 'ai_lesson_planner':
      case 'ai-lesson-plan' as any:
        return <AiLessonPlannerView />;
      case 'ai_marketing_banner':
      case 'ai-marketing' as any:
        return <AiMarketingBannerCreatorView />;

      // White-label settings
      case 'whitelabel_settings':
        return <WhiteLabelSettingsView />;

      default:
        return <DashboardOverview />;
    }
  };

  return (
    <div className="h-screen w-full font-sans bg-gradient-to-br from-slate-50 via-sky-50/30 to-blue-50/20 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 text-slate-900 dark:text-slate-100 flex overflow-hidden transition-colors relative">
      {/* Subtle ambient light blue decorative glow */}
      <div className="pointer-events-none absolute -top-32 right-1/4 w-96 h-96 bg-sky-200/25 dark:bg-sky-500/5 rounded-full blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 left-1/3 w-80 h-80 bg-blue-200/20 dark:bg-blue-500/5 rounded-full blur-3xl" />

      {/* DRM Anti-Piracy Watermark & Protection Layer */}
      <DRMProtection />

      {/* Global OTP Passwordless Authentication Modal */}
      <AuthModal />

      {/* Left Navigation Sidebar */}
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative z-10">
        {/* Top Application Header */}
        <Navbar onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />

        {/* Scrollable Viewport with Motion Tab Transitions */}
        <section className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.2, ease: 'easeOut' }}
              >
                {renderActiveView()}
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        {/* Professional Polish Standard Institutional Footer with White & Little Blue Theme */}
        <footer className="h-10 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xs border-t border-sky-100 dark:border-slate-800 px-4 sm:px-8 flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 shrink-0 font-medium shadow-2xs">
          <div className="truncate flex items-center gap-1.5">
            <span>&copy; 2026 SabioMind SaaS Platform &bull; Enterprise v2.8.4 &bull;</span>
            <span className="font-bold text-sky-900 dark:text-sky-200">{tenant.name}</span>
          </div>
          <div className="flex items-center gap-3 sm:gap-5 shrink-0">
            <span className="flex items-center gap-1.5 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>AP-South-1 (Mumbai)</span>
            </span>
            <button
              onClick={() => setActiveTab('overview')}
              className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors hidden sm:inline"
            >
              Security Logs
            </button>
            <button
              onClick={() => setActiveTab('whitelabel_settings')}
              className="hover:text-sky-600 dark:hover:text-sky-400 transition-colors font-semibold"
            >
              System Status
            </button>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

